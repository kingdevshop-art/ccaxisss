-- =========================================================================
-- WEST BENGAL STATE CORPORATE BANK (WBSCB)
-- MySQL 8.0 Database Schema & Initial CBS Migration Script
-- =========================================================================

CREATE DATABASE IF NOT EXISTS wbscb_banking CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE wbscb_banking;

-- 1. Users Table
CREATE TABLE IF NOT EXISTS users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  uid VARCHAR(255) NOT NULL UNIQUE,
  name VARCHAR(255) NOT NULL,
  phone VARCHAR(50) NOT NULL UNIQUE,
  email VARCHAR(255) NOT NULL,
  photo_url LONGTEXT,
  dob VARCHAR(50),
  address TEXT,
  ckyc_number VARCHAR(50),
  upi_id VARCHAR(255) NOT NULL,
  account_number VARCHAR(50) NOT NULL,
  ifsc_code VARCHAR(50) NOT NULL DEFAULT 'WBSC0000001',
  savings_balance DOUBLE NOT NULL DEFAULT 0,
  wallet_balance DOUBLE NOT NULL DEFAULT 0,
  upi_lite_balance DOUBLE NOT NULL DEFAULT 0,
  fixed_deposit_balance DOUBLE NOT NULL DEFAULT 0,
  digital_gold_grams DOUBLE NOT NULL DEFAULT 0,
  kyc_status VARCHAR(50) NOT NULL DEFAULT 'verified',
  aadhaar_number VARCHAR(50) NOT NULL DEFAULT '',
  pan_number VARCHAR(50) NOT NULL DEFAULT '',
  biometric_enabled BOOLEAN NOT NULL DEFAULT FALSE,
  biometric_limit INT NOT NULL DEFAULT 5000,
  soundbox_voice_alerts BOOLEAN NOT NULL DEFAULT TRUE,
  soundbox_language VARCHAR(10) NOT NULL DEFAULT 'en',
  senior_mode BOOLEAN NOT NULL DEFAULT FALSE,
  high_contrast BOOLEAN NOT NULL DEFAULT FALSE,
  branch_name VARCHAR(255) DEFAULT 'Kolkata Main Branch',
  cif_number VARCHAR(50) DEFAULT 'CIF8891002',
  account_type VARCHAR(50) DEFAULT 'SAVINGS',
  account_status VARCHAR(50) NOT NULL DEFAULT 'APPROVED',
  rejection_reason TEXT,
  profile_photo_updated_at VARCHAR(100),
  active_session_token VARCHAR(255),
  last_login_at VARCHAR(100),
  is_blocked BOOLEAN DEFAULT FALSE,
  block_reason TEXT,
  services JSON,
  mpin VARCHAR(50) DEFAULT '1234',
  live_latitude DOUBLE,
  live_longitude DOUBLE,
  live_accuracy DOUBLE,
  live_location_address TEXT,
  live_location_updated_at VARCHAR(100),
  is_online BOOLEAN DEFAULT FALSE,
  qr_code_data_url LONGTEXT,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_users_phone (phone),
  INDEX idx_users_account (account_number)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 2. Admin Accounts Table
CREATE TABLE IF NOT EXISTS admin_accounts (
  id VARCHAR(100) PRIMARY KEY,
  username VARCHAR(100) NOT NULL UNIQUE,
  full_name VARCHAR(255) NOT NULL,
  role VARCHAR(50) NOT NULL DEFAULT 'OFFICER',
  pin_or_password VARCHAR(255) NOT NULL,
  email VARCHAR(255),
  branch_name VARCHAR(255) DEFAULT 'Kolkata Main HO',
  is_active BOOLEAN NOT NULL DEFAULT TRUE,
  last_login_at VARCHAR(100),
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_admin_username (username)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 3. Transactions Table
CREATE TABLE IF NOT EXISTS transactions (
  id VARCHAR(100) PRIMARY KEY,
  user_id INT,
  title VARCHAR(255) NOT NULL,
  sub_title TEXT NOT NULL,
  amount DOUBLE NOT NULL,
  type VARCHAR(50) NOT NULL,
  category VARCHAR(50) NOT NULL,
  timestamp VARCHAR(100) NOT NULL,
  status VARCHAR(50) NOT NULL DEFAULT 'SUCCESS',
  payment_mode VARCHAR(50) NOT NULL DEFAULT 'UPI',
  upi_ref_id VARCHAR(100) NOT NULL,
  recipient_vpa VARCHAR(255),
  sender_vpa VARCHAR(255),
  bank_name VARCHAR(255),
  fraud_flag VARCHAR(50) DEFAULT 'CLEAN',
  beneficiary_name VARCHAR(255),
  beneficiary_account VARCHAR(100),
  recipient_ifsc VARCHAR(50),
  qr_data TEXT,
  scanner_address TEXT,
  transfer_type VARCHAR(50),
  approval_status VARCHAR(50),
  approval_reason TEXT,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL,
  INDEX idx_tx_user (user_id),
  INDEX idx_tx_status (status),
  INDEX idx_tx_ref (upi_ref_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 4. KYC Applications Table
CREATE TABLE IF NOT EXISTS kyc_applications (
  id VARCHAR(100) PRIMARY KEY,
  applicant_name VARCHAR(255) NOT NULL,
  phone VARCHAR(50) NOT NULL,
  aadhaar_number VARCHAR(50) NOT NULL,
  pan_number VARCHAR(50) NOT NULL,
  account_type VARCHAR(50) NOT NULL,
  status VARCHAR(50) NOT NULL,
  submitted_at VARCHAR(100) NOT NULL,
  document_type VARCHAR(50) NOT NULL,
  risk_score INT NOT NULL DEFAULT 10,
  initial_deposit DOUBLE NOT NULL DEFAULT 0,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_kyc_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 5. Push Alerts Table
CREATE TABLE IF NOT EXISTS push_alerts (
  id VARCHAR(100) PRIMARY KEY,
  user_id INT,
  title VARCHAR(255) NOT NULL,
  body TEXT NOT NULL,
  time VARCHAR(100) NOT NULL,
  `read` BOOLEAN DEFAULT FALSE,
  type VARCHAR(50) NOT NULL,
  amount DOUBLE,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  INDEX idx_alert_user (user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Seed Default Admin Officer
INSERT INTO admin_accounts (id, username, full_name, role, pin_or_password, email, branch_name, is_active)
VALUES ('adm_001', 'admin', 'Senior Branch Manager (Officer)', 'ADMIN', '9988', 'manager@wbscb.coop.in', 'Kolkata Main HO', TRUE)
ON DUPLICATE KEY UPDATE full_name = VALUES(full_name);
