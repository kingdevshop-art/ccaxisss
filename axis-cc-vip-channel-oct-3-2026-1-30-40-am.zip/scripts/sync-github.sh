#!/bin/bash
# WBSCB Corporate Banking — GitHub Sync Helper Script

set -e

REPO_URL="$1"

if [ -z "$REPO_URL" ]; then
    echo "=========================================================="
    echo "  WBSCB Banking — Sync to GitHub Repository"
    echo "=========================================================="
    echo ""
    echo "Usage:"
    echo "  ./scripts/sync-github.sh <GITHUB_REPO_URL>"
    echo ""
    echo "Examples:"
    echo "  ./scripts/sync-github.sh https://github.com/your-username/wbscb-banking.git"
    echo "  ./scripts/sync-github.sh https://<TOKEN>@github.com/your-username/wbscb-banking.git"
    echo "  ./scripts/sync-github.sh git@github.com:your-username/wbscb-banking.git"
    echo ""
    exit 1
fi

echo "==> Configuring remote origin: $REPO_URL"
if git remote | grep -q "^origin$"; then
    git remote set-url origin "$REPO_URL"
else
    git remote add origin "$REPO_URL"
fi

echo "==> Ensuring on main branch"
git branch -M main

echo "==> Staging and committing any pending changes"
git add .
if ! git diff-index --quiet HEAD --; then
    git commit -m "Update WBSCB Corporate Banking production codebase" || true
fi

echo "==> Pushing to origin main..."
git push -u origin main

echo "==> Successfully synchronized codebase with GitHub repository!"
