const fs = require('fs');
const path = require('path');
const { Resvg } = require('@resvg/resvg-js');

// 1. Master Standard 512x512 SVG with rounded squircle for display & standard icon
const standardSvg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" width="512" height="512">
  <defs>
    <!-- Background Gradients -->
    <linearGradient id="bg_grad" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#97144D"/>
      <stop offset="45%" stop-color="#861F41"/>
      <stop offset="100%" stop-color="#4E061E"/>
    </linearGradient>

    <radialGradient id="center_glow" cx="50%" cy="40%" r="55%">
      <stop offset="0%" stop-color="#B81D5B" stop-opacity="0.5"/>
      <stop offset="60%" stop-color="#861F41" stop-opacity="0"/>
    </radialGradient>

    <!-- Metallic Gold Gradients -->
    <linearGradient id="gold_metallic" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#FFFBEB"/>
      <stop offset="25%" stop-color="#FDE047"/>
      <stop offset="50%" stop-color="#F59E0B"/>
      <stop offset="75%" stop-color="#D97706"/>
      <stop offset="100%" stop-color="#92400E"/>
    </linearGradient>

    <linearGradient id="gold_badge" x1="0%" y1="0%" x2="100%" y2="0%">
      <stop offset="0%" stop-color="#D97706"/>
      <stop offset="30%" stop-color="#FBBF24"/>
      <stop offset="50%" stop-color="#FEF08A"/>
      <stop offset="70%" stop-color="#FBBF24"/>
      <stop offset="100%" stop-color="#D97706"/>
    </linearGradient>

    <linearGradient id="crest_gold" x1="0%" y1="0%" x2="0%" y2="100%">
      <stop offset="0%" stop-color="#FEF08A"/>
      <stop offset="50%" stop-color="#F59E0B"/>
      <stop offset="100%" stop-color="#B45309"/>
    </linearGradient>

    <!-- Subtle Drop Shadow for Crest & Badges -->
    <filter id="crest_shadow" x="-20%" y="-20%" width="140%" height="140%">
      <feDropShadow dx="0" dy="6" stdDeviation="8" flood-color="#000000" flood-opacity="0.45"/>
    </filter>
  </defs>

  <!-- Base Rounded Background Squircle -->
  <rect width="512" height="512" rx="112" fill="url(#bg_grad)"/>
  <rect width="512" height="512" rx="112" fill="url(#center_glow)"/>

  <!-- Outer Metallic Gold Border Trim -->
  <rect x="8" y="8" width="496" height="496" rx="104" fill="none" stroke="url(#gold_metallic)" stroke-width="4" stroke-opacity="0.65"/>
  <rect x="16" y="16" width="480" height="480" rx="96" fill="none" stroke="#FFFFFF" stroke-width="1" stroke-opacity="0.2"/>

  <!-- Decorative Corner Accents (Subtle Gold Dots) -->
  <circle cx="48" cy="48" r="4" fill="url(#gold_metallic)" opacity="0.6"/>
  <circle cx="464" cy="48" r="4" fill="url(#gold_metallic)" opacity="0.6"/>
  <circle cx="48" cy="464" r="4" fill="url(#gold_metallic)" opacity="0.6"/>
  <circle cx="464" cy="464" r="4" fill="url(#gold_metallic)" opacity="0.6"/>

  <!-- Main Center Content Group with Drop Shadow -->
  <g filter="url(#crest_shadow)">
    <!-- Axis Iconic Crest Geometry (Scaled & Perfectly Centered) -->
    <!-- Outer White Wings (Width ~216, Height ~144, Centered at x=256, y=170) -->
    <path d="M256 90 L364 246 H298 L256 166 L214 246 H148 L256 90 Z" fill="#FFFFFF"/>
    
    <!-- Inner Gold Shading -->
    <path d="M256 102 L308 190 H204 L256 102 Z" fill="url(#crest_gold)"/>
    
    <!-- Central Burgundy Triangle Notch -->
    <path d="M232 208 H280 L256 168 L232 208 Z" fill="#861F41"/>
  </g>

  <!-- Typography: AXIS BANK -->
  <g text-anchor="middle">
    <text x="256" y="306"
          font-family="-apple-system, BlinkMacSystemFont, 'Segoe UI', 'Plus Jakarta Sans', Roboto, sans-serif"
          font-size="44"
          font-weight="900"
          fill="#FFFFFF"
          letter-spacing="5">
      AXIS BANK
    </text>

    <!-- Sub-heading / Tagline -->
    <text x="256" y="338"
          font-family="-apple-system, BlinkMacSystemFont, 'Segoe UI', 'Plus Jakarta Sans', Roboto, sans-serif"
          font-size="14"
          font-weight="800"
          fill="#FDE047"
          letter-spacing="3"
          opacity="0.9">
      PRIORITY BANKING
    </text>
  </g>

  <!-- CC VIP Luxury Golden Badge (Centered at x=256, y=396) -->
  <g transform="translate(146, 372)">
    <!-- Badge Background Pill -->
    <rect width="220" height="52" rx="26" fill="url(#gold_badge)" stroke="#FFFBEB" stroke-width="2" filter="url(#crest_shadow)"/>
    
    <!-- Badge Inner Border -->
    <rect x="4" y="4" width="212" height="44" rx="22" fill="none" stroke="#92400E" stroke-width="1" stroke-opacity="0.3"/>

    <!-- Decorative Stars on Badge Sides -->
    <path d="M 28 26 L 31 20 L 37 20 L 32 24 L 34 30 L 28 26 Z" fill="#580824"/>
    <path d="M 192 26 L 189 20 L 183 20 L 188 24 L 186 30 L 192 26 Z" fill="#580824"/>

    <!-- Text: CC VIP -->
    <text x="110" y="34"
          text-anchor="middle"
          font-family="-apple-system, BlinkMacSystemFont, 'Segoe UI', 'Plus Jakarta Sans', Roboto, sans-serif"
          font-size="24"
          font-weight="900"
          fill="#4E061E"
          letter-spacing="3">
      CC VIP
    </text>
  </g>

  <!-- Bottom Official Verification Marker -->
  <text x="256" y="468"
        text-anchor="middle"
        font-family="-apple-system, BlinkMacSystemFont, 'Segoe UI', 'Plus Jakarta Sans', Roboto, sans-serif"
        font-size="12"
        font-weight="700"
        fill="#FFFFFF"
        opacity="0.5"
        letter-spacing="2">
    IFSC: UTIB000001 • RBI LICENSED
  </text>
</svg>`;

// 2. Master Maskable 512x512 SVG (Solid full bleed, elements scaled to fit 75-80% safe-zone circle)
const maskableSvg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" width="512" height="512">
  <defs>
    <!-- Background Gradients (Full Bleed to 0,0,512,512 with NO corner radius) -->
    <linearGradient id="bg_grad_m" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#97144D"/>
      <stop offset="45%" stop-color="#861F41"/>
      <stop offset="100%" stop-color="#4E061E"/>
    </linearGradient>

    <radialGradient id="center_glow_m" cx="50%" cy="45%" r="50%">
      <stop offset="0%" stop-color="#B81D5B" stop-opacity="0.55"/>
      <stop offset="70%" stop-color="#861F41" stop-opacity="0"/>
    </radialGradient>

    <!-- Metallic Gold Gradients -->
    <linearGradient id="gold_metallic_m" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#FFFBEB"/>
      <stop offset="25%" stop-color="#FDE047"/>
      <stop offset="50%" stop-color="#F59E0B"/>
      <stop offset="75%" stop-color="#D97706"/>
      <stop offset="100%" stop-color="#92400E"/>
    </linearGradient>

    <linearGradient id="gold_badge_m" x1="0%" y1="0%" x2="100%" y2="0%">
      <stop offset="0%" stop-color="#D97706"/>
      <stop offset="30%" stop-color="#FBBF24"/>
      <stop offset="50%" stop-color="#FEF08A"/>
      <stop offset="70%" stop-color="#FBBF24"/>
      <stop offset="100%" stop-color="#D97706"/>
    </linearGradient>

    <linearGradient id="crest_gold_m" x1="0%" y1="0%" x2="0%" y2="100%">
      <stop offset="0%" stop-color="#FEF08A"/>
      <stop offset="50%" stop-color="#F59E0B"/>
      <stop offset="100%" stop-color="#B45309"/>
    </linearGradient>

    <filter id="crest_shadow_m" x="-20%" y="-20%" width="140%" height="140%">
      <feDropShadow dx="0" dy="5" stdDeviation="6" flood-color="#000000" flood-opacity="0.4"/>
    </filter>
  </defs>

  <!-- Full-Bleed Solid Rect (Required for Maskable icons so no transparent edges show) -->
  <rect width="512" height="512" fill="url(#bg_grad_m)"/>
  <rect width="512" height="512" fill="url(#center_glow_m)"/>

  <!-- Subtle Circular Frame marking the inner safe-zone perimeter -->
  <circle cx="256" cy="256" r="198" fill="none" stroke="url(#gold_metallic_m)" stroke-width="2" stroke-opacity="0.3" stroke-dasharray="8 6"/>

  <!-- All content scaled slightly (0.86) to fit 100% safely inside Android's 80% circle crop -->
  <g transform="translate(256, 256) scale(0.86) translate(-256, -256)">
    <!-- Main Center Content Group with Drop Shadow -->
    <g filter="url(#crest_shadow_m)">
      <!-- Axis Iconic Crest Geometry -->
      <path d="M256 94 L364 250 H298 L256 170 L214 250 H148 L256 94 Z" fill="#FFFFFF"/>
      <path d="M256 106 L308 194 H204 L256 106 Z" fill="url(#crest_gold_m)"/>
      <path d="M232 212 H280 L256 172 L232 212 Z" fill="#861F41"/>
    </g>

    <!-- Typography: AXIS BANK -->
    <g text-anchor="middle">
      <text x="256" y="308"
            font-family="-apple-system, BlinkMacSystemFont, 'Segoe UI', 'Plus Jakarta Sans', Roboto, sans-serif"
            font-size="44"
            font-weight="900"
            fill="#FFFFFF"
            letter-spacing="5">
        AXIS BANK
      </text>

      <text x="256" y="340"
            font-family="-apple-system, BlinkMacSystemFont, 'Segoe UI', 'Plus Jakarta Sans', Roboto, sans-serif"
            font-size="14"
            font-weight="800"
            fill="#FDE047"
            letter-spacing="3"
            opacity="0.9">
        PRIORITY BANKING
      </text>
    </g>

    <!-- CC VIP Luxury Golden Badge -->
    <g transform="translate(146, 372)">
      <rect width="220" height="52" rx="26" fill="url(#gold_badge_m)" stroke="#FFFBEB" stroke-width="2" filter="url(#crest_shadow_m)"/>
      <rect x="4" y="4" width="212" height="44" rx="22" fill="none" stroke="#92400E" stroke-width="1" stroke-opacity="0.3"/>
      <text x="110" y="34"
            text-anchor="middle"
            font-family="-apple-system, BlinkMacSystemFont, 'Segoe UI', 'Plus Jakarta Sans', Roboto, sans-serif"
            font-size="24"
            font-weight="900"
            fill="#4E061E"
            letter-spacing="3">
        CC VIP
      </text>
    </g>
  </g>
</svg>`;

// Helper function to render SVG to PNG buffer with specified dimensions
function renderSvgToPng(svgStr, width, height) {
  const resvg = new Resvg(svgStr, {
    fitTo: {
      mode: 'width',
      value: width,
    },
    font: {
      loadSystemFonts: true,
      defaultFontFamily: 'sans-serif',
    },
  });
  const pngData = resvg.render();
  return pngData.asPng();
}

async function main() {
  const publicDir = path.resolve(__dirname, '../public');

  console.log('1. Saving master SVG files to public/...');
  fs.writeFileSync(path.join(publicDir, 'icon.svg'), standardSvg, 'utf8');
  fs.writeFileSync(path.join(publicDir, 'axis_logo.svg'), standardSvg, 'utf8');
  console.log('   Saved: icon.svg, axis_logo.svg');

  console.log('2. Rendering public/pwa-512x512.png (512x512 standard)...');
  const pwa512Buffer = renderSvgToPng(standardSvg, 512, 512);
  fs.writeFileSync(path.join(publicDir, 'pwa-512x512.png'), pwa512Buffer);
  console.log('   Wrote: pwa-512x512.png (' + pwa512Buffer.length + ' bytes)');

  console.log('3. Rendering public/pwa-maskable-512x512.png (512x512 maskable safe-zone)...');
  const maskable512Buffer = renderSvgToPng(maskableSvg, 512, 512);
  fs.writeFileSync(path.join(publicDir, 'pwa-maskable-512x512.png'), maskable512Buffer);
  console.log('   Wrote: pwa-maskable-512x512.png (' + maskable512Buffer.length + ' bytes)');

  console.log('4. Rendering public/pwa-192x192.png (192x192)...');
  const pwa192Buffer = renderSvgToPng(standardSvg, 192, 192);
  fs.writeFileSync(path.join(publicDir, 'pwa-192x192.png'), pwa192Buffer);
  console.log('   Wrote: pwa-192x192.png (' + pwa192Buffer.length + ' bytes)');

  console.log('5. Rendering public/apple-touch-icon.png (180x180 for iOS)...');
  const appleTouchBuffer = renderSvgToPng(maskableSvg, 180, 180);
  fs.writeFileSync(path.join(publicDir, 'apple-touch-icon.png'), appleTouchBuffer);
  console.log('   Wrote: apple-touch-icon.png (' + appleTouchBuffer.length + ' bytes)');

  console.log('6. Rendering public/favicon.png (64x64)...');
  const faviconBuffer = renderSvgToPng(standardSvg, 64, 64);
  fs.writeFileSync(path.join(publicDir, 'favicon.png'), faviconBuffer);
  console.log('   Wrote: favicon.png (' + faviconBuffer.length + ' bytes)');

  console.log('All PWA AXIS BANK CC VIP icons successfully generated and saved!');
}

main().catch((err) => {
  console.error('Error generating PWA icons:', err);
  process.exit(1);
});
