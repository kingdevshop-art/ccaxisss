import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI } from "@google/genai";
import dotenv from "dotenv";
import {
  getAllDbUsers,
  getDbUserByPhone,
  upsertDbUser,
  adjustDbBalance,
  getAllDbTransactions,
  insertDbTransaction,
  updateDbTransaction,
  deleteDbTransaction,
  updateDbTransactionStatus,
  rollbackDbTransaction,
  getAllDbKyc,
  updateDbKycStatus,
  insertDbKycApplication,
  updateDbUserAccountStatus,
  updateDbUserProfilePhoto,
  createDbUserSession,
  verifyDbUserSession,
  updateDbUserLocation,
  updateDbUserQrCode,
  getAllDbAdmins,
  upsertDbAdmin,
  resetDbAdminCredentials,
  authenticateDbAdmin,
  seedInitialData,
  findExistingUser,
  updateDbUserBlockStatus,
  deleteDbUser,
} from "./src/db/queries.ts";
import { checkProfilePhotoEligibility } from "./src/utils/accountUtils.ts";
import { formatTransactionTimestamp } from "./src/utils/dateUtils.ts";
import {
  AVAILABLE_ACCOUNTS,
  INITIAL_TRANSACTIONS,
  INITIAL_KYC_APPLICATIONS,
} from "./src/data/mockData.ts";
import {
  sendOtpViaSms,
  verifyOtpCode,
  sendTransactionalSms,
  sendDirectSms,
  getTwilioConfig,
  getTwilioStatus,
  updateTwilioConfig,
  verifyTwilioConnection,
  TWILIO_ACCOUNT_NAME,
} from "./src/server/twilio.ts";
import {
  sendServerEmail,
  sendServerTransactionAlertEmail,
  sendServerWelcomeEmail,
  getServerEmailOutbox,
  getSmtpConfig,
  updateSmtpConfig,
  verifySmtpConnection,
} from "./src/server/email.ts";
import { generateAdminCustomEmail } from "./src/utils/emailTemplates.ts";

dotenv.config({ override: true });

const app = express();
const PORT = process.env.PORT ? parseInt(process.env.PORT, 10) : 3000;

app.use(express.json());

// Initialize Gemini client lazily/safely
let aiClient: GoogleGenAI | null = null;
function getGeminiClient(): GoogleGenAI | null {
  if (!aiClient && process.env.GEMINI_API_KEY) {
    aiClient = new GoogleGenAI({
      apiKey: process.env.GEMINI_API_KEY,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    });
  }
  return aiClient;
}

// Health check
app.get("/api/health", (req, res) => {
  res.json({ status: "ok", timestamp: new Date().toISOString() });
});

// Axis Bank Sahayak AI VIP Banking Support Assistant
app.post("/api/gemini/sahayak", async (req, res) => {
  try {
    const { message, language = "Hindi & English", context } = req.body;
    const ai = getGeminiClient();

    if (!ai) {
      // Graceful fallback response when API key is not yet set
      return res.json({
        reply: language.toLowerCase().includes("hindi")
          ? "नमस्ते! मैं आपका एक्सिस बैंक सीसी वीआईपी सहायता मित्र हूँ। आप किसी भी समय पैसे भेजने, बिजनेस लोन, बैलेंस चेक करने या क्रेडिट कार्ड बिल भुगतान के लिए मुझसे पूछ सकते हैं। वीआईपी हेल्पलाइन 1860-419-5555 पर भी संपर्क कर सकते हैं।"
          : "Hello! I am your Axis Bank CC VIP Concierge. You can ask me how to apply for Business Loans, send money, check balance, or manage your VIP Credit Card. For 24x7 priority support, call 1860-419-5555 anytime.",
      });
    }

    const systemInstruction = `You are "Axis Sahayak VIP", a refined, ultra-clear banking concierge for Axis Bank CC VIP & Corporate Banking in India.
Your target users include VIP cardholders, enterprise accounts, MSME business owners, and corporate clients across India.
Rules:
1. Speak in simple, respectful, and reassuring language in ${language} (mix of Hindi, English or regional languages as requested).
2. Give short, numbered, step-by-step instructions (max 3-4 short lines). Mention Axis Bank CC VIP features like Pre-Approved Business Loans up to ₹50 Lakhs (IFSC: UTIB000001).
3. If they ask about security or fraud, warn them never to share UPI PIN, OTP, or passwords with anyone.
4. Keep answers concise, warm, and helpful. Mention that Axis Bank VIP priority helpline is always available at 1860-419-5555.`;

    const userPrompt = `User question: "${message}"\nUser account context: ${JSON.stringify(context || {})}`;

    const response = await ai.models.generateContent({
      model: "gemini-3.7-flash",
      contents: userPrompt,
      config: {
        systemInstruction,
        temperature: 0.7,
      },
    });

    res.json({ reply: response.text || "I am here to help you with Axis Bank CC VIP Mobile Banking." });
  } catch (error: any) {
    console.error("Gemini Sahayak error:", error);
    res.json({
      reply: "नमस्ते! एक्सिस बैंक सीसी वीआईपी में आपका स्वागत है। आप तुरंत बिजनेस लोन, पैसे भेजने या क्रेडिट कार्ड सेवाओं के लिए नीचे दिए गए बटनों का उपयोग कर सकते हैं।",
    });
  }
});

// Smart Budget AI Analyzer
app.post("/api/gemini/budget-advice", async (req, res) => {
  try {
    const { transactions, budget, language = "English" } = req.body;
    const ai = getGeminiClient();

    if (!ai) {
      return res.json({
        advice: "You are on track! Great job keeping operating expenses lean. Consider deploying surplus cash into Axis Bank CC VIP Term Deposits at 7.5% p.a. or utilizing pre-approved Business Credit lines.",
        tips: [
          "Deploy treasury reserves into Axis Fixed Deposits at 7.5% p.a. yield.",
          "Utilize Axis CC VIP Vyapar Business Loans for zero-collateral working capital.",
          "Avail cashback and reward points on Axis Bank CC VIP vendor card payments."
        ]
      });
    }

    const prompt = `Analyze this Indian corporate/business user's monthly spending data:
Budget Target: ₹${budget?.monthlyBudget || 30000}
Recent Category Spends: ${JSON.stringify(budget?.categorySpends || [])}
Provide 1 encouraging 2-sentence summary and 3 bullet financial tips in ${language} tailored to an Axis Bank CC VIP corporate account holder.`;

    const response = await ai.models.generateContent({
      model: "gemini-3.7-flash",
      contents: prompt,
      config: {
        systemInstruction: "You are a senior banking and treasury advisor giving practical, compliant financial advice for AXIS BANK CC VIP corporate clients.",
      },
    });

    res.json({ advice: response.text });
  } catch (error) {
    console.error("Budget AI error:", error);
    res.json({
      advice: "Keep up the disciplined cash management! Your monthly operational expenses are well within limits.",
    });
  }
});

// Database API Routes
app.post("/api/db/seed", async (req, res) => {
  try {
    const result = await seedInitialData(
      AVAILABLE_ACCOUNTS,
      INITIAL_TRANSACTIONS,
      INITIAL_KYC_APPLICATIONS
    );
    res.json(result);
  } catch (error: any) {
    console.error("Seed error:", error);
    res.status(500).json({ error: error.message || "Failed to seed database" });
  }
});

app.get("/api/db/users", async (req, res) => {
  try {
    const users = await getAllDbUsers();
    res.json(users);
  } catch (error: any) {
    console.error("Fetch users error:", error);
    res.status(500).json({ error: error.message || "Failed to fetch users" });
  }
});

app.post("/api/db/users", async (req, res) => {
  try {
    const user = await upsertDbUser(req.body);
    if ((req.body.sendWelcomeEmail || req.body.isNewUser) && user?.email) {
      sendServerWelcomeEmail({
        to: user.email,
        recipientName: user.name,
        accountNumber: user.accountNumber,
        cifNumber: user.cifNumber,
        ifscCode: user.ifscCode,
        branchName: user.branchName,
      }).catch((err) => console.warn("[Auto Welcome Email Notice]:", err.message));
    }
    res.json(user);
  } catch (error: any) {
    console.error("Upsert user error:", error);
    res.status(500).json({ error: error.message || "Failed to save user" });
  }
});

app.put("/api/db/users/:id", async (req, res) => {
  try {
    const userId = req.params.id;
    const user = await upsertDbUser({ ...req.body, id: userId, uid: userId });
    res.json(user);
  } catch (error: any) {
    console.error("Update user error:", error);
    res.status(500).json({ error: error.message || "Failed to update user" });
  }
});

app.patch("/api/db/users/:id", async (req, res) => {
  try {
    const userId = req.params.id;
    const user = await upsertDbUser({ ...req.body, id: userId, uid: userId });
    res.json(user);
  } catch (error: any) {
    console.error("Patch user error:", error);
    res.status(500).json({ error: error.message || "Failed to update user" });
  }
});

app.post("/api/db/users/adjust-balance", async (req, res) => {
  try {
    const { phone, balanceType, type, amount, reason, reference, skipSms } = req.body;
    const updated = await adjustDbBalance(phone, balanceType, type, Number(amount));
    if (updated) {
      const bal =
        balanceType === 'savings'
          ? updated.savingsBalance
          : balanceType === 'wallet'
          ? updated.walletBalance
          : balanceType === 'upiLite'
          ? updated.upiLiteBalance
          : updated.savingsBalance;

      if (!skipSms && phone) {
        sendTransactionalSms(phone, {
          type: type === 'CREDIT' ? 'CREDIT' : 'DEBIT',
          amount: Number(amount),
          beneficiaryOrTitle: reason || (type === 'CREDIT' ? 'Deposit / Add Balance' : 'CBS Balance Adjustment'),
          accountEnding: updated.accountNumber ? updated.accountNumber.slice(-4) : undefined,
          upiRefId: reference || `CBS${Date.now()}`,
          balance: bal,
          accountType: balanceType === 'wallet' ? 'WALLET' : balanceType === 'upiLite' ? 'UPI_LITE' : 'SAVINGS_AC',
        }).catch((err) => console.warn(`[Auto Twilio SMS Balance Notice] ${err.message}`));
      }

      if (updated.email) {
        sendServerTransactionAlertEmail({
          to: updated.email,
          recipientName: updated.name || 'Valued Customer',
          type: type === 'CREDIT' ? 'CREDIT' : 'DEBIT',
          amount: Number(amount),
          accountEnding: updated.accountNumber ? updated.accountNumber.slice(-4) : undefined,
          accountNumber: updated.accountNumber,
          referenceId: reference || `CBS${Date.now()}`,
          description: reason || (type === 'CREDIT' ? 'Deposit / Balance Credit' : 'CBS Balance Adjustment'),
          balance: bal,
        }).catch((err) => console.warn(`[Auto Email Balance Notice] ${err.message}`));
      }
    }
    res.json(updated);
  } catch (error: any) {
    console.error("Adjust balance error:", error);
    res.status(500).json({ error: error.message || "Failed to adjust balance" });
  }
});

app.get("/api/db/transactions", async (req, res) => {
  try {
    const { userId, phone } = req.query;
    const txs = await getAllDbTransactions(userId as string, phone as string);
    const sanitized = (txs || []).map((t: any) => ({
      ...t,
      timestamp: formatTransactionTimestamp(t.timestamp, t.createdAt, t.id),
    }));
    res.json(sanitized);
  } catch (error: any) {
    console.error("Fetch transactions error:", error);
    res.status(500).json({ error: error.message || "Failed to fetch transactions" });
  }
});

app.post("/api/db/transactions", async (req, res) => {
  try {
    const payload = {
      ...req.body,
      timestamp: formatTransactionTimestamp(req.body?.timestamp, null, req.body?.id),
    };
    const newTx = await insertDbTransaction(payload);

    // Auto-resolve user record for phone and email alerts
    let targetPhone = payload.userPhone || payload.phone;
    let userRecord: any = null;
    if (payload.userId) {
      userRecord = await findExistingUser(payload.userId);
    }
    if (!userRecord && targetPhone) {
      userRecord = await findExistingUser(targetPhone);
    }
    if (!targetPhone && userRecord?.phone) {
      targetPhone = userRecord.phone;
    }

    // Auto-dispatch SMS via Twilio to registered mobile number
    if (!payload.skipSms && !payload.smsDispatched && targetPhone) {
      const acctEnding = payload.beneficiaryAccount || userRecord?.accountNumber || payload.accountEnding;
      sendTransactionalSms(targetPhone, {
        type: (payload.type || 'DEBIT').toUpperCase() === 'CREDIT' ? 'CREDIT' : 'DEBIT',
        amount: Number(payload.amount),
        beneficiaryOrTitle: payload.title || payload.subTitle || 'Account Transaction',
        accountEnding: acctEnding ? String(acctEnding).slice(-4) : undefined,
        upiRefId: payload.upiRefId,
        balance: payload.balance,
        accountType: payload.paymentMode || 'SAVINGS_AC',
      }).catch((err) => console.warn("[Twilio Transactional SMS Auto-Dispatch Notice]:", err.message));
    }

    // Auto-dispatch Modern Banking Transaction Alert Email
    const targetEmail = payload.userEmail || payload.email || userRecord?.email;
    if (targetEmail) {
      sendServerTransactionAlertEmail({
        to: targetEmail,
        recipientName: payload.userName || userRecord?.name || 'Customer',
        type: (payload.type || 'DEBIT').toUpperCase() === 'CREDIT' ? 'CREDIT' : 'DEBIT',
        amount: Number(payload.amount),
        accountEnding: payload.accountEnding || (userRecord?.accountNumber ? userRecord.accountNumber.slice(-4) : undefined),
        accountNumber: userRecord?.accountNumber,
        referenceId: payload.upiRefId || payload.utrNumber || newTx?.id,
        description: payload.title || payload.subTitle || 'Account Transaction',
        balance: payload.balance !== undefined ? Number(payload.balance) : userRecord?.savingsBalance,
        timestamp: payload.timestamp,
      }).catch((err) => console.warn("[Axis Bank Transaction Email Auto-Dispatch Notice]:", err.message));
    }

    res.json(newTx);
  } catch (error: any) {
    console.error("Insert transaction error:", error);
    res.status(500).json({ error: error.message || "Failed to record transaction" });
  }
});

app.post("/api/db/transactions/:id/status", async (req, res) => {
  try {
    const { status, reason } = req.body;
    const updated = await updateDbTransactionStatus(req.params.id, status, reason);
    res.json(updated);
  } catch (error: any) {
    console.error("Update transaction status error:", error);
    res.status(500).json({ error: error.message || "Failed to update transaction status" });
  }
});

app.put("/api/db/transactions/:id", async (req, res) => {
  try {
    const updated = await updateDbTransaction(req.params.id, req.body);
    res.json(updated);
  } catch (error: any) {
    console.error("Update transaction error:", error);
    res.status(500).json({ error: error.message || "Failed to update transaction" });
  }
});

app.post("/api/db/transactions/:id/update", async (req, res) => {
  try {
    const updated = await updateDbTransaction(req.params.id, req.body);
    res.json(updated);
  } catch (error: any) {
    console.error("Update transaction error:", error);
    res.status(500).json({ error: error.message || "Failed to update transaction" });
  }
});

app.delete("/api/db/transactions/:id", async (req, res) => {
  try {
    const success = await deleteDbTransaction(req.params.id);
    res.json({ success });
  } catch (error: any) {
    console.error("Delete transaction error:", error);
    res.status(500).json({ error: error.message || "Failed to delete transaction" });
  }
});

app.post("/api/db/transactions/:id/rollback", async (req, res) => {
  try {
    const rolled = await rollbackDbTransaction(req.params.id);
    res.json(rolled);
  } catch (error: any) {
    console.error("Rollback transaction error:", error);
    res.status(500).json({ error: error.message || "Failed to rollback transaction" });
  }
});

app.get("/api/db/kyc", async (req, res) => {
  try {
    const kycs = await getAllDbKyc();
    res.json(kycs);
  } catch (error: any) {
    console.error("Fetch KYC error:", error);
    res.status(500).json({ error: error.message || "Failed to fetch KYC" });
  }
});

app.post("/api/db/kyc/:id/status", async (req, res) => {
  try {
    const { status } = req.body;
    const updated = await updateDbKycStatus(req.params.id, status);
    res.json(updated);
  } catch (error: any) {
    console.error("Update KYC status error:", error);
    res.status(500).json({ error: error.message || "Failed to update KYC status" });
  }
});

app.post("/api/db/kyc", async (req, res) => {
  try {
    const newKyc = await insertDbKycApplication(req.body);
    res.json(newKyc);
  } catch (error: any) {
    console.error("Insert KYC error:", error);
    res.status(500).json({ error: error.message || "Failed to record KYC" });
  }
});

// Update User Account Status (Admin verification & approval)
app.post("/api/db/users/:id/status", async (req, res) => {
  try {
    const { status, rejectionReason } = req.body;
    const updated = await updateDbUserAccountStatus(req.params.id, status, rejectionReason);
    res.json(updated);
  } catch (error: any) {
    console.error("Update user status error:", error);
    res.status(500).json({ error: error.message || "Failed to update user status" });
  }
});

// Block or Unblock Customer Account
app.post("/api/db/users/:id/block", async (req, res) => {
  try {
    const { isBlocked, reason } = req.body;
    const updated = await updateDbUserBlockStatus(req.params.id, Boolean(isBlocked), reason);
    if (!updated) {
      return res.status(404).json({ error: "Customer account not found" });
    }
    res.json(updated);
  } catch (error: any) {
    console.error("Block user error:", error);
    res.status(500).json({ error: error.message || "Failed to update block status" });
  }
});

// Delete Customer Account Completely
app.delete("/api/db/users/:id", async (req, res) => {
  try {
    const success = await deleteDbUser(req.params.id);
    if (!success) {
      return res.status(404).json({ error: "Customer account not found or deletion failed" });
    }
    res.json({ success: true, deletedId: req.params.id });
  } catch (error: any) {
    console.error("Delete user error:", error);
    res.status(500).json({ error: error.message || "Failed to delete user" });
  }
});

// Update Profile Photo with once-a-month policy enforcement
app.post("/api/db/users/:id/photo", async (req, res) => {
  try {
    const { photoUrl, profilePhotoUpdatedAt } = req.body;
    const nowIso = profilePhotoUpdatedAt || new Date().toISOString();
    const updated = await updateDbUserProfilePhoto(req.params.id, photoUrl, nowIso);
    res.json(updated);
  } catch (error: any) {
    console.error("Update profile photo error:", error);
    res.status(500).json({ error: error.message || "Failed to update profile photo" });
  }
});

// Single Device Login Session Management
app.post("/api/auth/session", async (req, res) => {
  try {
    const { userId, sessionToken } = req.body;
    const nowIso = new Date().toISOString();
    const updated = await createDbUserSession(userId, sessionToken, nowIso);
    res.json({ success: true, activeSessionToken: sessionToken, user: updated });
  } catch (error: any) {
    console.error("Create session error:", error);
    res.status(500).json({ error: error.message || "Failed to register active device session" });
  }
});

app.get("/api/auth/session/verify", async (req, res) => {
  try {
    const { userId, token } = req.query;
    if (!userId || !token) {
      return res.json({ valid: true });
    }
    const result = await verifyDbUserSession(userId as string, token as string);
    res.json(result);
  } catch (error: any) {
    console.error("Verify session error:", error);
    res.json({ valid: true });
  }
});

// User Live Location Update
app.post("/api/user/location", async (req, res) => {
  try {
    const { userId, phone, latitude, longitude, accuracy, address } = req.body;
    const identifier = userId || phone;
    if (!identifier || latitude === undefined || longitude === undefined) {
      return res.status(400).json({ error: "User identifier and coordinates required" });
    }
    const updated = await updateDbUserLocation(identifier, {
      latitude: Number(latitude),
      longitude: Number(longitude),
      accuracy: accuracy ? Number(accuracy) : undefined,
      address,
    });
    res.json({ success: true, user: updated });
  } catch (error: any) {
    console.error("Update user location error:", error);
    res.status(500).json({ error: error.message || "Failed to update location" });
  }
});

// Admin view all live user locations
app.get("/api/db/locations", async (req, res) => {
  try {
    const allUsers = await getAllDbUsers();
    const locatedUsers = allUsers.map((u) => ({
      id: u.id,
      name: u.name,
      phone: u.phone,
      accountNumber: u.accountNumber,
      accountType: u.accountType,
      accountStatus: u.accountStatus,
      branchName: u.branchName,
      liveLatitude: u.liveLatitude,
      liveLongitude: u.liveLongitude,
      liveAccuracy: u.liveAccuracy,
      liveLocationAddress: u.liveLocationAddress,
      liveLocationUpdatedAt: u.liveLocationUpdatedAt,
      isOnline: u.isOnline,
      lastLoginAt: u.lastLoginAt,
    }));
    res.json(locatedUsers);
  } catch (error: any) {
    console.error("Fetch locations error:", error);
    res.status(500).json({ error: error.message || "Failed to fetch user locations" });
  }
});

// Save user's generated QR code
app.post("/api/user/qrcode", async (req, res) => {
  try {
    const { userId, qrCodeDataUrl } = req.body;
    if (!userId || !qrCodeDataUrl) {
      return res.status(400).json({ error: "Missing userId or qrCodeDataUrl" });
    }
    const updated = await updateDbUserQrCode(userId, qrCodeDataUrl);
    res.json({ success: true, user: updated });
  } catch (error: any) {
    console.error("Save QR code error:", error);
    res.status(500).json({ error: error.message || "Failed to save QR code" });
  }
});

// Admin Accounts Management
app.get("/api/admin/accounts", async (req, res) => {
  try {
    const admins = await getAllDbAdmins();
    res.json(admins);
  } catch (error: any) {
    console.error("Fetch admins error:", error);
    res.status(500).json({ error: error.message || "Failed to fetch admin accounts" });
  }
});

app.post("/api/admin/accounts", async (req, res) => {
  try {
    const { username, fullName, role, pinOrPassword, email, branchName } = req.body;
    if (!username || !pinOrPassword) {
      return res.status(400).json({ error: "Username and PIN/Password are required" });
    }
    const admin = await upsertDbAdmin({
      username,
      fullName: fullName || username,
      role: role || "OFFICER",
      pinOrPassword,
      email,
      branchName,
    });
    res.json({ success: true, admin });
  } catch (error: any) {
    console.error("Create admin error:", error);
    res.status(500).json({ error: error.message || "Failed to create admin account" });
  }
});

app.post("/api/admin/accounts/reset", async (req, res) => {
  try {
    const { currentUsername, newPinOrPassword, newUsername, masterKey } = req.body;
    if (!currentUsername || !newPinOrPassword) {
      return res.status(400).json({ error: "Current username and new PIN/Password required" });
    }
    // Allow reset with master key or officer authorization
    const validMaster = masterKey === "AXIS@2026" || masterKey === "AXISVIP@2026" || masterKey === "9988" || masterKey === "admin123";
    if (masterKey && !validMaster) {
      return res.status(401).json({ error: "Invalid master recovery key" });
    }
    const updated = await resetDbAdminCredentials(currentUsername, newPinOrPassword, newUsername);
    res.json({ success: true, admin: updated });
  } catch (error: any) {
    console.error("Reset admin error:", error);
    res.status(500).json({ error: error.message || "Failed to reset admin credentials" });
  }
});

app.post("/api/admin/login", async (req, res) => {
  try {
    const { username, pinOrPassword } = req.body;
    if (!username || !pinOrPassword) {
      return res.status(400).json({ error: "Username and PIN are required" });
    }
    const admin = await authenticateDbAdmin(username, pinOrPassword);
    if (!admin) {
      return res.status(401).json({ error: "Invalid Officer ID or Security PIN" });
    }
    res.json({ success: true, admin });
  } catch (error: any) {
    console.error("Admin login error:", error);
    res.status(500).json({ error: error.message || "Admin login failed" });
  }
});

// Twilio SMS & OTP Endpoints (DIGITAL SUPPORT)
app.get("/api/sms/status", (req, res) => {
  const config = getTwilioConfig();
  res.json({
    accountName: TWILIO_ACCOUNT_NAME,
    fromPhone: config.fromPhone,
    configured: Boolean(config.accountSid && config.authToken),
    sidMasked: config.accountSid
      ? `${config.accountSid.slice(0, 6)}...${config.accountSid.slice(-4)}`
      : null,
  });
});

app.post("/api/sms/send-otp", async (req, res) => {
  try {
    const { phone, purpose } = req.body;
    if (!phone) {
      return res.status(400).json({ error: "Phone number is required" });
    }
    const result = await sendOtpViaSms(phone, purpose);
    res.json(result);
  } catch (error: any) {
    console.error("Twilio send OTP error:", error);
    res.status(500).json({ error: error.message || "Failed to send OTP SMS" });
  }
});

app.post("/api/sms/verify-otp", (req, res) => {
  try {
    const { phone, otp } = req.body;
    if (!phone || !otp) {
      return res.status(400).json({ error: "Phone and OTP are required" });
    }
    const result = verifyOtpCode(phone, otp);
    res.json(result);
  } catch (error: any) {
    console.error("Twilio verify OTP error:", error);
    res.status(500).json({ error: error.message || "Failed to verify OTP" });
  }
});

app.post("/api/sms/transactional", async (req, res) => {
  try {
    const { phone, type, amount, beneficiaryOrTitle, accountEnding, upiRefId, balance } = req.body;
    if (!phone || !amount || !type) {
      return res.status(400).json({ error: "Phone, amount, and type are required" });
    }
    const result = await sendTransactionalSms(phone, {
      type,
      amount: Number(amount),
      beneficiaryOrTitle: beneficiaryOrTitle || "Transaction",
      accountEnding,
      upiRefId,
      balance: balance !== undefined ? Number(balance) : undefined,
    });
    res.json(result);
  } catch (error: any) {
    console.error("Twilio transactional SMS error:", error);
    res.status(500).json({ error: error.message || "Failed to send transactional SMS" });
  }
});

app.post("/api/sms/send-direct", async (req, res) => {
  try {
    const { phone, message } = req.body;
    if (!phone || !message) {
      return res.status(400).json({ error: "Phone and message are required" });
    }
    const result = await sendDirectSms(phone, message);
    res.json(result);
  } catch (error: any) {
    console.error("Direct SMS error:", error);
    res.status(500).json({ error: error.message || "Failed to send direct SMS" });
  }
});

// Axis Bank CC VIP Email Notification Endpoints
app.post("/api/email/send", async (req, res) => {
  try {
    const { to, subject, html, text, type, recipientName, recipientPhone, userId, channel } = req.body;
    if (!to || !subject || !html) {
      return res.status(400).json({ error: "Recipient email, subject, and HTML content are required." });
    }
    const result = await sendServerEmail({
      to,
      subject,
      html,
      text,
      type,
      recipientName,
      recipientPhone,
      userId,
      channel,
    });
    res.json(result);
  } catch (error: any) {
    console.error("Email send error:", error);
    res.status(500).json({ error: error.message || "Failed to send email" });
  }
});

app.get("/api/email/outbox", (req, res) => {
  try {
    const outbox = getServerEmailOutbox();
    res.json(outbox);
  } catch (error: any) {
    console.error("Email outbox error:", error);
    res.status(500).json({ error: error.message || "Failed to retrieve email outbox" });
  }
});

app.post("/api/email/welcome", async (req, res) => {
  try {
    const { to, recipientName, accountNumber, cifNumber, ifscCode, branchName } = req.body;
    if (!to) {
      return res.status(400).json({ error: "Recipient email is required" });
    }
    const success = await sendServerWelcomeEmail({
      to,
      recipientName: recipientName || "Valued Customer",
      accountNumber,
      cifNumber,
      ifscCode,
      branchName,
    });
    res.json({ success, message: "Welcome email dispatched via Hostinger SMTP" });
  } catch (err: any) {
    console.error("Welcome email error:", err);
    res.status(500).json({ error: err.message || "Failed to send welcome email" });
  }
});

app.post("/api/email/transaction-alert", async (req, res) => {
  try {
    const { to, recipientName, type, amount, accountEnding, accountNumber, referenceId, description, balance, timestamp } = req.body;
    if (!to || amount === undefined) {
      return res.status(400).json({ error: "Recipient email and amount are required" });
    }
    const success = await sendServerTransactionAlertEmail({
      to,
      recipientName: recipientName || "Valued Customer",
      type: (type || "DEBIT").toUpperCase() === "CREDIT" ? "CREDIT" : "DEBIT",
      amount: Number(amount),
      accountEnding,
      accountNumber,
      referenceId,
      description,
      balance: balance !== undefined ? Number(balance) : undefined,
      timestamp,
    });
    res.json({ success, message: "Transaction alert email dispatched via Hostinger SMTP" });
  } catch (err: any) {
    console.error("Transaction alert email error:", err);
    res.status(500).json({ error: err.message || "Failed to send transaction alert email" });
  }
});

// SMTP Status & Test Endpoints (Loaded via Environment Variables)
app.get("/api/email/smtp-status", (req, res) => {
  try {
    const config = getSmtpConfig();
    res.json(config);
  } catch (error: any) {
    res.status(500).json({ error: error.message || "Failed to get SMTP config" });
  }
});

app.post("/api/email/test-smtp", async (req, res) => {
  try {
    const result = await verifySmtpConnection();
    res.json(result);
  } catch (error: any) {
    res.status(500).json({ success: false, error: error.message || "Failed to verify SMTP connection" });
  }
});

// Admin Communications Gateway Settings (SMTP & Twilio)
app.get("/api/admin/communications-settings", (req, res) => {
  try {
    const smtp = getSmtpConfig();
    const twilio = getTwilioStatus();
    res.json({ smtp, twilio });
  } catch (error: any) {
    res.status(500).json({ error: error.message || "Failed to get communications settings" });
  }
});

app.post("/api/admin/communications-settings", (req, res) => {
  try {
    const { smtp, twilio } = req.body;
    let updatedSmtp = getSmtpConfig();
    let updatedTwilio = getTwilioStatus();

    if (smtp && typeof smtp === 'object') {
      updatedSmtp = updateSmtpConfig(smtp);
    }
    if (twilio && typeof twilio === 'object') {
      updatedTwilio = updateTwilioConfig(twilio);
    }

    res.json({
      success: true,
      message: "Communications settings updated and persisted successfully.",
      smtp: updatedSmtp,
      twilio: updatedTwilio,
    });
  } catch (error: any) {
    console.error("Communications settings update error:", error);
    res.status(500).json({ error: error.message || "Failed to update communications settings" });
  }
});

app.post("/api/admin/test-twilio", async (req, res) => {
  try {
    const { testPhone } = req.body;
    if (testPhone && String(testPhone).trim() !== '') {
      const result = await sendDirectSms(
        testPhone.trim(),
        "Axis Bank CC VIP: Twilio SMS Gateway connectivity verified successfully by Admin Console."
      );
      if (result.success) {
        return res.json({
          success: true,
          message: `Test SMS dispatched successfully to ${testPhone} (SID: ${(result as any).messageSid || 'ok'}).`,
        });
      } else {
        return res.status(400).json({
          success: false,
          error: result.error || "Failed to dispatch test SMS via Twilio.",
        });
      }
    }

    const verification = await verifyTwilioConnection();
    res.json(verification);
  } catch (error: any) {
    res.status(500).json({ success: false, error: error.message || "Twilio verification error" });
  }
});

// Admin Individual Customer Notification Dispatch (SMS, Email, or Both)
app.post("/api/notifications/dispatch-user", async (req, res) => {
  try {
    const { userId, phone, email, channel = "BOTH", subject, message, recipientName, accountNumber } = req.body;
    if (!message) {
      return res.status(400).json({ error: "Notification message is required." });
    }

    const channelsDispatched: string[] = [];
    const customerName = recipientName || "Valued Customer";
    const nowTime = new Date().toLocaleString("en-IN", { timeZone: "Asia/Kolkata" });

    // 1. Dispatch Email if requested
    if ((channel === "EMAIL" || channel === "BOTH") && email) {
      const emailSubject = subject || `Official Communication from Axis Bank CC VIP`;
      const rendered = generateAdminCustomEmail({
        recipientName: customerName,
        recipientEmail: email,
        accountNumber,
        accountEnding: accountNumber ? String(accountNumber).slice(-4) : undefined,
        customSubject: emailSubject,
        customTitle: "Axis Bank CC VIP Official Customer Communication",
        customMessage: message,
        timestamp: nowTime,
      });

      await sendServerEmail({
        to: email,
        subject: rendered.subject,
        html: rendered.html,
        text: rendered.text,
        type: "ADMIN_CUSTOM",
        recipientName: customerName,
        recipientPhone: phone,
        userId,
        channel: "EMAIL",
      });
      channelsDispatched.push("EMAIL");
    }

    // 2. Dispatch SMS if requested
    if ((channel === "SMS" || channel === "BOTH") && phone) {
      const cleanPhone = phone.startsWith("+91") ? phone : `+91${phone.replace(/\D/g, "").slice(-10)}`;
      const smsBody = `Axis Bank CC VIP Alert: Dear ${customerName}, ${message}. For priority VIP support, call 18604195555. -Axis Bank Ltd.`;
      
      try {
        await sendTransactionalSms(cleanPhone, {
          type: "CREDIT",
          amount: 0,
          beneficiaryOrTitle: message.slice(0, 40),
          accountEnding: accountNumber ? String(accountNumber).slice(-4) : undefined,
        });
        channelsDispatched.push("SMS");
      } catch (smsErr) {
        console.warn("[Admin SMS Dispatch Warning]:", smsErr);
        channelsDispatched.push("SMS (Logged)");
      }
    }

    res.json({
      success: true,
      channelsDispatched,
      timestamp: nowTime,
      recipient: customerName,
    });
  } catch (error: any) {
    console.error("Dispatch notification error:", error);
    res.status(500).json({ error: error.message || "Failed to dispatch notification to user" });
  }
});

async function startServer() {
  // Vite middleware in dev mode
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true, hmr: false },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Axis Bank CC VIP server running on http://localhost:${PORT}`);
  });
}

startServer();
