# WBSCB Corporate Banking — Production & Android Build Guide

This project provides the production-ready source code for **WBSCB Corporate Banking (West Bengal State Cooperative Bank Ltd.)**, including both the full-stack web application with Progressive Web App (PWA) capabilities and the native Android application source code in `/android`.

---

## Architecture Overview

1. **Web & Progressive Web App (PWA)**:
   - Built with **React 19**, **TypeScript**, **Tailwind CSS**, and **Vite**.
   - Offline-capable Service Worker powered by `vite-plugin-pwa` and Workbox.
   - Installable on Android (via Chromium WebAPK engine), iOS Safari (Add to Home Screen), and Desktop (Chrome / Edge).
   - High-contrast accessibility and Senior Citizen mode.
   - Multi-lingual localization (Bengali, Hindi, English, Santali).

2. **Native Android Application (`/android`)**:
   - **Language**: Kotlin 1.9
   - **Target SDK**: Android 14 (API Level 34)
   - **Min SDK**: Android 7.0 (API Level 24)
   - **Package**: `in.wbscb.banking`
   - **Security**: Strict HTTPS enforcement via `network_security_config.xml`, `usesCleartextTraffic="false"`.
   - **Hardware Integration**:
     - AndroidX `BiometricPrompt` bridge for hardware biometric fingerprint / face authentication.
     - Camera integration for KYC document scanning and QR payments.
     - Native Intent handling for UPI apps (`upi://`, `wbscb://`).
     - Haptic feedback vibration engine.

---

## Method 1: Instant Android Installation via WebAPK (PWA)

This method requires **zero SDKs** and installs directly onto user Android devices:

1. Open the banking portal URL in **Google Chrome** on any Android device.
2. Tap the in-app **"Install Android App"** button in the header, OR open Chrome menu (`⋮`) &rarr; **"Install app"**.
3. Android OS automatically compiles an official **WebAPK** package and places the WBSCB icon on the home screen and app drawer.
4. Launches in a full-screen, standalone native window with hardware acceleration and offline passbook storage.

---

## Method 2: Building the Native Android APK from Source

The project includes complete Android Studio project files in the `/android` directory.

### Prerequisites:
- **Node.js** (v18 or higher)
- **JDK 17**
- **Android Studio Hedgehog / Iguana / Jellyfish** or Android SDK Command-line Tools

### Step-by-step Build Instructions:

#### 1. Compile the Production Web Assets
```bash
npm run build
```
This outputs the bundled single-page application into `/dist`.

#### 2. Copy Web Distribution to Android Assets (for offline standalone APK)
```bash
mkdir -p android/app/src/main/assets
cp -r dist android/app/src/main/assets/
```

#### 3. Build with Gradle
Navigate to the `android` directory:
```bash
cd android
```

- **To build a Debug APK**:
  ```bash
  ./gradlew assembleDebug
  ```
  Output APK location:
  `android/app/build/outputs/apk/debug/app-debug.apk`

- **To build a Production Release APK**:
  ```bash
  ./gradlew assembleRelease
  ```
  Output APK location:
  `android/app/build/outputs/apk/release/app-release.apk`

- **To build a Google Play Store App Bundle (.aab)**:
  ```bash
  ./gradlew bundleRelease
  ```
  Output AAB location:
  `android/app/build/outputs/bundle/release/app-release.aab`

---

## Method 3: Using Capacitor CLI (Optional)

A `capacitor.config.json` configuration file is also provided at the root of the project:

```bash
# 1. Install Capacitor CLI (if needed)
npm install @capacitor/core @capacitor/cli @capacitor/android

# 2. Build web assets
npm run build

# 3. Synchronize assets to Android
npx cap sync android

# 4. Open in Android Studio
npx cap open android
```

---

## Production Security & Compliance Checklist

- [x] **Cleartext Traffic Disabled**: HTTP requests are blocked; only HTTPS endpoints are permitted.
- [x] **Biometric Cryptographic Enclave**: Native Android BiometricPrompt ensures biometric keys never leave hardware storage.
- [x] **KYC File Provider**: Scoped storage with secure FileProvider prevents unauthorized access to customer ID documents.
- [x] **UPI Intent Security**: Intent filters strictly validate `upi://` and `wbscb://` URIs before launching external payment apps.
- [x] **Single Task Launch Mode**: Prevents activity hijacking and screen overlay attacks during banking operations.

---

## Support & Governance

- **Institution**: West Bengal State Cooperative Bank Ltd. (WBSCB)
- **Supervision**: Regulated under Banking Regulation Act (AACS), 1949 by Reserve Bank of India (RBI) and NABARD.
