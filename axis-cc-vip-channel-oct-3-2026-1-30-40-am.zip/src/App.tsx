import React, { useState, useEffect, useMemo } from 'react';
import {
  UserProfile,
  LanguageCode,
  Transaction,
  TransactionCategory,
  BudgetCategorySpend,
  SavingsPot,
  Contact,
  KYCApplication,
  PushAlert,
  OfflineQueuedTransfer,
  UserServices,
} from './types';
import {
  INITIAL_USER,
  AVAILABLE_ACCOUNTS,
  DEFAULT_SERVICES,
  INITIAL_TRANSACTIONS,
  INITIAL_BUDGET_SPENDS,
  INITIAL_SAVINGS_POTS,
  INITIAL_CONTACTS,
  INITIAL_KYC_APPLICATIONS,
  INITIAL_PUSH_ALERTS,
} from './data/mockData';
import { dbService } from './services/dbService';
import { smsService } from './services/smsService';
import { emailService } from './services/emailService';
import { AirtelHeader } from './components/AirtelHeader';
import { BalanceCard } from './components/BalanceCard';
import { QuickServicesGrid } from './components/QuickServicesGrid';
import { PassbookView } from './components/PassbookView';
import { BudgetTracker } from './components/BudgetTracker';
import { PayModal } from './components/PayModal';
import { BiometricModal } from './components/BiometricModal';
import { OfflineBankingModal } from './components/OfflineBankingModal';
import { AddBalanceModal } from './components/AddBalanceModal';
import { ReceiveMoneyModal } from './components/ReceiveMoneyModal';
import { SelfTransferModal } from './components/SelfTransferModal';
import { TermDepositModal } from './components/TermDepositModal';
import { SahayakChat } from './components/SahayakChat';
import { SeniorModeView } from './components/SeniorModeView';
import { SoundboxWidget } from './components/SoundboxWidget';
import { PushNotificationDrawer } from './components/PushNotificationDrawer';
import { CustomerAuthModal } from './components/CustomerAuthModal';
import { BottomNavBar, UserDashboardTab } from './components/BottomNavBar';
import { AndroidAppModal } from './components/AndroidAppModal';
import { CustomerAuthPage } from './components/CustomerAuthPage';
import { OfficerAdminApp } from './components/OfficerAdminApp';
import { BusinessLoanModal } from './components/BusinessLoanModal';
import { VirtualCardsManager } from './components/VirtualCardsManager';
import { ServicesAndUpdateModal } from './components/ServicesAndUpdateModal';
import { speakSoundboxAlert } from './utils/audioAlert';
import { generateSessionToken } from './utils/accountUtils';
import { getNowBankingTimestamp, formatTransactionTimestamp } from './utils/dateUtils';
import { getDeviceLocationNative } from './utils/nativeBridge';
import { ShieldCheck, Wifi, WifiOff, Sparkles, Smartphone, Landmark, Lock, LogIn, ShieldAlert, Briefcase, CheckCircle2 } from 'lucide-react';

export function App() {
  // Portal Navigation State: 'CUSTOMER' | 'ADMIN'
  const [portal, setPortal] = useState<'CUSTOMER' | 'ADMIN'>(() => {
    if (typeof window !== 'undefined') {
      const path = window.location.pathname;
      const search = window.location.search;
      const hash = window.location.hash;
      if (path.startsWith('/admin') || search.includes('portal=admin') || hash === '#admin') {
        return 'ADMIN';
      }
    }
    return 'CUSTOMER';
  });

  // Core Application States (Persistent across sessions)
  const [users, setUsers] = useState<UserProfile[]>(() => {
    const saved = localStorage.getItem('axis_users');
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      } catch (e) {
        console.error('Failed to parse cached users', e);
      }
    }
    return AVAILABLE_ACCOUNTS;
  });

  // Customer starts at Login/Registration unless session is restored
  const [user, setUser] = useState<UserProfile | null>(() => {
    const savedId = localStorage.getItem('axis_active_user_id');
    if (savedId) {
      const savedUsers = localStorage.getItem('axis_users');
      const pool: UserProfile[] = savedUsers ? JSON.parse(savedUsers) : AVAILABLE_ACCOUNTS;
      const found = pool.find((u) => u.id === savedId);
      if (found) {
        if (found.isBlocked) {
          localStorage.removeItem('axis_active_user_id');
          localStorage.removeItem('axis_active_session_token');
          return null;
        }
        return found;
      }
    }
    return null;
  });

  const [language, setLanguage] = useState<LanguageCode>('en');
  const [highContrast, setHighContrast] = useState(false);
  const [isSeniorMode, setIsSeniorMode] = useState(false);
  const [isOffline, setIsOffline] = useState(false);
  const [activeTab, setActiveTab] = useState<UserDashboardTab>('HOME');

  // Banking Data States
  const [transactions, setTransactions] = useState<Transaction[]>(INITIAL_TRANSACTIONS);
  const [budgetSpends, setBudgetSpends] = useState<BudgetCategorySpend[]>(INITIAL_BUDGET_SPENDS);
  const [savingsPots, setSavingsPots] = useState<SavingsPot[]>(INITIAL_SAVINGS_POTS);
  const [contacts] = useState<Contact[]>(INITIAL_CONTACTS);
  const [kycApplications, setKycApplications] = useState<KYCApplication[]>(INITIAL_KYC_APPLICATIONS);
  const [pushAlerts, setPushAlerts] = useState<PushAlert[]>(INITIAL_PUSH_ALERTS);

  // Modal Open States
  const [isPayModalOpen, setIsPayModalOpen] = useState(false);
  const [payInitialTab, setPayInitialTab] = useState<'qr' | 'contact' | 'upi' | 'bank' | 'bill'>('contact');
  const [payInitialBill, setPayInitialBill] = useState<string | undefined>(undefined);
  const [isBiometricModalOpen, setIsBiometricModalOpen] = useState(false);
  const [isOfflineModalOpen, setIsOfflineModalOpen] = useState(false);
  const [isAddBalanceModalOpen, setIsAddBalanceModalOpen] = useState(false);
  const [isReceiveModalOpen, setIsReceiveModalOpen] = useState(false);
  const [isSelfTransferModalOpen, setIsSelfTransferModalOpen] = useState(false);
  const [isTermDepositModalOpen, setIsTermDepositModalOpen] = useState(false);
  const [isSahayakOpen, setIsSahayakOpen] = useState(false);
  const [isPushDrawerOpen, setIsPushDrawerOpen] = useState(false);
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  const [isAndroidModalOpen, setIsAndroidModalOpen] = useState(false);
  const [isBusinessLoanOpen, setIsBusinessLoanOpen] = useState(false);
  const [isServicesModalOpen, setIsServicesModalOpen] = useState(false);

  // Listen to popstate / hash for URL route sync
  useEffect(() => {
    const handleNav = () => {
      const path = window.location.pathname;
      const search = window.location.search;
      const hash = window.location.hash;
      if (path.startsWith('/admin') || search.includes('portal=admin') || hash === '#admin') {
        setPortal('ADMIN');
      } else {
        setPortal('CUSTOMER');
      }
    };
    window.addEventListener('popstate', handleNav);
    window.addEventListener('hashchange', handleNav);
    return () => {
      window.removeEventListener('popstate', handleNav);
      window.removeEventListener('hashchange', handleNav);
    };
  }, []);

  // Save users in storage
  useEffect(() => {
    localStorage.setItem('axis_users', JSON.stringify(users));
  }, [users]);

  // Save active customer ID in storage
  useEffect(() => {
    if (user) {
      localStorage.setItem('axis_active_user_id', user.id);
    } else {
      localStorage.removeItem('axis_active_user_id');
    }
  }, [user]);

  // Native Android Deep Link & Route Handling (axis:// and upi://)
  useEffect(() => {
    const handleNativeLink = (e: any) => {
      const url = e.detail?.url || '';
      if (url.includes('admin') || url.includes('officer')) {
        setPortal('ADMIN');
      } else if (url.includes('pay') || url.includes('scan') || url.includes('upi')) {
        setPortal('CUSTOMER');
        setIsPayModalOpen(true);
      }
    };
    window.addEventListener('axis-deep-link', handleNativeLink);
    window.handleNativeDeepLink = (url: string) => {
      if (url.includes('admin') || url.includes('officer')) {
        setPortal('ADMIN');
      } else if (url.includes('pay') || url.includes('scan') || url.includes('upi')) {
        setPortal('CUSTOMER');
        setIsPayModalOpen(true);
      }
    };
    return () => {
      window.removeEventListener('axis-deep-link', handleNativeLink);
    };
  }, []);

  // Live GPS Telemetry Sync for Native Android & Web Radar
  useEffect(() => {
    if (!user) return;
    const syncLocation = async () => {
      try {
        const loc = await getDeviceLocationNative();
        if (loc) {
          await dbService.updateUserLocation(
            user.id || user.phone,
            loc.latitude,
            loc.longitude,
            loc.accuracy
          );
        }
      } catch {
        // Continue silently if location fails
      }
    };
    syncLocation();
    const locInterval = setInterval(syncLocation, 45000);
    return () => clearInterval(locInterval);
  }, [user?.id, user?.phone]);

  // Synchronize with server-side PostgreSQL database
  useEffect(() => {
    let isMounted = true;
    const initAndSync = async () => {
      try {
        await dbService.initDb();
        const [dbUsers, dbTxs, dbKycs] = await Promise.all([
          dbService.fetchUsers(),
          dbService.fetchTransactions(),
          dbService.fetchKycApplications(),
        ]);
        if (!isMounted) return;
        if (dbUsers && dbUsers.length > 0) {
          setUsers(dbUsers);
          const activeId = localStorage.getItem('axis_active_user_id');
          if (activeId) {
            const found = dbUsers.find((u) => u.id === activeId || u.phone === activeId);
            if (found) {
              if (found.isBlocked) {
                // If account was blocked, clear active session immediately
                setUser(null);
                localStorage.removeItem('axis_active_user_id');
                localStorage.removeItem('axis_active_session_token');
              } else {
                setUser(found);
              }
            }
          }
        }
        if (dbTxs && dbTxs.length > 0) {
          const sanitizedTxs = dbTxs.map((tx) => ({
            ...tx,
            timestamp: formatTransactionTimestamp(tx.timestamp, tx.createdAt, tx.id),
          }));
          setTransactions(sanitizedTxs);
        }
        if (dbKycs && dbKycs.length > 0) {
          setKycApplications(dbKycs);
        }
      } catch (err) {
        console.warn('PostgreSQL database sync notice (using client cache):', err);
      }
    };
    initAndSync();
    return () => {
      isMounted = false;
    };
  }, []);

  // Single Device Active Session Conflict State
  const [sessionConflictAlert, setSessionConflictAlert] = useState<string | null>(null);

  // Single Active Device Enforcement: Continually verify that this device's token matches DB
  useEffect(() => {
    if (!user) return;

    const checkActiveSession = async () => {
      try {
        const localToken = localStorage.getItem('axis_active_session_token');
        if (!localToken) return;

        const latest = await dbService.getUserByPhone(user.phone);
        if (latest && latest.activeSessionToken && latest.activeSessionToken !== localToken) {
          // Another device logged in: Terminate this session immediately
          setUser(null);
          localStorage.removeItem('axis_active_user_id');
          localStorage.removeItem('axis_active_session_token');
          setSessionConflictAlert(
            `Session Terminated: Your account (${user.name}) was logged into from another device or browser session. In compliance with RBI banking security guidelines, only one active device session is permitted at a time.`
          );
        }
      } catch (err) {
        // Continue silently if network error
      }
    };

    // Periodically verify every 8 seconds
    const interval = setInterval(checkActiveSession, 8000);

    const handleStorageChange = (e: StorageEvent) => {
      if (e.key === 'axis_active_session_token') {
        checkActiveSession();
      }
    };
    window.addEventListener('storage', handleStorageChange);

    return () => {
      clearInterval(interval);
      window.removeEventListener('storage', handleStorageChange);
    };
  }, [user]);

  const handleSwitchToAdmin = () => {
    setPortal('ADMIN');
    if (typeof window !== 'undefined' && window.history) {
      window.history.pushState(null, '', '/admin');
    }
  };

  const handleSwitchToCustomer = () => {
    setPortal('CUSTOMER');
    if (typeof window !== 'undefined' && window.history) {
      window.history.pushState(null, '', '/');
    }
  };

  // Auto-listen to system network status
  useEffect(() => {
    const handleOnline = () => setIsOffline(false);
    const handleOffline = () => setIsOffline(true);
    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);
    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  // Isolate transactions strictly for the active logged-in customer
  const customerTransactions = useMemo(() => {
    if (!user) return [];
    const cleanUserPhone = user.phone ? user.phone.replace(/\D/g, '').slice(-10) : '';
    const userUpi = user.upiId ? user.upiId.trim().toLowerCase() : '';
    const userAcc = user.accountNumber ? user.accountNumber.trim() : '';
    const userIdStr = String(user.id || '');
    const userDbIdStr = user.dbId != null ? String(user.dbId) : '';

    return transactions.filter((tx) => {
      const txUserIdStr = tx.userId != null ? String(tx.userId) : '';
      const txUserDbIdStr = (tx as any).userDbId != null ? String((tx as any).userDbId) : '';
      const cleanTxPhone = tx.userPhone ? tx.userPhone.replace(/\D/g, '').slice(-10) : '';

      // 1. Direct User ID or DB ID match
      if (txUserIdStr && (txUserIdStr === userIdStr || (userDbIdStr && txUserIdStr === userDbIdStr))) {
        return true;
      }
      if (txUserDbIdStr && (txUserDbIdStr === userIdStr || (userDbIdStr && txUserDbIdStr === userDbIdStr))) {
        return true;
      }

      // 2. User registered phone match
      if (cleanTxPhone && cleanUserPhone && cleanTxPhone === cleanUserPhone) {
        return true;
      }

      // 3. Inward CREDIT transactions received by this user
      if (tx.type === 'credit') {
        if (tx.recipientVpa && userUpi && tx.recipientVpa.trim().toLowerCase() === userUpi) {
          return true;
        }
        if (tx.beneficiaryAccount && userAcc && tx.beneficiaryAccount.trim() === userAcc) {
          return true;
        }
        if (
          tx.beneficiaryName &&
          user.name &&
          tx.beneficiaryName.trim().toLowerCase() === user.name.trim().toLowerCase() &&
          (tx.transferType === 'SAME_BANK' || !tx.userId)
        ) {
          return true;
        }
      }

      // 4. Outward DEBIT transactions initiated by this user
      if (tx.type === 'debit') {
        if (tx.senderVpa && userUpi && tx.senderVpa.trim().toLowerCase() === userUpi) {
          return true;
        }
      }

      return false;
    });
  }, [transactions, user]);

  // Dynamic category spends derived directly from the logged-in customer's own debit transactions
  const customerBudgetSpends = useMemo(() => {
    const categories: Record<
      TransactionCategory,
      { name: string; budget: number; color: string; iconName: string }
    > = {
      bills: { name: 'Bills & Utilities', budget: 5000, color: 'text-amber-500 bg-amber-500/10', iconName: 'Zap' },
      groceries: { name: 'Groceries & Provisions', budget: 8000, color: 'text-emerald-500 bg-emerald-500/10', iconName: 'ShoppingBag' },
      food: { name: 'Dining & Cafes', budget: 4000, color: 'text-rose-500 bg-rose-500/10', iconName: 'Utensils' },
      travel: { name: 'Travel & Mobility', budget: 3500, color: 'text-sky-500 bg-sky-500/10', iconName: 'Car' },
      transfer: { name: 'Direct Remittances', budget: 10000, color: 'text-indigo-500 bg-indigo-500/10', iconName: 'Send' },
      shopping: { name: 'Commerce & Retail', budget: 5000, color: 'text-purple-500 bg-purple-500/10', iconName: 'ShoppingBag' },
      recharge: { name: 'Telecom & Data', budget: 1500, color: 'text-cyan-500 bg-cyan-500/10', iconName: 'Zap' },
      invest: { name: 'Corporate Reserves', budget: 15000, color: 'text-teal-500 bg-teal-500/10', iconName: 'Gift' },
      savings: { name: 'Term & Fixed Deposits', budget: 20000, color: 'text-blue-500 bg-blue-500/10', iconName: 'Gift' },
      salary: { name: 'Payroll & Compensation', budget: 0, color: 'text-green-500 bg-green-500/10', iconName: 'Send' },
      cashback: { name: 'Incentives & Rewards', budget: 0, color: 'text-amber-500 bg-amber-500/10', iconName: 'Gift' },
    };

    const spentMap: Record<string, number> = {};
    customerTransactions.forEach((tx) => {
      if (tx.type === 'debit') {
        const cat = tx.category || 'transfer';
        spentMap[cat] = (spentMap[cat] || 0) + tx.amount;
      }
    });

    return Object.entries(categories)
      .map(([cat, meta]) => ({
        category: cat as TransactionCategory,
        name: meta.name,
        budget: meta.budget,
        spent: spentMap[cat] || 0,
        color: meta.color,
        iconName: meta.iconName,
      }))
      .filter((c) => c.budget > 0 || c.spent > 0);
  }, [customerTransactions]);

  // Push alerts scoped strictly to the current customer or system-wide announcements
  const customerAlerts = useMemo(() => {
    if (!user) return [];
    return pushAlerts.filter(
      (a) =>
        !a.userId ||
        a.userId === user.id ||
        (user.dbId != null && a.userId === String(user.dbId))
    );
  }, [pushAlerts, user]);

  // Handlers for Payment & Balance updates
  const handlePaymentSuccess = (newTx: Transaction) => {
    // Ensure transaction has sender customer identifiers
    const completeTx: Transaction = {
      ...newTx,
      userId: newTx.userId || user?.id,
      userPhone: newTx.userPhone || user?.phone,
      senderVpa: newTx.senderVpa || user?.upiId,
      smsDispatched: true,
    };

    setTransactions((prev) => [completeTx, ...prev]);
    dbService.recordTransaction(completeTx);

    // Deduct from appropriate balance
    setUser((prev) => {
      if (!prev) return null;
      let balanceType: 'savings' | 'wallet' | 'upiLite' = 'upiLite';
      if (completeTx.paymentMode === 'SAVINGS_AC') {
        balanceType = 'savings';
      } else if (completeTx.paymentMode === 'WALLET') {
        balanceType = 'wallet';
      }
      dbService.adjustBalance(prev.phone, balanceType, 'DEBIT', completeTx.amount, {
        reason: completeTx.title,
        reference: completeTx.upiRefId,
        skipSms: true,
      });

      const updatedBal =
        completeTx.paymentMode === 'SAVINGS_AC'
          ? Math.max(0, prev.savingsBalance - completeTx.amount)
          : completeTx.paymentMode === 'WALLET'
          ? Math.max(0, prev.walletBalance - completeTx.amount)
          : Math.max(0, prev.upiLiteBalance - completeTx.amount);

      // 1. Send Twilio Transactional DEBIT SMS to Sender's Registered Mobile Number
      if (prev.phone) {
        smsService.sendTransactionalAlert({
          phone: prev.phone,
          type: 'DEBIT',
          amount: completeTx.amount,
          beneficiaryOrTitle: completeTx.title || 'Payment Transfer',
          accountEnding: prev.accountNumber?.slice(-4),
          upiRefId: completeTx.upiRefId,
          balance: updatedBal,
          accountType: completeTx.paymentMode,
        }).catch((err) => console.warn('[Sender Twilio SMS Error]', err));
      }

      // Modern Banking Transaction Alert Email to Sender
      if (prev.email) {
        emailService.sendTransactionEmail(prev, completeTx, updatedBal).catch((err) =>
          console.warn('[Sender Email Alert Notice]:', err)
        );
      }

      if (completeTx.paymentMode === 'SAVINGS_AC') {
        return { ...prev, savingsBalance: updatedBal };
      } else if (completeTx.paymentMode === 'WALLET') {
        return { ...prev, walletBalance: updatedBal };
      } else {
        return { ...prev, upiLiteBalance: updatedBal };
      }
    });

    // Handle same-bank internal transfer recipient credit
    if (completeTx.transferType === 'SAME_BANK' && completeTx.status === 'SUCCESS') {
      const recipientUser = users.find((u) => {
        if (completeTx.beneficiaryAccount && u.accountNumber === completeTx.beneficiaryAccount) return true;
        if (completeTx.recipientVpa && u.upiId && u.upiId.toLowerCase() === completeTx.recipientVpa.toLowerCase()) return true;
        const cleanVpa = completeTx.recipientVpa?.replace(/\D/g, '').slice(-10);
        const cleanUserPhone = u.phone.replace(/\D/g, '').slice(-10);
        if (cleanVpa && cleanUserPhone && cleanVpa === cleanUserPhone) return true;
        return false;
      });

      if (recipientUser && recipientUser.id !== user?.id) {
        const recipientNewBal = recipientUser.savingsBalance + completeTx.amount;
        dbService.adjustBalance(recipientUser.phone, 'savings', 'CREDIT', completeTx.amount, {
          reason: `Transfer from ${user?.name || 'Axis Bank Customer'}`,
          reference: completeTx.upiRefId,
          skipSms: true,
        });
        setUsers((prev) =>
          prev.map((u) =>
            u.id === recipientUser.id
              ? { ...u, savingsBalance: recipientNewBal }
              : u
          )
        );

        const creditTx: Transaction = {
          id: `tx_${Date.now()}_cr`,
          userId: recipientUser.id,
          userPhone: recipientUser.phone,
          title: user?.name || 'Internal Transfer Received',
          subTitle: `Direct transfer from ${user?.name || 'Axis Bank Account'} (Ref: ${completeTx.upiRefId})`,
          amount: completeTx.amount,
          type: 'credit',
          category: 'transfer',
          timestamp: getNowBankingTimestamp(),
          status: 'SUCCESS',
          paymentMode: completeTx.paymentMode,
          upiRefId: completeTx.upiRefId,
          senderVpa: user?.upiId,
          recipientVpa: recipientUser.upiId,
          beneficiaryAccount: recipientUser.accountNumber,
          beneficiaryName: recipientUser.name,
          transferType: 'SAME_BANK',
          approvalStatus: 'APPROVED',
          fraudFlag: 'CLEAN',
          smsDispatched: true,
        };
        setTransactions((prev) => [creditTx, ...prev]);
        dbService.recordTransaction(creditTx);

        // 2. Send Twilio Transactional CREDIT SMS to Recipient's Registered Mobile Number
        if (recipientUser.phone) {
          smsService.sendTransactionalAlert({
            phone: recipientUser.phone,
            type: 'CREDIT',
            amount: completeTx.amount,
            beneficiaryOrTitle: user?.name || 'Axis Bank Transfer',
            accountEnding: recipientUser.accountNumber?.slice(-4),
            upiRefId: completeTx.upiRefId,
            balance: recipientNewBal,
            accountType: 'SAVINGS_AC',
          }).catch((err) => console.warn('[Recipient Twilio SMS Error]', err));
        }

        // Modern Banking Transaction Alert Email to Recipient
        if (recipientUser.email) {
          emailService.sendTransactionEmail(recipientUser, creditTx, recipientNewBal).catch((err) =>
            console.warn('[Recipient Email Alert Notice]:', err)
          );
        }

        const creditAlert: PushAlert = {
          id: `alert_cr_${Date.now()}`,
          userId: recipientUser.id,
          title: `₹${completeTx.amount.toFixed(2)} Credited to your Savings Account`,
          body: `Received from ${user?.name || 'Axis Bank Customer'}. Ref: ${completeTx.upiRefId}`,
          time: getNowBankingTimestamp(),
          read: false,
          type: 'TRANSACTION',
          amount: completeTx.amount,
        };
        setPushAlerts((prev) => [creditAlert, ...prev]);
      }
    }

    // Add push alert for sender customer
    const newAlert: PushAlert = {
      id: `alert_${Date.now()}`,
      userId: user?.id,
      title: `₹${completeTx.amount.toFixed(2)} debited from Axis Bank CC VIP`,
      body: `Paid to ${completeTx.title}. Ref: ${completeTx.upiRefId}`,
      time: getNowBankingTimestamp(),
      read: false,
      type: 'TRANSACTION',
    };
    setPushAlerts((prev) => [newAlert, ...prev]);
  };

  // Handler: Axis Bank CC VIP Business Loan Disbursal
  const handleDisburseLoan = (amount: number, loanData: any, tx: Transaction) => {
    if (!user) return;
    const newSavingsBal = user.savingsBalance + amount;
    setUser((prev) => (prev ? { ...prev, savingsBalance: newSavingsBal } : null));
    setUsers((prev) =>
      prev.map((u) => (u.id === user.id ? { ...u, savingsBalance: newSavingsBal } : u))
    );
    setTransactions((prev) => [tx, ...prev]);
    dbService.adjustBalance(user.phone, 'savings', 'CREDIT', amount, {
      reason: `Axis CC VIP Business Loan Disbursal - ${loanData?.planTitle || 'Vyapar Growth Loan'}`,
      reference: tx.upiRefId,
      skipSms: true,
    });
    dbService.recordTransaction(tx);

    if (user.phone) {
      smsService.sendTransactionalAlert({
        phone: user.phone,
        type: 'CREDIT',
        amount: amount,
        beneficiaryOrTitle: 'Axis VIP Business Loan Disbursal',
        accountEnding: user.accountNumber?.slice(-4),
        upiRefId: tx.upiRefId,
        balance: newSavingsBal,
        accountType: 'SAVINGS_AC',
      }).catch((err) => console.warn('[Business Loan SMS Error]', err));
    }

    const loanAlert: PushAlert = {
      id: `alert_loan_${Date.now()}`,
      userId: user.id,
      title: `🎉 Business Loan Disbursed: ₹${amount.toLocaleString('en-IN')}`,
      body: `Funds credited immediately to A/C ending ••${user.accountNumber.slice(-4)}. Sanction Ref: ${tx.upiRefId}`,
      time: getNowBankingTimestamp(),
      read: false,
      type: 'TRANSACTION',
      amount: amount,
    };
    setPushAlerts((prev) => [loanAlert, ...prev]);
  };

  // Handler: Customer Adds Balance / Deposits to Account
  const handleAddBalance = (
    accountType: 'savings' | 'wallet' | 'upiLite',
    amount: number,
    paymentMethod: string,
    reference?: string
  ) => {
    if (!user) return;
    const refId = reference || `DEP${Date.now().toString().slice(-8)}`;

    let newBal = user.savingsBalance;
    if (accountType === 'savings') {
      newBal = user.savingsBalance + amount;
      setUser((prev) => (prev ? { ...prev, savingsBalance: newBal } : null));
    } else if (accountType === 'wallet') {
      newBal = user.walletBalance + amount;
      setUser((prev) => (prev ? { ...prev, walletBalance: newBal } : null));
    } else {
      newBal = user.upiLiteBalance + amount;
      setUser((prev) => (prev ? { ...prev, upiLiteBalance: newBal } : null));
    }

    setUsers((prev) =>
      prev.map((u) => {
        if (u.id !== user.id) return u;
        if (accountType === 'savings') return { ...u, savingsBalance: u.savingsBalance + amount };
        if (accountType === 'wallet') return { ...u, walletBalance: u.walletBalance + amount };
        return { ...u, upiLiteBalance: u.upiLiteBalance + amount };
      })
    );

    dbService.adjustBalance(user.phone, accountType, 'CREDIT', amount, {
      reason: `Add Balance via ${paymentMethod}`,
      reference: refId,
      skipSms: true,
    });

    const title =
      accountType === 'wallet'
        ? 'Digital Wallet Top-up'
        : accountType === 'upiLite'
        ? 'UPI Lite Balance Load'
        : 'Added Money to Savings Account';

    const depositTx: Transaction = {
      id: `tx_dep_${Date.now()}`,
      userId: user.id,
      userPhone: user.phone,
      title: title,
      subTitle: `Credited via ${paymentMethod} (Ref: ${refId})`,
      amount: amount,
      type: 'credit',
      category: 'transfer',
      timestamp: getNowBankingTimestamp(),
      status: 'SUCCESS',
      paymentMode: accountType === 'wallet' ? 'WALLET' : accountType === 'upiLite' ? 'UPI_LITE' : 'SAVINGS_AC',
      upiRefId: refId,
      fraudFlag: 'CLEAN',
      beneficiaryAccount: user.accountNumber,
      beneficiaryName: user.name,
      smsDispatched: true,
    };
    setTransactions((prev) => [depositTx, ...prev]);
    dbService.recordTransaction(depositTx);

    // Send Twilio Transactional CREDIT SMS to Registered Mobile
    if (user.phone) {
      smsService.sendTransactionalAlert({
        phone: user.phone,
        type: 'CREDIT',
        amount: amount,
        beneficiaryOrTitle: `${paymentMethod} Deposit`,
        accountEnding: user.accountNumber?.slice(-4),
        upiRefId: refId,
        balance: newBal,
        accountType: accountType === 'wallet' ? 'WALLET' : accountType === 'upiLite' ? 'UPI_LITE' : 'SAVINGS_AC',
      }).catch((err) => console.warn('[Add Balance Twilio SMS Error]', err));
    }

    // Voice announcement via Soundbox
    speakSoundboxAlert(amount, language);

    // Push alert
    const newAlert: PushAlert = {
      id: `alert_dep_${Date.now()}`,
      userId: user.id,
      title: `₹${amount.toFixed(2)} Credited to your ${accountType === 'wallet' ? 'Wallet' : accountType === 'upiLite' ? 'UPI Lite' : 'Savings A/c'}`,
      body: `Deposit successful via ${paymentMethod}. Twilio SMS sent to ${user.phone}.`,
      time: getNowBankingTimestamp(),
      read: false,
      type: 'TRANSACTION',
      amount: amount,
    };
    setPushAlerts((prev) => [newAlert, ...prev]);
  };

  // Handler: Self Transfer between own accounts
  const handleSelfTransfer = (
    from: 'SAVINGS' | 'WALLET' | 'UPI_LITE',
    to: 'SAVINGS' | 'WALLET' | 'UPI_LITE',
    amount: number
  ) => {
    if (!user) return;
    const refId = `SELF${Date.now().toString().slice(-8)}`;

    const fromKey = from === 'SAVINGS' ? 'savingsBalance' : from === 'WALLET' ? 'walletBalance' : 'upiLiteBalance';
    const toKey = to === 'SAVINGS' ? 'savingsBalance' : to === 'WALLET' ? 'walletBalance' : 'upiLiteBalance';
    const fromType = from === 'SAVINGS' ? 'savings' : from === 'WALLET' ? 'wallet' : 'upiLite';
    const toType = to === 'SAVINGS' ? 'savings' : to === 'WALLET' ? 'wallet' : 'upiLite';

    const newFromBal = Math.max(0, user[fromKey] - amount);
    const newToBal = user[toKey] + amount;

    setUser((prev) => (prev ? { ...prev, [fromKey]: newFromBal, [toKey]: newToBal } : null));
    setUsers((prev) =>
      prev.map((u) => (u.id === user.id ? { ...u, [fromKey]: newFromBal, [toKey]: newToBal } : u))
    );

    dbService.adjustBalance(user.phone, fromType, 'DEBIT', amount, {
      reason: `Transfer to ${to}`,
      reference: refId,
      skipSms: true,
    });
    dbService.adjustBalance(user.phone, toType, 'CREDIT', amount, {
      reason: `Transfer from ${from}`,
      reference: refId,
      skipSms: true,
    });

    const debitTx: Transaction = {
      id: `tx_self_dr_${Date.now()}`,
      userId: user.id,
      userPhone: user.phone,
      title: `Transfer to ${to === 'SAVINGS' ? 'Savings A/c' : to === 'WALLET' ? 'Wallet' : 'UPI Lite'}`,
      subTitle: `Internal Self Transfer (Ref: ${refId})`,
      amount: amount,
      type: 'debit',
      category: 'transfer',
      timestamp: getNowBankingTimestamp(),
      status: 'SUCCESS',
      paymentMode: from === 'SAVINGS' ? 'SAVINGS_AC' : from === 'WALLET' ? 'WALLET' : 'UPI_LITE',
      upiRefId: refId,
      fraudFlag: 'CLEAN',
      beneficiaryAccount: user.accountNumber,
      beneficiaryName: user.name,
      smsDispatched: true,
    };

    const creditTx: Transaction = {
      id: `tx_self_cr_${Date.now() + 1}`,
      userId: user.id,
      userPhone: user.phone,
      title: `Received from ${from === 'SAVINGS' ? 'Savings A/c' : from === 'WALLET' ? 'Wallet' : 'UPI Lite'}`,
      subTitle: `Internal Self Transfer (Ref: ${refId})`,
      amount: amount,
      type: 'credit',
      category: 'transfer',
      timestamp: getNowBankingTimestamp(),
      status: 'SUCCESS',
      paymentMode: to === 'SAVINGS' ? 'SAVINGS_AC' : to === 'WALLET' ? 'WALLET' : 'UPI_LITE',
      upiRefId: refId,
      fraudFlag: 'CLEAN',
      beneficiaryAccount: user.accountNumber,
      beneficiaryName: user.name,
      smsDispatched: true,
    };

    setTransactions((prev) => [creditTx, debitTx, ...prev]);
    dbService.recordTransaction(debitTx);
    dbService.recordTransaction(creditTx);

    // Send Twilio SMS for both Debit and Credit to registered phone
    if (user.phone) {
      smsService.sendTransactionalAlert({
        phone: user.phone,
        type: 'DEBIT',
        amount: amount,
        beneficiaryOrTitle: `Self Transfer to ${to}`,
        accountEnding: user.accountNumber?.slice(-4),
        upiRefId: refId,
        balance: newFromBal,
        accountType: from === 'SAVINGS' ? 'SAVINGS_AC' : from === 'WALLET' ? 'WALLET' : 'UPI_LITE',
      }).catch((err) => console.warn('[Self Transfer Debit SMS Error]', err));

      smsService.sendTransactionalAlert({
        phone: user.phone,
        type: 'CREDIT',
        amount: amount,
        beneficiaryOrTitle: `Self Transfer from ${from}`,
        accountEnding: user.accountNumber?.slice(-4),
        upiRefId: refId,
        balance: newToBal,
        accountType: to === 'SAVINGS' ? 'SAVINGS_AC' : to === 'WALLET' ? 'WALLET' : 'UPI_LITE',
      }).catch((err) => console.warn('[Self Transfer Credit SMS Error]', err));
    }
  };

  // Handler: Inward QR Payment / Credit Received
  const handleSimulateCredit = (amount: number, senderName: string, note?: string) => {
    if (!user) return;
    const refId = `INW${Date.now().toString().slice(-8)}`;
    const newBal = user.savingsBalance + amount;

    setUser((prev) => (prev ? { ...prev, savingsBalance: newBal } : null));
    setUsers((prev) =>
      prev.map((u) => (u.id === user.id ? { ...u, savingsBalance: u.savingsBalance + amount } : u))
    );

    dbService.adjustBalance(user.phone, 'savings', 'CREDIT', amount, {
      reason: `Received from ${senderName}`,
      reference: refId,
      skipSms: true,
    });

    const creditTx: Transaction = {
      id: `tx_inw_${Date.now()}`,
      userId: user.id,
      userPhone: user.phone,
      title: senderName || 'Inward Payment',
      subTitle: note || `Received via QR Scan (Ref: ${refId})`,
      amount: amount,
      type: 'credit',
      category: 'transfer',
      timestamp: getNowBankingTimestamp(),
      status: 'SUCCESS',
      paymentMode: 'SAVINGS_AC',
      upiRefId: refId,
      fraudFlag: 'CLEAN',
      beneficiaryAccount: user.accountNumber,
      beneficiaryName: user.name,
      smsDispatched: true,
    };
    setTransactions((prev) => [creditTx, ...prev]);
    dbService.recordTransaction(creditTx);

    // Send Twilio Transactional CREDIT SMS to Registered Mobile
    if (user.phone) {
      smsService.sendTransactionalAlert({
        phone: user.phone,
        type: 'CREDIT',
        amount: amount,
        beneficiaryOrTitle: senderName || 'Inward Transfer',
        accountEnding: user.accountNumber?.slice(-4),
        upiRefId: refId,
        balance: newBal,
        accountType: 'SAVINGS_AC',
      }).catch((err) => console.warn('[Inward Credit Twilio SMS Error]', err));
    }

    // Modern Banking Inward Credit Alert Email
    if (user.email) {
      emailService.sendTransactionEmail(user, creditTx, newBal).catch((err) =>
        console.warn('[Inward Credit Email Alert Error]', err)
      );
    }

    speakSoundboxAlert(amount, language);
  };

  // Handler: Term Deposit / FD Booking
  const handleOpenTermDeposit = (pot: SavingsPot, amount: number) => {
    if (!user) return;
    const refId = `FD${Date.now().toString().slice(-8)}`;
    const newSavingsBal = Math.max(0, user.savingsBalance - amount);
    const newFdBal = user.fixedDepositBalance + amount;

    setUser((prev) =>
      prev
        ? {
            ...prev,
            savingsBalance: newSavingsBal,
            fixedDepositBalance: newFdBal,
          }
        : null
    );
    setUsers((prev) =>
      prev.map((u) =>
        u.id === user.id
          ? {
              ...u,
              savingsBalance: newSavingsBal,
              fixedDepositBalance: newFdBal,
            }
          : u
      )
    );

    const potName = pot.title || pot.name || 'Fixed Deposit';
    dbService.adjustBalance(user.phone, 'savings', 'DEBIT', amount, {
      reason: `Term Deposit Booking (${potName})`,
      reference: refId,
      skipSms: true,
    });
    dbService.adjustBalance(user.phone, 'fixedDeposit', 'CREDIT', amount, {
      reason: `Term Deposit Created (${potName})`,
      reference: refId,
      skipSms: true,
    });

    const fdTx: Transaction = {
      id: `tx_fd_${Date.now()}`,
      userId: user.id,
      userPhone: user.phone,
      title: `Term Deposit: ${potName}`,
      subTitle: `Axis Bank Fixed Deposit Booking (Ref: ${refId})`,
      amount: amount,
      type: 'debit',
      category: 'savings',
      timestamp: getNowBankingTimestamp(),
      status: 'SUCCESS',
      paymentMode: 'SAVINGS_AC',
      upiRefId: refId,
      fraudFlag: 'CLEAN',
      beneficiaryAccount: user.accountNumber,
      beneficiaryName: user.name,
      smsDispatched: true,
    };
    setTransactions((prev) => [fdTx, ...prev]);
    dbService.recordTransaction(fdTx);

    // Send Twilio Transactional DEBIT SMS to Registered Mobile
    if (user.phone) {
      smsService.sendTransactionalAlert({
        phone: user.phone,
        type: 'DEBIT',
        amount: amount,
        beneficiaryOrTitle: `Term Deposit ${potName}`,
        accountEnding: user.accountNumber?.slice(-4),
        upiRefId: refId,
        balance: newSavingsBal,
        accountType: 'SAVINGS_AC',
      }).catch((err) => console.warn('[Term Deposit Twilio SMS Error]', err));
    }
  };

  const handleOpenPay = (mode: 'qr' | 'contact' | 'upi' | 'bank' | 'bill', billName?: string) => {
    if (user?.isBlocked) {
      alert(`⚠️ Account Frozen: Outward transactions are suspended for this account.\nReason: ${user.blockReason || 'Administrative Freeze'}.\nPlease contact branch administration or open Officer Terminal to unblock.`);
      return;
    }
    setPayInitialTab(mode);
    setPayInitialBill(billName);
    setIsPayModalOpen(true);
  };

  const handleUpdateBiometrics = (enabled: boolean, limit: number) => {
    setUser((prev) => (prev ? { ...prev, biometricEnabled: enabled, biometricLimit: limit } : null));
    if (user) {
      setUsers((prev) =>
        prev.map((u) =>
          u.id === user.id ? { ...u, biometricEnabled: enabled, biometricLimit: limit } : u
        )
      );
    }
  };

  const handleToggleSoundbox = (enabled: boolean) => {
    setUser((prev) => (prev ? { ...prev, soundboxVoiceAlerts: enabled } : null));
  };

  const handleChangeSoundboxLanguage = (lang: LanguageCode) => {
    setUser((prev) => (prev ? { ...prev, soundboxLanguage: lang } : null));
  };

  const handleAddMoneyToPot = (potId: string, amount: number) => {
    setSavingsPots((prev) =>
      prev.map((pot) =>
        pot.id === potId
          ? { ...pot, currentAmount: pot.currentAmount + amount }
          : pot
      )
    );
    setUser((prev) => (prev ? { ...prev, savingsBalance: Math.max(0, prev.savingsBalance - amount) } : null));

    const potName = savingsPots.find((p) => p.id === potId)?.title || 'Savings Pot';
    const newTx: Transaction = {
      id: `tx_${Date.now()}`,
      userId: user?.id,
      userPhone: user?.phone,
      title: `Deposit to ${potName}`,
      subTitle: 'Axis Bank VIP Corporate Reserve',
      amount: amount,
      type: 'debit',
      category: 'invest',
      timestamp: getNowBankingTimestamp(),
      status: 'SUCCESS',
      paymentMode: 'SAVINGS_AC',
      upiRefId: `SAV/${Math.floor(100000000000 + Math.random() * 900000000000)}`,
      fraudFlag: 'CLEAN',
    };
    setTransactions((prev) => [newTx, ...prev]);
    dbService.recordTransaction(newTx);
  };

  const handleOfflinePayment = (amount: number, recipient: string) => {
    const offlineTx: Transaction = {
      id: `tx_off_${Date.now()}`,
      userId: user?.id,
      userPhone: user?.phone,
      title: recipient,
      subTitle: 'Offline Mode Transaction (USSD / UPI Lite)',
      amount: amount,
      type: 'debit',
      category: 'transfer',
      timestamp: 'Offline (Queued)',
      status: 'SUCCESS',
      paymentMode: 'UPI_LITE',
      upiRefId: `OFFLINE/${Math.floor(100000 + Math.random() * 900000)}`,
      fraudFlag: 'CLEAN',
      smsDispatched: true,
    };
    setTransactions((prev) => [offlineTx, ...prev]);
    dbService.recordTransaction(offlineTx);

    const updatedBal = Math.max(0, (user?.upiLiteBalance || 0) - amount);
    setUser((prev) => (prev ? { ...prev, upiLiteBalance: updatedBal } : null));

    if (user?.phone) {
      dbService.adjustBalance(user.phone, 'upiLite', 'DEBIT', amount, {
        reason: `Offline Payment to ${recipient}`,
        reference: offlineTx.upiRefId,
        skipSms: true,
      });

      smsService.sendTransactionalAlert({
        phone: user.phone,
        type: 'DEBIT',
        amount: amount,
        beneficiaryOrTitle: recipient,
        accountEnding: user.accountNumber?.slice(-4),
        upiRefId: offlineTx.upiRefId,
        balance: updatedBal,
        accountType: 'UPI_LITE',
      }).catch((err) => console.warn('[Offline Payment Twilio SMS Error]', err));
    }
  };

  // Customer Authentication & Onboarding Handlers
  const handleCustomerLogin = (selectedUser: UserProfile) => {
    if (selectedUser.isBlocked) {
      alert(
        `⛔ Account Blocked: Account ${selectedUser.accountNumber} has been blocked/frozen by Branch Administration (${
          selectedUser.blockReason || 'Administrative freeze'
        }). Login is disabled until the account is unblocked by an admin.`
      );
      return;
    }
    const sessionToken = selectedUser.activeSessionToken || generateSessionToken();
    const userWithSession: UserProfile = {
      ...selectedUser,
      activeSessionToken: sessionToken,
    };
    setUser(userWithSession);
    setUsers((prev) => prev.map((u) => (u.id === selectedUser.id ? userWithSession : u)));
    localStorage.setItem('axis_active_user_id', selectedUser.id);
    localStorage.setItem('axis_active_session_token', sessionToken);
    dbService.saveUser(userWithSession);
    dbService.updateSessionToken(selectedUser.id, sessionToken);
    if (selectedUser.seniorMode) {
      setIsSeniorMode(true);
    }
  };

  const handleCustomerRegister = (newUser: UserProfile) => {
    setUsers((prev) => [newUser, ...prev]);
    // Online registration must be approved by Branch Officer before auto-login
    if (newUser.accountStatus !== 'PENDING_APPROVAL') {
      const sessionToken = generateSessionToken();
      const userWithSession: UserProfile = {
        ...newUser,
        activeSessionToken: sessionToken,
      };
      setUser(userWithSession);
      localStorage.setItem('axis_active_user_id', newUser.id);
      localStorage.setItem('axis_active_session_token', sessionToken);
      dbService.saveUser(userWithSession);
      dbService.updateSessionToken(newUser.id, sessionToken);
    } else {
      dbService.saveUser(newUser);
    }

    const initialDepositTx: Transaction = {
      id: `tx_init_${Date.now()}`,
      userId: newUser.id,
      userPhone: newUser.phone,
      title: 'Digital Account Opening Deposit',
      subTitle: 'Axis Bank CC VIP Onboarding',
      amount: newUser.savingsBalance,
      type: 'credit',
      category: 'transfer',
      timestamp: getNowBankingTimestamp(),
      status: 'SUCCESS',
      paymentMode: 'SAVINGS_AC',
      upiRefId: `AXIS${Date.now().toString().slice(-8)}`,
      fraudFlag: 'CLEAN',
      beneficiaryName: newUser.name,
      beneficiaryAccount: newUser.accountNumber,
    };
    setTransactions((prev) => [initialDepositTx, ...prev]);
    dbService.recordTransaction(initialDepositTx);

    // Modern Banking Welcome Email Dispatch
    if (newUser.email) {
      emailService.sendWelcomeEmail(newUser).catch((err) =>
        console.warn('[Welcome Email Notice]:', err)
      );
    }

    const welcomeAlert: PushAlert = {
      id: `alert_welcome_${Date.now()}`,
      userId: newUser.id,
      title: `Account Registered: Welcome to Axis Bank CC VIP, ${newUser.name}!`,
      body: `Your A/C ${newUser.accountNumber} has been registered. Dashboard unlocks upon Admin authorization.`,
      time: getNowBankingTimestamp(),
      read: false,
      type: 'TRANSACTION',
      amount: newUser.savingsBalance,
    };
    setPushAlerts((prev) => [welcomeAlert, ...prev]);
  };

  const handleCustomerLogout = () => {
    if (user) {
      dbService.updateSessionToken(user.id, '');
    }
    setUser(null);
    localStorage.removeItem('axis_active_user_id');
    localStorage.removeItem('axis_active_session_token');
    setIsAuthModalOpen(false);
  };

  // Comprehensive Admin Panel Handlers
  const handleSelectUser = (selectedUser: UserProfile) => {
    const fresh = users.find((u) => u.id === selectedUser.id) || selectedUser;
    if (fresh.isBlocked) {
      alert(
        `⚠️ Cannot switch to frozen account: A/C ${fresh.accountNumber} (${fresh.name}) is currently blocked by administration.\nReason: ${
          fresh.blockReason || 'Administrative Freeze'
        }.\nUnblock the account first before accessing it.`
      );
      return;
    }
    setUser(fresh);
    if (fresh.seniorMode) {
      setIsSeniorMode(true);
    }
  };

  const handleUpdateUser = (updatedUser: UserProfile) => {
    setUsers((prev) => {
      const next = prev.map((u) => (u.id === updatedUser.id ? updatedUser : u));
      try {
        localStorage.setItem('axis_users', JSON.stringify(next));
      } catch (e) {
        // ignore
      }
      return next;
    });

    if (user?.id === updatedUser.id) {
      setUser(updatedUser);
      if (updatedUser.seniorMode !== undefined) {
        setIsSeniorMode(Boolean(updatedUser.seniorMode));
      }
    }

    dbService.saveUser(updatedUser).catch((err) => {
      console.error('Failed to persist user updates to database:', err);
    });

    const editAlert: PushAlert = {
      id: `alert_edit_${Date.now()}`,
      userId: updatedUser.id,
      title: 'Customer Details Updated',
      body: `Account & personal details for A/C ${updatedUser.accountNumber} (${updatedUser.name}) were updated by Branch Administration.`,
      time: getNowBankingTimestamp(),
      read: false,
      type: 'SECURITY',
    };
    setPushAlerts((prev) => [editAlert, ...prev]);
  };

  const handleCreateUser = (newUser: UserProfile, initialDepositTx?: Transaction) => {
    setUsers((prev) => [newUser, ...prev]);
    dbService.saveUser(newUser);
    if (initialDepositTx) {
      const scopedInitTx: Transaction = {
        ...initialDepositTx,
        userId: newUser.id,
        userPhone: newUser.phone,
        timestamp: initialDepositTx.timestamp && initialDepositTx.timestamp !== 'Just now'
          ? initialDepositTx.timestamp
          : getNowBankingTimestamp(),
        beneficiaryAccount: newUser.accountNumber,
        beneficiaryName: newUser.name,
        smsDispatched: true,
      };
      setTransactions((prev) => [scopedInitTx, ...prev]);
      dbService.recordTransaction(scopedInitTx);

      if (newUser.phone && newUser.savingsBalance > 0) {
        smsService.sendTransactionalAlert({
          phone: newUser.phone,
          type: 'CREDIT',
          amount: newUser.savingsBalance,
          beneficiaryOrTitle: 'Initial Account Opening Deposit',
          accountEnding: newUser.accountNumber.slice(-4),
          upiRefId: scopedInitTx.upiRefId,
          balance: newUser.savingsBalance,
          accountType: 'SAVINGS_AC',
        }).catch((err) => console.warn('[Account Opening SMS Error]', err));
      }
    }
    const welcomeAlert: PushAlert = {
      id: `alert_welcome_${Date.now()}`,
      userId: newUser.id,
      title: `Account Activated: Welcome to Axis Bank CC VIP, ${newUser.name}!`,
      body: `Your A/C *${newUser.accountNumber.slice(-4)} and UPI ID ${newUser.upiId} are active.`,
      time: getNowBankingTimestamp(),
      read: false,
      type: 'TRANSACTION',
      amount: newUser.savingsBalance,
    };
    setPushAlerts((prev) => [welcomeAlert, ...prev]);
  };

  const handleBlockUser = async (userId: string, isBlocked: boolean, reason?: string) => {
    const finalReason = isBlocked ? reason || 'Administrative freeze by Branch' : undefined;

    setUsers((prev) =>
      prev.map((u) =>
        u.id === userId
          ? {
              ...u,
              isBlocked,
              blockReason: finalReason,
            }
          : u
      )
    );

    // If currently logged in as this user and account is blocked, terminate session immediately
    if (user?.id === userId && isBlocked) {
      setUser(null);
      localStorage.removeItem('axis_active_user_id');
      localStorage.removeItem('axis_active_session_token');
    } else if (user?.id === userId && !isBlocked) {
      setUser((prev) => (prev ? { ...prev, isBlocked: false, blockReason: undefined } : null));
    }

    // Persist to PostgreSQL database
    try {
      await dbService.blockUser(userId, isBlocked, finalReason);
    } catch (err) {
      console.error('Failed to persist block status to DB:', err);
    }

    const alertItem: PushAlert = {
      id: `alert_block_${Date.now()}`,
      userId,
      title: isBlocked ? 'Account Temporarily Frozen' : 'Account Re-Activated',
      body: isBlocked
        ? `Axis Bank Security: Account has been frozen. Reason: ${reason || 'Administrative Review'}. Contact branch.`
        : 'Axis Bank Alert: Your account freeze has been lifted by Branch Officer. Normal operations restored.',
      time: getNowBankingTimestamp(),
      read: false,
      type: 'SECURITY',
    };
    setPushAlerts((prev) => [alertItem, ...prev]);
  };

  const handleDeleteUser = async (userId: string) => {
    const targetUser = users.find((u) => u.id === userId);

    // Remove from local and stored users state
    setUsers((prev) => prev.filter((u) => u.id !== userId));

    // Terminate session if currently logged in as this user
    if (user?.id === userId) {
      setUser(null);
      localStorage.removeItem('axis_active_user_id');
      localStorage.removeItem('axis_active_session_token');
    }

    // Remove transactions linked to this user
    setTransactions((prev) => prev.filter((t) => t.userId !== userId));

    // Remove KYC applications linked to this user
    setKycApplications((prev) =>
      prev.filter(
        (k) =>
          k.id !== `kyc_${userId}` &&
          !(targetUser?.phone && k.phone && k.phone.replace(/\D/g, '').slice(-10) === targetUser.phone.replace(/\D/g, '').slice(-10))
      )
    );

    // Persist deletion to PostgreSQL
    try {
      await dbService.deleteUser(userId);
    } catch (err) {
      console.error('Failed to delete user from database:', err);
    }

    const alertItem: PushAlert = {
      id: `alert_del_${Date.now()}`,
      title: 'Customer Account Deleted',
      body: `Account ${targetUser?.accountNumber || userId} (${targetUser?.name || 'Customer'}) has been completely removed from core banking database.`,
      time: getNowBankingTimestamp(),
      read: false,
      type: 'SECURITY',
    };
    setPushAlerts((prev) => [alertItem, ...prev]);
  };

  const handleAdjustBalance = (action: {
    userId: string;
    type: 'CREDIT' | 'DEBIT';
    balanceType: 'savings' | 'wallet' | 'upiLite' | 'fixedDeposit';
    amount: number;
    reason: string;
    reference: string;
  }) => {
    const { userId, type, balanceType, amount, reason, reference } = action;

    setUsers((prev) =>
      prev.map((u) => {
        if (u.id !== userId) return u;
        const key =
          balanceType === 'savings'
            ? 'savingsBalance'
            : balanceType === 'wallet'
            ? 'walletBalance'
            : balanceType === 'upiLite'
            ? 'upiLiteBalance'
            : 'fixedDepositBalance';

        const currentVal = u[key] || 0;
        const updatedVal = type === 'CREDIT' ? currentVal + amount : Math.max(0, currentVal - amount);
        return { ...u, [key]: updatedVal };
      })
    );

    if (user?.id === userId) {
      setUser((prev) => {
        if (!prev) return null;
        const key =
          balanceType === 'savings'
            ? 'savingsBalance'
            : balanceType === 'wallet'
            ? 'walletBalance'
            : balanceType === 'upiLite'
            ? 'upiLiteBalance'
            : 'fixedDepositBalance';

        const currentVal = prev[key] || 0;
        const updatedVal = type === 'CREDIT' ? currentVal + amount : Math.max(0, currentVal - amount);
        return { ...prev, [key]: updatedVal };
      });
    }

    const targetUser = users.find((u) => u.id === userId);

    // Passbook Transaction
    const newTx: Transaction = {
      id: `tx_teller_${Date.now()}`,
      userId: userId,
      userPhone: targetUser?.phone,
      title: type === 'CREDIT' ? `Credit: ${reason}` : `Debit: ${reason}`,
      subTitle: `CBS Branch Terminal (${balanceType.toUpperCase()})`,
      amount: amount,
      type: type === 'CREDIT' ? 'credit' : 'debit',
      category: 'transfer',
      timestamp: getNowBankingTimestamp(),
      status: 'SUCCESS',
      paymentMode:
        balanceType === 'savings'
          ? 'SAVINGS_AC'
          : balanceType === 'wallet'
          ? 'WALLET'
          : balanceType === 'upiLite'
          ? 'UPI_LITE'
          : 'SAVINGS_AC',
      upiRefId: reference,
      fraudFlag: 'CLEAN',
      beneficiaryAccount: targetUser?.accountNumber,
      beneficiaryName: targetUser?.name,
      smsDispatched: true,
    };
    setTransactions((prev) => [newTx, ...prev]);
    dbService.recordTransaction(newTx);

    if (targetUser) {
      dbService.adjustBalance(targetUser.phone, balanceType, type, amount, {
        reason: reason,
        reference: reference,
        skipSms: true,
      });

      const key =
        balanceType === 'savings'
          ? 'savingsBalance'
          : balanceType === 'wallet'
          ? 'walletBalance'
          : balanceType === 'upiLite'
          ? 'upiLiteBalance'
          : 'fixedDepositBalance';
      const currentBal = targetUser[key] || 0;
      const finalBal = type === 'CREDIT' ? currentBal + amount : Math.max(0, currentBal - amount);

      if (targetUser.phone) {
        smsService.sendTransactionalAlert({
          phone: targetUser.phone,
          type: type === 'CREDIT' ? 'CREDIT' : 'DEBIT',
          amount: amount,
          beneficiaryOrTitle: reason || (type === 'CREDIT' ? 'CBS Branch Deposit' : 'CBS Branch Debit'),
          accountEnding: targetUser.accountNumber?.slice(-4),
          upiRefId: reference,
          balance: finalBal,
          accountType:
            balanceType === 'wallet'
              ? 'WALLET'
              : balanceType === 'upiLite'
              ? 'UPI_LITE'
              : 'SAVINGS_AC',
        }).catch((err) => console.warn('[Teller Adjust Balance SMS Error]', err));
      }

      // Modern Banking Transaction Alert Email
      if (targetUser.email) {
        emailService.sendTransactionEmail(targetUser, newTx, finalBal).catch((err) =>
          console.warn('[Teller Adjust Balance Email Error]', err)
        );
      }
    }

    // Push Alert
    const newAlert: PushAlert = {
      id: `alert_adj_${Date.now()}`,
      userId: userId,
      title: `₹${amount.toFixed(2)} ${type === 'CREDIT' ? 'Credited' : 'Debited'} via CBS Branch`,
      body: `${reason}. Ref: ${reference}`,
      time: getNowBankingTimestamp(),
      read: false,
      type: 'TRANSACTION',
      amount: amount,
    };
    setPushAlerts((prev) => [newAlert, ...prev]);
  };

  const handleToggleUserService = (
    userId: string,
    serviceKey: keyof UserServices,
    enabled: boolean
  ) => {
    setUsers((prev) =>
      prev.map((u) => {
        if (u.id !== userId) return u;
        const currentServices = u.services || DEFAULT_SERVICES;
        return {
          ...u,
          services: {
            ...currentServices,
            [serviceKey]: enabled,
          },
        };
      })
    );

    if (user?.id === userId) {
      setUser((prev) => {
        if (!prev) return null;
        const currentServices = prev.services || DEFAULT_SERVICES;
        return {
          ...prev,
          services: {
            ...currentServices,
            [serviceKey]: enabled,
          },
        };
      });
    }
  };

  const handleUpdateKycStatus = (
    userId: string,
    kycStatus: 'verified' | 'pending' | 'rejected'
  ) => {
    setUsers((prev) =>
      prev.map((u) => (u.id === userId ? { ...u, kycStatus } : u))
    );
    if (user?.id === userId) {
      setUser((prev) => (prev ? { ...prev, kycStatus } : null));
    }
  };

  const handleRollbackTransaction = (txId: string) => {
    const targetTx = transactions.find((t) => t.id === txId);
    if (!targetTx) return;

    const targetUserId = targetTx.userId || user?.id;
    const targetUser = users.find((u) => u.id === targetUserId);

    const revTx: Transaction = {
      id: `tx_rev_${Date.now()}`,
      userId: targetUserId,
      userPhone: targetTx.userPhone || targetUser?.phone,
      title: `Reversal of: ${targetTx.title}`,
      subTitle: `Reversal of Ref: ${targetTx.upiRefId}`,
      amount: targetTx.amount,
      type: targetTx.type === 'credit' ? 'debit' : 'credit',
      category: 'transfer',
      timestamp: getNowBankingTimestamp(),
      status: 'SUCCESS',
      paymentMode: targetTx.paymentMode,
      upiRefId: `REV/${Math.floor(100000000000 + Math.random() * 900000000000)}`,
      fraudFlag: 'CLEAN',
      smsDispatched: true,
    };
    setTransactions((prev) => [revTx, ...prev]);
    dbService.recordTransaction(revTx);

    if (targetUserId) {
      const isReversalCredit = targetTx.type === 'debit';
      setUsers((prev) =>
        prev.map((u) => {
          if (u.id === targetUserId) {
            const updated = isReversalCredit
              ? u.savingsBalance + targetTx.amount
              : Math.max(0, u.savingsBalance - targetTx.amount);
            return { ...u, savingsBalance: updated };
          }
          return u;
        })
      );
      if (user?.id === targetUserId) {
        setUser((prev) => {
          if (!prev) return null;
          const updated = isReversalCredit
            ? prev.savingsBalance + targetTx.amount
            : Math.max(0, prev.savingsBalance - targetTx.amount);
          return { ...prev, savingsBalance: updated };
        });
      }
      if (targetUser) {
        const finalBal = isReversalCredit
          ? targetUser.savingsBalance + targetTx.amount
          : Math.max(0, targetUser.savingsBalance - targetTx.amount);

        dbService.adjustBalance(
          targetUser.phone,
          'savings',
          isReversalCredit ? 'CREDIT' : 'DEBIT',
          targetTx.amount,
          {
            reason: `Reversal of ${targetTx.title}`,
            reference: revTx.upiRefId,
            skipSms: true,
          }
        );

        if (targetUser.phone) {
          smsService.sendTransactionalAlert({
            phone: targetUser.phone,
            type: isReversalCredit ? 'CREDIT' : 'DEBIT',
            amount: targetTx.amount,
            beneficiaryOrTitle: `Reversal: ${targetTx.title}`,
            accountEnding: targetUser.accountNumber?.slice(-4),
            upiRefId: revTx.upiRefId,
            balance: finalBal,
            accountType: 'SAVINGS_AC',
          }).catch((err) => console.warn('[Reversal SMS Error]', err));
        }
      }
    }
  };

  const handleApproveKyc = (id: string) => {
    const targetKyc = kycApplications.find((a) => a.id === id);
    setKycApplications((prev) =>
      prev.map((app) => (app.id === id ? { ...app, status: 'APPROVED' } : app))
    );
    dbService.updateKycStatus(id, 'APPROVED');

    // Also activate the matching user's account if pending
    if (targetKyc) {
      const cleanKycPhone = targetKyc.phone ? targetKyc.phone.replace(/\D/g, '').slice(-10) : '';
      setUsers((prev) =>
        prev.map((u) => {
          const isMatch =
            id === `kyc_${u.id}` ||
            Boolean(cleanKycPhone && u.phone && u.phone.replace(/\D/g, '').slice(-10) === cleanKycPhone);
          if (isMatch) {
            const updated: UserProfile = { ...u, accountStatus: 'APPROVED', kycStatus: 'verified' };
            dbService.saveUser(updated);
            dbService.updateUserStatus(u.id, 'APPROVED');
            return updated;
          }
          return u;
        })
      );
    }
  };

  const handleRejectKyc = (id: string, reason?: string) => {
    const targetKyc = kycApplications.find((a) => a.id === id);
    const rejReason = reason || 'KYC verification failed';
    setKycApplications((prev) =>
      prev.map((app) => (app.id === id ? { ...app, status: 'REJECTED' } : app))
    );
    dbService.updateKycStatus(id, 'REJECTED');

    if (targetKyc) {
      const cleanKycPhone = targetKyc.phone ? targetKyc.phone.replace(/\D/g, '').slice(-10) : '';
      setUsers((prev) =>
        prev.map((u) => {
          const isMatch =
            id === `kyc_${u.id}` ||
            Boolean(cleanKycPhone && u.phone && u.phone.replace(/\D/g, '').slice(-10) === cleanKycPhone);
          if (isMatch) {
            const updated: UserProfile = { ...u, accountStatus: 'REJECTED', rejectionReason: rejReason, kycStatus: 'rejected' };
            dbService.saveUser(updated);
            dbService.updateUserStatus(u.id, 'REJECTED', rejReason);
            return updated;
          }
          return u;
        })
      );
    }
  };

  const handleBroadcastAlert = (alert: PushAlert, targetSegment?: string) => {
    setPushAlerts((prev) => [alert, ...prev]);
  };

  const handleApproveTransaction = (txId: string) => {
    const targetTx = transactions.find((t) => t.id === txId);
    if (!targetTx) return;

    setTransactions((prev) =>
      prev.map((t) =>
        t.id === txId
          ? {
              ...t,
              status: 'SUCCESS',
              approvalStatus: 'APPROVED',
            }
          : t
      )
    );

    dbService.updateTransactionStatus(txId, 'SUCCESS');

    const approveAlert: PushAlert = {
      id: `alert_appr_${Date.now()}`,
      userId: targetTx.userId || user?.id,
      title: `Transfer of ₹${targetTx.amount.toFixed(2)} Approved & Cleared`,
      body: `Treasury clearance complete for transfer to ${targetTx.beneficiaryName || targetTx.recipient || targetTx.title}. Ref: ${targetTx.utrNumber || targetTx.id}`,
      time: getNowBankingTimestamp(),
      read: false,
      type: 'TRANSACTION',
      amount: targetTx.amount,
    };
    setPushAlerts((prev) => [approveAlert, ...prev]);
  };

  const handleRejectTransaction = (txId: string, reason?: string) => {
    const targetTx = transactions.find((t) => t.id === txId);
    if (!targetTx) return;

    const returnReason = reason || 'Beneficiary verification failed';

    // 1. Mark transaction as REJECTED
    setTransactions((prev) =>
      prev.map((t) =>
        t.id === txId
          ? {
              ...t,
              status: 'REJECTED',
              approvalStatus: 'REJECTED',
              rejectionReason: returnReason,
            }
          : t
      )
    );

    dbService.updateTransactionStatus(txId, 'REJECTED', returnReason);

    // 2. Refund money back to the sender's savings account
    setUsers((prev) =>
      prev.map((u) => {
        if (u.id === targetTx.userId || (user && u.id === user.id)) {
          return { ...u, savingsBalance: u.savingsBalance + targetTx.amount };
        }
        return u;
      })
    );

    if (user && (user.id === targetTx.userId || !targetTx.userId)) {
      setUser((prev) =>
        prev ? { ...prev, savingsBalance: prev.savingsBalance + targetTx.amount } : null
      );
    }

    // 3. Record reversal transaction in passbook
    const refundTx: Transaction = {
      id: `tx_ref_${Date.now()}`,
      userId: targetTx.userId || user?.id,
      userPhone: targetTx.userPhone || user?.phone,
      title: `Refund: Transfer Returned (${returnReason})`,
      subTitle: `Reversal of Ref: ${targetTx.utrNumber || targetTx.id}`,
      amount: targetTx.amount,
      type: 'credit',
      category: 'transfer',
      timestamp: getNowBankingTimestamp(),
      status: 'SUCCESS',
      paymentMode: 'SAVINGS_AC',
      upiRefId: `RET/${Math.floor(100000000000 + Math.random() * 900000000000)}`,
      fraudFlag: 'CLEAN',
    };
    setTransactions((prev) => [refundTx, ...prev]);
    dbService.recordTransaction(refundTx);

    // 4. Alert user
    const rejectAlert: PushAlert = {
      id: `alert_rej_${Date.now()}`,
      userId: targetTx.userId || user?.id,
      title: `₹${targetTx.amount.toFixed(2)} Transfer Returned & Refunded`,
      body: `Notice: Transfer could not be cleared (${returnReason}). Full funds reversed to Savings Account.`,
      time: getNowBankingTimestamp(),
      read: false,
      type: 'SECURITY',
      amount: targetTx.amount,
    };
    setPushAlerts((prev) => [rejectAlert, ...prev]);
  };

  const handleHoldTransaction = (txId: string, reason?: string) => {
    const holdReason = reason || 'Under administrative review';
    const targetTx = transactions.find((t) => t.id === txId);

    setTransactions((prev) =>
      prev.map((t) =>
        t.id === txId
          ? {
              ...t,
              status: 'HOLD',
              approvalStatus: 'HOLD',
              approvalReason: holdReason,
            }
          : t
      )
    );
    dbService.updateTransactionStatus(txId, 'HOLD', holdReason);

    const holdAlert: PushAlert = {
      id: `alert_hold_${Date.now()}`,
      userId: targetTx?.userId || user?.id,
      title: `Transfer Status: Under Review`,
      body: `Notice: Transfer has been placed on temporary hold (${holdReason}) pending branch officer clearance.`,
      time: getNowBankingTimestamp(),
      read: false,
      type: 'SECURITY',
    };
    setPushAlerts((prev) => [holdAlert, ...prev]);
  };

  const handleEditTransaction = (txId: string, updates: Partial<Transaction>) => {
    setTransactions((prev) =>
      prev.map((t) => (t.id === txId ? { ...t, ...updates } : t))
    );
    dbService.updateTransaction(txId, updates);
  };

  const handleDeleteTransaction = (txId: string) => {
    setTransactions((prev) => prev.filter((t) => t.id !== txId));
    dbService.deleteTransaction(txId);
  };

  const handleSetUserMpin = (userId: string, newMpin: string) => {
    setUsers((prev) =>
      prev.map((u) => (u.id === userId ? { ...u, mpin: newMpin } : u))
    );
    if (user?.id === userId) {
      setUser((prev) => (prev ? { ...prev, mpin: newMpin } : null));
    }
    const target = users.find((u) => u.id === userId);
    if (target) {
      dbService.saveUser({ ...target, mpin: newMpin });
    }
  };

  // ----------------------------------------------------
  // RENDER BRANCH 1: Dedicated Branch Officer & CBS Admin Console
  // ----------------------------------------------------
  if (portal === 'ADMIN') {
    return (
      <OfficerAdminApp
        users={users}
        currentUser={user}
        onSelectUser={handleSelectUser}
        onUpdateUser={handleUpdateUser}
        onCreateUser={handleCreateUser}
        onBlockUser={handleBlockUser}
        onAdjustBalance={handleAdjustBalance}
        onToggleUserService={handleToggleUserService}
        onUpdateKycStatus={handleUpdateKycStatus}
        kycApplications={kycApplications}
        onApproveKyc={handleApproveKyc}
        onRejectKyc={handleRejectKyc}
        transactions={transactions}
        onRollbackTransaction={handleRollbackTransaction}
        onBroadcastAlert={handleBroadcastAlert}
        onSwitchToCustomerApp={handleSwitchToCustomer}
        onApproveTransaction={handleApproveTransaction}
        onRejectTransaction={handleRejectTransaction}
        onHoldTransaction={handleHoldTransaction}
        onEditTransaction={handleEditTransaction}
        onDeleteTransaction={handleDeleteTransaction}
        onSetUserMpin={handleSetUserMpin}
        onDeleteUser={handleDeleteUser}
      />
    );
  }

  // ----------------------------------------------------
  // RENDER BRANCH 2: Customer Login / Advisory Portal
  // (Standard production banking entry: clean login, real phone & MPIN verification)
  // ----------------------------------------------------
  if (!user) {
    return (
      <CustomerAuthPage
        users={users}
        onLogin={handleCustomerLogin}
        onRegister={handleCustomerRegister}
        language={language}
        onLanguageChange={setLanguage}
      />
    );
  }

  // ----------------------------------------------------
  // RENDER BRANCH 3: Authenticated Customer Mobile Banking Dashboard
  // ----------------------------------------------------
  return (
    <div
      className={`min-h-screen bg-slate-50 text-slate-900 font-sans antialiased pb-24 ${
        highContrast ? 'contrast-125 saturate-150' : ''
      }`}
    >
      {/* Top Header */}
      <AirtelHeader
        user={user}
        language={language}
        onLanguageChange={setLanguage}
        isOffline={isOffline}
        onToggleOffline={() => setIsOffline(!isOffline)}
        highContrast={highContrast}
        onToggleHighContrast={() => setHighContrast(!highContrast)}
        unreadAlertsCount={customerAlerts.filter((a) => !a.read).length}
        onOpenNotifications={() => setIsPushDrawerOpen(true)}
        onOpenProfile={() => setIsAuthModalOpen(true)}
        onLogout={handleCustomerLogout}
        onOpenSoundboxTest={() => speakSoundboxAlert(100, user.soundboxLanguage || 'en')}
        onOpenAndroidGuide={() => setIsAndroidModalOpen(true)}
        onToggleSeniorMode={() => setIsSeniorMode(!isSeniorMode)}
        isSeniorMode={isSeniorMode}
      />

      {/* Main Content Area */}
      <main className="max-w-4xl mx-auto px-3 sm:px-4 pt-3 sm:pt-4 space-y-4">
        {/* Account Freeze Alert Banner */}
        {user.isBlocked && (
              <div className="bg-rose-50 border-2 border-rose-300 p-4 rounded-3xl flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 text-rose-950 shadow-sm animate-in slide-in-from-top-2">
                <div className="flex items-start gap-3">
                  <div className="w-10 h-10 rounded-2xl bg-rose-600 text-white flex items-center justify-center flex-shrink-0 shadow-sm mt-0.5 sm:mt-0">
                    <Lock className="w-5 h-5" />
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <h4 className="text-xs font-black uppercase tracking-wider text-rose-800">
                        Account Frozen by Branch Administration
                      </h4>
                      <span className="px-2 py-0.5 rounded-md bg-rose-200 text-rose-900 text-[10px] font-black uppercase">
                        Debit Blocked
                      </span>
                    </div>
                    <p className="text-xs text-rose-700 font-medium mt-0.5">
                      {user.blockReason || 'Administrative Compliance / KYC Action. Outward payments and debit transfers are disabled.'}
                    </p>
                  </div>
                </div>
                <div className="flex-shrink-0 text-right sm:text-left">
                  <span className="text-[10px] uppercase tracking-wider font-bold text-rose-600 block">Home Branch Support</span>
                  <span className="text-xs font-black text-rose-950">1800-345-3030 (Toll-Free)</span>
                </div>
              </div>
            )}

            {/* Offline Notice Banner if simulated offline */}
            {isOffline && (
              <div className="bg-amber-50 border border-amber-300 p-3.5 rounded-2xl flex items-center justify-between text-amber-900 text-xs shadow-2xs">
                <div className="flex items-center gap-2">
                  <WifiOff className="w-4 h-4 text-amber-600 animate-pulse flex-shrink-0" />
                  <span>
                    <strong>Offline Mode Active:</strong> You can pay with UPI Lite or dial *99# USSD without data.
                  </span>
                </div>
                <button
                  onClick={() => setIsOfflineModalOpen(true)}
                  className="px-3 py-1.5 bg-amber-500 text-slate-950 font-black uppercase tracking-wider rounded-xl hover:bg-amber-400 transition text-[11px] shadow-2xs flex-shrink-0"
                >
                  Offline Banking
                </button>
              </div>
            )}

            {/* If Senior Citizen Mode is active */}
            {isSeniorMode ? (
              <SeniorModeView
                user={user}
                language={language}
                onSendMoney={() => handleOpenPay('contact')}
                onScanQr={() => handleOpenPay('qr')}
                onPayElectricity={() => handleOpenPay('bill', 'Electricity Bill')}
                onOpenSahayak={() => setIsSahayakOpen(true)}
                onExitSeniorMode={() => setIsSeniorMode(false)}
              />
            ) : (
              <>
                {/* VIEW 1: HOME DASHBOARD */}
                {activeTab === 'HOME' && (
                  <div className="space-y-4 animate-in fade-in duration-300">
                    {/* Axis Bank VIP Card Carousel & Accounts */}
                    <BalanceCard
                      user={user}
                      language={language}
                      onSendMoney={() => handleOpenPay('contact')}
                      onScanQr={() => handleOpenPay('qr')}
                      onAddMoney={() => setIsAddBalanceModalOpen(true)}
                      onReceiveMoney={() => setIsReceiveModalOpen(true)}
                      onSelfTransfer={() => setIsSelfTransferModalOpen(true)}
                      onOpenTermDeposit={() => setIsTermDepositModalOpen(true)}
                      onOpenPassbook={() => setActiveTab('PASSBOOK')}
                      onOpenBiometrics={() => setIsBiometricModalOpen(true)}
                      onOpenUpiLite={() => setIsOfflineModalOpen(true)}
                      onOpenAccountDetails={() => setIsAuthModalOpen(true)}
                      onOpenBusinessLoan={() => setIsBusinessLoanOpen(true)}
                    />

                    {/* Axis Bank VIP Business Loan Showcase Banner */}
                    <div className="relative overflow-hidden rounded-3xl bg-gradient-to-r from-[#580824] via-[#861F41] to-[#97144D] p-5 sm:p-6 text-white shadow-lg border border-[#700a2f]">
                      <div className="absolute -right-10 -bottom-10 w-44 h-44 rounded-full bg-amber-400/10 blur-2xl pointer-events-none" />
                      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 relative z-10">
                        <div className="space-y-1.5 max-w-lg">
                          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-black/25 backdrop-blur-xs border border-amber-400/30 text-[10px] font-black uppercase tracking-wider text-amber-300">
                            <Briefcase className="w-3 h-3 text-amber-300" />
                            <span>Pre-Approved VIP Business Term Loan</span>
                          </div>
                          <h3 className="text-lg sm:text-xl font-black text-white tracking-tight">
                            Instant Business Expansion up to ₹50,00,000
                          </h3>
                          <p className="text-xs text-rose-100/90 font-medium">
                            Collateral-free instant credit with zero processing fee for VIP clients. Disbursed directly into your account in 60 seconds.
                          </p>
                          <div className="flex flex-wrap items-center gap-3 pt-1 text-[11px] text-amber-200/90 font-bold">
                            <span className="flex items-center gap-1">
                              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" /> Interest from 9.99% p.a.
                            </span>
                            <span className="flex items-center gap-1">
                              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" /> Instant Sanction Letter
                            </span>
                            <span className="flex items-center gap-1">
                              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" /> Zero Collateral
                            </span>
                          </div>
                        </div>
                        <button
                          type="button"
                          onClick={() => setIsBusinessLoanOpen(true)}
                          className="px-5 py-3 rounded-2xl bg-amber-400 hover:bg-amber-300 text-slate-950 font-black text-xs uppercase tracking-wider shadow-lg transition active:scale-95 whitespace-nowrap flex items-center gap-2 flex-shrink-0 cursor-pointer"
                        >
                          <Briefcase className="w-4 h-4" />
                          <span>Avail Loan Now</span>
                        </button>
                      </div>
                    </div>

                    {/* VIP Banking & BBPS Services Grid */}
                    <QuickServicesGrid
                      language={language}
                      onSelectService={(svc) => handleOpenPay('bill', svc)}
                      onOpenScanQr={() => handleOpenPay('qr')}
                      onOpenSendMoney={() => handleOpenPay('contact')}
                      onOpenBusinessLoan={() => setIsBusinessLoanOpen(true)}
                      onOpenVirtualCards={() => setActiveTab('CARDS')}
                      onOpenServices={() => setActiveTab('SERVICES')}
                    />

                    {/* Mini Passbook Recent View */}
                    <PassbookView
                      transactions={customerTransactions.slice(0, 5)}
                      language={language}
                    />

                    {/* Smart Financial Advisory Card */}
                    <div className="bg-white border border-slate-200 rounded-3xl p-5 text-slate-900 shadow-2xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                      <div className="space-y-1">
                        <span className="text-[10px] font-black text-[#861F41] uppercase tracking-wider flex items-center gap-1">
                          <Sparkles className="w-3.5 h-3.5 text-[#861F41]" />
                          Axis VIP High-Yield Treasury
                        </span>
                        <h3 className="text-base font-black text-slate-900">
                          Grow liquidity with Axis Bank CC VIP 7.5% Term Deposits
                        </h3>
                        <p className="text-xs text-slate-500 font-medium">
                          RBI regulated • Instant liquidity & corporate sweep-in facilities
                        </p>
                      </div>
                      <button
                        onClick={() => setActiveTab('BUDGET')}
                        className="px-4 py-2.5 rounded-xl bg-[#861F41] hover:bg-[#580824] text-amber-300 font-black text-xs uppercase tracking-wider whitespace-nowrap shadow-md shadow-rose-950/20 transition active:scale-95 self-start sm:self-center"
                      >
                        View Reserves
                      </button>
                    </div>
                  </div>
            )}

            {/* VIEW 2: VIRTUAL DEBIT CARDS MANAGER */}
            {activeTab === 'CARDS' && (
              <div className="animate-in fade-in duration-300">
                <VirtualCardsManager
                  user={user}
                  onUpdateUser={handleUpdateUser}
                />
              </div>
            )}

            {/* VIEW 3: FULL PASSBOOK & STATEMENT */}
            {activeTab === 'PASSBOOK' && (
              <div className="animate-in fade-in duration-300">
                <PassbookView
                  transactions={customerTransactions}
                  language={language}
                />
              </div>
            )}

            {/* VIEW 4: SERVICES & PROFILE UPDATE MANAGER */}
            {activeTab === 'SERVICES' && (
              <div className="animate-in fade-in duration-300">
                <ServicesAndUpdateModal
                  user={user}
                  isOpen={true}
                  onClose={() => setActiveTab('HOME')}
                  onUpdateUser={handleUpdateUser}
                />
              </div>
            )}

            {/* VIEW 5: BUDGET TRACKING & GULLAK */}
            {activeTab === 'BUDGET' && (
              <div className="animate-in fade-in duration-300">
                <BudgetTracker
                  user={user}
                  language={language}
                  categorySpends={customerBudgetSpends}
                  savingsPots={savingsPots}
                  transactions={customerTransactions}
                  onAddMoneyToPot={handleAddMoneyToPot}
                  onUpdateBudget={(val) => {}}
                />
              </div>
            )}

            {/* VIEW 6: SAHAYAK SUPPORT CHAT */}
            {activeTab === 'SAHAYAK' && (
              <div className="animate-in fade-in duration-300">
                <div className="bg-white border border-slate-200 rounded-3xl p-6 text-center space-y-4 shadow-2xs">
                  <h2 className="text-base font-black text-slate-900 uppercase tracking-wider">
                    Axis Sahayak VIP Concierge
                  </h2>
                  <p className="text-xs text-slate-500 max-w-md mx-auto font-medium">
                    Dedicated 24x7 intelligent banking assistant powered by Gemini AI designed for Axis Bank CC VIP cardholders and corporate treasury operations.
                  </p>
                  <button
                    onClick={() => setIsSahayakOpen(true)}
                    className="px-5 py-2.5 rounded-xl bg-[#861F41] hover:bg-[#580824] text-amber-300 font-black text-xs uppercase tracking-wider shadow-md shadow-rose-950/20 transition active:scale-95 cursor-pointer"
                  >
                    Open Live Sahayak Chat Window
                  </button>
                </div>
              </div>
            )}
          </>
        )}
      </main>

      {/* Persistent Floating Soundbox Controller */}
      <SoundboxWidget
        user={user}
        language={language}
        onToggleSoundbox={handleToggleSoundbox}
        onChangeSoundboxLanguage={handleChangeSoundboxLanguage}
      />

      {/* Bottom Tab Navigation */}
      <BottomNavBar
        currentTab={activeTab}
        language={language}
        onSelectTab={(tab) => {
          if (tab === 'SAHAYAK') {
            setIsSahayakOpen(true);
          } else {
            setActiveTab(tab);
          }
        }}
        onOpenQuickPay={() => handleOpenPay('qr')}
      />

      {/* ALL INTERACTIVE MODALS */}
      {/* 0. VIP Business Loan Modal */}
      {user && (
        <BusinessLoanModal
          isOpen={isBusinessLoanOpen}
          onClose={() => setIsBusinessLoanOpen(false)}
          user={user}
          onDisburseLoan={handleDisburseLoan}
        />
      )}

      {/* 1. Payment Modal */}
      <PayModal
        isOpen={isPayModalOpen}
        onClose={() => setIsPayModalOpen(false)}
        user={user}
        contacts={contacts}
        language={language}
        initialTab={payInitialTab}
        initialBillName={payInitialBill}
        onPaymentSuccess={handlePaymentSuccess}
        onOpenBiometrics={() => setIsBiometricModalOpen(true)}
      />

      {/* 2. Biometrics Configuration */}
      <BiometricModal
        isOpen={isBiometricModalOpen}
        onClose={() => setIsBiometricModalOpen(false)}
        user={user}
        language={language}
        onUpdateBiometrics={handleUpdateBiometrics}
      />

      {/* 3. Offline USSD / UPI Lite Banking */}
      <OfflineBankingModal
        isOpen={isOfflineModalOpen}
        onClose={() => setIsOfflineModalOpen(false)}
        user={user}
        language={language}
        onSyncQueuedTransfer={() => {}}
        onOfflinePayment={handleOfflinePayment}
      />

      {/* 4. Sahayak Chat Assistant */}
      <SahayakChat
        isOpen={isSahayakOpen}
        onClose={() => setIsSahayakOpen(false)}
        user={user}
        language={language}
      />

      {/* 5. Push Notification & SMS Alert Drawer */}
      <PushNotificationDrawer
        isOpen={isPushDrawerOpen}
        onClose={() => setIsPushDrawerOpen(false)}
        alerts={customerAlerts}
        onMarkAllRead={() =>
          setPushAlerts((prev) => prev.map((a) => ({ ...a, read: true })))
        }
        onClearAlert={(id) =>
          setPushAlerts((prev) => prev.filter((a) => a.id !== id))
        }
      />

      {/* 6. Customer Account Details & Verification Modal */}
      <CustomerAuthModal
        isOpen={isAuthModalOpen}
        onClose={() => setIsAuthModalOpen(false)}
        currentUser={user}
        onLogout={handleCustomerLogout}
        onUpdateUser={handleUpdateUser}
        language={language}
      />

      {/* 6a. Add Balance / Deposit Modal */}
      {user && (
        <AddBalanceModal
          isOpen={isAddBalanceModalOpen}
          onClose={() => setIsAddBalanceModalOpen(false)}
          user={user}
          language={language}
          onAddBalance={handleAddBalance}
        />
      )}

      {/* 6b. Receive Money / QR Code Modal */}
      {user && (
        <ReceiveMoneyModal
          isOpen={isReceiveModalOpen}
          onClose={() => setIsReceiveModalOpen(false)}
          user={user}
          language={language}
          onSimulateCredit={handleSimulateCredit}
          onPayUserQr={(_upiId, _name, _presetAmt) => {
            setIsReceiveModalOpen(false);
            handleOpenPay('upi');
          }}
        />
      )}

      {/* 6c. Internal Self Transfer Modal */}
      {user && (
        <SelfTransferModal
          isOpen={isSelfTransferModalOpen}
          onClose={() => setIsSelfTransferModalOpen(false)}
          user={user}
          language={language}
          onTransfer={handleSelfTransfer}
        />
      )}

      {/* 6d. Term Deposit / Fixed Deposit Booking Modal */}
      {user && (
        <TermDepositModal
          isOpen={isTermDepositModalOpen}
          onClose={() => setIsTermDepositModalOpen(false)}
          user={user}
          language={language}
          onOpenDeposit={handleOpenTermDeposit}
        />
      )}

      {/* 6e. Services & Profile Update Modal */}
      {user && (
        <ServicesAndUpdateModal
          isOpen={isServicesModalOpen}
          onClose={() => setIsServicesModalOpen(false)}
          user={user}
          onUpdateUser={handleUpdateUser}
        />
      )}

      {/* 7. Android & Native App Compilation Guide Modal */}
      <AndroidAppModal
        isOpen={isAndroidModalOpen}
        onClose={() => setIsAndroidModalOpen(false)}
      />

      {/* 8. Single Device Session Conflict Security Modal */}
      {sessionConflictAlert && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-md w-full p-6 text-center space-y-4 shadow-2xl border border-red-200 animate-in zoom-in-95">
            <div className="w-16 h-16 rounded-2xl bg-red-100 text-red-700 flex items-center justify-center mx-auto shadow-inner">
              <ShieldAlert className="w-9 h-9" />
            </div>
            <div className="space-y-2">
              <span className="text-[10px] font-black uppercase tracking-wider text-red-600 bg-red-50 border border-red-200 px-2.5 py-1 rounded-full">
                Single Device Login Policy
              </span>
              <h3 className="text-xl font-black text-slate-900">
                Session Terminated
              </h3>
              <p className="text-xs text-slate-600 font-medium leading-relaxed">
                {sessionConflictAlert}
              </p>
            </div>
            <button
              type="button"
              onClick={() => setSessionConflictAlert(null)}
              className="w-full py-3.5 rounded-2xl bg-[#861F41] hover:bg-[#580824] text-amber-300 font-black uppercase tracking-wider text-xs shadow-md transition active:scale-95 flex items-center justify-center gap-2 cursor-pointer"
            >
              <LogIn className="w-4 h-4" />
              <span>Acknowledge & Sign In Here</span>
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

export default App;
