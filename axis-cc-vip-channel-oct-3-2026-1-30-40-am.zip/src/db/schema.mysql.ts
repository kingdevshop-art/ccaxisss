import { relations } from 'drizzle-orm';
import {
  mysqlTable,
  int,
  varchar,
  text,
  double,
  boolean,
  datetime,
  json,
} from 'drizzle-orm/mysql-core';

export const users = mysqlTable('users', {
  id: int('id').autoincrement().primaryKey(),
  uid: varchar('uid', { length: 255 }).notNull().unique(),
  name: varchar('name', { length: 255 }).notNull(),
  phone: varchar('phone', { length: 50 }).notNull().unique(),
  email: varchar('email', { length: 255 }).notNull(),
  photoUrl: text('photo_url'),
  dob: varchar('dob', { length: 50 }),
  address: text('address'),
  ckycNumber: varchar('ckyc_number', { length: 50 }),
  upiId: varchar('upi_id', { length: 255 }).notNull(),
  accountNumber: varchar('account_number', { length: 50 }).notNull(),
  ifscCode: varchar('ifsc_code', { length: 50 }).notNull().default('UTIB000001'),
  savingsBalance: double('savings_balance').notNull().default(0),
  walletBalance: double('wallet_balance').notNull().default(0),
  upiLiteBalance: double('upi_lite_balance').notNull().default(0),
  fixedDepositBalance: double('fixed_deposit_balance').notNull().default(0),
  digitalGoldGrams: double('digital_gold_grams').notNull().default(0),
  kycStatus: varchar('kyc_status', { length: 50 }).notNull().default('verified'),
  aadhaarNumber: varchar('aadhaar_number', { length: 50 }).notNull().default(''),
  panNumber: varchar('pan_number', { length: 50 }).notNull().default(''),
  biometricEnabled: boolean('biometric_enabled').notNull().default(false),
  biometricLimit: int('biometric_limit').notNull().default(5000),
  soundboxVoiceAlerts: boolean('soundbox_voice_alerts').notNull().default(true),
  soundboxLanguage: varchar('soundbox_language', { length: 10 }).notNull().default('en'),
  seniorMode: boolean('senior_mode').notNull().default(false),
  highContrast: boolean('high_contrast').notNull().default(false),
  branchName: varchar('branch_name', { length: 255 }).default('Axis Bank Corporate HO (Mumbai)'),
  cifNumber: varchar('cif_number', { length: 50 }).default('AXIS8891002'),
  accountType: varchar('account_type', { length: 50 }).default('SAVINGS'),
  accountStatus: varchar('account_status', { length: 50 }).notNull().default('APPROVED'),
  rejectionReason: text('rejection_reason'),
  profilePhotoUpdatedAt: varchar('profile_photo_updated_at', { length: 100 }),
  activeSessionToken: varchar('active_session_token', { length: 255 }),
  lastLoginAt: varchar('last_login_at', { length: 100 }),
  isBlocked: boolean('is_blocked').default(false),
  blockReason: text('block_reason'),
  services: json('services'),
  mpin: varchar('mpin', { length: 50 }).default('1234'),
  liveLatitude: double('live_latitude'),
  liveLongitude: double('live_longitude'),
  liveAccuracy: double('live_accuracy'),
  liveLocationAddress: text('live_location_address'),
  liveLocationUpdatedAt: varchar('live_location_updated_at', { length: 100 }),
  isOnline: boolean('is_online').default(false),
  qrCodeDataUrl: text('qr_code_data_url'),
  createdAt: datetime('created_at'),
});

export const adminAccounts = mysqlTable('admin_accounts', {
  id: varchar('id', { length: 100 }).primaryKey(),
  username: varchar('username', { length: 100 }).notNull().unique(),
  fullName: varchar('full_name', { length: 255 }).notNull(),
  role: varchar('role', { length: 50 }).notNull().default('OFFICER'),
  pinOrPassword: varchar('pin_or_password', { length: 255 }).notNull(),
  email: varchar('email', { length: 255 }),
  branchName: varchar('branch_name', { length: 255 }).default('Kolkata Main HO'),
  isActive: boolean('is_active').notNull().default(true),
  lastLoginAt: varchar('last_login_at', { length: 100 }),
  createdAt: datetime('created_at'),
});

export const transactions = mysqlTable('transactions', {
  id: varchar('id', { length: 100 }).primaryKey(),
  userId: int('user_id').references(() => users.id),
  title: varchar('title', { length: 255 }).notNull(),
  subTitle: text('sub_title').notNull(),
  amount: double('amount').notNull(),
  type: varchar('type', { length: 50 }).notNull(), // 'debit' | 'credit'
  category: varchar('category', { length: 50 }).notNull(),
  timestamp: varchar('timestamp', { length: 100 }).notNull(),
  status: varchar('status', { length: 50 }).notNull().default('SUCCESS'),
  paymentMode: varchar('payment_mode', { length: 50 }).notNull().default('UPI'),
  upiRefId: varchar('upi_ref_id', { length: 100 }).notNull(),
  recipientVpa: varchar('recipient_vpa', { length: 255 }),
  senderVpa: varchar('sender_vpa', { length: 255 }),
  bankName: varchar('bank_name', { length: 255 }),
  fraudFlag: varchar('fraud_flag', { length: 50 }).default('CLEAN'),
  beneficiaryName: varchar('beneficiary_name', { length: 255 }),
  beneficiaryAccount: varchar('beneficiary_account', { length: 100 }),
  recipientIfsc: varchar('recipient_ifsc', { length: 50 }),
  qrData: text('qr_data'),
  scannerAddress: text('scanner_address'),
  transferType: varchar('transfer_type', { length: 50 }),
  approvalStatus: varchar('approval_status', { length: 50 }),
  approvalReason: text('approval_reason'),
  createdAt: datetime('created_at'),
});

export const kycApplications = mysqlTable('kyc_applications', {
  id: varchar('id', { length: 100 }).primaryKey(),
  applicantName: varchar('applicant_name', { length: 255 }).notNull(),
  phone: varchar('phone', { length: 50 }).notNull(),
  aadhaarNumber: varchar('aadhaar_number', { length: 50 }).notNull(),
  panNumber: varchar('pan_number', { length: 50 }).notNull(),
  accountType: varchar('account_type', { length: 50 }).notNull(),
  status: varchar('status', { length: 50 }).notNull(),
  submittedAt: varchar('submitted_at', { length: 100 }).notNull(),
  documentType: varchar('document_type', { length: 50 }).notNull(),
  riskScore: int('risk_score').notNull().default(10),
  initialDeposit: double('initial_deposit').notNull().default(0),
  createdAt: datetime('created_at'),
});

export const pushAlerts = mysqlTable('push_alerts', {
  id: varchar('id', { length: 100 }).primaryKey(),
  userId: int('user_id').references(() => users.id),
  title: varchar('title', { length: 255 }).notNull(),
  body: text('body').notNull(),
  time: varchar('time', { length: 100 }).notNull(),
  read: boolean('read').default(false),
  type: varchar('type', { length: 50 }).notNull(),
  amount: double('amount'),
  createdAt: datetime('created_at'),
});

export const usersRelations = relations(users, ({ many }) => ({
  transactions: many(transactions),
  pushAlerts: many(pushAlerts),
}));

export const transactionsRelations = relations(transactions, ({ one }) => ({
  user: one(users, {
    fields: [transactions.userId],
    references: [users.id],
  }),
}));

export const pushAlertsRelations = relations(pushAlerts, ({ one }) => ({
  user: one(users, {
    fields: [pushAlerts.userId],
    references: [users.id],
  }),
}));
