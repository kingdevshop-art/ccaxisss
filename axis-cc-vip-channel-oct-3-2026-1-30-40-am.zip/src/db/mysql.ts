import { drizzle } from 'drizzle-orm/mysql2';
import mysql from 'mysql2/promise';
import * as schema from './schema.mysql.ts';

declare global {
  var _mysqlPool: mysql.Pool | undefined;
}

export const createMySqlPool = (): mysql.Pool => {
  if (!global._mysqlPool) {
    const host = process.env.MYSQL_HOST || process.env.SQL_HOST || '127.0.0.1';
    const port = parseInt(process.env.MYSQL_PORT || '3306', 10);
    const user = process.env.MYSQL_USER || process.env.SQL_USER || 'root';
    const password = process.env.MYSQL_PASSWORD || process.env.SQL_PASSWORD || '';
    const database = process.env.MYSQL_DATABASE || process.env.SQL_DB_NAME || 'axis_cc_vip_banking';

    global._mysqlPool = mysql.createPool({
      host,
      port,
      user,
      password,
      database,
      waitForConnections: true,
      connectionLimit: 10,
      queueLimit: 0,
      enableKeepAlive: true,
      keepAliveInitialDelay: 0,
    });
  }
  return global._mysqlPool;
};

export const mysqlPool = createMySqlPool();
export const mysqlDb = drizzle(mysqlPool, { schema, mode: 'default' });
