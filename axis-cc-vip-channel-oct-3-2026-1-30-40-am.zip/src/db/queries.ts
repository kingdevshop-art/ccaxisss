import { db } from './index.ts';
import * as schema from './schema.ts';
import { eq, desc } from 'drizzle-orm';
import { generateRandomAccountNumber } from '../utils/accountUtils.ts';

function formatUserRow(u: any) {
  if (!u) return null;
  return {
    ...u,
    id: u.uid || String(u.id),
    dbId: typeof u.id === 'number' ? u.id : undefined,
    accountStatus: u.accountStatus || 'APPROVED',
    rejectionReason: u.rejectionReason || '',
    profilePhotoUpdatedAt: u.profilePhotoUpdatedAt || undefined,
    activeSessionToken: u.activeSessionToken || undefined,
    lastLoginAt: u.lastLoginAt || undefined,
    isBlocked: Boolean(u.isBlocked),
    blockReason: u.blockReason || '',
    liveLatitude: u.liveLatitude ?? undefined,
    liveLongitude: u.liveLongitude ?? undefined,
    liveAccuracy: u.liveAccuracy ?? undefined,
    liveLocationAddress: u.liveLocationAddress || undefined,
    liveLocationUpdatedAt: u.liveLocationUpdatedAt || undefined,
    isOnline: Boolean(u.isOnline),
    qrCodeDataUrl: u.qrCodeDataUrl || undefined,
  };
}

export async function getAllDbUsers() {
  try {
    const rows = await db.select().from(schema.users).orderBy(schema.users.id);
    return rows.map(formatUserRow);
  } catch (error) {
    console.error('Database query failed in getAllDbUsers:', error);
    return [];
  }
}

export async function findExistingUser(uid?: string, phone?: string) {
  try {
    const cleanPhone = phone ? phone.replace(/\D/g, '').slice(-10) : '';
    const results = await db.select().from(schema.users);
    const found = results.find((u) => {
      if (uid && (u.uid === uid || String(u.id) === uid)) return true;
      if (cleanPhone && u.phone && u.phone.replace(/\D/g, '').slice(-10) === cleanPhone) return true;
      return false;
    });
    return found ? formatUserRow(found) : null;
  } catch (error) {
    console.error('Database query failed in findExistingUser:', error);
    return null;
  }
}

export async function getDbUserByPhone(phone: string) {
  return await findExistingUser(undefined, phone);
}

export async function upsertDbUser(userData: any) {
  try {
    const uid = userData.uid || userData.id || `usr_${Date.now()}`;
    const rawPhone = userData.phone || '';

    // First check if user exists by either uid or phone
    const existing = await findExistingUser(uid, rawPhone);
    if (existing) {
      const updated = await db
        .update(schema.users)
        .set({
          name: userData.name ?? existing.name,
          phone: userData.phone ?? existing.phone,
          email: userData.email ?? existing.email,
          photoUrl: userData.photoUrl ?? existing.photoUrl,
          dob: userData.dob ?? existing.dob,
          address: userData.address ?? existing.address,
          ckycNumber: userData.ckycNumber ?? existing.ckycNumber,
          upiId: userData.upiId ?? existing.upiId,
          accountNumber: userData.accountNumber ?? existing.accountNumber,
          ifscCode: userData.ifscCode ?? existing.ifscCode,
          savingsBalance: userData.savingsBalance ?? existing.savingsBalance,
          walletBalance: userData.walletBalance ?? existing.walletBalance,
          upiLiteBalance: userData.upiLiteBalance ?? existing.upiLiteBalance,
          fixedDepositBalance: userData.fixedDepositBalance ?? existing.fixedDepositBalance,
          digitalGoldGrams: userData.digitalGoldGrams ?? existing.digitalGoldGrams,
          kycStatus: userData.kycStatus ?? existing.kycStatus,
          aadhaarNumber: userData.aadhaarNumber ?? existing.aadhaarNumber,
          panNumber: userData.panNumber ?? existing.panNumber,
          biometricEnabled: userData.biometricEnabled ?? existing.biometricEnabled,
          biometricLimit: userData.biometricLimit ?? existing.biometricLimit,
          soundboxVoiceAlerts: userData.soundboxVoiceAlerts ?? existing.soundboxVoiceAlerts,
          soundboxLanguage: userData.soundboxLanguage ?? existing.soundboxLanguage,
          seniorMode: userData.seniorMode !== undefined ? Boolean(userData.seniorMode) : existing.seniorMode,
          highContrast: userData.highContrast !== undefined ? Boolean(userData.highContrast) : existing.highContrast,
          branchName: userData.branchName ?? existing.branchName,
          cifNumber: userData.cifNumber ?? existing.cifNumber,
          accountType: userData.accountType ?? existing.accountType,
          accountStatus: userData.accountStatus ?? existing.accountStatus,
          rejectionReason: userData.rejectionReason ?? existing.rejectionReason,
          profilePhotoUpdatedAt: userData.profilePhotoUpdatedAt ?? existing.profilePhotoUpdatedAt,
          activeSessionToken: userData.activeSessionToken ?? existing.activeSessionToken,
          lastLoginAt: userData.lastLoginAt ?? existing.lastLoginAt,
          isBlocked: userData.isBlocked !== undefined ? Boolean(userData.isBlocked) : existing.isBlocked,
          blockReason: userData.blockReason !== undefined ? userData.blockReason : existing.blockReason,
          services: userData.services ?? existing.services,
          mpin: userData.mpin ?? existing.mpin,
          liveLatitude: userData.liveLatitude !== undefined ? userData.liveLatitude : existing.liveLatitude,
          liveLongitude: userData.liveLongitude !== undefined ? userData.liveLongitude : existing.liveLongitude,
          liveAccuracy: userData.liveAccuracy !== undefined ? userData.liveAccuracy : existing.liveAccuracy,
          liveLocationAddress: userData.liveLocationAddress ?? existing.liveLocationAddress,
          liveLocationUpdatedAt: userData.liveLocationUpdatedAt ?? existing.liveLocationUpdatedAt,
          isOnline: userData.isOnline !== undefined ? userData.isOnline : existing.isOnline,
          qrCodeDataUrl: userData.qrCodeDataUrl ?? existing.qrCodeDataUrl,
        })
        .where(
          existing.dbId
            ? eq(schema.users.id, Number(existing.dbId))
            : eq(schema.users.uid, existing.uid || String(existing.id))
        )
        .returning();
      return formatUserRow(updated[0]);
    }

    // Try inserting, with fallback to update if a concurrent insert happens
    try {
      const inserted = await db
        .insert(schema.users)
        .values({
          uid,
          name: userData.name || 'Account Holder',
          phone: userData.phone || `+91 9${Date.now().toString().slice(-9)}`,
          email: userData.email || `${uid}@axisbank.com`,
          photoUrl: userData.photoUrl || null,
          dob: userData.dob || null,
          address: userData.address || null,
          ckycNumber: userData.ckycNumber || null,
          upiId: userData.upiId || `${(userData.name || 'user').toLowerCase().replace(/\s+/g, '.')}@axisbank`,
          accountNumber: userData.accountNumber || generateRandomAccountNumber(),
          ifscCode: userData.ifscCode || 'UTIB000001',
          savingsBalance: userData.savingsBalance ?? 10000,
          walletBalance: userData.walletBalance ?? 1000,
          upiLiteBalance: userData.upiLiteBalance ?? 500,
          fixedDepositBalance: userData.fixedDepositBalance ?? 0,
          digitalGoldGrams: userData.digitalGoldGrams ?? 0,
          kycStatus: userData.kycStatus ?? 'verified',
          aadhaarNumber: userData.aadhaarNumber || 'XXXX-XXXX-1234',
          panNumber: userData.panNumber || 'ABCPS1234K',
          biometricEnabled: userData.biometricEnabled ?? false,
          biometricLimit: userData.biometricLimit ?? 5000,
          soundboxVoiceAlerts: userData.soundboxVoiceAlerts ?? true,
          soundboxLanguage: userData.soundboxLanguage ?? 'en',
          seniorMode: userData.seniorMode ?? false,
          highContrast: userData.highContrast ?? false,
          branchName: userData.branchName || 'Axis Bank Corporate Branch (Mumbai)',
          cifNumber: userData.cifNumber || `CIF${Math.floor(10000000 + Math.random() * 90000000)}`,
          accountType: userData.accountType || 'SAVINGS',
          accountStatus: userData.accountStatus || 'APPROVED',
          rejectionReason: userData.rejectionReason || '',
          profilePhotoUpdatedAt: userData.profilePhotoUpdatedAt || null,
          activeSessionToken: userData.activeSessionToken || null,
          lastLoginAt: userData.lastLoginAt || null,
          isBlocked: userData.isBlocked ?? false,
          blockReason: userData.blockReason || '',
          services: userData.services || {},
          mpin: userData.mpin || '1234',
          liveLatitude: userData.liveLatitude ?? null,
          liveLongitude: userData.liveLongitude ?? null,
          liveAccuracy: userData.liveAccuracy ?? null,
          liveLocationAddress: userData.liveLocationAddress || null,
          liveLocationUpdatedAt: userData.liveLocationUpdatedAt || null,
          isOnline: userData.isOnline ?? false,
          qrCodeDataUrl: userData.qrCodeDataUrl || null,
        })
        .returning();
      return formatUserRow(inserted[0]);
    } catch (insertErr: any) {
      if (insertErr?.code === '23505' || insertErr?.message?.includes('unique constraint')) {
        // Unique violation occurred, re-query and update gracefully
        const retryExisting = await findExistingUser(uid, rawPhone);
        if (retryExisting) {
          const updated = await db
            .update(schema.users)
            .set({
              name: userData.name ?? retryExisting.name,
              photoUrl: userData.photoUrl ?? retryExisting.photoUrl,
              dob: userData.dob ?? retryExisting.dob,
              address: userData.address ?? retryExisting.address,
              ckycNumber: userData.ckycNumber ?? retryExisting.ckycNumber,
              savingsBalance: userData.savingsBalance ?? retryExisting.savingsBalance,
              walletBalance: userData.walletBalance ?? retryExisting.walletBalance,
              upiLiteBalance: userData.upiLiteBalance ?? retryExisting.upiLiteBalance,
            })
            .where(
              retryExisting.dbId
                ? eq(schema.users.id, Number(retryExisting.dbId))
                : eq(schema.users.uid, retryExisting.uid || String(retryExisting.id))
            )
            .returning();
          return formatUserRow(updated[0]);
        }
      }
      throw insertErr;
    }
  } catch (error) {
    console.error('Database error in upsertDbUser:', error);
    // Don't crash, attempt fallback retrieve
    const fallback = await findExistingUser(userData?.uid || userData?.id, userData?.phone);
    if (fallback) return fallback;
    throw new Error('Failed to upsert user profile in database.', { cause: error });
  }
}

export async function adjustDbBalance(
  phone: string,
  balanceType: 'savings' | 'wallet' | 'upiLite' | 'fixedDeposit',
  type: 'CREDIT' | 'DEBIT',
  amount: number
) {
  try {
    const user = await findExistingUser(undefined, phone);
    if (!user) {
      console.warn(`User with phone ${phone} not found for balance adjustment`);
      return null;
    }

    const columnMap = {
      savings: 'savingsBalance',
      wallet: 'walletBalance',
      upiLite: 'upiLiteBalance',
      fixedDeposit: 'fixedDepositBalance',
    } as const;

    const key = columnMap[balanceType];
    const currentVal = (user as any)[key] || 0;
    const newVal = type === 'CREDIT' ? currentVal + amount : Math.max(0, currentVal - amount);

    const updateObj: Record<string, number> = {};
    if (balanceType === 'savings') updateObj.savingsBalance = newVal;
    if (balanceType === 'wallet') updateObj.walletBalance = newVal;
    if (balanceType === 'upiLite') updateObj.upiLiteBalance = newVal;
    if (balanceType === 'fixedDeposit') updateObj.fixedDepositBalance = newVal;

    const result = await db
      .update(schema.users)
      .set(updateObj)
      .where(
        user.dbId
          ? eq(schema.users.id, Number(user.dbId))
          : eq(schema.users.uid, user.uid || String(user.id))
      )
      .returning();

    return formatUserRow(result[0]);
  } catch (error) {
    console.error('Database error in adjustDbBalance:', error);
    return null;
  }
}

export async function getAllDbTransactions(filterUserId?: string, filterPhone?: string) {
  try {
    const rows = await db
      .select({
        tx: schema.transactions,
        userUid: schema.users.uid,
        userPhone: schema.users.phone,
      })
      .from(schema.transactions)
      .leftJoin(schema.users, eq(schema.transactions.userId, schema.users.id))
      .orderBy(desc(schema.transactions.createdAt));

    const formatted = rows.map((r) => ({
      ...r.tx,
      // Map userId to client-facing user string UID (e.g. usr_...) so client state matches user.id seamlessly
      userId: r.userUid || (r.tx.userId != null ? String(r.tx.userId) : undefined),
      userDbId: r.tx.userId,
      userPhone: r.userPhone || undefined,
    }));

    if (filterUserId || filterPhone) {
      const cleanFilterPhone = filterPhone ? filterPhone.replace(/\D/g, '').slice(-10) : '';
      return formatted.filter((tx) => {
        if (filterUserId && (tx.userId === filterUserId || String(tx.userDbId) === filterUserId)) return true;
        if (cleanFilterPhone && tx.userPhone && tx.userPhone.replace(/\D/g, '').slice(-10) === cleanFilterPhone) return true;
        return false;
      });
    }

    return formatted;
  } catch (error) {
    console.error('Database error in getAllDbTransactions:', error);
    return [];
  }
}

export async function insertDbTransaction(tx: any) {
  try {
    if (tx.id) {
      const existing = await db
        .select()
        .from(schema.transactions)
        .where(eq(schema.transactions.id, tx.id));
      if (existing.length > 0) {
        return existing[0];
      }
    }

    // Resolve dbUserId (integer foreign key in PostgreSQL)
    let dbUserId: number | null = null;
    if (tx.userId != null) {
      if (typeof tx.userId === 'number') {
        dbUserId = tx.userId;
      } else {
        const found = await findExistingUser(tx.userId, tx.userPhone || tx.phone);
        if (found && found.dbId) {
          dbUserId = found.dbId;
        } else {
          const parsed = parseInt(tx.userId, 10);
          if (!isNaN(parsed) && String(parsed) === String(tx.userId)) {
            dbUserId = parsed;
          }
        }
      }
    } else if (tx.userPhone || tx.phone) {
      const found = await findExistingUser(undefined, tx.userPhone || tx.phone);
      if (found && found.dbId) {
        dbUserId = found.dbId;
      }
    }

    const inserted = await db
      .insert(schema.transactions)
      .values({
        id: tx.id || `TXN_${Date.now()}`,
        userId: dbUserId,
        title: tx.title,
        subTitle: tx.subTitle || '',
        amount: Number(tx.amount),
        type: tx.type,
        category: tx.category || 'transfer',
        timestamp: tx.timestamp || new Date().toLocaleString(),
        status: tx.status || 'SUCCESS',
        paymentMode: tx.paymentMode || 'UPI',
        upiRefId: tx.upiRefId || `UPI${Date.now()}`,
        recipientVpa: tx.recipientVpa || null,
        senderVpa: tx.senderVpa || null,
        bankName: tx.bankName || 'Axis Bank Ltd.',
        fraudFlag: tx.fraudFlag || 'CLEAN',
        beneficiaryName: tx.beneficiaryName || null,
        beneficiaryAccount: tx.beneficiaryAccount || null,
        recipientIfsc: tx.recipientIfsc || null,
        qrData: tx.qrData || null,
        scannerAddress: tx.scannerAddress || null,
        transferType: tx.transferType || null,
        approvalStatus: tx.approvalStatus || null,
        approvalReason: tx.approvalReason || null,
      })
      .returning();
    return inserted[0];
  } catch (error) {
    console.error('Database error in insertDbTransaction:', error);
    return null;
  }
}

export async function updateDbTransaction(txId: string, updates: any) {
  try {
    const updateObj: Record<string, any> = {};
    if (updates.title !== undefined) updateObj.title = updates.title;
    if (updates.subTitle !== undefined) updateObj.subTitle = updates.subTitle;
    if (updates.amount !== undefined) updateObj.amount = Number(updates.amount);
    if (updates.type !== undefined) updateObj.type = updates.type;
    if (updates.category !== undefined) updateObj.category = updates.category;
    if (updates.timestamp !== undefined) updateObj.timestamp = updates.timestamp;
    if (updates.status !== undefined) updateObj.status = updates.status;
    if (updates.paymentMode !== undefined) updateObj.paymentMode = updates.paymentMode;
    if (updates.upiRefId !== undefined) updateObj.upiRefId = updates.upiRefId;
    if (updates.recipientVpa !== undefined) updateObj.recipientVpa = updates.recipientVpa;
    if (updates.senderVpa !== undefined) updateObj.senderVpa = updates.senderVpa;
    if (updates.bankName !== undefined) updateObj.bankName = updates.bankName;
    if (updates.fraudFlag !== undefined) updateObj.fraudFlag = updates.fraudFlag;
    if (updates.beneficiaryName !== undefined) updateObj.beneficiaryName = updates.beneficiaryName;
    if (updates.beneficiaryAccount !== undefined) updateObj.beneficiaryAccount = updates.beneficiaryAccount;
    if (updates.recipientIfsc !== undefined) updateObj.recipientIfsc = updates.recipientIfsc;
    if (updates.qrData !== undefined) updateObj.qrData = updates.qrData;
    if (updates.scannerAddress !== undefined) updateObj.scannerAddress = updates.scannerAddress;
    if (updates.transferType !== undefined) updateObj.transferType = updates.transferType;
    if (updates.approvalStatus !== undefined) updateObj.approvalStatus = updates.approvalStatus;
    if (updates.approvalReason !== undefined) updateObj.approvalReason = updates.approvalReason;

    const result = await db
      .update(schema.transactions)
      .set(updateObj)
      .where(eq(schema.transactions.id, txId))
      .returning();
    return result[0] || null;
  } catch (error) {
    console.error('Database error in updateDbTransaction:', error);
    return null;
  }
}

export async function deleteDbTransaction(txId: string) {
  try {
    const result = await db
      .delete(schema.transactions)
      .where(eq(schema.transactions.id, txId))
      .returning();
    return result.length > 0;
  } catch (error) {
    console.error('Database error in deleteDbTransaction:', error);
    return false;
  }
}

export async function updateDbTransactionStatus(
  txId: string,
  status: 'SUCCESS' | 'REJECTED' | 'PENDING_APPROVAL' | 'PROCESSED' | 'HOLD' | 'FAILED',
  reason?: string
) {
  try {
    const approvalStatus =
      status === 'SUCCESS'
        ? 'APPROVED'
        : status === 'REJECTED'
        ? 'REJECTED'
        : status === 'HOLD'
        ? 'HOLD'
        : 'AWAITING_ADMIN';

    const result = await db
      .update(schema.transactions)
      .set({
        status,
        approvalStatus,
        approvalReason: reason || null,
        fraudFlag: status === 'REJECTED' ? 'SUSPICIOUS' : 'CLEAN',
      })
      .where(eq(schema.transactions.id, txId))
      .returning();
    return result[0];
  } catch (error) {
    console.error('Database error in updateDbTransactionStatus:', error);
    return null;
  }
}

export async function rollbackDbTransaction(txId: string) {
  try {
    const result = await db
      .update(schema.transactions)
      .set({ status: 'FAILED', fraudFlag: 'REVIEW' })
      .where(eq(schema.transactions.id, txId))
      .returning();
    return result[0];
  } catch (error) {
    console.error('Database error in rollbackDbTransaction:', error);
    return null;
  }
}

export async function getAllDbKyc() {
  try {
    return await db.select().from(schema.kycApplications).orderBy(desc(schema.kycApplications.createdAt));
  } catch (error) {
    console.error('Database error in getAllDbKyc:', error);
    return [];
  }
}

export async function updateDbKycStatus(id: string, status: 'APPROVED' | 'REJECTED') {
  try {
    const result = await db
      .update(schema.kycApplications)
      .set({ status })
      .where(eq(schema.kycApplications.id, id))
      .returning();
    return result[0];
  } catch (error) {
    console.error('Database error in updateDbKycStatus:', error);
    return null;
  }
}

export async function insertDbKycApplication(kycData: any) {
  try {
    const id = kycData.id || `kyc_${Date.now()}`;
    const result = await db
      .insert(schema.kycApplications)
      .values({
        id,
        applicantName: kycData.applicantName,
        phone: kycData.phone,
        aadhaarNumber: kycData.aadhaarNumber,
        panNumber: kycData.panNumber,
        accountType: kycData.accountType || 'SAVINGS',
        status: kycData.status || 'PENDING',
        submittedAt: kycData.submittedAt || new Date().toISOString(),
        documentType: kycData.documentType || 'Aadhaar + PAN (eKYC)',
        riskScore: kycData.riskScore ?? 10,
        initialDeposit: Number(kycData.initialDeposit || 0),
      })
      .returning();
    return result[0];
  } catch (error) {
    console.error('Database error in insertDbKycApplication:', error);
    return null;
  }
}

export async function updateDbUserAccountStatus(
  userIdOrPhone: string,
  status: 'APPROVED' | 'PENDING_APPROVAL' | 'REJECTED',
  rejectionReason = ''
) {
  try {
    const user = await findExistingUser(userIdOrPhone, userIdOrPhone);
    if (!user) return null;

    const updated = await db
      .update(schema.users)
      .set({
        accountStatus: status,
        rejectionReason: rejectionReason,
      })
      .where(
        user.dbId
          ? eq(schema.users.id, Number(user.dbId))
          : eq(schema.users.uid, user.uid || String(user.id))
      )
      .returning();
    return formatUserRow(updated[0]);
  } catch (error) {
    console.error('Database error in updateDbUserAccountStatus:', error);
    return null;
  }
}

export async function updateDbUserProfilePhoto(
  userIdOrPhone: string,
  photoUrl: string,
  profilePhotoUpdatedAt: string
) {
  try {
    const user = await findExistingUser(userIdOrPhone, userIdOrPhone);
    if (!user) return null;

    const updated = await db
      .update(schema.users)
      .set({
        photoUrl,
        profilePhotoUpdatedAt,
      })
      .where(
        user.dbId
          ? eq(schema.users.id, Number(user.dbId))
          : eq(schema.users.uid, user.uid || String(user.id))
      )
      .returning();
    return formatUserRow(updated[0]);
  } catch (error) {
    console.error('Database error in updateDbUserProfilePhoto:', error);
    return null;
  }
}

export async function createDbUserSession(
  userIdOrPhone: string,
  sessionToken: string,
  lastLoginAt: string
) {
  try {
    const user = await findExistingUser(userIdOrPhone, userIdOrPhone);
    if (!user) return null;

    const updated = await db
      .update(schema.users)
      .set({
        activeSessionToken: sessionToken,
        lastLoginAt,
      })
      .where(
        user.dbId
          ? eq(schema.users.id, Number(user.dbId))
          : eq(schema.users.uid, user.uid || String(user.id))
      )
      .returning();
    return formatUserRow(updated[0]);
  } catch (error) {
    console.error('Database error in createDbUserSession:', error);
    return null;
  }
}

export async function verifyDbUserSession(
  userIdOrPhone: string,
  sessionToken: string
): Promise<{ valid: boolean; activeSessionToken?: string }> {
  try {
    const user = await findExistingUser(userIdOrPhone, userIdOrPhone);
    if (!user) return { valid: false };

    // If no active session set in DB yet, accept and set it
    if (!user.activeSessionToken) {
      return { valid: true, activeSessionToken: sessionToken };
    }

    const valid = user.activeSessionToken === sessionToken;
    return { valid, activeSessionToken: user.activeSessionToken };
  } catch (error) {
    console.error('Database error in verifyDbUserSession:', error);
    return { valid: true }; // On transient DB error, do not aggressively kick out user
  }
}

export async function updateDbUserLocation(
  userIdOrPhone: string,
  location: {
    latitude: number;
    longitude: number;
    accuracy?: number;
    address?: string;
  }
) {
  try {
    const user = await findExistingUser(userIdOrPhone, userIdOrPhone);
    if (!user) return null;

    const nowIso = new Date().toISOString();
    const updated = await db
      .update(schema.users)
      .set({
        liveLatitude: location.latitude,
        liveLongitude: location.longitude,
        liveAccuracy: location.accuracy || null,
        liveLocationAddress: location.address || null,
        liveLocationUpdatedAt: nowIso,
        isOnline: true,
      })
      .where(
        user.dbId
          ? eq(schema.users.id, Number(user.dbId))
          : eq(schema.users.uid, user.uid || String(user.id))
      )
      .returning();
    return formatUserRow(updated[0]);
  } catch (error) {
    console.error('Database error in updateDbUserLocation:', error);
    return null;
  }
}

export async function updateDbUserQrCode(userIdOrPhone: string, qrCodeDataUrl: string) {
  try {
    const user = await findExistingUser(userIdOrPhone, userIdOrPhone);
    if (!user) return null;

    const updated = await db
      .update(schema.users)
      .set({ qrCodeDataUrl })
      .where(
        user.dbId
          ? eq(schema.users.id, Number(user.dbId))
          : eq(schema.users.uid, user.uid || String(user.id))
      )
      .returning();
    return formatUserRow(updated[0]);
  } catch (error) {
    console.error('Database error in updateDbUserQrCode:', error);
    return null;
  }
}

export async function getAllDbAdmins() {
  try {
    const rows = await db.select().from(schema.adminAccounts).orderBy(schema.adminAccounts.createdAt);
    return rows.map((r) => ({
      id: r.id,
      username: r.username,
      fullName: r.fullName,
      role: r.role,
      email: r.email || undefined,
      branchName: r.branchName || 'Kolkata Main HO',
      isActive: r.isActive,
      lastLoginAt: r.lastLoginAt || undefined,
      createdAt: r.createdAt ? r.createdAt.toISOString() : undefined,
    }));
  } catch (error) {
    console.error('Database query failed in getAllDbAdmins:', error);
    return [];
  }
}

export async function upsertDbAdmin(adminData: {
  username: string;
  fullName: string;
  role?: string;
  pinOrPassword: string;
  email?: string;
  branchName?: string;
}) {
  try {
    const cleanUsername = adminData.username.trim();
    const existing = await db
      .select()
      .from(schema.adminAccounts)
      .where(eq(schema.adminAccounts.username, cleanUsername));

    if (existing.length > 0) {
      const updated = await db
        .update(schema.adminAccounts)
        .set({
          fullName: adminData.fullName || existing[0].fullName,
          role: adminData.role || existing[0].role,
          pinOrPassword: adminData.pinOrPassword || existing[0].pinOrPassword,
          email: adminData.email ?? existing[0].email,
          branchName: adminData.branchName ?? existing[0].branchName,
        })
        .where(eq(schema.adminAccounts.id, existing[0].id))
        .returning();
      return updated[0];
    } else {
      const id = `admin_${Date.now()}`;
      const inserted = await db
        .insert(schema.adminAccounts)
        .values({
          id,
          username: cleanUsername,
          fullName: adminData.fullName || cleanUsername,
          role: adminData.role || 'OFFICER',
          pinOrPassword: adminData.pinOrPassword,
          email: adminData.email || null,
          branchName: adminData.branchName || 'Kolkata Main HO',
          isActive: true,
        })
        .returning();
      return inserted[0];
    }
  } catch (error) {
    console.error('Database error in upsertDbAdmin:', error);
    throw error;
  }
}

export async function resetDbAdminCredentials(
  currentUsername: string,
  newPinOrPassword: string,
  newUsername?: string
) {
  try {
    const cleanCurrent = currentUsername.trim();
    const existing = await db
      .select()
      .from(schema.adminAccounts)
      .where(eq(schema.adminAccounts.username, cleanCurrent));

    if (existing.length === 0) {
      // If not in DB, create it with the reset credentials
      return await upsertDbAdmin({
        username: newUsername || cleanCurrent,
        fullName: 'Authorized Administrator',
        role: 'SUPER_ADMIN',
        pinOrPassword: newPinOrPassword,
      });
    }

    const updated = await db
      .update(schema.adminAccounts)
      .set({
        username: newUsername?.trim() || existing[0].username,
        pinOrPassword: newPinOrPassword,
      })
      .where(eq(schema.adminAccounts.id, existing[0].id))
      .returning();
    return updated[0];
  } catch (error) {
    console.error('Database error in resetDbAdminCredentials:', error);
    throw error;
  }
}

export async function authenticateDbAdmin(username: string, pinOrPassword: string) {
  try {
    const cleanUser = username.trim();
    const rows = await db
      .select()
      .from(schema.adminAccounts)
      .where(eq(schema.adminAccounts.username, cleanUser));

    if (rows.length === 0) {
      // Fallback for default hardcoded credentials if DB has not yet populated
      if (
        (cleanUser === 'OFFICER_001' && pinOrPassword === '9988') ||
        (cleanUser === 'admin' && pinOrPassword === 'admin123')
      ) {
        return {
          id: 'admin_master',
          username: cleanUser,
          fullName: 'Authorized Branch Officer',
          role: 'SUPER_ADMIN',
          branchName: 'Kolkata Main HO',
          isActive: true,
        };
      }
      return null;
    }

    const admin = rows[0];
    if (admin.pinOrPassword === pinOrPassword && admin.isActive) {
      // Update last login
      await db
        .update(schema.adminAccounts)
        .set({ lastLoginAt: new Date().toISOString() })
        .where(eq(schema.adminAccounts.id, admin.id));

      return {
        id: admin.id,
        username: admin.username,
        fullName: admin.fullName,
        role: admin.role,
        email: admin.email,
        branchName: admin.branchName,
        isActive: admin.isActive,
      };
    }
    return null;
  } catch (error) {
    console.error('Database error in authenticateDbAdmin:', error);
    // On transient DB error, allow authorized fallback
    if (
      (username === 'OFFICER_001' && pinOrPassword === '9988') ||
      (username === 'admin' && pinOrPassword === 'admin123')
    ) {
      return {
        id: 'admin_fallback',
        username,
        fullName: 'Authorized Branch Officer',
        role: 'SUPER_ADMIN',
        branchName: 'Kolkata Main HO',
        isActive: true,
      };
    }
    return null;
  }
}

let isSeeding = false;

export async function updateDbUserBlockStatus(
  userIdOrPhone: string,
  isBlocked: boolean,
  reason?: string
) {
  try {
    const existing = await findExistingUser(userIdOrPhone, userIdOrPhone);
    if (!existing) {
      console.warn(`[updateDbUserBlockStatus] User not found with ID/phone: ${userIdOrPhone}`);
      return null;
    }
    const targetDbId = existing.dbId || existing.id;
    const blockReasonText = isBlocked ? (reason || 'Administrative freeze by Branch Administration') : '';
    const updated = await db
      .update(schema.users)
      .set({
        isBlocked: Boolean(isBlocked),
        blockReason: blockReasonText,
      })
      .where(
        existing.dbId
          ? eq(schema.users.id, Number(existing.dbId))
          : eq(schema.users.uid, existing.uid || String(existing.id))
      )
      .returning();
    return formatUserRow(updated[0]);
  } catch (error) {
    console.error('Database error in updateDbUserBlockStatus:', error);
    return null;
  }
}

export async function deleteDbUser(userIdOrPhone: string) {
  try {
    const existing = await findExistingUser(userIdOrPhone, userIdOrPhone);
    if (!existing) {
      console.warn(`[deleteDbUser] User not found with ID/phone: ${userIdOrPhone}`);
      return false;
    }
    const cleanPhone = (existing.phone || '').replace(/\D/g, '').slice(-10);

    // 1. Delete transactions referencing this user ID
    try {
      if (existing.dbId) {
        await db
          .delete(schema.transactions)
          .where(eq(schema.transactions.userId, Number(existing.dbId)));
      }
    } catch (txErr) {
      console.warn('Notice while deleting user transactions:', txErr);
    }

    // 2. Delete KYC application if matching
    try {
      const allKycs = await db.select().from(schema.kycApplications);
      for (const kyc of allKycs) {
        const kPhone = (kyc.phone || '').replace(/\D/g, '').slice(-10);
        if (
          kyc.id === `kyc_${existing.id}` ||
          (existing.dbId && kyc.id === `kyc_${existing.dbId}`) ||
          (cleanPhone && kPhone && cleanPhone === kPhone)
        ) {
          await db
            .delete(schema.kycApplications)
            .where(eq(schema.kycApplications.id, kyc.id));
        }
      }
    } catch (kycErr) {
      console.warn('Notice while deleting user KYC records:', kycErr);
    }

    // 3. Delete user row from database
    const deleted = await db
      .delete(schema.users)
      .where(
        existing.dbId
          ? eq(schema.users.id, Number(existing.dbId))
          : eq(schema.users.uid, existing.uid || String(existing.id))
      )
      .returning();

    return deleted.length > 0;
  } catch (error) {
    console.error('Database error in deleteDbUser:', error);
    return false;
  }
}

export async function seedInitialData(accounts: any[], transactions: any[], kycs: any[]) {
  // Do not seed dummy accounts or dummy transactions
  return { success: true, message: 'Database initialized. No demo accounts seeded.' };
}
export const seedCooperativeData = seedInitialData;
