import { relations } from 'drizzle-orm';
import {
  pgTable,
  serial,
  text,
  doublePrecision,
  integer,
  boolean,
  timestamp,
  jsonb,
} from 'drizzle-orm/pg-core';

export const users = pgTable('users', {
  id: serial('id').primaryKey(),
  uid: text('uid').notNull().unique(), // Firebase Auth UID or user identifier
  name: text('name').notNull(),
  phone: text('phone').notNull().unique(),
  email: text('email').notNull(),
  photoUrl: text('photo_url'),
  dob: text('dob'),
  address: text('address'),
  ckycNumber: text('ckyc_number'),
  upiId: text('upi_id').notNull(),
  accountNumber: text('account_number').notNull(),
  ifscCode: text('ifsc_code').notNull().default('UTIB000001'),
  savingsBalance: doublePrecision('savings_balance').notNull().default(0),
  walletBalance: doublePrecision('wallet_balance').notNull().default(0),
  upiLiteBalance: doublePrecision('upi_lite_balance').notNull().default(0),
  fixedDepositBalance: doublePrecision('fixed_deposit_balance').notNull().default(0),
  digitalGoldGrams: doublePrecision('digital_gold_grams').notNull().default(0),
  kycStatus: text('kyc_status').notNull().default('verified'),
  aadhaarNumber: text('aadhaar_number').notNull().default(''),
  panNumber: text('pan_number').notNull().default(''),
  biometricEnabled: boolean('biometric_enabled').notNull().default(false),
  biometricLimit: integer('biometric_limit').notNull().default(5000),
  soundboxVoiceAlerts: boolean('soundbox_voice_alerts').notNull().default(true),
  soundboxLanguage: text('soundbox_language').notNull().default('en'),
  seniorMode: boolean('senior_mode').notNull().default(false),
  highContrast: boolean('high_contrast').notNull().default(false),
  branchName: text('branch_name').default('Axis Bank Corporate HO (Mumbai)'),
  cifNumber: text('cif_number').default('AXIS8891002'),
  accountType: text('account_type').default('SAVINGS'),
  accountStatus: text('account_status').notNull().default('APPROVED'),
  rejectionReason: text('rejection_reason').default(''),
  profilePhotoUpdatedAt: text('profile_photo_updated_at'),
  activeSessionToken: text('active_session_token'),
  lastLoginAt: text('last_login_at'),
  isBlocked: boolean('is_blocked').default(false),
  blockReason: text('block_reason').default(''),
  services: jsonb('services'),
  mpin: text('mpin').default('1234'),
  liveLatitude: doublePrecision('live_latitude'),
  liveLongitude: doublePrecision('live_longitude'),
  liveAccuracy: doublePrecision('live_accuracy'),
  liveLocationAddress: text('live_location_address'),
  liveLocationUpdatedAt: text('live_location_updated_at'),
  isOnline: boolean('is_online').default(false),
  qrCodeDataUrl: text('qr_code_data_url'),
  createdAt: timestamp('created_at').defaultNow(),
});

export const adminAccounts = pgTable('admin_accounts', {
  id: text('id').primaryKey(),
  username: text('username').notNull().unique(),
  fullName: text('full_name').notNull(),
  role: text('role').notNull().default('OFFICER'),
  pinOrPassword: text('pin_or_password').notNull(),
  email: text('email'),
  branchName: text('branch_name').default('Kolkata Main HO'),
  isActive: boolean('is_active').notNull().default(true),
  lastLoginAt: text('last_login_at'),
  createdAt: timestamp('created_at').defaultNow(),
});

export const transactions = pgTable('transactions', {
  id: text('id').primaryKey(),
  userId: integer('user_id').references(() => users.id),
  title: text('title').notNull(),
  subTitle: text('sub_title').notNull(),
  amount: doublePrecision('amount').notNull(),
  type: text('type').notNull(), // 'debit' | 'credit'
  category: text('category').notNull(),
  timestamp: text('timestamp').notNull(),
  status: text('status').notNull().default('SUCCESS'),
  paymentMode: text('payment_mode').notNull().default('UPI'),
  upiRefId: text('upi_ref_id').notNull(),
  recipientVpa: text('recipient_vpa'),
  senderVpa: text('sender_vpa'),
  bankName: text('bank_name'),
  fraudFlag: text('fraud_flag').default('CLEAN'),
  beneficiaryName: text('beneficiary_name'),
  beneficiaryAccount: text('beneficiary_account'),
  recipientIfsc: text('recipient_ifsc'),
  qrData: text('qr_data'),
  scannerAddress: text('scanner_address'),
  transferType: text('transfer_type'),
  approvalStatus: text('approval_status'),
  approvalReason: text('approval_reason'),
  createdAt: timestamp('created_at').defaultNow(),
});

export const kycApplications = pgTable('kyc_applications', {
  id: text('id').primaryKey(),
  applicantName: text('applicant_name').notNull(),
  phone: text('phone').notNull(),
  aadhaarNumber: text('aadhaar_number').notNull(),
  panNumber: text('pan_number').notNull(),
  accountType: text('account_type').notNull(),
  status: text('status').notNull(),
  submittedAt: text('submitted_at').notNull(),
  documentType: text('document_type').notNull(),
  riskScore: integer('risk_score').notNull().default(10),
  initialDeposit: doublePrecision('initial_deposit').notNull().default(0),
  createdAt: timestamp('created_at').defaultNow(),
});

export const pushAlerts = pgTable('push_alerts', {
  id: text('id').primaryKey(),
  userId: integer('user_id').references(() => users.id),
  title: text('title').notNull(),
  body: text('body').notNull(),
  time: text('time').notNull(),
  read: boolean('read').default(false),
  type: text('type').notNull(),
  amount: doublePrecision('amount'),
  createdAt: timestamp('created_at').defaultNow(),
});

// Relationships
export const usersRelations = relations(users, ({ many }) => ({
  transactions: many(transactions),
  pushAlerts: many(pushAlerts),
}));

export const transactionsRelations = relations(transactions, ({ one }) => ({
  user: one(users, {
    fields: [transactions.userId],
    references: [users.id],
  }),
}));

export const pushAlertsRelations = relations(pushAlerts, ({ one }) => ({
  user: one(users, {
    fields: [pushAlerts.userId],
    references: [users.id],
  }),
}));
