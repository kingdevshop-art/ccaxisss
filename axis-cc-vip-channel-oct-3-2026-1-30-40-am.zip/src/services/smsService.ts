export interface SmsConfigStatus {
  accountName: string;
  fromPhone: string;
  configured: boolean;
  sidMasked: string | null;
}

export interface SendOtpResponse {
  success: boolean;
  messageSid?: string;
  status?: string;
  to?: string;
  otp?: string;
  body?: string;
  error?: string;
  fallbackUsed?: boolean;
}

export interface VerifyOtpResponse {
  valid: boolean;
  message: string;
}

export interface TransactionalSmsParams {
  phone: string;
  type: 'DEBIT' | 'CREDIT';
  amount: number;
  beneficiaryOrTitle: string;
  accountEnding?: string;
  upiRefId?: string;
  balance?: number;
  accountType?: string;
}

export const smsService = {
  async getStatus(): Promise<SmsConfigStatus | null> {
    try {
      const res = await fetch('/api/sms/status');
      if (!res.ok) return null;
      return await res.json();
    } catch {
      return null;
    }
  },

  async sendOtp(phone: string, purpose: string = 'Login Authentication'): Promise<SendOtpResponse> {
    try {
      const res = await fetch('/api/sms/send-otp', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ phone, purpose }),
      });
      if (!res.ok) {
        const err = await res.json();
        throw new Error(err.error || 'Failed to send OTP');
      }
      return await res.json();
    } catch (error: any) {
      console.warn('sendOtp failed:', error);
      return {
        success: false,
        error: error.message,
        fallbackUsed: true,
      };
    }
  },

  async verifyOtp(phone: string, otp: string): Promise<VerifyOtpResponse> {
    try {
      const res = await fetch('/api/sms/verify-otp', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ phone, otp }),
      });
      if (!res.ok) {
        const err = await res.json();
        return { valid: false, message: err.error || 'Verification failed' };
      }
      return await res.json();
    } catch (error: any) {
      return { valid: false, message: error.message || 'Verification failed' };
    }
  },

  async sendTransactionalAlert(params: TransactionalSmsParams): Promise<boolean> {
    try {
      const res = await fetch('/api/sms/transactional', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(params),
      });
      return res.ok;
    } catch (err) {
      console.warn('sendTransactionalAlert error:', err);
      return false;
    }
  },

  async sendTransactionalSms(phone: string, message: string): Promise<boolean> {
    try {
      const res = await fetch('/api/sms/send-direct', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ phone, message }),
      });
      return res.ok;
    } catch (err) {
      console.warn('sendTransactionalSms error:', err);
      return false;
    }
  },
};
