import { UserProfile, Transaction, KYCApplication } from '../types';
import { formatTransactionTimestamp, getNowBankingTimestamp } from '../utils/dateUtils';

export const dbService = {
  async initDb(): Promise<boolean> {
    try {
      const res = await fetch('/api/db/seed', { method: 'POST' });
      return res.ok;
    } catch {
      return false;
    }
  },

  async fetchUsers(): Promise<UserProfile[] | null> {
    try {
      const res = await fetch('/api/db/users');
      if (!res.ok) return null;
      const data = await res.json();
      return Array.isArray(data) && data.length > 0 ? data : null;
    } catch {
      return null;
    }
  },

  async saveUser(user: UserProfile): Promise<UserProfile | null> {
    try {
      const res = await fetch('/api/db/users', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(user),
      });
      if (!res.ok) return null;
      return await res.json();
    } catch {
      return null;
    }
  },

  async updateUser(userId: string, updates: Partial<UserProfile>): Promise<UserProfile | null> {
    try {
      const res = await fetch(`/api/db/users/${encodeURIComponent(userId)}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(updates),
      });
      if (!res.ok) {
        return await this.saveUser({ ...updates, id: userId } as UserProfile);
      }
      return await res.json();
    } catch {
      return null;
    }
  },

  async blockUser(
    userId: string,
    isBlocked: boolean,
    reason?: string
  ): Promise<UserProfile | null> {
    try {
      const res = await fetch(`/api/db/users/${encodeURIComponent(userId)}/block`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ isBlocked, reason }),
      });
      if (!res.ok) return null;
      return await res.json();
    } catch (err) {
      console.error('dbService blockUser error:', err);
      return null;
    }
  },

  async deleteUser(userId: string): Promise<boolean> {
    try {
      const res = await fetch(`/api/db/users/${encodeURIComponent(userId)}`, {
        method: 'DELETE',
      });
      if (!res.ok) return false;
      const data = await res.json();
      return Boolean(data.success);
    } catch (err) {
      console.error('dbService deleteUser error:', err);
      return false;
    }
  },

  async adjustBalance(
    phone: string,
    balanceType: 'savings' | 'wallet' | 'upiLite' | 'fixedDeposit',
    type: 'CREDIT' | 'DEBIT',
    amount: number,
    options?: { reason?: string; reference?: string; skipSms?: boolean }
  ): Promise<UserProfile | null> {
    try {
      const res = await fetch('/api/db/users/adjust-balance', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          phone,
          balanceType,
          type,
          amount,
          reason: options?.reason,
          reference: options?.reference,
          skipSms: options?.skipSms,
        }),
      });
      if (!res.ok) return null;
      return await res.json();
    } catch {
      return null;
    }
  },

  async fetchTransactions(): Promise<Transaction[] | null> {
    try {
      const res = await fetch('/api/db/transactions');
      if (!res.ok) return null;
      const data = await res.json();
      if (Array.isArray(data) && data.length > 0) {
        return data.map((tx: Transaction) => ({
          ...tx,
          timestamp: formatTransactionTimestamp(tx.timestamp, tx.createdAt, tx.id),
        }));
      }
      return null;
    } catch {
      return null;
    }
  },

  async recordTransaction(tx: Transaction): Promise<Transaction | null> {
    try {
      const sanitizedTx: Transaction = {
        ...tx,
        timestamp: formatTransactionTimestamp(tx.timestamp, tx.createdAt, tx.id),
      };
      const res = await fetch('/api/db/transactions', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(sanitizedTx),
      });
      if (!res.ok) return null;
      const saved = await res.json();
      return {
        ...saved,
        timestamp: formatTransactionTimestamp(saved.timestamp, saved.createdAt, saved.id),
      };
    } catch {
      return null;
    }
  },

  async rollbackTransaction(txId: string): Promise<boolean> {
    try {
      const res = await fetch(`/api/db/transactions/${txId}/rollback`, {
        method: 'POST',
      });
      return res.ok;
    } catch {
      return false;
    }
  },

  async updateTransactionStatus(
    txId: string,
    status: 'SUCCESS' | 'REJECTED' | 'PENDING_APPROVAL' | 'PROCESSED' | 'HOLD' | 'FAILED',
    reason?: string
  ): Promise<boolean> {
    try {
      const res = await fetch(`/api/db/transactions/${txId}/status`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status, reason }),
      });
      return res.ok;
    } catch {
      return false;
    }
  },

  async updateTransaction(
    txId: string,
    updates: Partial<Transaction>
  ): Promise<Transaction | null> {
    try {
      const res = await fetch(`/api/db/transactions/${txId}/update`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(updates),
      });
      if (!res.ok) return null;
      return await res.json();
    } catch {
      return null;
    }
  },

  async deleteTransaction(txId: string): Promise<boolean> {
    try {
      const res = await fetch(`/api/db/transactions/${txId}`, {
        method: 'DELETE',
      });
      return res.ok;
    } catch {
      return false;
    }
  },

  async fetchKycApplications(): Promise<KYCApplication[] | null> {
    try {
      const res = await fetch('/api/db/kyc');
      if (!res.ok) return null;
      const data = await res.json();
      return Array.isArray(data) && data.length > 0 ? data : null;
    } catch {
      return null;
    }
  },

  async updateKycStatus(id: string, status: 'APPROVED' | 'REJECTED'): Promise<boolean> {
    try {
      const res = await fetch(`/api/db/kyc/${id}/status`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status }),
      });
      return res.ok;
    } catch {
      return false;
    }
  },

  async recordKycApplication(kyc: KYCApplication): Promise<boolean> {
    try {
      const res = await fetch('/api/db/kyc', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(kyc),
      });
      return res.ok;
    } catch {
      return false;
    }
  },

  async updateUserStatus(
    userId: string,
    status: 'APPROVED' | 'PENDING_APPROVAL' | 'REJECTED',
    rejectionReason?: string
  ): Promise<UserProfile | null> {
    try {
      const res = await fetch(`/api/db/users/${encodeURIComponent(userId)}/status`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status, rejectionReason }),
      });
      if (!res.ok) return null;
      return await res.json();
    } catch {
      return null;
    }
  },

  async updateProfilePhoto(
    userId: string,
    photoUrl: string,
    profilePhotoUpdatedAt?: string
  ): Promise<UserProfile | null> {
    try {
      const res = await fetch(`/api/db/users/${encodeURIComponent(userId)}/photo`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ photoUrl, profilePhotoUpdatedAt }),
      });
      if (!res.ok) return null;
      return await res.json();
    } catch {
      return null;
    }
  },

  async registerSession(
    userId: string,
    sessionToken: string
  ): Promise<{ success: boolean; activeSessionToken?: string }> {
    try {
      const res = await fetch('/api/auth/session', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId, sessionToken }),
      });
      if (!res.ok) return { success: false };
      return await res.json();
    } catch {
      return { success: false };
    }
  },

  async updateSessionToken(
    userId: string,
    sessionToken: string
  ): Promise<{ success: boolean; activeSessionToken?: string }> {
    return this.registerSession(userId, sessionToken);
  },

  async verifySession(
    userId: string,
    token: string
  ): Promise<{ valid: boolean; activeSessionToken?: string }> {
    try {
      const res = await fetch(`/api/auth/session/verify?userId=${encodeURIComponent(userId)}&token=${encodeURIComponent(token)}`);
      if (!res.ok) return { valid: true };
      return await res.json();
    } catch {
      return { valid: true };
    }
  },

  async getUserByPhone(phone: string): Promise<UserProfile | null> {
    try {
      const cleanTarget = phone.replace(/\D/g, '').slice(-10);
      const allUsers = await this.fetchUsers();
      const found = allUsers.find(
        (u) => (u.phone || '').replace(/\D/g, '').slice(-10) === cleanTarget
      );
      return found || null;
    } catch {
      return null;
    }
  },

  async updateUserLocation(
    userIdOrPhone: string,
    latitude: number,
    longitude: number,
    accuracy?: number,
    address?: string
  ): Promise<UserProfile | null> {
    try {
      const res = await fetch('/api/user/location', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userId: userIdOrPhone,
          phone: userIdOrPhone,
          latitude,
          longitude,
          accuracy,
          address,
        }),
      });
      if (!res.ok) return null;
      const data = await res.json();
      return data.user || null;
    } catch {
      return null;
    }
  },
};
