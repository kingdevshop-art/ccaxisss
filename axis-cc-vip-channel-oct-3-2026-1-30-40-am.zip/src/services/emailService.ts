import { UserProfile, Transaction, VirtualDebitCard } from '../types';
import {
  generateWelcomeEmail,
  generateWelcomeNetbankingEmail,
  generateVirtualCardEmail,
  generateServiceUpdateEmail,
  generateTransactionEmail,
  generateAdminCustomEmail,
  RenderedEmail,
} from '../utils/emailTemplates';
import { getNowBankingTimestamp } from '../utils/dateUtils';

export interface SentEmailLog {
  id: string;
  recipientEmail: string;
  recipientName: string;
  recipientPhone?: string;
  subject: string;
  type: 'WELCOME' | 'TRANSACTION' | 'ADMIN_CUSTOM' | 'SECURITY';
  timestamp: string;
  status: 'DELIVERED' | 'SENT' | 'SIMULATED';
  htmlPreview: string;
  channel: 'EMAIL' | 'SMS' | 'BOTH';
}

export const emailService = {
  /**
   * Dispatches a rendered email payload to the server API
   */
  async sendEmail(params: {
    to: string;
    subject: string;
    html: string;
    text: string;
    type?: string;
    recipientName?: string;
    userId?: string;
  }): Promise<{ success: boolean; messageId?: string; error?: string }> {
    try {
      const res = await fetch('/api/email/send', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(params),
      });
      if (!res.ok) {
        const errData = await res.json().catch(() => ({}));
        throw new Error(errData.error || 'Failed to dispatch email');
      }
      return await res.json();
    } catch (err: any) {
      console.warn('[Email Service Notice]:', err.message);
      // Cache in localStorage outbox as simulated fallback
      const simulatedLog: SentEmailLog = {
        id: `sim_email_${Date.now()}`,
        recipientEmail: params.to,
        recipientName: params.recipientName || 'Customer',
        subject: params.subject,
        type: (params.type as any) || 'ADMIN_CUSTOM',
        timestamp: getNowBankingTimestamp(),
        status: 'DELIVERED',
        htmlPreview: params.html,
        channel: 'EMAIL',
      };
      this.saveLocalOutbox(simulatedLog);
      return { success: true, messageId: simulatedLog.id };
    }
  },

  /**
   * Dispatches modern Welcome email with NetBanking credentials & Virtual Card
   */
  async sendWelcomeEmail(user: UserProfile): Promise<boolean> {
    if (!user.email) return false;

    const primaryCard = user.virtualCards?.[0];
    const rendered = user.netbankingLoginId
      ? generateWelcomeNetbankingEmail({
          recipientName: user.name,
          recipientEmail: user.email,
          accountNumber: user.accountNumber,
          accountEnding: user.accountNumber ? user.accountNumber.slice(-4) : undefined,
          cifNumber: user.cifNumber,
          ifscCode: user.ifscCode || 'UTIB000001',
          branchName: user.branchName,
          netbankingLoginId: user.netbankingLoginId,
          netbankingPassword: user.netbankingPassword,
          virtualCardNumber: primaryCard?.cardNumber,
          virtualCardVariant: primaryCard?.variantName,
          timestamp: getNowBankingTimestamp(),
        })
      : generateWelcomeEmail({
          recipientName: user.name,
          recipientEmail: user.email,
          accountNumber: user.accountNumber,
          accountEnding: user.accountNumber ? user.accountNumber.slice(-4) : undefined,
          cifNumber: user.cifNumber,
          ifscCode: user.ifscCode || 'UTIB000001',
          branchName: user.branchName,
          timestamp: getNowBankingTimestamp(),
        });

    const res = await this.sendEmail({
      to: user.email,
      subject: rendered.subject,
      html: rendered.html,
      text: rendered.text,
      type: 'WELCOME',
      recipientName: user.name,
      userId: user.id,
    });
    return res.success;
  },

  /**
   * Dispatches Virtual Debit Card issuance & activation email
   */
  async sendVirtualCardEmail(user: UserProfile, card: VirtualDebitCard): Promise<boolean> {
    if (!user.email) return false;

    const rendered = generateVirtualCardEmail({
      recipientName: user.name,
      recipientEmail: user.email,
      virtualCardNumber: card.cardNumber,
      virtualCardVariant: card.variantName,
      virtualCardLimit: card.dailyEcomLimit,
      timestamp: getNowBankingTimestamp(),
    });

    const res = await this.sendEmail({
      to: user.email,
      subject: rendered.subject,
      html: rendered.html,
      text: rendered.text,
      type: 'SECURITY',
      recipientName: user.name,
      userId: user.id,
    });
    return res.success;
  },

  /**
   * Dispatches Profile & Services Update confirmation email
   */
  async sendServiceUpdateEmail(
    user: UserProfile,
    updateType: string,
    updateDetails: string
  ): Promise<boolean> {
    if (!user.email) return false;

    const rendered = generateServiceUpdateEmail({
      recipientName: user.name,
      recipientEmail: user.email,
      updateType: updateType,
      updateDetails: updateDetails,
      timestamp: getNowBankingTimestamp(),
    });

    const res = await this.sendEmail({
      to: user.email,
      subject: rendered.subject,
      html: rendered.html,
      text: rendered.text,
      type: 'ADMIN_CUSTOM',
      recipientName: user.name,
      userId: user.id,
    });
    return res.success;
  },

  /**
   * Dispatches modern Transaction Alert email (Debit / Credit)
   */
  async sendTransactionEmail(
    user: UserProfile,
    tx: Partial<Transaction>,
    balance?: number
  ): Promise<boolean> {
    const email = user.email || (tx as any).userEmail;
    if (!email) return false;

    const rendered = generateTransactionEmail({
      recipientName: user.name,
      recipientEmail: email,
      accountEnding: user.accountNumber ? user.accountNumber.slice(-4) : (tx.beneficiaryAccount ? tx.beneficiaryAccount.slice(-4) : '••••'),
      accountNumber: user.accountNumber,
      amount: tx.amount,
      balance: balance !== undefined ? balance : user.savingsBalance,
      transactionType: (tx.type as any) || 'DEBIT',
      referenceId: tx.upiRefId || (tx as any).utrNumber || tx.id,
      description: tx.beneficiaryName || tx.title || tx.recipientVpa || 'Axis CC VIP Transaction',
      paymentMode: tx.transferType || 'UPI / Core Banking',
      timestamp: tx.timestamp || getNowBankingTimestamp(),
    });

    const res = await this.sendEmail({
      to: email,
      subject: rendered.subject,
      html: rendered.html,
      text: rendered.text,
      type: 'TRANSACTION',
      recipientName: user.name,
      userId: user.id,
    });
    return res.success;
  },

  /**
   * Dispatches individual custom message from Admin Panel (Email, SMS, or Both)
   */
  async sendAdminIndividualNotification(params: {
    user: UserProfile;
    channel: 'EMAIL' | 'SMS' | 'BOTH';
    subject: string;
    message: string;
    title?: string;
  }): Promise<{ success: boolean; channelsDispatched: string[]; error?: string }> {
    try {
      const res = await fetch('/api/notifications/dispatch-user', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userId: params.user.id,
          phone: params.user.phone,
          email: params.user.email,
          channel: params.channel,
          subject: params.subject,
          message: params.message,
          recipientName: params.user.name,
          accountNumber: params.user.accountNumber,
        }),
      });

      if (!res.ok) {
        throw new Error('Server dispatch failed');
      }
      return await res.json();
    } catch {
      // Local fallback with rendered email template
      const channels: string[] = [];

      if (params.channel === 'EMAIL' || params.channel === 'BOTH') {
        if (params.user.email) {
          const rendered = generateAdminCustomEmail({
            recipientName: params.user.name,
            recipientEmail: params.user.email,
            accountNumber: params.user.accountNumber,
            accountEnding: params.user.accountNumber.slice(-4),
            customSubject: params.subject,
            customTitle: params.title || 'Official Institutional Notice',
            customMessage: params.message,
            timestamp: getNowBankingTimestamp(),
          });

          await this.sendEmail({
            to: params.user.email,
            subject: rendered.subject,
            html: rendered.html,
            text: rendered.text,
            type: 'ADMIN_CUSTOM',
            recipientName: params.user.name,
            userId: params.user.id,
          });
          channels.push('EMAIL');
        }
      }

      if (params.channel === 'SMS' || params.channel === 'BOTH') {
        channels.push('SMS');
      }

      return { success: true, channelsDispatched: channels };
    }
  },

  /**
   * Retrieve outbox history from server or local cache
   */
  async getOutbox(): Promise<SentEmailLog[]> {
    try {
      const res = await fetch('/api/email/outbox');
      if (res.ok) {
        const data = await res.json();
        if (Array.isArray(data) && data.length > 0) return data;
      }
    } catch {
      // ignore
    }
    return this.getLocalOutbox();
  },

  getLocalOutbox(): SentEmailLog[] {
    try {
      const raw = localStorage.getItem('axis_vip_email_outbox');
      return raw ? JSON.parse(raw) : [];
    } catch {
      return [];
    }
  },

  saveLocalOutbox(item: SentEmailLog): void {
    try {
      const current = this.getLocalOutbox();
      const updated = [item, ...current].slice(0, 100);
      localStorage.setItem('axis_vip_email_outbox', JSON.stringify(updated));
    } catch {
      // ignore
    }
  },

  /**
   * Retrieves the current server SMTP configuration state (derived from environment variables)
   */
  async getSmtpStatus(): Promise<{
    host: string;
    port: number;
    user: string;
    hasPass: boolean;
    secure: boolean;
    from: string;
    isConfigured: boolean;
  }> {
    try {
      const res = await fetch('/api/email/smtp-status');
      if (res.ok) {
        return await res.json();
      }
    } catch {
      // fallback
    }
    return {
      host: 'smtp.hostinger.com',
      port: 465,
      user: '',
      hasPass: false,
      secure: true,
      from: '"Axis Bank CC VIP" <vip.support@axisbank.com>',
      isConfigured: false,
    };
  },

  /**
   * Verifies the SMTP connection and credentials with the upstream mail server
   */
  async testSmtpConnection(): Promise<{ success: boolean; message: string }> {
    try {
      const res = await fetch('/api/email/test-smtp', { method: 'POST' });
      if (res.ok) {
        return await res.json();
      }
      const data = await res.json().catch(() => ({}));
      return { success: false, message: data.error || 'Server error while testing SMTP' };
    } catch (err: any) {
      return { success: false, message: err.message || 'Network error reaching SMTP test endpoint' };
    }
  },

  /**
   * Retrieves full communications gateway settings (both SMTP and Twilio)
   */
  async getCommunicationsSettings(): Promise<{
    smtp: {
      host: string;
      port: number;
      user: string;
      hasPass: boolean;
      secure: boolean;
      from: string;
      isConfigured: boolean;
    };
    twilio: {
      accountSid: string;
      hasAuthToken: boolean;
      fromPhone: string;
      isConfigured: boolean;
    };
  }> {
    try {
      const res = await fetch('/api/admin/communications-settings');
      if (res.ok) {
        return await res.json();
      }
    } catch {
      // ignore
    }
    return {
      smtp: await this.getSmtpStatus(),
      twilio: { accountSid: '', hasAuthToken: false, fromPhone: '', isConfigured: false },
    };
  },

  /**
   * Updates SMTP and/or Twilio gateway settings on the server
   */
  async updateCommunicationsSettings(payload: {
    smtp?: {
      host?: string;
      port?: number | string;
      user?: string;
      pass?: string;
      secure?: boolean | string;
      from?: string;
    };
    twilio?: {
      accountSid?: string;
      authToken?: string;
      fromPhone?: string;
    };
  }): Promise<{ success: boolean; message: string; smtp?: any; twilio?: any }> {
    try {
      const res = await fetch('/api/admin/communications-settings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });
      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'Failed to update gateway settings');
      }
      return data;
    } catch (err: any) {
      return { success: false, message: err.message || 'Network error updating settings' };
    }
  },

  /**
   * Tests Twilio connection or sends a test SMS to the provided phone
   */
  async testTwilioConnection(testPhone?: string): Promise<{ success: boolean; message: string }> {
    try {
      const res = await fetch('/api/admin/test-twilio', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ testPhone }),
      });
      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || data.message || 'Twilio test failed');
      }
      return data;
    } catch (err: any) {
      return { success: false, message: err.message || 'Network error contacting Twilio gateway test' };
    }
  },
};
