import React, { useState } from 'react';
import {
  WifiOff,
  PhoneCall,
  Zap,
  ShieldCheck,
  CheckCircle2,
  X,
  Send,
  HelpCircle,
  RefreshCw,
  Hash,
  AlertCircle,
} from 'lucide-react';
import {
  UserProfile,
  LanguageCode,
  OfflineQueuedTransfer,
  Transaction,
} from '../types';
import { TRANSLATIONS } from '../i18n/translations';

interface OfflineBankingModalProps {
  isOpen: boolean;
  onClose: () => void;
  user: UserProfile;
  language: LanguageCode;
  onSyncQueuedTransfer: (transfer: OfflineQueuedTransfer) => void;
  onOfflinePayment: (amount: number, recipient: string) => void;
}

export const OfflineBankingModal: React.FC<OfflineBankingModalProps> = ({
  isOpen,
  onClose,
  user,
  language,
  onSyncQueuedTransfer,
  onOfflinePayment,
}) => {
  if (!isOpen) return null;

  const [activeScreen, setActiveScreen] = useState<'HOME' | 'USSD' | 'UPI_LITE'>('HOME');
  const [ussdStep, setUssdStep] = useState<number>(0);
  const [ussdInput, setUssdInput] = useState<string>('');
  const [ussdLog, setUssdLog] = useState<string[]>([
    'Welcome to *99# Axis Bank CC VIP NUUP Service.',
    'Select Option:',
    '1. Send Money',
    '2. Request Money',
    '3. Check Balance',
    '4. My Profile',
    '5. UPI Lite Offline',
  ]);

  // UPI Lite form
  const [liteAmount, setLiteAmount] = useState('200');
  const [liteRecipient, setLiteRecipient] = useState('9811234567');
  const [isDoneLite, setIsDoneLite] = useState(false);

  const t = TRANSLATIONS[language] || TRANSLATIONS.en;

  const handleUssdSubmit = () => {
    if (!ussdInput.trim()) return;

    const trimmed = ussdInput.trim();
    setUssdInput('');

    if (ussdStep === 0) {
      if (trimmed === '1') {
        setUssdStep(1); // Send Money
        setUssdLog((prev) => [
          ...prev,
          `> ${trimmed}`,
          'Send Money via:',
          '1. Mobile Number',
          '2. UPI ID',
          '3. Saved Beneficiary',
        ]);
      } else if (trimmed === '3') {
        setUssdLog((prev) => [
          ...prev,
          `> ${trimmed}`,
          `Your Axis Bank CC VIP Balance is: Rs. ${user.savingsBalance.toFixed(2)}`,
          'UPI Lite Balance: Rs. ' + user.upiLiteBalance.toFixed(2),
          'Press 0 to return to main menu.',
        ]);
      } else if (trimmed === '5') {
        setActiveScreen('UPI_LITE');
      } else {
        setUssdLog((prev) => [
          ...prev,
          `> ${trimmed}`,
          'Service processed successfully. Press 0 for Main Menu.',
        ]);
      }
    } else if (ussdStep === 1) {
      if (trimmed === '1') {
        setUssdStep(2);
        setUssdLog((prev) => [
          ...prev,
          `> ${trimmed}`,
          'Enter 10-digit Mobile Number of Beneficiary:',
        ]);
      }
    } else if (ussdStep === 2) {
      setUssdStep(3);
      setUssdLog((prev) => [
        ...prev,
        `> ${trimmed}`,
        'Enter Amount in Rupees (Max Rs. 5000):',
      ]);
    } else if (ussdStep === 3) {
      const amt = parseFloat(trimmed) || 100;
      onOfflinePayment(amt, 'USSD Beneficiary (*99#)');
      setUssdStep(0);
      setUssdLog((prev) => [
        ...prev,
        `> Rs. ${amt}`,
        'Enter 4-digit UPI PIN to confirm: ****',
        `SUCCESS: Rs. ${amt} transferred successfully via Axis Bank *99# NUUP! Ref: USSD/${Math.floor(
          100000 + Math.random() * 900000
        )}`,
      ]);
    }
  };

  const handleExecuteUpiLite = () => {
    const amt = parseFloat(liteAmount);
    if (!amt || amt > 500) {
      alert('UPI Lite is limited to ₹500 per payment');
      return;
    }
    if (user.upiLiteBalance < amt) {
      alert('Insufficient UPI Lite balance');
      return;
    }

    onOfflinePayment(amt, liteRecipient);
    setIsDoneLite(true);
    setTimeout(() => {
      setIsDoneLite(false);
      onClose();
    }, 1500);
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-xs flex items-end sm:items-center justify-center p-0 sm:p-4 animate-in fade-in">
      <div className="w-full sm:max-w-md bg-white border border-slate-200 text-slate-900 rounded-t-3xl sm:rounded-3xl p-5 sm:p-6 shadow-2xl relative animate-in slide-in-from-bottom duration-300">
        <div className="flex items-center justify-between pb-3 border-b border-slate-100">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-amber-50 border border-amber-200 flex items-center justify-center text-amber-700">
              <WifiOff className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-black text-sm text-slate-900 uppercase tracking-wider">
                {t.offlineBanking}
              </h3>
              <p className="text-[11px] text-slate-500 font-bold">
                Low-Bandwidth & Zero Internet Banking
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-full bg-slate-100 text-slate-400 hover:text-slate-900 hover:bg-slate-200 transition"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Navigation screen selector */}
        <div className="grid grid-cols-2 gap-2 my-3">
          <button
            onClick={() => setActiveScreen('USSD')}
            className={`py-2 px-3 rounded-xl text-xs font-black uppercase tracking-wider flex items-center justify-center gap-1.5 border transition ${
              activeScreen === 'USSD'
                ? 'bg-[#0a2540] border-[#0a2540] text-amber-300 shadow-xs'
                : 'bg-slate-50 border-slate-200 text-slate-700 hover:bg-slate-100'
            }`}
          >
            <Hash className="w-3.5 h-3.5" />
            <span>*99# USSD Dialpad</span>
          </button>

          <button
            onClick={() => setActiveScreen('UPI_LITE')}
            className={`py-2 px-3 rounded-xl text-xs font-black uppercase tracking-wider flex items-center justify-center gap-1.5 border transition ${
              activeScreen === 'UPI_LITE'
                ? 'bg-emerald-600 border-emerald-600 text-white shadow-xs'
                : 'bg-slate-50 border-slate-200 text-slate-700 hover:bg-slate-100'
            }`}
          >
            <Zap className="w-3.5 h-3.5" />
            <span>UPI Lite (Offline)</span>
          </button>
        </div>

        {/* SCREEN 1: USSD DIALPAD SIMULATOR */}
        {activeScreen === 'USSD' && (
          <div className="space-y-3">
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-3.5 font-mono text-xs text-emerald-400 max-h-48 overflow-y-auto space-y-1 shadow-inner">
              {ussdLog.map((line, idx) => (
                <p key={idx} className="leading-snug">
                  {line}
                </p>
              ))}
            </div>

            <div className="flex gap-2">
              <input
                type="text"
                value={ussdInput}
                onChange={(e) => setUssdInput(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleUssdSubmit()}
                placeholder="Enter option number (e.g. 1)"
                className="flex-1 bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-900 font-mono font-bold focus:outline-none focus:border-[#0a2540]"
              />
              <button
                onClick={handleUssdSubmit}
                className="px-4 py-2 bg-[#0a2540] hover:bg-[#071d34] text-amber-300 font-black uppercase tracking-wider text-xs rounded-xl transition active:scale-95 shadow-md"
              >
                Send
              </button>
            </div>
            <p className="text-[10px] text-slate-500 font-bold text-center">
              Works on any basic feature phone via GSM signaling without 4G/5G data.
            </p>
          </div>
        )}

        {/* SCREEN 2: UPI LITE OFFLINE */}
        {activeScreen === 'UPI_LITE' && (
          <div className="space-y-3">
            <div className="p-3.5 bg-emerald-50 border border-emerald-300 rounded-2xl flex items-center justify-between shadow-2xs">
              <div>
                <p className="text-xs text-slate-600 font-bold">Offline UPI Lite Reserve</p>
                <p className="text-2xl font-black font-sans text-emerald-700">
                  ₹{user.upiLiteBalance.toFixed(2)}
                </p>
              </div>
              <span className="text-[10px] bg-emerald-100 text-emerald-800 px-2.5 py-1 rounded-full font-black uppercase tracking-wider">
                PIN-less & Offline
              </span>
            </div>

            {isDoneLite ? (
              <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200 text-center space-y-2">
                <CheckCircle2 className="w-10 h-10 text-emerald-600 mx-auto animate-bounce" />
                <p className="text-xs font-black uppercase tracking-wider text-slate-900">
                  Offline Payment Queued & Settled!
                </p>
                <p className="text-[11px] text-slate-500 font-bold">
                  Transaction will sync automatically when network returns.
                </p>
              </div>
            ) : (
              <div className="space-y-2.5">
                <div>
                  <label className="text-xs font-black text-slate-700 uppercase tracking-wider block mb-1">
                    Pay To (Mobile / UPI ID)
                  </label>
                  <input
                    type="text"
                    value={liteRecipient}
                    onChange={(e) => setLiteRecipient(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-900 font-mono font-bold focus:outline-none focus:border-emerald-500"
                  />
                </div>
                <div>
                  <label className="text-xs font-black text-slate-700 uppercase tracking-wider block mb-1">
                    Amount (Max ₹500 per transaction)
                  </label>
                  <input
                    type="number"
                    value={liteAmount}
                    onChange={(e) => setLiteAmount(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-lg font-black text-slate-900 font-sans focus:outline-none focus:border-emerald-500"
                  />
                </div>

                <button
                  onClick={handleExecuteUpiLite}
                  className="w-full py-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-black uppercase tracking-wider text-xs shadow-md shadow-emerald-900/20 transition active:scale-98"
                >
                  Pay ₹{liteAmount} Instantly Without Internet
                </button>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};
