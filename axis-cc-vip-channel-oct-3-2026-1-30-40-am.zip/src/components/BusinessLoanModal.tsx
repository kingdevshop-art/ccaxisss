import React, { useState, useId } from 'react';
import {
  X,
  Briefcase,
  TrendingUp,
  ShieldCheck,
  CheckCircle2,
  FileText,
  Calculator,
  Percent,
  Sparkles,
  ArrowRight,
  Landmark,
  Building2,
  AlertCircle,
  Download,
  Clock,
  ChevronRight,
  BadgeCheck,
} from 'lucide-react';
import { UserProfile, Transaction } from '../types';
import { AxisBankLogo } from './AxisBankLogo';
import { speakSoundboxTransactionAlert } from '../utils/audioAlert';
import { formatTransactionTimestamp, getNowBankingTimestamp } from '../utils/dateUtils';

interface BusinessLoanModalProps {
  isOpen: boolean;
  onClose: () => void;
  user: UserProfile;
  onDisburseLoan: (amount: number, loanData: any, tx: Transaction) => void;
}

export type BusinessLoanType =
  | 'VYAPAR_GROWTH'
  | 'WORKING_CAPITAL_OD'
  | 'MACHINERY_EQUIPMENT'
  | 'INVOICE_DISCOUNTING';

interface LoanPlan {
  id: BusinessLoanType;
  title: string;
  badge: string;
  rate: number; // annual percentage
  maxLimit: number;
  maxTenureMonths: number;
  description: string;
  features: string[];
}

const LOAN_PLANS: LoanPlan[] = [
  {
    id: 'VYAPAR_GROWTH',
    title: 'Axis CC VIP Vyapar Growth Term Loan',
    badge: 'Pre-Approved for VIP',
    rate: 9.99,
    maxLimit: 5000000,
    maxTenureMonths: 60,
    description: 'Collateral-free instant business expansion loan with zero processing fee for VIP clients.',
    features: ['Zero Collateral Required', 'Instant In-Account Disbursal', 'Flexible Part-Payment Option'],
  },
  {
    id: 'WORKING_CAPITAL_OD',
    title: 'Working Capital Cash Credit / Overdraft',
    badge: 'Flexi OD Facility',
    rate: 9.25,
    maxLimit: 7500000,
    maxTenureMonths: 36,
    description: 'Revolving credit line for day-to-day operations. Pay interest strictly on utilized funds.',
    features: ['Pay Only On Amount Used', 'Annual Auto-Renewal', 'Linked to Current/Savings A/c'],
  },
  {
    id: 'MACHINERY_EQUIPMENT',
    title: 'Machinery & Equipment Capital Loan',
    badge: 'Low Interest 8.75%',
    rate: 8.75,
    maxLimit: 10000000,
    maxTenureMonths: 84,
    description: 'Finance high-end manufacturing, IT, healthcare, or corporate infrastructure assets.',
    features: ['Up to 90% Asset Value', 'Extended 7-Year Tenure', 'Tax Deductible Depreciation'],
  },
  {
    id: 'INVOICE_DISCOUNTING',
    title: 'Express Invoice & Vendor Bill Discounting',
    badge: 'Same-Day Cash',
    rate: 10.25,
    maxLimit: 3000000,
    maxTenureMonths: 12,
    description: 'Unlock working capital trapped in 30-90 day unpaid enterprise supplier invoices.',
    features: ['80% Advance against Invoices', '100% Digital Document Upload', 'No CIBIL Impact on Buyer'],
  },
];

export const BusinessLoanModal: React.FC<BusinessLoanModalProps> = ({
  isOpen,
  onClose,
  user,
  onDisburseLoan,
}) => {
  const loanAmountInputId = useId();
  const loanTenureInputId = useId();
  const [selectedPlanId, setSelectedPlanId] = useState<BusinessLoanType>('VYAPAR_GROWTH');
  const [loanAmount, setLoanAmount] = useState<number>(1500000);
  const [tenureMonths, setTenureMonths] = useState<number>(36);
  const [businessName, setBusinessName] = useState<string>(
    user.name ? `${user.name} Enterprises` : 'Global Commercial Corp'
  );
  const [gstin, setGstin] = useState<string>('19AAACB1234F1Z5');
  const [annualTurnover, setAnnualTurnover] = useState<string>('25000000');
  const [purpose, setPurpose] = useState<string>('Working Capital & Business Expansion');
  const [step, setStep] = useState<'CALCULATOR' | 'DETAILS' | 'SANCTION' | 'SUCCESS'>('CALCULATOR');
  const [sanctionId, setSanctionId] = useState<string>('');
  const [isProcessing, setIsProcessing] = useState<boolean>(false);

  if (!isOpen) return null;

  const currentPlan = LOAN_PLANS.find((p) => p.id === selectedPlanId) || LOAN_PLANS[0];

  // EMI Calculation: E = P * r * (1+r)^n / ((1+r)^n - 1)
  const monthlyRate = currentPlan.rate / 12 / 100;
  const emi = Math.round(
    (loanAmount * monthlyRate * Math.pow(1 + monthlyRate, tenureMonths)) /
      (Math.pow(1 + monthlyRate, tenureMonths) - 1)
  );
  const totalRepayment = emi * tenureMonths;
  const totalInterest = Math.max(0, totalRepayment - loanAmount);

  const handleProceedToDetails = () => {
    setStep('DETAILS');
  };

  const handleGenerateSanction = (e: React.FormEvent) => {
    e.preventDefault();
    setIsProcessing(true);
    setTimeout(() => {
      const generatedId = `AXIS-VIP-BL-${Math.floor(100000 + Math.random() * 900000)}`;
      setSanctionId(generatedId);
      setIsProcessing(false);
      setStep('SANCTION');
    }, 700);
  };

  const handleConfirmDisbursement = () => {
    setIsProcessing(true);

    setTimeout(() => {
      const nowTs = getNowBankingTimestamp();
      const formattedTs = formatTransactionTimestamp(nowTs);
      const txId = `TXN_LN_${Date.now()}`;
      const upiRef = `AXISBL${Math.floor(1000000000 + Math.random() * 9000000000)}`;

      const newTx: Transaction = {
        id: txId,
        userId: user.id,
        userPhone: user.phone,
        title: 'Axis Bank CC VIP Business Loan Disbursal',
        subTitle: `Sanction Ref: ${sanctionId || 'AXIS-VIP-BL-88190'} • ${currentPlan.title}`,
        amount: loanAmount,
        type: 'credit',
        category: 'invest',
        timestamp: formattedTs,
        status: 'SUCCESS',
        paymentMode: 'SAVINGS_AC',
        upiRefId: upiRef,
        bankName: 'Axis Bank Ltd.',
        fraudFlag: 'CLEAN',
        beneficiaryName: businessName,
        beneficiaryAccount: user.accountNumber,
        recipientIfsc: 'UTIB000001',
        transferType: 'SAME_BANK',
        approvalStatus: 'APPROVED',
        approvalReason: 'Instant Corporate VIP Loan Disbursal',
        createdAt: nowTs,
      };

      onDisburseLoan(
        loanAmount,
        {
          sanctionId,
          plan: currentPlan,
          loanAmount,
          tenureMonths,
          monthlyEmi: emi,
          businessName,
          gstin,
          annualTurnover,
          purpose,
        },
        newTx
      );

      // Voice notification via Axis soundbox
      speakSoundboxTransactionAlert({
        type: 'CREDIT',
        amount: loanAmount,
        customText: `Axis Bank CC VIP Business Loan of Rupees ${loanAmount.toLocaleString('en-IN')} successfully disbursed to your account.`,
      });

      setIsProcessing(false);
      setStep('SUCCESS');
    }, 1200);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/75 backdrop-blur-md overflow-y-auto">
      <div className="bg-white rounded-3xl w-full max-w-2xl overflow-hidden shadow-2xl border border-slate-200 text-slate-900 my-auto animate-in fade-in zoom-in-95 duration-200">
        {/* Modal Header in Dark Red / Axis Burgundy */}
        <div className="bg-gradient-to-r from-[#5F0C2B] via-[#861F41] to-[#97144D] text-white p-5 sm:p-6 relative border-b border-[#700a2f]">
          <button
            onClick={onClose}
            className="absolute top-4 right-4 p-2 text-white/80 hover:text-white bg-white/10 hover:bg-white/20 rounded-full transition active:scale-95"
          >
            <X className="w-5 h-5" />
          </button>

          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-white/15 backdrop-blur-md p-1.5 flex items-center justify-center border border-white/20 shadow-inner">
              <Briefcase className="w-7 h-7 text-amber-300" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xs font-black uppercase tracking-wider text-amber-300 bg-black/25 px-2 py-0.5 rounded-full border border-amber-300/30">
                  Axis Bank CC VIP
                </span>
                <span className="text-xs text-white/80 font-mono font-bold">
                  IFSC: UTIB000001
                </span>
              </div>
              <h2 className="text-xl sm:text-2xl font-black tracking-tight text-white mt-1">
                Commercial & Business Loans
              </h2>
              <p className="text-xs text-amber-100/90 font-medium">
                Instant collateral-free finance & working capital for MSMEs and VIP enterprises
              </p>
            </div>
          </div>

          {/* Stepper Tabs */}
          <div className="flex items-center gap-2 mt-4 pt-3 border-t border-white/15 text-xs font-bold">
            <span
              className={`px-3 py-1 rounded-full ${
                step === 'CALCULATOR'
                  ? 'bg-amber-400 text-slate-950 font-black'
                  : 'bg-white/15 text-white'
              }`}
            >
              1. Choose Offer & EMI
            </span>
            <ChevronRight className="w-4 h-4 text-white/50" />
            <span
              className={`px-3 py-1 rounded-full ${
                step === 'DETAILS'
                  ? 'bg-amber-400 text-slate-950 font-black'
                  : 'bg-white/15 text-white'
              }`}
            >
              2. Business Details
            </span>
            <ChevronRight className="w-4 h-4 text-white/50" />
            <span
              className={`px-3 py-1 rounded-full ${
                step === 'SANCTION' || step === 'SUCCESS'
                  ? 'bg-amber-400 text-slate-950 font-black'
                  : 'bg-white/15 text-white'
              }`}
            >
              3. Sanction & Disbursal
            </span>
          </div>
        </div>

        {/* Modal Body */}
        <div className="p-5 sm:p-6 max-h-[75vh] overflow-y-auto">
          {/* STEP 1: CALCULATOR & PLAN SELECTION */}
          {step === 'CALCULATOR' && (
            <div className="space-y-6">
              {/* Plan Cards Grid */}
              <div>
                <label className="text-xs font-black uppercase tracking-wider text-slate-500 block mb-2">
                  Select Business Credit Solution
                </label>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {LOAN_PLANS.map((plan) => {
                    const isSelected = selectedPlanId === plan.id;
                    return (
                      <button
                        key={plan.id}
                        type="button"
                        onClick={() => {
                          setSelectedPlanId(plan.id);
                          if (loanAmount > plan.maxLimit) setLoanAmount(plan.maxLimit);
                        }}
                        className={`text-left p-3.5 rounded-2xl border transition-all relative ${
                          isSelected
                            ? 'border-[#861F41] bg-rose-50/70 shadow-sm ring-2 ring-[#861F41]/30'
                            : 'border-slate-200 bg-white hover:bg-slate-50'
                        }`}
                      >
                        <div className="flex items-start justify-between gap-1 mb-1">
                          <span
                            className={`text-[10px] font-black uppercase tracking-wider px-2 py-0.5 rounded-md ${
                              isSelected
                                ? 'bg-[#861F41] text-white'
                                : 'bg-slate-100 text-slate-600'
                            }`}
                          >
                            {plan.badge}
                          </span>
                          <span className="text-xs font-black text-[#861F41]">
                            {plan.rate}% p.a.
                          </span>
                        </div>
                        <h4 className="text-xs font-black text-slate-900 leading-snug">
                          {plan.title}
                        </h4>
                        <p className="text-[11px] text-slate-500 mt-1 line-clamp-2">
                          {plan.description}
                        </p>
                        <div className="mt-2 text-[10px] font-bold text-slate-700 flex items-center justify-between border-t border-slate-100 pt-1.5">
                          <span>Max: ₹{(plan.maxLimit / 100000).toFixed(0)} Lakhs</span>
                          <span>Tenure: Up to {plan.maxTenureMonths} Mo</span>
                        </div>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Loan Amount Range Slider */}
              <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200">
                <div className="flex items-center justify-between mb-2">
                  <label htmlFor={loanAmountInputId} className="text-xs font-black uppercase tracking-wider text-slate-700">
                    Required Loan Amount
                  </label>
                  <span className="text-lg font-black text-[#861F41] font-sans">
                    ₹{loanAmount.toLocaleString('en-IN')}
                  </span>
                </div>
                <input
                  id={loanAmountInputId}
                  type="range"
                  min={100000}
                  max={currentPlan.maxLimit}
                  step={50000}
                  value={loanAmount}
                  onChange={(e) => setLoanAmount(Number(e.target.value))}
                  className="w-full accent-[#861F41] h-2 bg-slate-200 rounded-lg cursor-pointer"
                />
                <div className="flex justify-between text-[10px] text-slate-400 font-bold mt-1">
                  <span>₹1 Lakh</span>
                  <span>₹{(currentPlan.maxLimit / 100000).toFixed(0)} Lakhs</span>
                </div>

                {/* Preset Amount Chips */}
                <div className="flex flex-wrap gap-2 mt-3">
                  {[500000, 1000000, 2500000, 5000000]
                    .filter((amt) => amt <= currentPlan.maxLimit)
                    .map((preset) => (
                      <button
                        key={preset}
                        type="button"
                        onClick={() => setLoanAmount(preset)}
                        className={`text-xs font-bold px-3 py-1 rounded-xl transition ${
                          loanAmount === preset
                            ? 'bg-[#861F41] text-white'
                            : 'bg-white border border-slate-200 text-slate-700 hover:bg-slate-100'
                        }`}
                      >
                        ₹{(preset / 100000).toFixed(0)} Lakhs
                      </button>
                    ))}
                </div>
              </div>

              {/* Tenure Selection */}
              <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200">
                <div className="flex items-center justify-between mb-2">
                  <label htmlFor={loanTenureInputId} className="text-xs font-black uppercase tracking-wider text-slate-700">
                    Repayment Tenure (Months)
                  </label>
                  <span className="text-base font-black text-slate-900">
                    {tenureMonths} Months ({Math.round(tenureMonths / 12)} Years)
                  </span>
                </div>
                <input
                  id={loanTenureInputId}
                  type="range"
                  min={12}
                  max={currentPlan.maxTenureMonths}
                  step={6}
                  value={tenureMonths}
                  onChange={(e) => setTenureMonths(Number(e.target.value))}
                  className="w-full accent-[#861F41] h-2 bg-slate-200 rounded-lg cursor-pointer"
                />
                <div className="flex justify-between text-[10px] text-slate-400 font-bold mt-1">
                  <span>12 Months</span>
                  <span>{currentPlan.maxTenureMonths} Months</span>
                </div>
              </div>

              {/* Dynamic EMI Result Box in Axis Burgundy theme */}
              <div className="p-4 rounded-2xl bg-gradient-to-br from-[#861F41] to-[#5F0C2B] text-white shadow-md">
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-center">
                  <div>
                    <span className="text-[10px] text-amber-200 font-black uppercase tracking-wider block">
                      Monthly EMI
                    </span>
                    <span className="text-xl font-black text-white">
                      ₹{emi.toLocaleString('en-IN')}
                    </span>
                  </div>
                  <div>
                    <span className="text-[10px] text-amber-200 font-black uppercase tracking-wider block">
                      Interest Rate
                    </span>
                    <span className="text-xl font-black text-amber-300">
                      {currentPlan.rate}%
                    </span>
                  </div>
                  <div>
                    <span className="text-[10px] text-amber-200 font-black uppercase tracking-wider block">
                      Total Interest
                    </span>
                    <span className="text-base font-black text-white/90">
                      ₹{totalInterest.toLocaleString('en-IN')}
                    </span>
                  </div>
                  <div>
                    <span className="text-[10px] text-amber-200 font-black uppercase tracking-wider block">
                      Processing Fee
                    </span>
                    <span className="text-base font-black text-emerald-400">
                      ₹0 (VIP Waived)
                    </span>
                  </div>
                </div>
              </div>

              <button
                type="button"
                onClick={handleProceedToDetails}
                className="w-full py-3.5 bg-gradient-to-r from-[#861F41] to-[#97144D] hover:from-[#700a2f] hover:to-[#861F41] text-white font-black text-sm uppercase tracking-wider rounded-2xl shadow-lg shadow-[#861F41]/25 flex items-center justify-center gap-2 active:scale-98 transition"
              >
                <span>Continue to Business Details</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          )}

          {/* STEP 2: BUSINESS DETAILS FORM */}
          {step === 'DETAILS' && (
            <form onSubmit={handleGenerateSanction} className="space-y-4">
              <div className="bg-rose-50 border border-[#861F41]/20 p-3 rounded-xl flex items-center gap-3">
                <ShieldCheck className="w-6 h-6 text-[#861F41] flex-shrink-0" />
                <div className="text-xs text-slate-800">
                  <span className="font-bold text-[#861F41]">Axis Bank VIP Fast-Track Approval:</span>{' '}
                  As a registered corporate client, your eligibility is pre-verified against CIF #{user.cifNumber || 'CIF8891002'}.
                </div>
              </div>

              <div>
                <label className="text-xs font-black uppercase tracking-wider text-slate-700 block mb-1">
                  Business Entity / Trading Name
                </label>
                <input
                  type="text"
                  required
                  value={businessName}
                  onChange={(e) => setBusinessName(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 font-medium text-sm focus:outline-none focus:ring-2 focus:ring-[#861F41]"
                  placeholder="e.g. Apex Global Technologies Pvt Ltd"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-black uppercase tracking-wider text-slate-700 block mb-1">
                    GSTIN (GST Number)
                  </label>
                  <input
                    type="text"
                    required
                    value={gstin}
                    onChange={(e) => setGstin(e.target.value.toUpperCase())}
                    maxLength={15}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 font-mono text-sm uppercase focus:outline-none focus:ring-2 focus:ring-[#861F41]"
                    placeholder="19AAACB1234F1Z5"
                  />
                </div>

                <div>
                  <label className="text-xs font-black uppercase tracking-wider text-slate-700 block mb-1">
                    Annual Turnover (₹)
                  </label>
                  <select
                    value={annualTurnover}
                    onChange={(e) => setAnnualTurnover(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 font-medium text-sm focus:outline-none focus:ring-2 focus:ring-[#861F41]"
                  >
                    <option value="5000000">₹50 Lakhs - ₹1 Crore</option>
                    <option value="25000000">₹1 Crore - ₹5 Crores</option>
                    <option value="100000000">₹5 Crores - ₹25 Crores</option>
                    <option value="500000000">Above ₹25 Crores (Corporate)</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="text-xs font-black uppercase tracking-wider text-slate-700 block mb-1">
                  Purpose of Loan
                </label>
                <select
                  value={purpose}
                  onChange={(e) => setPurpose(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 font-medium text-sm focus:outline-none focus:ring-2 focus:ring-[#861F41]"
                >
                  <option value="Working Capital & Inventory Procurement">Working Capital & Inventory Procurement</option>
                  <option value="Business Unit & Branch Expansion">Business Unit & Branch Expansion</option>
                  <option value="Machinery & Technology Upgradation">Machinery & Technology Upgradation</option>
                  <option value="Supplier & Vendor Advance Payments">Supplier & Vendor Advance Payments</option>
                </select>
              </div>

              <div className="bg-slate-50 p-3.5 rounded-xl border border-slate-200 text-xs text-slate-600 space-y-1 font-medium">
                <div className="flex justify-between">
                  <span>Selected Facility:</span>
                  <span className="font-bold text-slate-900">{currentPlan.title}</span>
                </div>
                <div className="flex justify-between">
                  <span>Disbursal Account:</span>
                  <span className="font-mono font-bold text-slate-900">
                    •••• {user.accountNumber.slice(-4)} (IFSC: UTIB000001)
                  </span>
                </div>
                <div className="flex justify-between">
                  <span>Calculated Monthly EMI:</span>
                  <span className="font-bold text-[#861F41]">₹{emi.toLocaleString('en-IN')}/mo</span>
                </div>
              </div>

              <div className="flex gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setStep('CALCULATOR')}
                  className="w-1/3 py-3 rounded-2xl border border-slate-300 text-slate-700 font-bold text-xs uppercase tracking-wider hover:bg-slate-100 transition"
                >
                  Back
                </button>
                <button
                  type="submit"
                  disabled={isProcessing}
                  className="w-2/3 py-3 bg-gradient-to-r from-[#861F41] to-[#97144D] hover:from-[#700a2f] hover:to-[#861F41] text-white font-black text-xs uppercase tracking-wider rounded-2xl shadow-md active:scale-98 transition flex items-center justify-center gap-1.5"
                >
                  {isProcessing ? (
                    <span>Verifying Pre-Approval...</span>
                  ) : (
                    <>
                      <span>Generate Sanction Letter</span>
                      <ArrowRight className="w-4 h-4" />
                    </>
                  )}
                </button>
              </div>
            </form>
          )}

          {/* STEP 3: SANCTION LETTER & INSTANT DISBURSAL */}
          {step === 'SANCTION' && (
            <div className="space-y-4">
              {/* Formal Digital Sanction Certificate */}
              <div className="p-5 rounded-2xl bg-white border-2 border-[#861F41] relative overflow-hidden shadow-sm">
                <div className="absolute -right-6 -bottom-6 opacity-10 pointer-events-none">
                  <AxisBankLogo size={140} />
                </div>

                <div className="flex items-center justify-between border-b border-slate-200 pb-3 mb-3">
                  <div>
                    <span className="text-[10px] font-black uppercase tracking-widest text-[#861F41]">
                      Axis Bank CC VIP Credit Committee
                    </span>
                    <h3 className="text-base font-black text-slate-900">
                      Digital Sanction Approval Letter
                    </h3>
                  </div>
                  <span className="bg-emerald-100 text-emerald-800 font-black text-[10px] px-2.5 py-1 rounded-full uppercase border border-emerald-300">
                    APPROVED
                  </span>
                </div>

                <div className="space-y-2 text-xs">
                  <div className="flex justify-between">
                    <span className="text-slate-500">Sanction Reference ID:</span>
                    <span className="font-mono font-bold text-slate-900">{sanctionId}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500">Borrower Entity:</span>
                    <span className="font-bold text-slate-900">{businessName}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500">Borrower GSTIN:</span>
                    <span className="font-mono font-bold text-slate-900">{gstin}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500">Sanctioned Amount:</span>
                    <span className="font-black text-[#861F41] text-sm">
                      ₹{loanAmount.toLocaleString('en-IN')}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500">Facility Type:</span>
                    <span className="font-bold text-slate-900">{currentPlan.title}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500">Annual Interest Rate:</span>
                    <span className="font-bold text-slate-900">{currentPlan.rate}% p.a.</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500">Repayment Period:</span>
                    <span className="font-bold text-slate-900">{tenureMonths} Months</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500">Monthly Equated Instalment:</span>
                    <span className="font-bold text-[#861F41]">₹{emi.toLocaleString('en-IN')}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500">Disbursal Destination:</span>
                    <span className="font-mono font-bold text-slate-900">
                      A/c •••• {user.accountNumber.slice(-4)} • IFSC UTIB000001
                    </span>
                  </div>
                </div>

                <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between text-[10px] text-slate-500">
                  <span>Authorized by: Axis Bank Corporate Head Office, Mumbai</span>
                  <span className="font-mono font-bold text-emerald-700">Digital KYC Verified</span>
                </div>
              </div>

              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={() => setStep('DETAILS')}
                  className="w-1/3 py-3 rounded-2xl border border-slate-300 text-slate-700 font-bold text-xs uppercase tracking-wider hover:bg-slate-100 transition"
                >
                  Edit Terms
                </button>
                <button
                  type="button"
                  disabled={isProcessing}
                  onClick={handleConfirmDisbursement}
                  className="w-2/3 py-3.5 bg-gradient-to-r from-emerald-600 via-emerald-700 to-teal-800 hover:from-emerald-700 hover:to-teal-900 text-white font-black text-xs uppercase tracking-wider rounded-2xl shadow-lg shadow-emerald-900/20 active:scale-98 transition flex items-center justify-center gap-2"
                >
                  {isProcessing ? (
                    <span>Disbursing Funds to Account...</span>
                  ) : (
                    <>
                      <Sparkles className="w-4 h-4 text-amber-300" />
                      <span>Accept & Instant Disburse ₹{loanAmount.toLocaleString('en-IN')}</span>
                    </>
                  )}
                </button>
              </div>
            </div>
          )}

          {/* STEP 4: SUCCESS CONFIRMATION */}
          {step === 'SUCCESS' && (
            <div className="text-center py-6 space-y-4">
              <div className="w-16 h-16 rounded-full bg-emerald-100 text-emerald-700 flex items-center justify-center mx-auto border-2 border-emerald-300 shadow-inner">
                <CheckCircle2 className="w-10 h-10" />
              </div>

              <div>
                <span className="text-xs font-black uppercase tracking-wider text-emerald-700 bg-emerald-50 px-3 py-1 rounded-full border border-emerald-200">
                  Instant Disbursal Completed
                </span>
                <h3 className="text-2xl font-black text-slate-900 mt-2">
                  ₹{loanAmount.toLocaleString('en-IN')} Disbursed
                </h3>
                <p className="text-xs text-slate-600 mt-1 max-w-md mx-auto">
                  The funds have been credited immediately into your Axis Bank Corporate Account{' '}
                  <span className="font-mono font-bold">•••• {user.accountNumber.slice(-4)}</span>.
                </p>
              </div>

              <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200 max-w-md mx-auto text-left text-xs space-y-1.5 font-medium">
                <div className="flex justify-between">
                  <span className="text-slate-500">Facility:</span>
                  <span className="font-bold text-slate-900">{currentPlan.title}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Sanction Ref:</span>
                  <span className="font-mono font-bold text-slate-900">{sanctionId}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Monthly EMI:</span>
                  <span className="font-bold text-[#861F41]">₹{emi.toLocaleString('en-IN')}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">First EMI Due:</span>
                  <span className="font-bold text-slate-900">1st of Next Month</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">IFSC Code:</span>
                  <span className="font-mono font-bold text-slate-900">UTIB000001</span>
                </div>
              </div>

              <button
                type="button"
                onClick={onClose}
                className="w-full py-3.5 bg-slate-900 hover:bg-slate-800 text-white font-black text-xs uppercase tracking-wider rounded-2xl transition active:scale-98"
              >
                Done & Return to Dashboard
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
