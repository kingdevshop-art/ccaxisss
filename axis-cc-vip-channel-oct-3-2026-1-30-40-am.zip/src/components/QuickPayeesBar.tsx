import React from 'react';
import { User, Plus, Send, Zap, ChevronRight } from 'lucide-react';
import { Contact, LanguageCode } from '../types';

interface QuickPayeesBarProps {
  contacts: Contact[];
  language: LanguageCode;
  onSelectPayee: (contact: Contact) => void;
  onAddNewPayee: () => void;
}

export const QuickPayeesBar: React.FC<QuickPayeesBarProps> = ({
  contacts,
  language,
  onSelectPayee,
  onAddNewPayee,
}) => {
  return (
    <div className="bg-white rounded-2xl p-4 border border-slate-200 text-slate-900 shadow-sm">
      <div className="flex items-center justify-between mb-3 pb-2 border-b border-slate-100">
        <div className="flex items-center gap-2">
          <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
          <h3 className="text-xs font-black uppercase tracking-wider text-slate-800">
            Quick Payees & Beneficiaries
          </h3>
        </div>
        <button
          onClick={onAddNewPayee}
          className="text-[10px] font-black uppercase tracking-wider text-[#0a2540] hover:underline flex items-center gap-0.5"
        >
          <span>All Payees</span>
          <ChevronRight className="w-3 h-3" />
        </button>
      </div>

      <div className="flex items-center gap-3 overflow-x-auto pb-1 scrollbar-none">
        {/* Add New Payee Button */}
        <button
          onClick={onAddNewPayee}
          className="flex flex-col items-center justify-center flex-shrink-0 group active:scale-95 transition"
        >
          <div className="w-12 h-12 rounded-2xl border-2 border-dashed border-slate-300 group-hover:border-[#0a2540] bg-slate-50 flex items-center justify-center text-slate-400 group-hover:text-[#0a2540] transition">
            <Plus className="w-5 h-5" />
          </div>
          <span className="text-[10px] font-bold text-slate-600 mt-1.5 truncate max-w-[60px] text-center">
            New Payee
          </span>
        </button>

        {/* Frequent Payees List */}
        {contacts.slice(0, 7).map((contact) => (
          <button
            key={contact.id}
            onClick={() => onSelectPayee(contact)}
            className="flex flex-col items-center justify-center flex-shrink-0 group active:scale-95 transition"
            title={`Pay ${contact.name} (${contact.upiId})`}
          >
            <div className="relative">
              <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-slate-100 to-slate-200 border border-slate-200 group-hover:border-amber-400 group-hover:ring-2 group-hover:ring-amber-200 shadow-xs flex items-center justify-center text-slate-700 font-black text-sm transition">
                {contact.avatar ? (
                  <img
                    src={contact.avatar}
                    alt={contact.name}
                    className="w-full h-full object-cover rounded-2xl"
                  />
                ) : (
                  contact.name.charAt(0)
                )}
              </div>
              <div className="absolute -bottom-1 -right-1 w-4 h-4 rounded-full bg-[#0a2540] text-amber-300 border border-white flex items-center justify-center">
                <Send className="w-2.5 h-2.5" />
              </div>
            </div>

            <span className="text-[10px] font-bold text-slate-800 mt-1.5 truncate max-w-[65px] text-center">
              {contact.name.split(' ')[0]}
            </span>
          </button>
        ))}
      </div>
    </div>
  );
};
