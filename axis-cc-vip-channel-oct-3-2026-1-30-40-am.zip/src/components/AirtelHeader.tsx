import React, { useState, useRef, useEffect } from 'react';
import {
  Bell,
  Globe,
  Wifi,
  WifiOff,
  Volume2,
  Accessibility,
  ChevronDown,
  LogIn,
  LogOut,
  Sliders,
  Check,
  SlidersHorizontal,
} from 'lucide-react';
import { UserProfile, LanguageCode } from '../types';
import { SUPPORTED_LANGUAGES, TRANSLATIONS } from '../i18n/translations';
import { AxisBankLogo } from './AxisBankLogo';

export type HeaderLogoSize = 'compact' | 'balanced' | 'enlarged';

interface AirtelHeaderProps {
  user: UserProfile | null;
  language: LanguageCode;
  onLanguageChange: (lang: LanguageCode) => void;
  isOffline: boolean;
  onToggleOffline: () => void;
  onOpenNotifications: () => void;
  unreadAlertsCount: number;
  onToggleSeniorMode: () => void;
  onToggleHighContrast?: () => void;
  onOpenProfile: () => void;
  onLogout?: () => void;
  onOpenSoundboxTest: () => void;
  onOpenAndroidGuide?: () => void;
  isSeniorMode?: boolean;
  highContrast?: boolean;
}

export const AirtelHeader: React.FC<AirtelHeaderProps> = ({
  user,
  language,
  onLanguageChange,
  isOffline,
  onToggleOffline,
  onOpenNotifications,
  unreadAlertsCount,
  onToggleSeniorMode,
  onOpenProfile,
  onLogout,
  onOpenSoundboxTest,
  isSeniorMode,
}) => {
  const [langMenuOpen, setLangMenuOpen] = useState(false);
  const [toolsMenuOpen, setToolsMenuOpen] = useState(false);
  const [logoSize, setLogoSize] = useState<HeaderLogoSize>(() => {
    try {
      return (localStorage.getItem('axis_vip_header_logo_size') as HeaderLogoSize) || 'balanced';
    } catch {
      return 'balanced';
    }
  });

  const langRef = useRef<HTMLDivElement>(null);
  const toolsRef = useRef<HTMLDivElement>(null);

  const handleSetLogoSize = (newSize: HeaderLogoSize) => {
    setLogoSize(newSize);
    try {
      localStorage.setItem('axis_vip_header_logo_size', newSize);
    } catch {}
  };

  const cycleLogoSize = () => {
    const next: HeaderLogoSize =
      logoSize === 'compact' ? 'balanced' : logoSize === 'balanced' ? 'enlarged' : 'compact';
    handleSetLogoSize(next);
  };

  const t = TRANSLATIONS[language] || TRANSLATIONS.en;
  const currentLangObj =
    SUPPORTED_LANGUAGES.find((l) => l.code === language) || SUPPORTED_LANGUAGES[0];

  // Dynamic sizing classes for the adjustable header logo
  const logoDimensionClasses = {
    compact: 'w-7 h-7 sm:w-8 sm:h-8 md:w-8.5 md:h-8.5',
    balanced: 'w-9 h-9 sm:w-10 sm:h-10 md:w-11 md:h-11',
    enlarged: 'w-11 h-11 sm:w-12 sm:h-12 md:w-13 md:h-13',
  }[logoSize];

  const logoTitleClasses = {
    compact: 'text-xs sm:text-sm font-black',
    balanced: 'text-sm sm:text-base font-black',
    enlarged: 'text-base sm:text-lg font-black',
  }[logoSize];

  // Close dropdowns when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (langRef.current && !langRef.current.contains(event.target as Node)) {
        setLangMenuOpen(false);
      }
      if (toolsRef.current && !toolsRef.current.contains(event.target as Node)) {
        setToolsMenuOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  return (
    <header className="w-full max-w-full bg-gradient-to-r from-[#580824] via-[#861F41] to-[#97144D] text-white shadow-lg sticky top-0 z-40 border-b border-[#700a2f] overflow-x-clip">
      {/* Top Banner / Ticker if Offline */}
      {isOffline && (
        <div className="bg-amber-400 text-slate-950 text-xs px-3 py-1 font-black uppercase tracking-wider flex items-center justify-between shadow-inner">
          <div className="flex items-center gap-1.5 truncate">
            <WifiOff className="w-3.5 h-3.5 flex-shrink-0" />
            <span className="truncate">{t.offlineActive} - UPI Lite & *99# USSD Enabled</span>
          </div>
          <button
            onClick={onToggleOffline}
            className="underline font-black hover:text-slate-800 text-[10px] sm:text-[11px] uppercase tracking-wider flex-shrink-0 ml-2"
          >
            Go Online
          </button>
        </div>
      )}

      {/* Main Responsive Header Bar */}
      <div className="w-full max-w-7xl mx-auto px-2 sm:px-4 py-1.5 sm:py-2 flex items-center justify-between gap-1 sm:gap-2.5">
        {/* Left: Brand & Official Emblem (Clickable & Adjustable size) */}
        <div className="flex items-center gap-1.5 sm:gap-2.5 min-w-0 flex-shrink">
          <button
            type="button"
            onClick={cycleLogoSize}
            className={`relative ${logoDimensionClasses} flex items-center justify-center flex-shrink-0 cursor-pointer group active:scale-95 transition-all duration-200`}
            title={`Header Logo: ${logoSize.toUpperCase()} (Click to toggle Compact, Balanced, Large to fit all options)`}
            aria-label="Adjust Header Logo Size"
          >
            <AxisBankLogo size={logoSize === 'compact' ? 32 : logoSize === 'balanced' ? 42 : 48} />
            <span className="absolute bottom-0 right-0 w-2.5 h-2.5 bg-emerald-500 border-2 border-[#861F41] rounded-full z-10 shadow-sm" />
          </button>

          <div className="min-w-0">
            <div className="flex items-center gap-1 sm:gap-1.5">
              <span className={`${logoTitleClasses} tracking-tight text-white uppercase leading-none truncate`}>
                AXIS BANK
              </span>
              <span className="text-[8px] sm:text-[9px] font-black text-amber-300 uppercase tracking-wider bg-black/35 px-1.5 py-0.5 rounded border border-amber-400/40 leading-none whitespace-nowrap">
                CC VIP
              </span>
            </div>
            <span className="text-[8px] sm:text-[9px] uppercase tracking-widest text-amber-100/80 font-bold hidden md:block truncate mt-0.5">
              Axis Bank Mobile Banking • IFSC: UTIB000001
            </span>
          </div>

          {user && (
            <div className="hidden xl:flex items-center gap-1 pl-2.5 border-l border-white/20 text-[11px] text-white/90 font-bold">
              <span className="uppercase text-[9px] tracking-wider text-amber-200/90 font-black">
                A/C:
              </span>
              <span className="font-mono bg-black/30 px-2 py-0.5 rounded text-[11px] text-amber-300 font-bold border border-white/10">
                {user.upiId}
              </span>
            </div>
          )}
        </div>

        {/* Right: Fully Responsive Controls */}
        <div className="flex items-center gap-1 sm:gap-1.5 flex-shrink-0">
          {/* Desktop Utilities: Soundbox, Offline, Senior Mode, Logo Adjuster */}
          <div className="hidden md:flex items-center gap-1 sm:gap-1.5">
            {/* Logo Size Adjuster for Desktop */}
            <button
              onClick={cycleLogoSize}
              className={`p-2 rounded-xl border transition-all font-bold flex items-center gap-1 ${
                logoSize !== 'balanced'
                  ? 'bg-amber-400/20 text-amber-300 border-amber-400/50 shadow-xs'
                  : 'bg-white/10 hover:bg-white/20 text-white border-white/20'
              }`}
              title={`Header Logo Size: currently ${logoSize.toUpperCase()}. Click to switch Small / Medium / Large to fit all options.`}
              aria-label="Adjust Header Logo Size"
            >
              <SlidersHorizontal className="w-3.5 h-3.5 text-amber-300" />
              <span className="text-[10px] font-black uppercase hidden lg:inline">
                {logoSize === 'compact' ? 'Small' : logoSize === 'balanced' ? 'Med' : 'Large'}
              </span>
            </button>

            {/* Soundbox Voice Announcement */}
            <button
              onClick={onOpenSoundboxTest}
              className="p-2 rounded-xl bg-white/10 hover:bg-white/20 border border-white/20 text-white transition-all font-bold"
              title="Soundbox Voice Announcement Test"
              aria-label="Soundbox Voice Announcement Test"
            >
              <Volume2 className="w-3.5 h-3.5 text-amber-300" />
            </button>

            {/* Offline / Online Toggle */}
            <button
              onClick={onToggleOffline}
              className={`p-2 rounded-xl border transition-all ${
                isOffline
                  ? 'bg-amber-400 text-slate-950 border-amber-300 font-black shadow-xs'
                  : 'bg-white/10 hover:bg-white/20 text-emerald-300 border-white/20'
              }`}
              title={isOffline ? 'Switch to Online Mode' : 'Simulate Offline Mode'}
              aria-label={isOffline ? 'Switch to Online Mode' : 'Simulate Offline Mode'}
            >
              {isOffline ? <WifiOff className="w-3.5 h-3.5" /> : <Wifi className="w-3.5 h-3.5" />}
            </button>

            {/* Senior / High Contrast Accessibility Mode */}
            <button
              onClick={onToggleSeniorMode}
              className={`p-2 rounded-xl border transition-all ${
                user?.seniorMode || isSeniorMode
                  ? 'bg-amber-400 text-slate-950 border-amber-300 ring-2 ring-amber-200 font-black'
                  : 'bg-white/10 hover:bg-white/20 text-white border-white/20'
              }`}
              title="Senior Citizen / Accessible View"
              aria-label="Senior Citizen / Accessible View"
            >
              <Accessibility className="w-3.5 h-3.5" />
            </button>
          </div>

          {/* Mobile Utilities Dropdown Toggle (Hidden on md+) */}
          <div className="relative md:hidden" ref={toolsRef}>
            <button
              onClick={() => {
                setToolsMenuOpen(!toolsMenuOpen);
                setLangMenuOpen(false);
              }}
              className={`p-1.5 sm:p-2 rounded-xl border transition-all relative ${
                isOffline || user?.seniorMode || isSeniorMode || logoSize !== 'balanced'
                  ? 'bg-amber-400/30 border-amber-300 text-amber-300'
                  : 'bg-white/10 hover:bg-white/20 border-white/20 text-white'
              }`}
              title="Banking Tools (Soundbox, Logo Size, Offline, Senior Mode)"
              aria-label="Banking Tools"
            >
              <Sliders className="w-3.5 h-3.5 text-amber-300" />
              {(isOffline || user?.seniorMode || isSeniorMode) && (
                <span className="absolute -top-0.5 -right-0.5 w-2 h-2 bg-amber-400 rounded-full ring-1 ring-[#0a2540]" />
              )}
            </button>

            {toolsMenuOpen && (
              <div className="absolute right-0 mt-2 w-60 bg-white text-slate-900 rounded-2xl shadow-2xl border border-slate-200 py-2 z-50 animate-in fade-in zoom-in-95">
                <div className="px-3 py-1.5 border-b border-slate-100 text-[10px] font-black text-slate-400 uppercase tracking-widest flex items-center justify-between">
                  <span>Quick Banking Tools</span>
                  <span className="text-[9px] text-amber-600 font-bold capitalize">Logo: {logoSize}</span>
                </div>
                <div className="p-1 space-y-1">
                  {/* Logo Size Adjuster in Mobile Menu */}
                  <div className="p-2 bg-slate-50 rounded-xl border border-slate-200/80 mb-1">
                    <div className="flex items-center justify-between mb-1.5 px-0.5">
                      <span className="text-[10px] font-black text-slate-700 uppercase tracking-wider flex items-center gap-1">
                        <SlidersHorizontal className="w-3 h-3 text-amber-600" />
                        Header Logo Size
                      </span>
                      <span className="text-[9px] font-black text-amber-700 bg-amber-100 px-1.5 py-0.2 rounded uppercase">
                        {logoSize === 'compact' ? 'Small' : logoSize === 'balanced' ? 'Med' : 'Large'}
                      </span>
                    </div>
                    <div className="grid grid-cols-3 gap-1 bg-white p-0.5 rounded-lg border border-slate-200">
                      {(['compact', 'balanced', 'enlarged'] as const).map((s) => (
                        <button
                          key={s}
                          type="button"
                          onClick={() => handleSetLogoSize(s)}
                          className={`py-1 text-[10px] font-black rounded-md uppercase tracking-wider transition-all ${
                            logoSize === s
                              ? 'bg-[#861F41] text-amber-300 shadow-xs'
                              : 'text-slate-600 hover:text-slate-900'
                          }`}
                        >
                          {s === 'enlarged' ? 'Large' : s === 'compact' ? 'Small' : 'Med'}
                        </button>
                      ))}
                    </div>
                    <p className="text-[8px] text-slate-400 px-0.5 pt-1 font-semibold leading-tight">
                      Adjust size so all header menu options fit your screen.
                    </p>
                  </div>

                  <button
                    onClick={() => {
                      onOpenSoundboxTest();
                      setToolsMenuOpen(false);
                    }}
                    className="w-full text-left px-3 py-2 rounded-xl hover:bg-slate-50 text-xs font-bold text-slate-800 flex items-center justify-between"
                  >
                    <span className="flex items-center gap-2">
                      <Volume2 className="w-4 h-4 text-amber-600" />
                      <span>Soundbox Test</span>
                    </span>
                    <span className="text-[10px] text-slate-400 font-mono uppercase">Audio</span>
                  </button>

                  <button
                    onClick={() => {
                      onToggleOffline();
                      setToolsMenuOpen(false);
                    }}
                    className="w-full text-left px-3 py-2 rounded-xl hover:bg-slate-50 text-xs font-bold text-slate-800 flex items-center justify-between"
                  >
                    <span className="flex items-center gap-2">
                      {isOffline ? (
                        <WifiOff className="w-4 h-4 text-amber-600" />
                      ) : (
                        <Wifi className="w-4 h-4 text-emerald-600" />
                      )}
                      <span>Offline Mode</span>
                    </span>
                    <span
                      className={`text-[10px] font-black px-1.5 py-0.5 rounded ${
                        isOffline ? 'bg-amber-100 text-amber-800' : 'bg-slate-100 text-slate-600'
                      }`}
                    >
                      {isOffline ? 'ON' : 'OFF'}
                    </span>
                  </button>

                  <button
                    onClick={() => {
                      onToggleSeniorMode();
                      setToolsMenuOpen(false);
                    }}
                    className="w-full text-left px-3 py-2 rounded-xl hover:bg-slate-50 text-xs font-bold text-slate-800 flex items-center justify-between"
                  >
                    <span className="flex items-center gap-2">
                      <Accessibility className="w-4 h-4 text-rose-700" />
                      <span>Senior Mode</span>
                    </span>
                    <span
                      className={`text-[10px] font-black px-1.5 py-0.5 rounded ${
                        user?.seniorMode || isSeniorMode
                          ? 'bg-amber-100 text-amber-800'
                          : 'bg-slate-100 text-slate-600'
                      }`}
                    >
                      {user?.seniorMode || isSeniorMode ? 'ACTIVE' : 'OFF'}
                    </span>
                  </button>
                </div>
              </div>
            )}
          </div>

          {/* Language Selector Dropdown */}
          <div className="relative" ref={langRef}>
            <button
              onClick={() => {
                setLangMenuOpen(!langMenuOpen);
                setToolsMenuOpen(false);
              }}
              className="bg-white/10 hover:bg-white/20 border border-white/20 px-2 sm:px-2.5 py-1.5 rounded-xl text-xs font-bold uppercase tracking-wider text-white flex items-center gap-1 transition-all shadow-xs"
              title="Change Language"
              aria-label="Change Language"
            >
              <Globe className="w-3.5 h-3.5 text-amber-300" />
              {/* Short 2-letter on mobile, native label on sm+ */}
              <span className="sm:hidden font-mono text-[11px]">
                {language.toUpperCase()}
              </span>
              <span className="hidden sm:inline text-[11px]">
                {currentLangObj.nativeLabel}
              </span>
              <ChevronDown className="w-3 h-3 text-slate-300 hidden sm:inline" />
            </button>

            {langMenuOpen && (
              <div className="absolute right-0 mt-2 w-48 sm:w-52 bg-white text-slate-900 rounded-2xl shadow-2xl border border-slate-200 py-2 z-50 animate-in fade-in zoom-in-95">
                <div className="px-3 py-1.5 border-b border-slate-100 text-[10px] font-black text-slate-400 uppercase tracking-widest">
                  Select Language (भाषा)
                </div>
                <div className="max-h-60 overflow-y-auto">
                  {SUPPORTED_LANGUAGES.map((lang) => (
                    <button
                      key={lang.code}
                      onClick={() => {
                        onLanguageChange(lang.code);
                        setLangMenuOpen(false);
                      }}
                      className={`w-full text-left px-3 sm:px-4 py-2 text-xs flex items-center justify-between hover:bg-slate-50 transition-colors ${
                        language === lang.code
                          ? 'bg-rose-50 font-black text-[#861F41]'
                          : 'text-slate-700 font-bold'
                      }`}
                    >
                      <span className="flex items-center gap-2">
                        <span>{lang.flag}</span>
                        <span>{lang.nativeLabel}</span>
                      </span>
                      {language === lang.code && (
                        <Check className="w-3.5 h-3.5 text-[#861F41]" />
                      )}
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Notifications Bell */}
          <button
            onClick={onOpenNotifications}
            className="relative p-1.5 sm:p-2 rounded-xl bg-white/10 hover:bg-white/20 border border-white/20 text-white transition-all font-bold"
            title="Alerts & SMS Notifications"
            aria-label="Alerts & SMS Notifications"
          >
            <Bell className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-slate-200" />
            {unreadAlertsCount > 0 && (
              <span className="absolute -top-1 -right-1 w-4 h-4 bg-amber-400 text-slate-950 font-black text-[9px] sm:text-[10px] rounded-full flex items-center justify-center animate-pulse shadow">
                {unreadAlertsCount}
              </span>
            )}
          </button>

          {/* User Profile Button */}
          {user ? (
            <div className="flex items-center gap-1 sm:gap-1.5">
              <button
                onClick={onOpenProfile}
                className="flex items-center gap-1 sm:gap-1.5 bg-white/10 hover:bg-white/20 border border-amber-400/60 text-white p-0.5 sm:pl-1 sm:pr-2.5 sm:py-1 rounded-full text-xs font-black transition active:scale-95 shadow-xs"
                title="View Customer Profile & KYC Details"
                aria-label="View Customer Profile"
              >
                {user.photoUrl ? (
                  <img
                    src={user.photoUrl}
                    alt={user.name}
                    referrerPolicy="no-referrer"
                    className="w-6 h-6 sm:w-6 sm:h-6 rounded-full object-cover border border-amber-300 shadow-inner flex-shrink-0"
                  />
                ) : (
                  <div className="w-6 h-6 rounded-full bg-amber-400 text-slate-950 font-black text-xs flex items-center justify-center shadow-inner flex-shrink-0">
                    {user.name.charAt(0)}
                  </div>
                )}
                <span className="hidden md:inline text-[11px] font-bold text-amber-200 truncate max-w-[90px]">
                  {user.name.split(' ')[0]}
                </span>
              </button>

              {/* Logout Button */}
              {onLogout && (
                <button
                  onClick={onLogout}
                  className="flex items-center gap-1 bg-rose-600/90 hover:bg-rose-600 text-white p-1.5 sm:px-2.5 sm:py-1.5 rounded-xl text-xs font-bold transition shadow-xs active:scale-95"
                  title="Log Out of Mobile Banking"
                  aria-label="Log Out of Mobile Banking"
                >
                  <LogOut className="w-3.5 h-3.5 text-white" />
                  <span className="hidden sm:inline text-[11px]">Logout</span>
                </button>
              )}
            </div>
          ) : (
            <button
              onClick={onOpenProfile}
              className="flex items-center gap-1 bg-amber-400 hover:bg-amber-300 text-slate-950 px-2.5 sm:px-3 py-1.5 rounded-xl text-xs font-black uppercase tracking-wider transition active:scale-95 shadow-md"
              title="Customer Login"
              aria-label="Customer Login"
            >
              <LogIn className="w-3.5 h-3.5" />
              <span>Login</span>
            </button>
          )}
        </div>
      </div>
    </header>
  );
};

export const AxisBankHeader = AirtelHeader;
