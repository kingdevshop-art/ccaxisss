import React, { useState, useEffect } from 'react';
import {
  X,
  QrCode,
  Copy,
  Check,
  Share2,
  Download,
  Sparkles,
  ArrowDownLeft,
  Volume2,
  ShieldCheck,
  IndianRupee,
  Smartphone,
  Send,
} from 'lucide-react';
import { UserProfile, LanguageCode } from '../types';
import { speakSoundboxTransactionAlert } from '../utils/audioAlert';
import { generateUserQrCode } from '../utils/qrUtils';

interface ReceiveMoneyModalProps {
  isOpen: boolean;
  onClose: () => void;
  user: UserProfile;
  language: LanguageCode;
  onSimulateCredit: (amount: number, senderName: string, note?: string) => void;
  onPayUserQr?: (upiId: string, name: string, presetAmount?: number) => void;
}

export const ReceiveMoneyModal: React.FC<ReceiveMoneyModalProps> = ({
  isOpen,
  onClose,
  user,
  language,
  onSimulateCredit,
  onPayUserQr,
}) => {
  const [requestedAmount, setRequestedAmount] = useState<string>('');
  const [copied, setCopied] = useState(false);
  const [inwardSuccess, setInwardSuccess] = useState<string | null>(null);
  const [qrCodeDataUrl, setQrCodeDataUrl] = useState<string>('');
  const [isGenerating, setIsGenerating] = useState(true);

  // Generate crisp standard NPCI UPI QR code dynamically for the user
  useEffect(() => {
    if (!isOpen) return;
    let isMounted = true;
    setIsGenerating(true);

    const amountNum = requestedAmount ? parseFloat(requestedAmount) : undefined;
    generateUserQrCode(user, amountNum)
      .then((dataUrl) => {
        if (isMounted) {
          setQrCodeDataUrl(dataUrl);
          setIsGenerating(false);

          // Save QR code to server/db in background
          if (dataUrl && user.id) {
            fetch('/api/user/qrcode', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({ userId: user.id, qrCodeDataUrl: dataUrl }),
            }).catch(() => {});
          }
        }
      })
      .catch((err) => {
        console.error('QR code generation failed:', err);
        if (isMounted) setIsGenerating(false);
      });

    return () => {
      isMounted = false;
    };
  }, [isOpen, user, requestedAmount]);

  if (!isOpen) return null;

  const handleCopyUpi = () => {
    navigator.clipboard?.writeText(user.upiId);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownloadQr = () => {
    if (!qrCodeDataUrl) return;
    const link = document.createElement('a');
    link.download = `AXIS_VIP_QR_${user.upiId.replace(/[^a-zA-Z0-9]/g, '_')}.png`;
    link.href = qrCodeDataUrl;
    link.click();
  };

  const handleShareQr = () => {
    if (navigator.share) {
      navigator
        .share({
          title: `Axis Bank CC VIP UPI QR - ${user.name}`,
          text: `Pay ${user.name} directly on Axis Bank CC VIP Banking via UPI ID: ${user.upiId}`,
          url: window.location.href,
        })
        .catch(() => {});
    } else {
      handleCopyUpi();
    }
  };

  const handleSimulatePayment = (amount: number, sender: string) => {
    // Disabled balance transfer as requested: no funds are credited or added to account
    // Soundbox test alert remains fully active to test the voice speaker
    speakSoundboxTransactionAlert({
      type: 'CREDIT',
      amount,
      senderName: sender,
      language: user.soundboxLanguage || language,
    });
    setInwardSuccess(
      `Voice alert test: Announced ₹${amount.toLocaleString('en-IN')} from ${sender} (Audio only • No credit added to account)`
    );
    setTimeout(() => {
      setInwardSuccess(null);
    }, 4500);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-slate-950/70 backdrop-blur-xs animate-in fade-in">
      <div className="bg-white rounded-3xl w-full max-w-md border border-slate-200 overflow-hidden shadow-2xl flex flex-col max-h-[94vh]">
        {/* Modal Header */}
        <div className="bg-gradient-to-r from-[#071d34] via-[#0a2540] to-[#0d2e53] text-white p-4 sm:p-5 flex items-center justify-between border-b border-[#143d6b]">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-xl bg-amber-400/20 border border-amber-400/40 flex items-center justify-center text-amber-300 shadow-inner">
              <QrCode className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-sm font-black uppercase tracking-wider text-white">
                Receive Money / My QR
              </h2>
              <p className="text-[10px] text-amber-200 font-bold flex items-center gap-1">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping" />
                Active NPCI UPI QR • Instant Settlement
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-full bg-white/10 hover:bg-white/20 text-slate-300 hover:text-white transition"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content Body */}
        <div className="p-4 sm:p-5 space-y-4 overflow-y-auto">
          {/* Inward Alert Banner if simulated */}
          {inwardSuccess && (
            <div className="bg-emerald-50 border border-emerald-300 text-emerald-900 p-3 rounded-2xl flex items-center justify-between text-xs font-bold animate-in slide-in-from-top">
              <div className="flex items-center gap-2">
                <Volume2 className="w-4 h-4 text-emerald-600 flex-shrink-0 animate-bounce" />
                <span>{inwardSuccess}</span>
              </div>
              <span className="text-[10px] bg-emerald-600 text-white px-2 py-0.5 rounded-full font-black uppercase tracking-wider">
                Soundbox Alert
              </span>
            </div>
          )}

          {/* QR Code Container Card */}
          <div className="bg-gradient-to-b from-slate-50 to-white border-2 border-slate-200 rounded-3xl p-5 text-center flex flex-col items-center shadow-xs relative">
            <div className="flex items-center gap-2.5 mb-2.5">
              <div className="w-10 h-10 flex items-center justify-center flex-shrink-0">
                <img
                  src="/axis_logo.svg"
                  alt="Axis Bank CC VIP Logo"
                  className="w-full h-full object-contain filter drop-shadow-sm"
                />
              </div>
              <span className="text-xs sm:text-sm font-black uppercase tracking-wider text-[#861F41]">
                Axis Bank CC VIP Portal
              </span>
            </div>

            <p className="text-sm font-black text-slate-900">{user.name}</p>
            <p className="text-[11px] font-mono font-bold text-slate-600 mb-3">
              {user.upiId}
            </p>

            {/* Generated QR Code Canvas */}
            <div className="relative p-3.5 bg-white border border-slate-300 rounded-2xl shadow-inner inline-block">
              {isGenerating ? (
                <div className="w-48 h-48 sm:w-56 sm:h-56 flex flex-col items-center justify-center bg-slate-50 rounded-xl gap-2">
                  <div className="w-8 h-8 border-3 border-amber-400 border-t-[#861F41] rounded-full animate-spin" />
                  <span className="text-[11px] font-bold text-slate-500">Generating Active QR...</span>
                </div>
              ) : qrCodeDataUrl ? (
                <div className="relative w-48 h-48 sm:w-56 sm:h-56">
                  <img
                    src={qrCodeDataUrl}
                    alt="Active UPI QR Code"
                    className="w-full h-full object-contain rounded-lg"
                  />
                  {/* Central emblem */}
                  <div className="absolute inset-0 m-auto w-12 h-12 rounded-xl bg-white/95 border-2 border-[#861F41] p-1 flex items-center justify-center shadow-lg pointer-events-none">
                    <img
                      src="/axis_logo.svg"
                      alt="Axis Bank CC VIP Logo"
                      className="w-full h-full object-contain"
                    />
                  </div>
                </div>
              ) : (
                <div className="w-48 h-48 flex items-center justify-center text-slate-400 text-xs">
                  Failed to load QR code
                </div>
              )}
            </div>

            {/* Requested Amount Indicator if any */}
            {requestedAmount && parseFloat(requestedAmount) > 0 && (
              <div className="mt-2 bg-amber-100 border border-amber-300 text-amber-900 px-3 py-1 rounded-full text-xs font-black">
                Requesting: ₹{parseFloat(requestedAmount).toLocaleString('en-IN')}
              </div>
            )}

            <div className="mt-3 flex items-center gap-1.5 text-[10px] text-slate-500 font-bold">
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
              <span>NPCI UPI 2.0 • Scannable via PhonePe, GPay, Paytm, BHIM & Axis Mobile</span>
            </div>

            {/* Quick Actions for QR */}
            <div className="grid grid-cols-2 gap-2 w-full mt-3 pt-3 border-t border-slate-100">
              <button
                type="button"
                onClick={handleDownloadQr}
                disabled={!qrCodeDataUrl}
                className="py-1.5 px-3 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs flex items-center justify-center gap-1.5 transition active:scale-95 disabled:opacity-50"
              >
                <Download className="w-3.5 h-3.5 text-[#0a2540]" />
                <span>Save QR Image</span>
              </button>
              <button
                type="button"
                onClick={handleShareQr}
                className="py-1.5 px-3 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs flex items-center justify-center gap-1.5 transition active:scale-95"
              >
                <Share2 className="w-3.5 h-3.5 text-[#0a2540]" />
                <span>Share UPI</span>
              </button>
            </div>
          </div>

          {/* Copy UPI & Custom Amount Input */}
          <div className="space-y-2">
            <div className="flex items-center gap-2 bg-slate-50 border border-slate-200 rounded-xl p-2.5">
              <div className="flex-1 min-w-0">
                <p className="text-[10px] font-black text-slate-400 uppercase tracking-wider">
                  Your Virtual Payment Address (VPA)
                </p>
                <p className="text-xs font-black text-slate-900 font-mono truncate">
                  {user.upiId}
                </p>
              </div>
              <button
                onClick={handleCopyUpi}
                className="px-3 py-1.5 rounded-lg bg-[#0a2540] hover:bg-[#071d34] text-amber-300 font-black text-xs flex items-center gap-1 transition active:scale-95 shadow-xs"
              >
                {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copied ? 'Copied' : 'Copy'}</span>
              </button>
            </div>

            {/* Set Custom Request Amount */}
            <div className="flex items-center gap-2">
              <div className="relative flex-1">
                <IndianRupee className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                <input
                  type="number"
                  placeholder="Set custom request amount (optional)"
                  value={requestedAmount}
                  onChange={(e) => setRequestedAmount(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl pl-8 pr-3 py-2 text-xs font-bold text-slate-900 placeholder-slate-400 focus:outline-none focus:border-[#0a2540]"
                />
              </div>
              {requestedAmount && (
                <button
                  onClick={() => setRequestedAmount('')}
                  className="px-2.5 py-2 text-xs text-slate-400 hover:text-slate-600 font-bold"
                >
                  Clear
                </button>
              )}
            </div>
          </div>

          {/* Soundbox Voice Alert Audio Test (Credit Transfer Disabled) */}
          <div className="bg-amber-50/80 border border-amber-200 rounded-2xl p-3 space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-[11px] font-black text-amber-950 uppercase tracking-wider flex items-center gap-1.5">
                <Volume2 className="w-3.5 h-3.5 text-amber-600" />
                Live Soundbox Voice Alert Test
              </span>
              <span className="text-[9px] bg-amber-200 text-amber-900 border border-amber-300 px-2 py-0.5 rounded-full font-black uppercase tracking-wider">
                Voice Test • No Credit
              </span>
            </div>
            <p className="text-[10px] text-amber-800 font-medium leading-relaxed">
              Test the soundbox voice announcement in your selected voice language. Credit transfer is safely disabled so your account balance remains completely unaffected.
            </p>
            <div className="grid grid-cols-2 gap-2 pt-1">
              <button
                type="button"
                onClick={() => handleSimulatePayment(500, 'Bengal Agro Supplies')}
                className="py-2.5 px-3 rounded-xl bg-amber-400 hover:bg-amber-300 text-slate-950 font-black text-xs uppercase tracking-wider transition active:scale-95 shadow-xs flex items-center justify-center gap-1.5"
                title="Play test voice announcement for ₹500 (No credit to account)"
              >
                <Volume2 className="w-3.5 h-3.5 text-slate-950" />
                <span>Hear ₹500 Alert</span>
              </button>
              <button
                type="button"
                onClick={() => handleSimulatePayment(1250, 'Kolkata Traders')}
                className="py-2.5 px-3 rounded-xl bg-white hover:bg-amber-100 text-slate-900 border border-amber-300 font-black text-xs uppercase tracking-wider transition active:scale-95 shadow-xs flex items-center justify-center gap-1.5"
                title="Play test voice announcement for ₹1,250 (No credit to account)"
              >
                <Volume2 className="w-3.5 h-3.5 text-amber-600" />
                <span>Hear ₹1,250 Alert</span>
              </button>
            </div>
            <div className="flex items-center justify-center gap-1 text-[9px] text-amber-800/80 font-bold pt-0.5">
              <ShieldCheck className="w-3 h-3 text-emerald-600 inline" />
              <span>Balance Protection Active: Audio announcement only, zero funds transferred.</span>
            </div>
          </div>
        </div>

        {/* Modal Footer */}
        <div className="p-3.5 bg-slate-50 border-t border-slate-200 flex items-center justify-between">
          <div className="text-[10px] font-mono text-slate-500 font-bold">
            IFSC: {user.ifscCode} • A/C: •••• {user.accountNumber.slice(-4)}
          </div>
          <button
            onClick={onClose}
            className="px-5 py-2 rounded-xl bg-[#0a2540] hover:bg-[#071d34] text-white font-black text-xs uppercase tracking-wider shadow-sm transition active:scale-95"
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );
};
