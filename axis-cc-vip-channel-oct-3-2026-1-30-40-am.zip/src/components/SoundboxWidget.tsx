import React, { useState } from 'react';
import {
  Volume2,
  VolumeX,
  Sparkles,
  Radio,
  Play,
  Languages,
  Check,
  X,
} from 'lucide-react';
import { LanguageCode, UserProfile } from '../types';
import { speakSoundboxAlert } from '../utils/audioAlert';
import { TRANSLATIONS } from '../i18n/translations';

interface SoundboxWidgetProps {
  user: UserProfile;
  language: LanguageCode;
  onToggleSoundbox: (enabled: boolean) => void;
  onChangeSoundboxLanguage: (lang: LanguageCode) => void;
}

export const SoundboxWidget: React.FC<SoundboxWidgetProps> = ({
  user,
  language,
  onToggleSoundbox,
  onChangeSoundboxLanguage,
}) => {
  const [isOpen, setIsOpen] = useState(false);
  const [testAmount, setTestAmount] = useState('500');

  const supportedLanguages: { code: LanguageCode; label: string }[] = [
    { code: 'hi', label: 'Hindi (हिंदी)' },
    { code: 'en', label: 'English' },
    { code: 'bn', label: 'Bengali (বাংলা)' },
    { code: 'te', label: 'Telugu (తెలుగు)' },
    { code: 'mr', label: 'Marathi (मराठी)' },
    { code: 'ta', label: 'Tamil (தமிழ்)' },
    { code: 'gu', label: 'Gujarati (ગુજરાતી)' },
    { code: 'bho', label: 'Bhojpuri (भोजपुरी)' },
    { code: 'pa', label: 'Punjabi (ਪੰਜਾਬੀ)' },
  ];

  const handleTestChime = () => {
    const num = parseFloat(testAmount) || 500;
    speakSoundboxAlert(num, user.soundboxLanguage || language);
  };

  return (
    <>
      {/* Floating Soundbox Pill */}
      <button
        onClick={() => setIsOpen(true)}
        className="fixed bottom-20 right-4 z-40 bg-[#0a2540] text-amber-300 font-black p-2.5 sm:px-3.5 sm:py-2 rounded-full shadow-2xl shadow-blue-950/40 flex items-center gap-2 border-2 border-amber-400/60 hover:scale-105 active:scale-95 transition-all group"
      >
        <div className="relative">
          <Volume2 className="w-5 h-5 text-amber-300 animate-bounce" />
          <span className="absolute -top-1 -right-1 w-2 h-2 rounded-full bg-amber-400 animate-ping" />
        </div>
        <span className="hidden sm:inline text-xs font-black tracking-wider uppercase">
          Axis VIP Soundbox
        </span>
      </button>

      {/* Settings Modal */}
      {isOpen && (
        <div className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-4 animate-in fade-in">
          <div className="w-full max-w-sm bg-white border border-slate-200 text-slate-900 rounded-3xl p-5 shadow-2xl relative space-y-4">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-xl bg-rose-50 text-[#861F41] border border-rose-200 flex items-center justify-center font-black">
                  <Volume2 className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="font-black text-xs uppercase tracking-wider text-slate-900">
                    Axis VIP Soundbox
                  </h3>
                  <p className="text-[10px] text-slate-500 font-bold">
                    Real-Time Corporate Transaction Voice Alerts
                  </p>
                </div>
              </div>
              <button
                onClick={() => setIsOpen(false)}
                className="p-1.5 rounded-full bg-slate-100 text-slate-400 hover:text-slate-900 hover:bg-slate-200 transition"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Toggle Active */}
            <div className="flex items-center justify-between p-3.5 rounded-2xl bg-slate-50 border border-slate-200 shadow-2xs">
              <div>
                <p className="text-xs font-black text-slate-900 uppercase tracking-wider">Voice Alerts</p>
                <p className="text-[10px] text-slate-500 font-bold">
                  Announce received and sent amounts
                </p>
              </div>
              <label className="relative inline-flex items-center cursor-pointer">
                <input
                  type="checkbox"
                  checked={user.soundboxVoiceAlerts}
                  onChange={(e) => onToggleSoundbox(e.target.checked)}
                  className="sr-only peer"
                />
                <div className="w-11 h-6 bg-slate-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-[#0a2540]" />
              </label>
            </div>

            {/* Language Selector */}
            <div>
              <label className="text-[11px] font-black uppercase tracking-wider text-slate-700 block mb-1.5 flex items-center gap-1">
                <Languages className="w-3.5 h-3.5 text-[#0a2540]" />
                Voice Language (आवाज़ की भाषा)
              </label>
              <div className="grid grid-cols-2 gap-1.5 max-h-40 overflow-y-auto pr-1">
                {supportedLanguages.map((langItem) => {
                  const isSelected = (user.soundboxLanguage || language) === langItem.code;
                  return (
                    <button
                      key={langItem.code}
                      onClick={() => onChangeSoundboxLanguage(langItem.code)}
                      className={`p-2 rounded-xl text-left text-[11px] font-black uppercase tracking-wider flex items-center justify-between border transition shadow-2xs ${
                        isSelected
                          ? 'bg-blue-50 border-[#0a2540] text-[#0a2540]'
                          : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-50'
                      }`}
                    >
                      <span className="truncate">{langItem.label}</span>
                      {isSelected && <Check className="w-3.5 h-3.5 text-[#0a2540]" />}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Test Payment Soundbox Player */}
            <div className="p-3.5 bg-slate-50 rounded-2xl border border-slate-200 space-y-2 shadow-2xs">
              <label className="text-[11px] font-black uppercase tracking-wider text-slate-700 block">
                Test Soundbox Announcement
              </label>
              <div className="flex gap-2">
                <input
                  type="number"
                  value={testAmount}
                  onChange={(e) => setTestAmount(e.target.value)}
                  className="w-24 bg-white border border-slate-200 rounded-xl px-2.5 py-1.5 text-xs text-slate-900 font-bold"
                  placeholder="Amount"
                />
                <button
                  onClick={handleTestChime}
                  className="flex-1 py-1.5 px-3 rounded-xl bg-[#0a2540] hover:bg-[#071d34] text-amber-300 font-black uppercase tracking-wider text-xs flex items-center justify-center gap-1 shadow-md transition active:scale-95"
                >
                  <Play className="w-3.5 h-3.5 fill-amber-300" />
                  <span>Play Chime</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </>
  );
};
