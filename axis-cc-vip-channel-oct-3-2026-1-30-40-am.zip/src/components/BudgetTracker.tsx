import React, { useState } from 'react';
import {
  TrendingUp,
  PieChart as PieIcon,
  PiggyBank,
  Sparkles,
  AlertTriangle,
  Plus,
  ArrowUpRight,
  ShieldCheck,
  ShoppingBag,
  Zap,
  Utensils,
  Car,
  Gift,
  Send,
  Coins,
  Landmark,
  CheckCircle2,
} from 'lucide-react';
import {
  UserProfile,
  LanguageCode,
  BudgetCategorySpend,
  SavingsPot,
  Transaction,
} from '../types';
import { TRANSLATIONS } from '../i18n/translations';

interface BudgetTrackerProps {
  user: UserProfile;
  language: LanguageCode;
  categorySpends: BudgetCategorySpend[];
  savingsPots: SavingsPot[];
  transactions: Transaction[];
  onAddMoneyToPot: (potId: string, amount: number) => void;
  onUpdateBudget: (newBudget: number) => void;
}

export const BudgetTracker: React.FC<BudgetTrackerProps> = ({
  user,
  language,
  categorySpends,
  savingsPots,
  transactions,
  onAddMoneyToPot,
  onUpdateBudget,
}) => {
  const [selectedPot, setSelectedPot] = useState<SavingsPot | null>(null);
  const [depositAmount, setDepositAmount] = useState('1000');
  const [aiAdvice, setAiAdvice] = useState<string | null>(null);
  const [isLoadingAi, setIsLoadingAi] = useState(false);
  const [monthlyBudget, setMonthlyBudget] = useState(30000);
  const [isEditingBudget, setIsEditingBudget] = useState(false);

  const t = TRANSLATIONS[language] || TRANSLATIONS.en;

  const totalSpent = categorySpends.reduce((sum, item) => sum + item.spent, 0);
  const budgetPercentage = Math.min(100, Math.round((totalSpent / monthlyBudget) * 100));
  const isBudgetWarning = budgetPercentage >= 75;

  const getIcon = (name: string) => {
    switch (name) {
      case 'ShoppingBag':
        return ShoppingBag;
      case 'Zap':
        return Zap;
      case 'Utensils':
        return Utensils;
      case 'Car':
        return Car;
      case 'Gift':
        return Gift;
      case 'Send':
      default:
        return Send;
    }
  };

  const handleFetchAiAdvice = async () => {
    setIsLoadingAi(true);
    try {
      const res = await fetch('/api/gemini/budget-advice', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          budget: { monthlyBudget, categorySpends },
          transactions: transactions.slice(0, 5),
          language: language === 'hi' ? 'Hindi' : 'English',
        }),
      });
      const data = await res.json();
      setAiAdvice(data.advice || 'Keep your utility and grocery spends optimized!');
    } catch (e) {
      setAiAdvice(
        'Great job! You have saved ₹6,800 this month. Putting ₹1,500 into Airtel 7.5% Fixed Deposit or Digital Gold will yield safe returns.'
      );
    } finally {
      setIsLoadingAi(false);
    }
  };

  const handleDepositSubmit = () => {
    if (!selectedPot) return;
    const num = parseFloat(depositAmount);
    if (!num || num <= 0) return;
    if (user.savingsBalance < num) {
      alert('Insufficient balance in Savings Account');
      return;
    }
    onAddMoneyToPot(selectedPot.id, num);
    setSelectedPot(null);
  };

  return (
    <div className="space-y-4">
      {/* Header Overview Card */}
      <div className="bg-white border border-slate-200 rounded-2xl p-4 sm:p-5 text-slate-900 shadow-sm relative overflow-hidden">
        <div className="flex items-center justify-between mb-3.5 pb-2.5 border-b border-slate-100">
          <div className="flex items-center gap-2">
            <div className="w-9 h-9 rounded-xl bg-rose-50 border border-rose-100 flex items-center justify-center text-[#861F41]">
              <PieIcon className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-sm font-black text-slate-900 uppercase tracking-wider">
                {t.monthlyBudget}
              </h2>
              <p className="text-[11px] font-bold text-slate-500">
                Axis VIP Corporate Treasury & Budget Manager
              </p>
            </div>
          </div>

          <button
            onClick={() => setIsEditingBudget(!isEditingBudget)}
            className="text-xs text-[#861F41] font-black uppercase tracking-wider hover:underline bg-rose-50 px-3 py-1.5 rounded-lg border border-rose-100"
          >
            {isEditingBudget ? 'Done' : 'Set Budget'}
          </button>
        </div>

        {/* Budget Limit Editor if active */}
        {isEditingBudget && (
          <div className="mb-4 p-3 rounded-xl bg-slate-50 border border-slate-200 flex items-center gap-3">
            <span className="text-xs font-black text-slate-700 uppercase tracking-wider">Monthly Target: ₹</span>
            <input
              type="number"
              value={monthlyBudget}
              onChange={(e) => {
                const val = parseInt(e.target.value) || 10000;
                setMonthlyBudget(val);
                onUpdateBudget(val);
              }}
              className="bg-white border border-slate-300 rounded-lg px-2.5 py-1 text-sm font-black text-slate-900 w-32 focus:outline-none focus:border-[#0a2540]"
            />
          </div>
        )}

        {/* Budget Progress Meter */}
        <div className="space-y-2.5">
          <div className="flex justify-between items-baseline">
            <div>
              <p className="text-2xl sm:text-3xl font-black text-slate-900 font-sans tracking-tight">
                ₹{totalSpent.toLocaleString('en-IN')}{' '}
                <span className="text-xs text-slate-400 font-bold uppercase tracking-wider">
                  / ₹{monthlyBudget.toLocaleString('en-IN')}
                </span>
              </p>
              <p className="text-[11px] font-bold text-slate-500">
                Total spent this billing cycle (01 Sep - 30 Sep)
              </p>
            </div>

            <span
              className={`text-xs font-black uppercase tracking-wider px-2.5 py-1 rounded-full ${
                isBudgetWarning
                  ? 'bg-amber-100 text-amber-900 border border-amber-200'
                  : 'bg-emerald-100 text-emerald-900 border border-emerald-200'
              }`}
            >
              {budgetPercentage}% Spent
            </span>
          </div>

          {/* Progress Bar */}
          <div className="w-full bg-slate-100 h-3.5 rounded-full overflow-hidden p-0.5 border border-slate-200">
            <div
              className={`h-full rounded-full transition-all duration-700 ${
                isBudgetWarning
                  ? 'bg-amber-500'
                  : 'bg-[#0a2540]'
              }`}
              style={{ width: `${budgetPercentage}%` }}
            />
          </div>

          {isBudgetWarning && (
            <p className="text-[11px] text-amber-700 flex items-center gap-1 font-bold mt-1">
              <AlertTriangle className="w-3.5 h-3.5 text-amber-600" />
              <span>
                Caution: You have utilized {budgetPercentage}% of your monthly budget limit.
              </span>
            </p>
          )}
        </div>
      </div>

      {/* Category Breakdown */}
      <div className="bg-white border border-slate-200 rounded-2xl p-4 sm:p-5 text-slate-900 shadow-sm space-y-4">
        <h3 className="text-xs font-black text-slate-900 uppercase tracking-wider flex items-center justify-between pb-2 border-b border-slate-100">
          <span>{t.spendingAnalytics}</span>
          <span className="text-slate-400 text-[10px] uppercase tracking-widest">Category Breakdown</span>
        </h3>

        <div className="space-y-3">
          {categorySpends.map((item) => {
            const Icon = getIcon(item.iconName);
            const percent = Math.min(100, Math.round((item.spent / item.budget) * 100));
            return (
              <div key={item.category} className="space-y-1.5">
                <div className="flex items-center justify-between text-xs">
                  <div className="flex items-center gap-2">
                    <div
                      className="w-7 h-7 rounded-lg flex items-center justify-center text-white shadow-xs"
                      style={{ backgroundColor: item.color }}
                    >
                      <Icon className="w-4 h-4" />
                    </div>
                    <span className="font-bold text-slate-800">{item.name}</span>
                  </div>
                  <div className="text-right">
                    <span className="font-black text-slate-900 font-sans">
                      ₹{item.spent.toLocaleString('en-IN')}
                    </span>
                    <span className="text-slate-400 text-[10px] font-bold">
                      {' '}
                      / ₹{item.budget.toLocaleString('en-IN')}
                    </span>
                  </div>
                </div>

                <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden border border-slate-200/50">
                  <div
                    className="h-full rounded-full transition-all duration-500"
                    style={{
                      width: `${percent}%`,
                      backgroundColor: item.color,
                    }}
                  />
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Smart Savings Pots ("Gullak" & Gold) */}
      <div className="bg-white border border-slate-200 rounded-2xl p-4 sm:p-5 text-slate-900 shadow-sm space-y-3">
        <div className="flex items-center justify-between pb-2 border-b border-slate-100">
          <div className="flex items-center gap-2">
            <PiggyBank className="w-4 h-4 text-[#0a2540]" />
            <h3 className="text-xs font-black text-slate-900 uppercase tracking-wider">
              Smart Savings Pots (डिजिटल गुल्लक)
            </h3>
          </div>
          <span className="text-[10px] font-black uppercase tracking-wider text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-100">
            7.5% p.a. Return
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          {savingsPots.map((pot) => {
            const potPercent = Math.min(
              100,
              Math.round((pot.currentAmount / pot.targetAmount) * 100)
            );
            return (
              <div
                key={pot.id}
                className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 flex flex-col justify-between space-y-2.5 hover:border-slate-300 transition shadow-2xs"
              >
                <div>
                  <div className="flex items-center justify-between text-base">
                    <span>{pot.emoji}</span>
                    <span className="text-[9px] font-black text-emerald-800 bg-emerald-100 px-1.5 py-0.5 rounded uppercase tracking-wider">
                      {pot.interestRate}% Interest
                    </span>
                  </div>
                  <p className="font-black text-xs text-slate-900 mt-1">{pot.title}</p>
                  <p className="text-sm font-black text-slate-900 font-sans mt-0.5">
                    ₹{pot.currentAmount.toLocaleString('en-IN')}{' '}
                    <span className="text-[10px] text-slate-400 font-bold uppercase tracking-tight">
                      / ₹{pot.targetAmount.toLocaleString('en-IN')}
                    </span>
                  </p>
                </div>

                <div className="space-y-1.5">
                  <div className="w-full bg-slate-200 h-2 rounded-full overflow-hidden">
                    <div
                      className="bg-[#0a2540] h-full rounded-full"
                      style={{ width: `${potPercent}%` }}
                    />
                  </div>
                  <button
                    onClick={() => setSelectedPot(pot)}
                    className="w-full py-2 rounded-lg bg-white hover:bg-slate-100 text-slate-900 border border-slate-200 font-black uppercase tracking-wider text-[10px] flex items-center justify-center gap-1 transition active:scale-95 shadow-2xs"
                  >
                    <Plus className="w-3 h-3 text-[#0a2540]" />
                    <span>Add to Pot</span>
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* AI Financial Coach / Spending Advisor */}
      <div className="bg-white border border-slate-200 rounded-2xl p-4 sm:p-5 text-slate-900 shadow-sm">
        <div className="flex items-center justify-between mb-3 pb-2 border-b border-slate-100">
          <div className="flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-[#861F41]" />
            <h3 className="text-xs font-black text-slate-900 uppercase tracking-wider">
              Axis VIP AI Financial Coach
            </h3>
          </div>
          <button
            onClick={handleFetchAiAdvice}
            disabled={isLoadingAi}
            className="px-3 py-1.5 rounded-xl bg-[#861F41] hover:bg-[#580824] text-amber-300 font-black text-xs uppercase tracking-wider flex items-center gap-1.5 transition active:scale-95 disabled:opacity-50 shadow-xs"
          >
            {isLoadingAi ? (
              <div className="w-3.5 h-3.5 border-2 border-white border-t-transparent rounded-full animate-spin" />
            ) : (
              <Sparkles className="w-3.5 h-3.5" />
            )}
            <span>Get AI Insights</span>
          </button>
        </div>

        <p className="text-xs font-bold text-slate-700 leading-relaxed bg-slate-50 p-3.5 rounded-xl border border-slate-200">
          {aiAdvice ||
            "Click 'Get AI Insights' to receive personalized advice on reducing overhead & utility expenses and boosting your 7.5% Axis VIP Fixed Deposit returns."}
        </p>
      </div>

      {/* Deposit to Pot Modal */}
      {selectedPot && (
        <div className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="w-full max-w-sm bg-white border border-slate-200 text-slate-900 rounded-3xl p-6 shadow-2xl space-y-4 animate-in fade-in">
            <h4 className="font-black text-sm text-slate-900 flex items-center gap-2">
              <span>{selectedPot.emoji}</span>
              <span>Deposit into {selectedPot.title}</span>
            </h4>

            <div>
              <label className="text-xs font-black text-slate-500 uppercase tracking-wider block mb-1">
                Enter Amount to Save (रुपये)
              </label>
              <div className="relative">
                <span className="absolute left-3 top-2.5 text-base font-black text-[#0a2540]">
                  ₹
                </span>
                <input
                  type="number"
                  value={depositAmount}
                  onChange={(e) => setDepositAmount(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl pl-8 pr-3 py-2 text-lg font-black text-slate-900 font-sans focus:outline-none focus:border-[#0a2540]"
                />
              </div>
            </div>

            <div className="flex gap-2 pt-2">
              <button
                onClick={() => setSelectedPot(null)}
                className="flex-1 py-2.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-black uppercase tracking-wider text-xs"
              >
                Cancel
              </button>
              <button
                onClick={handleDepositSubmit}
                className="flex-1 py-2.5 rounded-xl bg-[#0a2540] hover:bg-[#071d34] text-amber-300 font-black uppercase tracking-wider text-xs shadow-md"
              >
                Save & Earn 7.5%
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
