import React, { useState } from 'react';
import {
  ShieldCheck,
  ShieldAlert,
  Lock,
  ArrowLeft,
  KeyRound,
  Building2,
  CheckCircle2,
  AlertCircle,
  Sparkles,
  Users,
  UserPlus,
  Landmark,
  Radio,
  FileCheck,
  RotateCcw,
  Sliders,
  LogOut,
  ExternalLink,
  Play,
} from 'lucide-react';
import {
  UserProfile,
  UserServices,
  KYCApplication,
  Transaction,
  PushAlert,
} from '../types';
import { AdminDashboard } from './AdminDashboard';
import { AnimatedAndroidStudioGuide } from './AnimatedAndroidStudioGuide';
import { AxisBankLogo } from './AxisBankLogo';

interface OfficerAdminAppProps {
  users: UserProfile[];
  currentUser: UserProfile | null;
  onSelectUser: (user: UserProfile) => void;
  onUpdateUser: (updatedUser: UserProfile) => void;
  onCreateUser: (newUser: UserProfile, initialDepositTx?: Transaction) => void;
  onBlockUser: (userId: string, isBlocked: boolean, reason?: string) => void;
  onAdjustBalance: (action: {
    userId: string;
    type: 'CREDIT' | 'DEBIT';
    balanceType: 'savings' | 'wallet' | 'upiLite' | 'fixedDeposit';
    amount: number;
    reason: string;
    reference: string;
  }) => void;
  onToggleUserService: (userId: string, serviceKey: keyof UserServices, enabled: boolean) => void;
  onUpdateKycStatus: (userId: string, kycStatus: 'verified' | 'pending' | 'rejected') => void;
  kycApplications: KYCApplication[];
  onApproveKyc: (id: string) => void;
  onRejectKyc: (id: string, reason?: string) => void;
  transactions: Transaction[];
  onRollbackTransaction: (txId: string) => void;
  onBroadcastAlert: (alert: PushAlert, targetSegment?: string) => void;
  onSwitchToCustomerApp: () => void;
  onApproveTransaction?: (txId: string) => void;
  onRejectTransaction?: (txId: string, reason?: string) => void;
  onHoldTransaction?: (txId: string, reason?: string) => void;
  onEditTransaction?: (txId: string, updates: Partial<Transaction>) => void;
  onDeleteTransaction?: (txId: string) => void;
  onSetUserMpin?: (userId: string, newMpin: string) => void;
  onDeleteUser?: (userId: string) => void;
}

export const OfficerAdminApp: React.FC<OfficerAdminAppProps> = ({
  users,
  currentUser,
  onSelectUser,
  onUpdateUser,
  onCreateUser,
  onBlockUser,
  onAdjustBalance,
  onToggleUserService,
  onUpdateKycStatus,
  kycApplications,
  onApproveKyc,
  onRejectKyc,
  transactions,
  onRollbackTransaction,
  onBroadcastAlert,
  onSwitchToCustomerApp,
  onApproveTransaction,
  onRejectTransaction,
  onHoldTransaction,
  onEditTransaction,
  onDeleteTransaction,
  onSetUserMpin,
  onDeleteUser,
}) => {
  const [isOfficerAuthenticated, setIsOfficerAuthenticated] = useState<boolean>(() => {
    return localStorage.getItem('axis_officer_authenticated') === 'true';
  });
  const [isVideoGuideOpen, setIsVideoGuideOpen] = useState(false);

  const [officerId, setOfficerId] = useState('OFFICER_001');
  const [officerPin, setOfficerPin] = useState('9988');
  const [errorMsg, setErrorMsg] = useState('');
  const [isLoggingIn, setIsLoggingIn] = useState(false);

  const handleOfficerLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');
    setIsLoggingIn(true);

    try {
      const res = await fetch('/api/admin/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username: officerId.trim(), password: officerPin.trim() }),
      });
      const data = await res.json();
      if (res.ok && data.success) {
        setIsOfficerAuthenticated(true);
        localStorage.setItem('axis_officer_authenticated', 'true');
        if (data.admin) {
          localStorage.setItem('axis_officer_user', JSON.stringify(data.admin));
        }
        setIsLoggingIn(false);
        return;
      } else if (res.status === 401) {
        setErrorMsg(data.error || 'Invalid Officer Credentials. Check Username & Password.');
        setIsLoggingIn(false);
        return;
      }
    } catch (err) {
      console.warn('Backend admin login network check:', err);
    }

    // Fallback credential check for offline or demo dev environment
    if (officerPin.length >= 4) {
      setIsOfficerAuthenticated(true);
      localStorage.setItem('axis_officer_authenticated', 'true');
    } else {
      setErrorMsg('Invalid Officer Security Key. Enter your 4-digit authorized PIN.');
    }
    setIsLoggingIn(false);
  };

  const handleOfficerLogout = () => {
    setIsOfficerAuthenticated(false);
    localStorage.removeItem('axis_officer_authenticated');
    localStorage.removeItem('axis_officer_user');
  };

  // If officer is not authenticated, show institutional authentication terminal
  if (!isOfficerAuthenticated) {
    return (
      <div className="min-h-screen bg-slate-900 text-slate-100 flex flex-col justify-between selection:bg-amber-400 selection:text-slate-900">
        {/* Terminal Header */}
        <header className="bg-slate-950 border-b border-slate-800 px-4 py-3">
          <div className="max-w-5xl mx-auto flex items-center justify-between">
            <div className="flex items-center gap-3">
              <AxisBankLogo size={48} />
              <div>
                <h2 className="text-sm font-black uppercase tracking-wider text-white">
                  Axis Bank CC VIP • CBS Terminal
                </h2>
                <p className="text-[10px] text-slate-400 font-mono">
                  Axis Bank • Branch 0001 (Mumbai Corporate HO) • IFSC: UTIB000001
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => setIsVideoGuideOpen(true)}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-amber-400 hover:bg-amber-300 text-slate-950 text-xs font-black uppercase tracking-wider transition shadow-sm active:scale-95"
                title="Watch Animated Android App Creation Video & Build Guide"
              >
                <Play className="w-3.5 h-3.5 fill-slate-950" />
                <span>Android App Guide</span>
              </button>

              <button
                onClick={onSwitchToCustomerApp}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs font-bold text-slate-200 border border-slate-700 transition"
              >
                <ArrowLeft className="w-3.5 h-3.5 text-amber-400" />
                <span>Customer Banking App</span>
              </button>
            </div>
          </div>
        </header>

        {/* Login Gate Form */}
        <main className="flex-1 flex items-center justify-center p-4">
          <div className="w-full max-w-md bg-slate-950 border border-slate-800 rounded-3xl p-6 sm:p-8 space-y-6 shadow-2xl relative overflow-hidden">
            <div className="absolute top-0 left-0 right-0 h-1.5 bg-gradient-to-r from-[#861F41] via-amber-400 to-[#861F41]" />

            <div className="text-center space-y-2">
              <div className="flex items-center justify-center mx-auto mb-2 transition-transform hover:scale-105 duration-200">
                <AxisBankLogo size={80} />
              </div>
              <h1 className="text-xl font-black text-white tracking-tight">
                Axis Bank CC VIP
              </h1>
              <p className="text-xs text-amber-300 font-bold uppercase tracking-wider">
                Axis Bank • Admin & Officer Console
              </p>
              <p className="text-[11px] text-slate-400 font-medium">
                Restricted CBS Institutional Access • Staff Credentials Required
              </p>
            </div>

            {errorMsg && (
              <div className="p-3 bg-rose-950/60 border border-rose-800 text-rose-300 text-xs font-bold rounded-2xl flex items-center gap-2">
                <AlertCircle className="w-4 h-4 text-rose-400 flex-shrink-0" />
                <span>{errorMsg}</span>
              </div>
            )}

            <form onSubmit={handleOfficerLogin} className="space-y-4">
              <div>
                <label className="block text-[11px] font-black uppercase tracking-wider text-slate-400 mb-1.5">
                  Officer Employee ID
                </label>
                <input
                  type="text"
                  value={officerId}
                  onChange={(e) => setOfficerId(e.target.value)}
                  placeholder="e.g. OFFICER_001"
                  className="w-full px-4 py-3 bg-slate-900 border border-slate-800 rounded-2xl text-xs font-mono font-bold text-white focus:outline-none focus:border-amber-400 focus:ring-1 focus:ring-amber-400"
                  required
                />
              </div>

              <div>
                <label className="block text-[11px] font-black uppercase tracking-wider text-slate-400 mb-1.5">
                  Security Access PIN
                </label>
                <input
                  type="password"
                  value={officerPin}
                  onChange={(e) => setOfficerPin(e.target.value)}
                  placeholder="Enter 4-digit access PIN"
                  className="w-full px-4 py-3 bg-slate-900 border border-slate-800 rounded-2xl text-xs font-mono font-bold text-white focus:outline-none focus:border-amber-400 focus:ring-1 focus:ring-amber-400"
                  required
                />
              </div>

              <div className="pt-2 space-y-2.5">
                <button
                  type="submit"
                  className="w-full py-3.5 rounded-2xl bg-amber-400 hover:bg-amber-300 text-slate-950 font-black uppercase tracking-wider text-xs shadow-lg shadow-amber-400/10 transition active:scale-95 flex items-center justify-center gap-2"
                >
                  <Lock className="w-4 h-4" />
                  <span>Authenticate & Open Admin Terminal</span>
                </button>

                <button
                  type="button"
                  onClick={() => setIsVideoGuideOpen(true)}
                  className="w-full py-2.5 rounded-2xl bg-amber-400/10 hover:bg-amber-400/20 text-amber-300 border border-amber-400/30 font-bold text-xs transition flex items-center justify-center gap-2"
                >
                  <Play className="w-3.5 h-3.5 fill-amber-300" />
                  <span>Android App Studio Guide & Cheatsheet</span>
                </button>
              </div>
            </form>

            <div className="pt-3 border-t border-slate-900 text-center text-[10px] text-slate-500 space-y-1">
              <p>Warning: System activities and IP addresses are recorded in the audit log.</p>
              <p>Axis Bank CC VIP CBS Core • Corporate Office, Mumbai</p>
            </div>
          </div>
        </main>

        <footer className="py-3 text-center text-[11px] text-slate-600 border-t border-slate-950">
          Axis Bank CC VIP • Institutional Admin Gateway
        </footer>

        {/* Animated Android Studio Video & Document Guide Modal */}
        <AnimatedAndroidStudioGuide
          isOpen={isVideoGuideOpen}
          onClose={() => setIsVideoGuideOpen(false)}
        />
      </div>
    );
  }

  // If officer is authenticated, render the full-screen institutional Admin Dashboard
  return (
    <div className="min-h-screen bg-slate-900 text-slate-100 flex flex-col selection:bg-amber-400 selection:text-slate-900">
      {/* Top Officer Terminal Bar */}
      <header className="bg-slate-950 border-b border-slate-800 px-4 py-3 sticky top-0 z-50 shadow-lg">
        <div className="max-w-7xl mx-auto flex items-center justify-between flex-wrap gap-2">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-amber-400 text-slate-950 flex items-center justify-center font-black shadow-md flex-shrink-0">
              <Landmark className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-sm font-black text-white uppercase tracking-wider">
                  Axis Bank CC VIP Branch Console
                </span>
                <span className="text-[10px] bg-emerald-950 text-emerald-300 border border-emerald-700 px-2 py-0.5 rounded-full font-bold uppercase">
                  Connected
                </span>
              </div>
              <p className="text-[11px] text-slate-400 font-medium">
                Officer: <strong className="text-slate-200">Amitav Ghosh</strong> (Chief Branch Manager, #AXIS-8891) • Axis Bank Corporate HO
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => setIsVideoGuideOpen(true)}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-amber-400 hover:bg-amber-300 text-slate-950 text-xs font-black uppercase tracking-wider transition shadow-sm active:scale-95"
              title="Watch Animated Android App Creation Video & Build Guide"
            >
              <Play className="w-3.5 h-3.5 fill-slate-950" />
              <span>Android App Guide</span>
            </button>

            <button
              onClick={onSwitchToCustomerApp}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs font-bold text-slate-200 border border-slate-700 transition"
              title="Open Customer Mobile Banking Application"
            >
              <ExternalLink className="w-3.5 h-3.5 text-amber-400" />
              <span>Customer App</span>
            </button>

            <button
              onClick={handleOfficerLogout}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-rose-950/80 hover:bg-rose-900 text-xs font-bold text-rose-200 border border-rose-800 transition"
              title="Lock and Log Out Officer Terminal"
            >
              <LogOut className="w-3.5 h-3.5 text-rose-400" />
              <span>Lock Terminal</span>
            </button>
          </div>
        </div>
      </header>

      {/* Main Admin Console Body */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-2 sm:p-4">
        <AdminDashboard
          isOpen={true}
          onClose={onSwitchToCustomerApp}
          users={users}
          currentUser={currentUser}
          onSelectUser={onSelectUser}
          onUpdateUser={onUpdateUser}
          onCreateUser={onCreateUser}
          onBlockUser={onBlockUser}
          onAdjustBalance={onAdjustBalance}
          onToggleUserService={onToggleUserService}
          onUpdateKycStatus={onUpdateKycStatus}
          kycApplications={kycApplications}
          onApproveKyc={onApproveKyc}
          onRejectKyc={onRejectKyc}
          transactions={transactions}
          onRollbackTransaction={onRollbackTransaction}
          onBroadcastAlert={onBroadcastAlert}
          onApproveTransaction={onApproveTransaction}
          onRejectTransaction={onRejectTransaction}
          onHoldTransaction={onHoldTransaction}
          onEditTransaction={onEditTransaction}
          onDeleteTransaction={onDeleteTransaction}
          onSetUserMpin={onSetUserMpin}
          onDeleteUser={onDeleteUser}
        />
      </main>

      {/* Animated Android Studio Video & Document Guide Modal */}
      <AnimatedAndroidStudioGuide
        isOpen={isVideoGuideOpen}
        onClose={() => setIsVideoGuideOpen(false)}
      />
    </div>
  );
};
