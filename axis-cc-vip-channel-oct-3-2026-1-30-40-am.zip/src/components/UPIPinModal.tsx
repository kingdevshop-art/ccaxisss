import React, { useState } from 'react';
import {
  ShieldCheck,
  Delete,
  Fingerprint,
  Lock,
  X,
  AlertCircle,
  CheckCircle2,
} from 'lucide-react';
import { LanguageCode } from '../types';
import { TRANSLATIONS } from '../i18n/translations';

interface UPIPinModalProps {
  amount: number;
  recipientTitle: string;
  recipientVpa?: string;
  language: LanguageCode;
  paymentMode: string;
  biometricAvailable: boolean;
  expectedPin?: string;
  onSuccess: () => void;
  onCancel: () => void;
}

export const UPIPinModal: React.FC<UPIPinModalProps> = ({
  amount,
  recipientTitle,
  recipientVpa,
  language,
  paymentMode,
  biometricAvailable,
  expectedPin = '1234',
  onSuccess,
  onCancel,
}) => {
  const [pin, setPin] = useState<string>('');
  const [error, setError] = useState<string | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const t = TRANSLATIONS[language] || TRANSLATIONS.en;

  const handleDigit = (digit: string) => {
    if (pin.length < 4) {
      const nextPin = pin + digit;
      setPin(nextPin);
      setError(null);
      if (nextPin.length === 4) {
        verifyPin(nextPin);
      }
    }
  };

  const handleDelete = () => {
    setPin((prev) => prev.slice(0, -1));
    setError(null);
  };

  const verifyPin = (pinToTest: string) => {
    setIsProcessing(true);
    setTimeout(() => {
      // Validate strictly against user's set MPIN
      const targetPin = expectedPin && expectedPin.trim() ? expectedPin.trim() : '1234';
      if (pinToTest !== targetPin) {
        setError('Incorrect 4-digit MPIN. Authorization denied.');
        setIsProcessing(false);
        setPin('');
      } else {
        setIsProcessing(false);
        onSuccess();
      }
    }, 600);
  };

  const handleBiometricAuth = () => {
    setIsProcessing(true);
    setTimeout(() => {
      setIsProcessing(false);
      onSuccess();
    }, 700);
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-xs flex items-end sm:items-center justify-center p-0 sm:p-4 animate-in fade-in">
      <div className="w-full sm:max-w-md bg-white border border-slate-200 text-slate-900 rounded-t-3xl sm:rounded-3xl p-5 sm:p-6 shadow-2xl relative animate-in slide-in-from-bottom duration-300">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-slate-100">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-[#861F41] flex items-center justify-center text-amber-300 font-black text-xs shadow-xs">
              UPI
            </div>
            <div>
              <p className="text-xs font-black text-slate-900 uppercase tracking-wider">
                NPCI / Axis Bank CC VIP Banking
              </p>
              <p className="text-[11px] text-slate-500 font-bold">Secure 256-bit Encrypted</p>
            </div>
          </div>
          <button
            onClick={onCancel}
            className="p-1.5 text-slate-400 hover:text-slate-900 rounded-full bg-slate-100 hover:bg-slate-200 transition"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Transaction Summary */}
        <div className="my-4 p-3.5 rounded-2xl bg-slate-50 border border-slate-200 flex items-center justify-between shadow-2xs">
          <div>
            <p className="text-[10px] font-black uppercase tracking-wider text-slate-400">Paying to</p>
            <p className="font-black text-slate-900 text-sm">{recipientTitle}</p>
            {recipientVpa && (
              <p className="text-[11px] text-slate-500 font-mono font-bold">
                {recipientVpa}
              </p>
            )}
          </div>
          <div className="text-right">
            <p className="text-[10px] font-black uppercase tracking-wider text-slate-400">Amount</p>
            <p className="text-xl font-black text-[#861F41] font-sans">
              ₹{amount.toLocaleString('en-IN', { minimumFractionDigits: 2 })}
            </p>
          </div>
        </div>

        {/* PIN Indicators */}
        <div className="text-center my-4">
          <label className="text-xs font-black text-slate-700 uppercase tracking-wider block mb-2">
            {t.enterUpiPin}
          </label>
          <div className="flex justify-center items-center gap-3">
            {[0, 1, 2, 3].map((index) => {
              const isFilled = pin.length > index;
              return (
                <div
                  key={index}
                  className={`w-4 h-4 rounded-full border-2 transition-all ${
                    isFilled
                      ? 'bg-[#861F41] border-[#861F41] scale-110 shadow-md shadow-rose-950/40'
                      : 'border-slate-300 bg-slate-100'
                  }`}
                />
              );
            })}
          </div>
          {error && (
            <p className="text-xs text-rose-600 font-black uppercase tracking-wider mt-2 flex items-center justify-center gap-1">
              <AlertCircle className="w-3.5 h-3.5" />
              {error}
            </p>
          )}
          {isProcessing && (
            <div className="flex items-center justify-center gap-2 text-xs text-amber-800 font-bold mt-2">
              <div className="w-3 h-3 border-2 border-amber-600 border-t-transparent rounded-full animate-spin" />
              <span>Verifying with NPCI & Axis Bank Core Bank...</span>
            </div>
          )}
        </div>

        {/* Biometric Quick Option */}
        {biometricAvailable && (
          <div className="mb-4">
            <button
              onClick={handleBiometricAuth}
              className="w-full py-2.5 px-4 rounded-xl bg-blue-50 border border-blue-200 hover:border-blue-400 text-[#0a2540] text-xs font-black uppercase tracking-wider flex items-center justify-center gap-2 transition active:scale-98 shadow-2xs"
            >
              <Fingerprint className="w-4 h-4 text-[#0a2540] animate-pulse" />
              <span>Approve Instantly with Biometric Fingerprint</span>
            </button>
          </div>
        )}

        {/* Custom Numeric Keypad */}
        <div className="grid grid-cols-3 gap-2 sm:gap-2.5 max-w-xs mx-auto">
          {['1', '2', '3', '4', '5', '6', '7', '8', '9'].map((digit) => (
            <button
              key={digit}
              onClick={() => handleDigit(digit)}
              className="h-12 rounded-xl bg-slate-50 hover:bg-slate-100 text-slate-900 font-black text-lg border border-slate-200 active:scale-95 transition flex items-center justify-center shadow-2xs"
            >
              {digit}
            </button>
          ))}
          <button
            onClick={onCancel}
            className="h-12 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-600 font-black text-xs uppercase tracking-wider border border-slate-200 active:scale-95 transition flex items-center justify-center"
          >
            Cancel
          </button>
          <button
            onClick={() => handleDigit('0')}
            className="h-12 rounded-xl bg-slate-50 hover:bg-slate-100 text-slate-900 font-black text-lg border border-slate-200 active:scale-95 transition flex items-center justify-center shadow-2xs"
          >
            0
          </button>
          <button
            onClick={handleDelete}
            className="h-12 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-black text-lg border border-slate-200 active:scale-95 transition flex items-center justify-center"
          >
            <Delete className="w-5 h-5" />
          </button>
        </div>

        {/* Safety Warning */}
        <p className="text-[10px] text-slate-500 font-bold text-center mt-3 flex items-center justify-center gap-1">
          <Lock className="w-3 h-3 text-[#0a2540]" />
          {t.fraudWarning}
        </p>
      </div>
    </div>
  );
};
