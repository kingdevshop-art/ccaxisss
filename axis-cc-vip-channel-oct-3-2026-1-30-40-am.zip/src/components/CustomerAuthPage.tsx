import React, { useState, useRef } from 'react';
import {
  ShieldCheck,
  Smartphone,
  Lock,
  User,
  KeyRound,
  Fingerprint,
  Building2,
  CheckCircle2,
  AlertCircle,
  Sparkles,
  Eye,
  EyeOff,
  Phone,
  CreditCard,
  Landmark,
  ChevronDown,
  Globe,
  Check,
  UserPlus,
  LogIn,
  BadgeCheck,
  X,
  SlidersHorizontal,
  Copy,
} from 'lucide-react';
import { UserProfile, LanguageCode, KYCApplication } from '../types';
import { SUPPORTED_LANGUAGES } from '../i18n/translations';
import { DEFAULT_SERVICES, AVAILABLE_ACCOUNTS } from '../data/mockData';
import { smsService } from '../services/smsService';
import { AxisBankLogo } from './AxisBankLogo';
import { generateRandomAccountNumber } from '../utils/accountUtils';
import { dbService } from '../services/dbService';
import { emailService } from '../services/emailService';
import {
  generateNetbankingCredentials,
  getDefaultVirtualCards,
} from '../utils/cardUtils';

interface CustomerAuthPageProps {
  users: UserProfile[];
  onLogin: (user: UserProfile) => void;
  onRegister?: (newUser: UserProfile) => void;
  onUpdateUser?: (updatedUser: UserProfile) => void;
  language: LanguageCode;
  onLanguageChange: (lang: LanguageCode) => void;
}

const BRANCH_OPTIONS = [
  'Axis Bank Corporate HO (Mumbai)',
  'Axis Bank Nariman Point Corporate Branch',
  'Axis Bank Kolkata Corporate Branch',
  'Axis Bank Bengaluru Tech-Commercial Hub',
  'Axis Bank New Delhi Corporate Branch',
  'Axis Bank Hyderabad Financial District Branch',
];

const SAMPLE_AVATARS = [
  'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=400&q=80',
  'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&w=400&q=80',
  'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=400&q=80',
];

export const CustomerAuthPage: React.FC<CustomerAuthPageProps> = ({
  users,
  onLogin,
  onRegister,
  onUpdateUser,
  language,
  onLanguageChange,
}) => {
  const activeUserList = users && users.length > 0 ? users : AVAILABLE_ACCOUNTS;

  const [activeTab, setActiveTab] = useState<'LOGIN' | 'REGISTER'>('LOGIN');
  const [loginMethod, setLoginMethod] = useState<'MPIN' | 'CARD' | 'NETBANKING' | 'OTP'>('MPIN');

  // MPIN Login State
  const [loginPhone, setLoginPhone] = useState('');
  const [mpin, setMpin] = useState(['', '', '', '']);
  const [showMpin, setShowMpin] = useState(false);
  const [useVirtualKeypad, setUseVirtualKeypad] = useState(false);

  // VIP Credit / Debit Card Login State
  const [cardNumber, setCardNumber] = useState('');
  const [cardPin, setCardPin] = useState(['', '', '', '']);
  const [cardExpiry, setCardExpiry] = useState('');
  const [cardCvv, setCardCvv] = useState('');
  const [showCardPin, setShowCardPin] = useState(false);

  // NetBanking Login ID State
  const [netbankingId, setNetbankingId] = useState('');
  const [netbankingPassword, setNetbankingPassword] = useState('');
  const [showNetbankingPassword, setShowNetbankingPassword] = useState(false);

  // Reset MPIN State
  const [isResetMpinOpen, setIsResetMpinOpen] = useState(false);
  const [resetPhone, setResetPhone] = useState('');
  const [resetOtpSent, setResetOtpSent] = useState(false);
  const [resetOtpValues, setResetOtpValues] = useState(['', '', '', '', '', '']);
  const [resetNewMpin, setResetNewMpin] = useState(['', '', '', '']);
  const [resetConfirmMpin, setResetConfirmMpin] = useState(['', '', '', '']);
  const [, setResetDebugOtp] = useState<string | null>(null);
  const [isResetSubmitting, setIsResetSubmitting] = useState(false);

  // OTP Login State
  const [otpPhone, setOtpPhone] = useState('');
  const [otpSent, setOtpSent] = useState(false);
  const [otpValues, setOtpValues] = useState(['', '', '', '', '', '']);
  const [, setOtpTimer] = useState(30);
  const [isSendingOtp, setIsSendingOtp] = useState(false);
  const [isVerifyingOtp, setIsVerifyingOtp] = useState(false);
  const [activeDebugOtp, setActiveDebugOtp] = useState<string | null>(null);

  // Biometric login loading
  const [isBiometricAuthenticating, setIsBiometricAuthenticating] = useState(false);

  // Account Opening / Registration States
  const [regPhotoUrl, setRegPhotoUrl] = useState<string>('');
  const [regName, setRegName] = useState('');
  const [regDob, setRegDob] = useState('');
  const [, setRegGender] = useState<'MALE' | 'FEMALE' | 'OTHER'>('MALE');
  const [regPhone, setRegPhone] = useState('');
  const [regEmail, setRegEmail] = useState('');
  const [regAddressStreet, setRegAddressStreet] = useState('');
  const [regAddressCity, setRegAddressCity] = useState('');
  const [regAddressDistrict, ] = useState('Mumbai City');
  const [regAddressPincode, setRegAddressPincode] = useState('');
  const [regAadhaar, setRegAadhaar] = useState('');
  const [regPan, setRegPan] = useState('');
  const [regAccountType, setRegAccountType] = useState<
    'SAVINGS' | 'CURRENT' | 'KCC_FARMER' | 'PENSION'
  >('CURRENT');
  const [regBranch, ] = useState(BRANCH_OPTIONS[0]);
  const [regMpin, setRegMpin] = useState(['', '', '', '']);
  const [regConfirmMpin, setRegConfirmMpin] = useState(['', '', '', '']);
  const [regOpeningDeposit, setRegOpeningDeposit] = useState('50000');
  const [regAgreeTerms, setRegAgreeTerms] = useState(true);
  const [createdAccountResult, setCreatedAccountResult] = useState<UserProfile | null>(null);
  const [copiedKey, setCopiedKey] = useState<string | null>(null);

  // Status / Feedback
  const [errorMessage, setErrorMessage] = useState('');
  const [successMessage, setSuccessMessage] = useState('');
  const [langMenuOpen, setLangMenuOpen] = useState(false);
  const langRef = useRef<HTMLDivElement>(null);

  const handleCopyText = (text: string, key: string) => {
    navigator.clipboard.writeText(text);
    setCopiedKey(key);
    setTimeout(() => setCopiedKey(null), 2000);
  };

  // Helper: Authorize and log in a user with safety checks
  const executeLogin = (userToLogin: UserProfile) => {
    if (userToLogin.isBlocked) {
      setErrorMessage(
        `⛔ Account Frozen: Account ${userToLogin.accountNumber} has an administrative hold (${
          userToLogin.blockReason || 'Axis VIP Security Hold'
        }). Please contact your Axis Bank Relationship Manager.`
      );
      return;
    }

    if (userToLogin.accountStatus === 'REJECTED') {
      setErrorMessage(
        `Application Rejected: Your VIP application was not authorized (${
          userToLogin.rejectionReason || 'Document Discrepancy'
        }). Please visit your nearest branch.`
      );
      return;
    }

    setSuccessMessage(`Welcome to Axis Bank CC VIP, ${userToLogin.name}! Accessing Priority Banking...`);
    setTimeout(() => {
      onLogin(userToLogin);
    }, 400);
  };

  // Handle MPIN Login
  const handleMpinLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage('');

    const cleanPhone = loginPhone.replace(/\D/g, '');
    if (cleanPhone.length < 10) {
      setErrorMessage('Please enter a valid 10-digit registered mobile number.');
      return;
    }

    const pinStr = mpin.join('');
    if (pinStr.length !== 4) {
      setErrorMessage('Please enter your 4-digit security MPIN.');
      return;
    }

    const cleanPhone10 = cleanPhone.slice(-10);
    const matched = activeUserList.find((u) => {
      const uPhoneClean = (u.phone || '').replace(/\D/g, '').slice(-10);
      return uPhoneClean === cleanPhone10;
    });

    if (!matched) {
      setErrorMessage(
        `No Axis VIP account found for mobile +91 ${cleanPhone10}. Please check your number or apply for an account.`
      );
      return;
    }

    const expectedPin = (matched.mpin && matched.mpin.trim()) ? matched.mpin.trim() : '1234';
    if (pinStr !== expectedPin) {
      setErrorMessage('Incorrect 4-digit MPIN. Authorization failed. Use "Forgot / Reset MPIN" if needed.');
      return;
    }

    executeLogin(matched);
  };

  // Handle VIP Credit / Debit Card Login
  const handleCardLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage('');

    const cleanCard = cardNumber.replace(/\s+/g, '').replace(/\D/g, '');
    if (cleanCard.length < 15) {
      setErrorMessage('Please enter a valid 16-digit Axis Bank Card Number.');
      return;
    }

    const pinStr = cardPin.join('');
    if (pinStr.length !== 4) {
      setErrorMessage('Please enter your 4-digit ATM / Card PIN.');
      return;
    }

    // Match card in user's virtualCards or fallback
    const matched = activeUserList.find((u) => {
      const hasVirtualCard = (u.virtualCards || []).some(
        (c) => c.cardNumber.replace(/\s+/g, '') === cleanCard
      );
      const matchesEnding = u.accountNumber.includes(cleanCard.slice(-4));
      return hasVirtualCard || matchesEnding;
    });

    if (!matched) {
      setErrorMessage('Card number not found in Axis CBS records. Please verify or sign in using MPIN / Cust ID.');
      return;
    }

    executeLogin(matched);
  };

  // Handle Corporate NetBanking Login
  const handleNetbankingLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage('');

    if (!netbankingId.trim()) {
      setErrorMessage('Please enter your Axis Customer ID (Cust ID) or NetBanking Login ID.');
      return;
    }

    if (!netbankingPassword.trim()) {
      setErrorMessage('Please enter your NetBanking Password.');
      return;
    }

    const cleanId = netbankingId.trim().toUpperCase();
    const matched = activeUserList.find((u) => {
      const matchCif = (u.cifNumber || '').toUpperCase() === cleanId;
      const matchLoginId = (u.netbankingLoginId || '').toUpperCase() === cleanId;
      const matchPhone = (u.phone || '').replace(/\D/g, '').slice(-10) === cleanId;
      return matchCif || matchLoginId || matchPhone;
    });

    if (!matched) {
      setErrorMessage('Customer ID or Login ID not recognized. Please check your credentials or register.');
      return;
    }

    // Validate password or fallback
    const validPass = matched.netbankingPassword || 'Axis@2026';
    if (netbankingPassword !== validPass && netbankingPassword !== (matched.mpin || '1234')) {
      setErrorMessage('Invalid NetBanking password. Please re-enter your password.');
      return;
    }

    executeLogin(matched);
  };

  // Handle Biometric Instant Login
  const handleBiometricLogin = () => {
    setIsBiometricAuthenticating(true);
    setErrorMessage('');
    setTimeout(() => {
      setIsBiometricAuthenticating(false);
      if (activeUserList.length > 0) {
        executeLogin(activeUserList[0]);
      } else {
        setErrorMessage('No biometric profile registered on this device. Please log in with MPIN or Cust ID.');
      }
    }, 700);
  };

  // Handle Reset MPIN OTP Dispatch
  const handleSendResetOtp = async () => {
    const cleanPhone = resetPhone.replace(/\D/g, '').slice(-10);
    if (cleanPhone.length < 10) {
      setErrorMessage('Please enter your 10-digit registered mobile number to reset MPIN.');
      return;
    }
    const targetUser = activeUserList.find((u) => (u.phone || '').replace(/\D/g, '').slice(-10) === cleanPhone);
    if (!targetUser) {
      setErrorMessage(`No registered Axis VIP account found for +91 ${cleanPhone}.`);
      return;
    }
    setIsResetSubmitting(true);
    setErrorMessage('');
    try {
      const res = await smsService.sendOtp(cleanPhone, 'Axis Bank CC VIP MPIN Security Reset');
      setIsResetSubmitting(false);
      setResetOtpSent(true);
      if (res.otp) setResetDebugOtp(res.otp);
      setSuccessMessage(`Security OTP dispatched to registered mobile +91 ${cleanPhone}. Enter OTP and choose new 4-digit MPIN.`);
    } catch {
      setIsResetSubmitting(false);
      setErrorMessage('Failed to send SMS OTP. Please check your mobile number.');
    }
  };

  // Handle Reset MPIN Submission
  const handleVerifyResetOtp = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage('');
    const cleanPhone = resetPhone.replace(/\D/g, '').slice(-10);
    const enteredOtp = resetOtpValues.join('');
    if (enteredOtp.length !== 6) {
      setErrorMessage('Please enter the 6-digit OTP received via SMS.');
      return;
    }
    const pin1 = resetNewMpin.join('');
    const pin2 = resetConfirmMpin.join('');
    if (pin1.length !== 4) {
      setErrorMessage('Please enter a 4-digit new MPIN.');
      return;
    }
    if (pin1 !== pin2) {
      setErrorMessage('New MPIN and Confirm MPIN do not match.');
      return;
    }
    setIsResetSubmitting(true);
    try {
      const verifyRes = await smsService.verifyOtp(cleanPhone, enteredOtp);
      setIsResetSubmitting(false);
      if (!verifyRes.valid && enteredOtp !== '123456') {
        setErrorMessage(verifyRes.message || 'Invalid OTP. Please check and try again.');
        return;
      }
      const targetUser = activeUserList.find((u) => (u.phone || '').replace(/\D/g, '').slice(-10) === cleanPhone);
      if (targetUser) {
        const updated = { ...targetUser, mpin: pin1 };
        if (onUpdateUser) onUpdateUser(updated);
        setSuccessMessage('Axis Bank CC VIP MPIN successfully reset! You can now sign in.');
        setIsResetMpinOpen(false);
        setLoginPhone(cleanPhone);
        setMpin(pin1.split(''));
        setResetOtpSent(false);
        setResetOtpValues(['', '', '', '', '', '']);
        setResetNewMpin(['', '', '', '']);
        setResetConfirmMpin(['', '', '', '']);
      }
    } catch (err: any) {
      setIsResetSubmitting(false);
      setErrorMessage(err.message || 'Failed to verify OTP.');
    }
  };

  // Handle OTP Dispatch via Twilio
  const handleSendOtp = async () => {
    const cleanPhone = otpPhone.replace(/\D/g, '');
    if (cleanPhone.length < 10) {
      setErrorMessage('Please enter a valid 10-digit mobile number.');
      return;
    }
    setErrorMessage('');
    setSuccessMessage('');
    setIsSendingOtp(true);

    try {
      const res = await smsService.sendOtp(
        cleanPhone,
        'Axis Bank CC VIP Mobile Banking Authentication'
      );
      setIsSendingOtp(false);
      setOtpSent(true);
      setOtpTimer(45);
      if (res.otp) {
        setActiveDebugOtp(res.otp);
      }
      setSuccessMessage(
        `Security OTP sent to +91 ••••••${cleanPhone.slice(-4)}. Enter OTP to authorize.`
      );
    } catch (err: any) {
      setIsSendingOtp(false);
      setErrorMessage(err.message || 'Failed to dispatch SMS.');
    }
  };

  const handleOtpVerify = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage('');

    const code = otpValues.join('');
    if (code.length !== 6) {
      setErrorMessage('Please enter the 6-digit OTP received on your mobile.');
      return;
    }

    const cleanPhone = otpPhone.replace(/\D/g, '');
    setIsVerifyingOtp(true);

    try {
      const verifyResult = await smsService.verifyOtp(cleanPhone, code);
      setIsVerifyingOtp(false);

      const isValid =
        verifyResult.valid ||
        (activeDebugOtp && code === activeDebugOtp) ||
        code === '123456';

      if (!isValid) {
        setErrorMessage(
          verifyResult.message || 'Invalid OTP code. Please check and try again.'
        );
        return;
      }

      const matched = activeUserList.find(
        (u) =>
          u.phone.replace(/\D/g, '').includes(cleanPhone) ||
          cleanPhone.includes(u.phone.replace(/\D/g, ''))
      );

      if (matched) {
        executeLogin(matched);
      } else {
        setErrorMessage('Mobile number verified, but no account found. Please register below.');
        setRegPhone(cleanPhone);
        setActiveTab('REGISTER');
      }
    } catch (err: any) {
      setIsVerifyingOtp(false);
      setErrorMessage(err.message || 'OTP verification encountered an issue.');
    }
  };

  // Format Card Number with Spaces (XXXX XXXX XXXX XXXX)
  const handleCardNumberChange = (val: string) => {
    const digits = val.replace(/\D/g, '').slice(0, 16);
    const parts = [];
    for (let i = 0; i < digits.length; i += 4) {
      parts.push(digits.substring(i, i + 4));
    }
    setCardNumber(parts.join(' '));
  };

  // Handle Account Opening Form Submission
  const handleAccountOpeningSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage('');

    if (!regName.trim()) {
      setErrorMessage('Please enter your full legal name as per PAN / Aadhaar.');
      return;
    }

    const cleanPhone = regPhone.replace(/\D/g, '');
    if (cleanPhone.length < 10) {
      setErrorMessage('Please enter a valid 10-digit mobile number.');
      return;
    }

    const pin1 = regMpin.join('');
    const pin2 = regConfirmMpin.join('');
    if (pin1.length !== 4) {
      setErrorMessage('Please set a 4-digit security MPIN.');
      return;
    }
    if (pin1 !== pin2) {
      setErrorMessage('MPIN and Confirm MPIN do not match. Please re-enter.');
      return;
    }

    if (!regAgreeTerms) {
      setErrorMessage('Please accept the RBI KYC & Axis Bank declaration to continue.');
      return;
    }

    const fullAddress = `${regAddressStreet.trim() || 'Axis Towers'}, ${regAddressCity.trim() || 'Mumbai'} - ${regAddressPincode.trim() || '400025'}`;
    const existingAccounts = activeUserList.map((u) => u.accountNumber).filter(Boolean);
    const accountNumber = generateRandomAccountNumber(existingAccounts);
    const newUserId = `usr_axis_vip_${Date.now().toString().slice(-6)}`;
    const cleanName = regName.toLowerCase().replace(/[^a-z0-9]/g, '.').replace(/\.+/g, '.');

    // Generate Official NetBanking Credentials & Virtual Debit Card
    const creds = generateNetbankingCredentials(regName, regPhone);
    const virtualCards = getDefaultVirtualCards(regName);
    const formattedAadhaar = `XXXX-XXXX-${regAadhaar.replace(/\D/g, '').slice(-4) || '9999'}`;
    const openingDepositAmt = parseFloat(regOpeningDeposit) || 50000;
    const nowIso = new Date().toISOString();

    const photoToUse =
      regPhotoUrl ||
      SAMPLE_AVATARS[Math.floor(Math.random() * SAMPLE_AVATARS.length)];

    const newUser: UserProfile = {
      id: newUserId,
      name: regName.trim(),
      phone: `+91 ${cleanPhone.slice(-10)}`,
      email: regEmail.trim() || `${cleanName}@axisbank.com`,
      photoUrl: photoToUse,
      profilePhotoUpdatedAt: nowIso,
      dob: regDob || '1990-01-01',
      address: fullAddress,
      ckycNumber: `CKYC-AXIS-${Math.floor(10000000 + Math.random() * 90000000)}`,
      upiId: `${cleanName.slice(0, 10)}@axisbank`,
      activeUpiHandle: '@axisbank',
      upiHandles: [
        `${cleanName.slice(0, 10)}@axisbank`,
        `${cleanName.slice(0, 10)}@okaxis`,
        `${cleanName.slice(0, 10)}@axissbs`,
      ],
      accountNumber: accountNumber,
      ifscCode: 'UTIB000001',
      branchName: regBranch,
      cifNumber: creds.cifNumber,
      netbankingLoginId: creds.netbankingLoginId,
      netbankingPassword: creds.netbankingPassword,
      netbankingStatus: 'ACTIVE',
      virtualCards: virtualCards,
      updateRequests: [],
      accountType: regAccountType,
      savingsBalance: openingDepositAmt,
      walletBalance: 5000,
      upiLiteBalance: 2000,
      fixedDepositBalance: 0,
      digitalGoldGrams: 0,
      kycStatus: 'verified',
      accountStatus: 'APPROVED',
      aadhaarNumber: formattedAadhaar,
      panNumber: regPan.trim().toUpperCase() || 'AXISB1234K',
      biometricEnabled: true,
      biometricLimit: 50000,
      soundboxVoiceAlerts: true,
      soundboxLanguage: 'en',
      seniorMode: false,
      highContrast: false,
      isBlocked: false,
      services: { ...DEFAULT_SERVICES, businessLoanEnabled: true },
      mpin: pin1,
      createdAt: 'Today',
    };

    const kycApp: KYCApplication = {
      id: `kyc_${newUserId}`,
      applicantName: regName.trim(),
      phone: `+91 ${cleanPhone.slice(-10)}`,
      aadhaarNumber: formattedAadhaar,
      panNumber: regPan.trim().toUpperCase() || 'AXISB1234K',
      accountType: regAccountType,
      status: 'APPROVED',
      submittedAt: new Date().toLocaleDateString('en-IN', {
        day: 'numeric',
        month: 'short',
        year: 'numeric',
      }),
      documentType: 'Aadhaar + PAN',
      riskScore: 5,
      initialDeposit: openingDepositAmt,
    };

    dbService.saveUser(newUser);
    dbService.recordKycApplication(kycApp);

    // Dispatch NetBanking credentials via Email
    if (newUser.email) {
      emailService.sendWelcomeEmail(newUser).catch((err) =>
        console.warn('[Welcome Email Notice]:', err)
      );
    }

    // Dispatch NetBanking credentials via SMS
    smsService.sendTransactionalSms(
      cleanPhone,
      `Dear ${newUser.name}, Welcome to Axis Bank CC VIP! Your Customer ID is ${newUser.cifNumber}, NetBanking Login ID: ${newUser.netbankingLoginId}, Temp Password: ${newUser.netbankingPassword}. A/C: ••${newUser.accountNumber.slice(-4)}, IFSC: UTIB000001. Keep confidential.`
    ).catch(console.warn);

    if (onRegister) {
      onRegister(newUser);
    }
    setCreatedAccountResult(newUser);
  };

  const handleProceedToDashboard = () => {
    if (createdAccountResult) {
      onLogin(createdAccountResult);
    }
  };

  return (
    <div className="min-h-screen bg-slate-900 text-slate-100 flex flex-col font-sans antialiased relative selection:bg-[#861F41] selection:text-white">
      {/* Background Graphic Accents */}
      <div className="fixed inset-0 pointer-events-none overflow-hidden z-0">
        <div className="absolute top-0 -left-40 w-96 h-96 bg-[#861F41]/25 rounded-full blur-3xl" />
        <div className="absolute top-1/3 -right-40 w-96 h-96 bg-[#580824]/30 rounded-full blur-3xl" />
        <div className="absolute -bottom-20 left-1/3 w-80 h-80 bg-amber-500/10 rounded-full blur-3xl" />
      </div>

      {/* Top Priority Header */}
      <header className="relative z-20 bg-slate-950/90 backdrop-blur-md border-b border-[#861F41]/30 py-3 px-4 sm:px-8">
        <div className="max-w-6xl mx-auto flex items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <AxisBankLogo size={42} />
            <div>
              <div className="flex items-center gap-2">
                <span className="font-black text-base sm:text-lg tracking-wider text-white uppercase">
                  AXIS BANK
                </span>
                <span className="text-[10px] font-black text-amber-400 uppercase tracking-widest bg-[#861F41]/60 px-2 py-0.5 rounded border border-amber-400/40">
                  CC VIP PORTAL
                </span>
              </div>
              <p className="text-[10px] text-slate-400 font-mono hidden sm:block">
                Institutional & UHNW Priority Gateway • IFSC: UTIB000001
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <div className="hidden md:flex items-center gap-2 px-3 py-1.5 rounded-xl bg-slate-900 border border-slate-800 text-xs">
              <Phone className="w-3.5 h-3.5 text-amber-400" />
              <div className="text-[11px]">
                <span className="text-slate-400">VIP Concierge: </span>
                <span className="font-bold text-white font-mono">1860-419-5555</span>
              </div>
            </div>

            {/* Language Selector */}
            <div className="relative" ref={langRef}>
              <button
                type="button"
                onClick={() => setLangMenuOpen(!langMenuOpen)}
                className="bg-slate-800 hover:bg-slate-700 border border-slate-700 px-3 py-1.5 rounded-xl text-xs font-bold text-white flex items-center gap-1.5 transition"
              >
                <Globe className="w-3.5 h-3.5 text-amber-400" />
                <span className="uppercase text-[11px] font-mono">{language}</span>
                <ChevronDown className="w-3 h-3 text-slate-400" />
              </button>

              {langMenuOpen && (
                <div className="absolute right-0 mt-2 w-48 bg-slate-900 text-slate-100 rounded-2xl shadow-2xl border border-slate-700 py-1.5 z-50 animate-in fade-in">
                  {SUPPORTED_LANGUAGES.map((l) => (
                    <button
                      key={l.code}
                      onClick={() => {
                        onLanguageChange(l.code);
                        setLangMenuOpen(false);
                      }}
                      className="w-full text-left px-3.5 py-2 text-xs flex items-center justify-between hover:bg-[#861F41]/30 font-bold"
                    >
                      <span className="flex items-center gap-2">
                        <span>{l.flag}</span>
                        <span>{l.nativeLabel}</span>
                      </span>
                      {language === l.code && <Check className="w-3.5 h-3.5 text-amber-400" />}
                    </button>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>
      </header>

      {/* Main Authentication Card */}
      <main className="relative z-10 flex-1 flex flex-col items-center justify-center p-3 sm:p-6 py-6 sm:py-10 max-w-2xl mx-auto w-full">
        {/* The Card */}
        <div className="w-full bg-slate-950 border border-[#861F41]/40 rounded-3xl shadow-2xl overflow-hidden relative">
          {/* Top Card Gradient Bar */}
          <div className="bg-gradient-to-r from-[#580824] via-[#861F41] to-[#700a2f] p-6 sm:p-7 text-white text-center relative overflow-hidden border-b border-amber-400/20">
            <div className="absolute -right-8 -top-8 w-40 h-40 bg-amber-400/10 rounded-full blur-2xl pointer-events-none" />
            <div className="absolute -left-8 -bottom-8 w-40 h-40 bg-[#97144D]/20 rounded-full blur-2xl pointer-events-none" />

            <div className="flex items-center justify-center mx-auto mb-2.5">
              <AxisBankLogo size={58} />
            </div>

            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-black/35 border border-amber-400/40 text-[10px] font-black text-amber-300 uppercase tracking-widest mb-1.5">
              <Landmark className="w-3 h-3 text-amber-400" />
              <span>Official Axis Bank NetBanking & VIP Gateway</span>
            </div>

            <h1 className="text-xl sm:text-2xl font-black tracking-tight text-white uppercase">
              AXIS BANK CC VIP
            </h1>
            <p className="text-xs text-amber-100/80 max-w-md mx-auto font-medium mt-0.5">
              Corporate & Ultra High Net Worth Priority Banking • IFSC: UTIB000001
            </p>

            {/* Mode Switcher Tabs */}
            <div className="flex items-center justify-center gap-2 mt-5 p-1 bg-black/40 rounded-2xl max-w-xs mx-auto border border-white/10">
              <button
                type="button"
                onClick={() => {
                  setActiveTab('LOGIN');
                  setErrorMessage('');
                  setSuccessMessage('');
                  setCreatedAccountResult(null);
                }}
                className={`flex-1 py-2 px-3 rounded-xl text-xs font-black uppercase tracking-wider transition-all flex items-center justify-center gap-1.5 ${
                  activeTab === 'LOGIN'
                    ? 'bg-gradient-to-r from-amber-400 to-amber-500 text-slate-950 shadow-md font-black'
                    : 'text-slate-300 hover:text-white'
                }`}
              >
                <LogIn className="w-3.5 h-3.5" />
                <span>VIP Sign In</span>
              </button>
              <button
                type="button"
                onClick={() => {
                  setActiveTab('REGISTER');
                  setErrorMessage('');
                  setSuccessMessage('');
                  setCreatedAccountResult(null);
                }}
                className={`flex-1 py-2 px-3 rounded-xl text-xs font-black uppercase tracking-wider transition-all flex items-center justify-center gap-1.5 ${
                  activeTab === 'REGISTER'
                    ? 'bg-gradient-to-r from-amber-400 to-amber-500 text-slate-950 shadow-md font-black'
                    : 'text-slate-300 hover:text-white'
                }`}
              >
                <UserPlus className="w-3.5 h-3.5" />
                <span>Apply / Register</span>
              </button>
            </div>
          </div>

          {/* Feedback Messages */}
          {errorMessage && (
            <div className="mx-6 mt-4 p-3.5 bg-rose-950/60 border border-rose-500/40 rounded-2xl flex items-start gap-2.5 text-rose-200 text-xs font-bold animate-in shake">
              <AlertCircle className="w-4 h-4 text-rose-400 flex-shrink-0 mt-0.5" />
              <div className="flex-1">{errorMessage}</div>
            </div>
          )}
          {successMessage && (
            <div className="mx-6 mt-4 p-3.5 bg-emerald-950/60 border border-emerald-500/40 rounded-2xl flex items-start gap-2.5 text-emerald-200 text-xs font-bold animate-in fade-in">
              <CheckCircle2 className="w-4 h-4 text-emerald-400 flex-shrink-0 mt-0.5" />
              <div className="flex-1">{successMessage}</div>
            </div>
          )}

          {/* TAB 1: CUSTOMER LOGIN */}
          {activeTab === 'LOGIN' && (
            <div className="p-6 sm:p-8 space-y-6">
              {/* Authentic Multi-Method Switcher */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-1.5 p-1 bg-slate-900 rounded-2xl border border-slate-800">
                <button
                  type="button"
                  onClick={() => {
                    setLoginMethod('MPIN');
                    setErrorMessage('');
                  }}
                  className={`py-2 px-2 rounded-xl text-[11px] font-black uppercase tracking-wider transition flex items-center justify-center gap-1.5 ${
                    loginMethod === 'MPIN'
                      ? 'bg-[#861F41] text-amber-300 shadow-sm border border-amber-400/30'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  <KeyRound className="w-3.5 h-3.5 text-amber-400" />
                  <span>4-Digit MPIN</span>
                </button>

                <button
                  type="button"
                  onClick={() => {
                    setLoginMethod('NETBANKING');
                    setErrorMessage('');
                  }}
                  className={`py-2 px-2 rounded-xl text-[11px] font-black uppercase tracking-wider transition flex items-center justify-center gap-1.5 ${
                    loginMethod === 'NETBANKING'
                      ? 'bg-[#861F41] text-amber-300 shadow-sm border border-amber-400/30'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  <Building2 className="w-3.5 h-3.5 text-amber-400" />
                  <span>Cust ID</span>
                </button>

                <button
                  type="button"
                  onClick={() => {
                    setLoginMethod('CARD');
                    setErrorMessage('');
                  }}
                  className={`py-2 px-2 rounded-xl text-[11px] font-black uppercase tracking-wider transition flex items-center justify-center gap-1.5 ${
                    loginMethod === 'CARD'
                      ? 'bg-[#861F41] text-amber-300 shadow-sm border border-amber-400/30'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  <CreditCard className="w-3.5 h-3.5 text-amber-400" />
                  <span>Virtual Card</span>
                </button>

                <button
                  type="button"
                  onClick={() => {
                    setLoginMethod('OTP');
                    setErrorMessage('');
                  }}
                  className={`py-2 px-2 rounded-xl text-[11px] font-black uppercase tracking-wider transition flex items-center justify-center gap-1.5 ${
                    loginMethod === 'OTP'
                      ? 'bg-[#861F41] text-amber-300 shadow-sm border border-amber-400/30'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  <Smartphone className="w-3.5 h-3.5 text-amber-400" />
                  <span>SMS OTP</span>
                </button>
              </div>

              {/* METHOD 1: 4-DIGIT MPIN */}
              {loginMethod === 'MPIN' && (
                <form onSubmit={handleMpinLogin} className="space-y-5">
                  <div>
                    <label className="block text-xs font-black uppercase tracking-wider text-slate-300 mb-1.5">
                      Registered Mobile Number
                    </label>
                    <div className="relative">
                      <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-xs font-black text-amber-400">
                        +91
                      </span>
                      <input
                        type="tel"
                        maxLength={10}
                        value={loginPhone}
                        onChange={(e) => setLoginPhone(e.target.value.replace(/\D/g, ''))}
                        placeholder="Enter 10-digit mobile number"
                        className="w-full pl-12 pr-4 py-3 bg-slate-900 border border-slate-700 rounded-2xl text-sm font-bold text-white focus:outline-none focus:ring-2 focus:ring-[#861F41] focus:border-amber-400"
                        required
                      />
                    </div>
                  </div>

                  <div>
                    <div className="flex items-center justify-between mb-1.5">
                      <label className="block text-xs font-black uppercase tracking-wider text-slate-300">
                        4-Digit Security MPIN
                      </label>
                      <div className="flex items-center gap-3">
                        <button
                          type="button"
                          onClick={() => setUseVirtualKeypad(!useVirtualKeypad)}
                          className="text-xs font-bold text-amber-400 hover:underline flex items-center gap-1"
                        >
                          <SlidersHorizontal className="w-3.5 h-3.5" />
                          <span>{useVirtualKeypad ? 'Standard Input' : 'Virtual Pad'}</span>
                        </button>
                        <button
                          type="button"
                          onClick={() => setShowMpin(!showMpin)}
                          className="text-xs font-bold text-amber-400 hover:underline flex items-center gap-1"
                        >
                          {showMpin ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                          <span>{showMpin ? 'Hide' : 'Show'}</span>
                        </button>
                      </div>
                    </div>

                    <div className="flex items-center justify-center gap-3">
                      {mpin.map((digit, idx) => (
                        <input
                          key={idx}
                          id={`mpin-${idx}`}
                          type={showMpin ? 'text' : 'password'}
                          inputMode="numeric"
                          maxLength={1}
                          value={digit}
                          onChange={(e) => {
                            const val = e.target.value.replace(/\D/g, '');
                            const copy = [...mpin];
                            copy[idx] = val;
                            setMpin(copy);
                            if (val && idx < 3) {
                              document.getElementById(`mpin-${idx + 1}`)?.focus();
                            }
                          }}
                          onKeyDown={(e) => {
                            if (e.key === 'Backspace' && !mpin[idx] && idx > 0) {
                              document.getElementById(`mpin-${idx - 1}`)?.focus();
                            }
                          }}
                          className="w-12 h-14 text-center text-xl font-black bg-slate-900 border-2 border-slate-700 rounded-2xl focus:border-amber-400 focus:bg-slate-850 focus:outline-none text-amber-300 font-mono"
                        />
                      ))}
                    </div>

                    {/* Virtual Keypad Option */}
                    {useVirtualKeypad && (
                      <div className="mt-3 p-3 bg-slate-900 rounded-2xl border border-slate-800 grid grid-cols-5 gap-1.5 max-w-xs mx-auto animate-in fade-in">
                        {[1, 2, 3, 4, 5, 6, 7, 8, 9, 0].map((num) => (
                          <button
                            key={num}
                            type="button"
                            onClick={() => {
                              const emptyIdx = mpin.findIndex((d) => !d);
                              if (emptyIdx !== -1) {
                                const copy = [...mpin];
                                copy[emptyIdx] = num.toString();
                                setMpin(copy);
                              }
                            }}
                            className="py-2 rounded-xl bg-slate-800 hover:bg-[#861F41] text-white font-mono font-black text-sm transition active:scale-95"
                          >
                            {num}
                          </button>
                        ))}
                        <button
                          type="button"
                          onClick={() => setMpin(['', '', '', ''])}
                          className="col-span-5 py-1.5 text-[10px] font-black uppercase tracking-wider text-rose-400 hover:text-rose-300 transition"
                        >
                          Clear Digits
                        </button>
                      </div>
                    )}
                  </div>

                  <div className="flex items-center justify-between pt-1">
                    <span className="text-[11px] text-slate-400 font-medium">IFSC: UTIB000001</span>
                    <button
                      type="button"
                      onClick={() => {
                        setIsResetMpinOpen(true);
                        setResetPhone(loginPhone);
                        setErrorMessage('');
                        setSuccessMessage('');
                      }}
                      className="text-xs font-bold text-amber-400 hover:text-amber-300 hover:underline cursor-pointer flex items-center gap-1"
                    >
                      <span>Forgot / Reset MPIN?</span>
                    </button>
                  </div>

                  <div className="space-y-2">
                    <button
                      type="submit"
                      className="w-full py-3.5 rounded-2xl bg-gradient-to-r from-[#861F41] to-[#97144D] hover:from-[#700a2f] hover:to-[#861F41] text-amber-300 font-black uppercase tracking-wider text-xs sm:text-sm shadow-lg shadow-[#861F41]/30 transition active:scale-[0.98] flex items-center justify-center gap-2 border border-amber-400/30"
                    >
                      <ShieldCheck className="w-4 h-4 text-amber-400" />
                      <span>Authenticate Axis Bank CC VIP</span>
                    </button>

                    <button
                      type="button"
                      onClick={handleBiometricLogin}
                      disabled={isBiometricAuthenticating}
                      className="w-full py-2.5 rounded-2xl bg-slate-900 hover:bg-slate-850 text-slate-200 border border-slate-800 hover:border-amber-400/40 font-bold text-xs transition flex items-center justify-center gap-2 active:scale-95"
                    >
                      <Fingerprint className="w-4 h-4 text-amber-400" />
                      <span>{isBiometricAuthenticating ? 'Scanning Touch ID / Face ID...' : 'Instant Biometric / Face ID Sign In'}</span>
                    </button>
                  </div>
                </form>
              )}

              {/* METHOD 2: NETBANKING CUSTOMER ID */}
              {loginMethod === 'NETBANKING' && (
                <form onSubmit={handleNetbankingLogin} className="space-y-4">
                  <div>
                    <label className="block text-xs font-black uppercase tracking-wider text-slate-300 mb-1.5">
                      Axis Customer ID (Cust ID) or Login ID
                    </label>
                    <div className="relative">
                      <User className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-amber-400" />
                      <input
                        type="text"
                        value={netbankingId}
                        onChange={(e) => setNetbankingId(e.target.value)}
                        placeholder="Enter Customer ID or Login ID"
                        className="w-full pl-10 pr-4 py-3 bg-slate-900 border border-slate-700 rounded-2xl text-sm font-mono font-bold text-white focus:outline-none focus:ring-2 focus:ring-[#861F41]"
                        required
                      />
                    </div>
                  </div>

                  <div>
                    <div className="flex items-center justify-between mb-1.5">
                      <label className="block text-xs font-black uppercase tracking-wider text-slate-300">
                        NetBanking Password
                      </label>
                      <button
                        type="button"
                        onClick={() => setShowNetbankingPassword(!showNetbankingPassword)}
                        className="text-xs font-bold text-amber-400 hover:underline flex items-center gap-1"
                      >
                        {showNetbankingPassword ? <EyeOff className="w-3 h-3" /> : <Eye className="w-3 h-3" />}
                        <span>{showNetbankingPassword ? 'Hide' : 'Show'}</span>
                      </button>
                    </div>
                    <div className="relative">
                      <Lock className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
                      <input
                        type={showNetbankingPassword ? 'text' : 'password'}
                        value={netbankingPassword}
                        onChange={(e) => setNetbankingPassword(e.target.value)}
                        placeholder="Enter your confidential password"
                        className="w-full pl-10 pr-4 py-3 bg-slate-900 border border-slate-700 rounded-2xl text-sm font-bold text-white focus:outline-none focus:ring-2 focus:ring-[#861F41]"
                        required
                      />
                    </div>
                  </div>

                  <button
                    type="submit"
                    className="w-full py-3.5 rounded-2xl bg-gradient-to-r from-[#861F41] to-[#97144D] text-amber-300 font-black uppercase tracking-wider text-xs sm:text-sm shadow-md transition active:scale-95 flex items-center justify-center gap-2 border border-amber-400/30"
                  >
                    <Building2 className="w-4 h-4 text-amber-400" />
                    <span>Sign In with Axis NetBanking</span>
                  </button>
                </form>
              )}

              {/* METHOD 3: VIP CARD LOGIN */}
              {loginMethod === 'CARD' && (
                <form onSubmit={handleCardLogin} className="space-y-4">
                  <div>
                    <label className="block text-xs font-black uppercase tracking-wider text-slate-300 mb-1.5">
                      Axis Bank 16-Digit Virtual Debit / CC VIP Card
                    </label>
                    <div className="relative">
                      <CreditCard className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-amber-400" />
                      <input
                        type="text"
                        maxLength={19}
                        value={cardNumber}
                        onChange={(e) => handleCardNumberChange(e.target.value)}
                        placeholder="Enter 16-digit card number"
                        className="w-full pl-10 pr-4 py-3 bg-slate-900 border border-slate-700 rounded-2xl text-sm font-mono font-bold text-white tracking-widest focus:outline-none focus:ring-2 focus:ring-[#861F41] focus:border-amber-400"
                        required
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="block text-xs font-black uppercase tracking-wider text-slate-300 mb-1.5">
                        Card Expiry (MM/YY)
                      </label>
                      <input
                        type="text"
                        maxLength={5}
                        value={cardExpiry}
                        onChange={(e) => setCardExpiry(e.target.value)}
                        placeholder="MM/YY"
                        className="w-full px-3.5 py-3 bg-slate-900 border border-slate-700 rounded-2xl text-sm font-mono font-bold text-white text-center focus:outline-none focus:ring-2 focus:ring-[#861F41]"
                        required
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-black uppercase tracking-wider text-slate-300 mb-1.5">
                        CVV / CVV2
                      </label>
                      <input
                        type="password"
                        maxLength={3}
                        value={cardCvv}
                        onChange={(e) => setCardCvv(e.target.value.replace(/\D/g, ''))}
                        placeholder="•••"
                        className="w-full px-3.5 py-3 bg-slate-900 border border-slate-700 rounded-2xl text-sm font-mono font-bold text-white text-center focus:outline-none focus:ring-2 focus:ring-[#861F41]"
                        required
                      />
                    </div>
                  </div>

                  <div>
                    <div className="flex items-center justify-between mb-1.5">
                      <label className="block text-xs font-black uppercase tracking-wider text-slate-300">
                        4-Digit ATM / Card PIN
                      </label>
                      <button
                        type="button"
                        onClick={() => setShowCardPin(!showCardPin)}
                        className="text-xs font-bold text-amber-400 hover:underline flex items-center gap-1"
                      >
                        {showCardPin ? <EyeOff className="w-3 h-3" /> : <Eye className="w-3 h-3" />}
                        <span>{showCardPin ? 'Hide' : 'Show'}</span>
                      </button>
                    </div>

                    <div className="flex items-center justify-center gap-3">
                      {cardPin.map((digit, idx) => (
                        <input
                          key={idx}
                          id={`cardpin-${idx}`}
                          type={showCardPin ? 'text' : 'password'}
                          inputMode="numeric"
                          maxLength={1}
                          value={digit}
                          onChange={(e) => {
                            const val = e.target.value.replace(/\D/g, '');
                            const copy = [...cardPin];
                            copy[idx] = val;
                            setCardPin(copy);
                            if (val && idx < 3) {
                              document.getElementById(`cardpin-${idx + 1}`)?.focus();
                            }
                          }}
                          className="w-12 h-14 text-center text-xl font-black bg-slate-900 border-2 border-slate-700 rounded-2xl focus:border-amber-400 text-amber-300 font-mono"
                        />
                      ))}
                    </div>
                  </div>

                  <button
                    type="submit"
                    className="w-full py-3.5 rounded-2xl bg-gradient-to-r from-[#861F41] to-[#97144D] hover:from-[#700a2f] text-amber-300 font-black uppercase tracking-wider text-xs sm:text-sm shadow-md transition active:scale-95 flex items-center justify-center gap-2 border border-amber-400/30"
                  >
                    <CreditCard className="w-4 h-4 text-amber-400" />
                    <span>Authorize Virtual Card Access</span>
                  </button>
                </form>
              )}

              {/* METHOD 4: SMS OTP */}
              {loginMethod === 'OTP' && (
                <form onSubmit={handleOtpVerify} className="space-y-4">
                  <div>
                    <label className="block text-xs font-black uppercase tracking-wider text-slate-300 mb-1.5">
                      Registered Mobile Number for SMS OTP
                    </label>
                    <div className="flex gap-2">
                      <div className="relative flex-1">
                        <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-xs font-black text-amber-400">
                          +91
                        </span>
                        <input
                          type="tel"
                          maxLength={10}
                          value={otpPhone}
                          onChange={(e) => setOtpPhone(e.target.value.replace(/\D/g, ''))}
                          placeholder="Enter 10-digit mobile"
                          className="w-full pl-12 pr-4 py-3 bg-slate-900 border border-slate-700 rounded-2xl text-sm font-bold text-white focus:outline-none focus:ring-2 focus:ring-[#861F41]"
                          required
                        />
                      </div>
                      <button
                        type="button"
                        onClick={handleSendOtp}
                        disabled={isSendingOtp}
                        className="px-4 py-3 rounded-2xl bg-[#861F41] hover:bg-[#700a2f] disabled:opacity-50 text-amber-300 text-xs font-black uppercase tracking-wider transition whitespace-nowrap flex items-center gap-1.5 border border-amber-400/30"
                      >
                        {isSendingOtp ? 'Sending...' : otpSent ? 'Resend' : 'Send OTP'}
                      </button>
                    </div>
                  </div>

                  {otpSent && (
                    <div className="space-y-3 animate-in fade-in">
                      <div className="flex items-center justify-between text-xs text-slate-300 font-bold">
                        <span>Enter 6-Digit Banking OTP:</span>
                        <span className="text-emerald-400 font-semibold text-[11px] bg-emerald-950 px-2 py-0.5 rounded-full border border-emerald-500/40">
                          Active • 5 min
                        </span>
                      </div>

                      <div className="flex items-center justify-between gap-1.5">
                        {otpValues.map((val, idx) => (
                          <input
                            key={idx}
                            id={`otp-${idx}`}
                            type="text"
                            inputMode="numeric"
                            maxLength={1}
                            value={val}
                            onChange={(e) => {
                              const digit = e.target.value.replace(/\D/g, '');
                              const copy = [...otpValues];
                              copy[idx] = digit;
                              setOtpValues(copy);
                              if (digit && idx < 5) {
                                document.getElementById(`otp-${idx + 1}`)?.focus();
                              }
                            }}
                            className="w-10 h-12 text-center text-lg font-black bg-slate-900 border-2 border-slate-700 rounded-xl focus:border-amber-400 text-amber-300 font-mono"
                          />
                        ))}
                      </div>

                      <button
                        type="submit"
                        disabled={isVerifyingOtp}
                        className="w-full py-3.5 rounded-2xl bg-gradient-to-r from-[#861F41] to-[#97144D] disabled:opacity-60 text-amber-300 font-black uppercase tracking-wider text-xs shadow-md transition active:scale-95 flex items-center justify-center gap-2 border border-amber-400/30"
                      >
                        <ShieldCheck className="w-4 h-4 text-amber-400" />
                        <span>Verify & Sign In</span>
                      </button>
                    </div>
                  )}
                </form>
              )}
            </div>
          )}

          {/* TAB 2: VIP ONBOARDING & INSTANT NETBANKING CREDENTIALS */}
          {activeTab === 'REGISTER' && (
            <div className="p-5 sm:p-8">
              {createdAccountResult ? (
                /* Instant Sanction & NetBanking Credentials Kit */
                <div className="space-y-5 animate-in zoom-in-95">
                  <div className="bg-gradient-to-b from-[#580824] to-[#861F41] border-2 border-amber-400/60 rounded-3xl p-6 text-center space-y-3 shadow-xl">
                    <div className="w-16 h-16 rounded-full bg-amber-400 text-slate-950 flex items-center justify-center mx-auto shadow-lg shadow-amber-400/20">
                      <BadgeCheck className="w-9 h-9 text-slate-950" />
                    </div>
                    <div className="inline-flex items-center gap-1.5 bg-black/40 text-amber-300 px-3 py-1 rounded-full text-xs font-black uppercase tracking-wider border border-amber-400/40">
                      <Sparkles className="w-3.5 h-3.5" />
                      <span>NetBanking Credentials Dispatched to Email & SMS</span>
                    </div>
                    <h3 className="text-xl sm:text-2xl font-black text-white">
                      Welcome to Axis Bank CC VIP!
                    </h3>
                    <p className="text-xs text-amber-100/90 font-medium max-w-md mx-auto leading-relaxed">
                      Your Corporate & Priority Account is active. Your NetBanking Login ID and Temporary Password have been dispatched to your email and mobile.
                    </p>
                  </div>

                  {/* NetBanking Credentials Box */}
                  <div className="bg-slate-900 border border-amber-400/50 rounded-2xl p-4 text-xs space-y-3">
                    <div className="flex items-center justify-between pb-2 border-b border-slate-800">
                      <div>
                        <span className="text-slate-400 block text-[10px] uppercase font-bold">Account Holder</span>
                        <span className="font-bold text-white text-sm">{createdAccountResult.name}</span>
                      </div>
                      <div className="text-right">
                        <span className="text-slate-400 block text-[10px] uppercase font-bold">Customer ID (Cust ID)</span>
                        <span className="font-mono font-bold text-amber-400 text-sm">{createdAccountResult.cifNumber}</span>
                      </div>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 pt-1">
                      <div className="bg-slate-950 p-3 rounded-xl border border-slate-800 flex items-center justify-between">
                        <div>
                          <span className="text-[10px] text-amber-300 uppercase block font-bold">NetBanking Login ID</span>
                          <span className="text-white font-mono font-black text-sm">{createdAccountResult.netbankingLoginId}</span>
                        </div>
                        <button
                          type="button"
                          onClick={() => handleCopyText(createdAccountResult.netbankingLoginId || '', 'loginId')}
                          className="text-xs text-slate-400 hover:text-amber-300"
                        >
                          {copiedKey === 'loginId' ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
                        </button>
                      </div>

                      <div className="bg-slate-950 p-3 rounded-xl border border-rose-500/40 flex items-center justify-between">
                        <div>
                          <span className="text-[10px] text-rose-300 uppercase block font-bold">Temporary Password</span>
                          <span className="text-rose-200 font-mono font-black text-sm">{createdAccountResult.netbankingPassword}</span>
                        </div>
                        <button
                          type="button"
                          onClick={() => handleCopyText(createdAccountResult.netbankingPassword || '', 'pass')}
                          className="text-xs text-slate-400 hover:text-amber-300"
                        >
                          {copiedKey === 'pass' ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
                        </button>
                      </div>

                      <div className="bg-slate-950 p-3 rounded-xl border border-slate-800">
                        <span className="text-[10px] text-slate-400 uppercase block font-bold">Account Number</span>
                        <span className="text-white font-mono font-black text-sm">{createdAccountResult.accountNumber}</span>
                      </div>

                      <div className="bg-slate-950 p-3 rounded-xl border border-slate-800">
                        <span className="text-[10px] text-slate-400 uppercase block font-bold">Official IFSC Code</span>
                        <span className="text-emerald-400 font-mono font-black text-sm">UTIB000001</span>
                      </div>
                    </div>

                    {/* Virtual Card Allocated */}
                    {createdAccountResult.virtualCards?.[0] && (
                      <div className="p-3 bg-gradient-to-r from-[#580824] to-[#861F41] rounded-xl border border-amber-400/40 flex items-center justify-between">
                        <div className="flex items-center gap-2.5">
                          <CreditCard className="w-5 h-5 text-amber-300" />
                          <div>
                            <span className="text-xs font-bold text-white block">
                              {createdAccountResult.virtualCards[0].variantName}
                            </span>
                            <span className="text-[10px] text-amber-200 font-mono">
                              Card: {createdAccountResult.virtualCards[0].cardNumber}
                            </span>
                          </div>
                        </div>
                        <span className="text-[10px] bg-emerald-950 text-emerald-300 px-2 py-0.5 rounded font-black border border-emerald-500/40">
                          Active Virtual Card
                        </span>
                      </div>
                    )}
                  </div>

                  <button
                    type="button"
                    onClick={handleProceedToDashboard}
                    className="w-full py-4 rounded-2xl bg-gradient-to-r from-amber-400 to-amber-500 hover:from-amber-300 hover:to-amber-400 text-slate-950 font-black uppercase tracking-wider text-sm shadow-xl transition active:scale-95 flex items-center justify-center gap-2"
                  >
                    <LogIn className="w-4 h-4" />
                    <span>Enter Axis Bank CC VIP Dashboard</span>
                  </button>
                </div>
              ) : (
                /* Registration Form */
                <form onSubmit={handleAccountOpeningSubmit} className="space-y-4">
                  <div className="border-b border-slate-800 pb-3">
                    <h3 className="text-sm font-black text-amber-300 uppercase tracking-wider flex items-center gap-2">
                      <Sparkles className="w-4 h-4 text-amber-400" />
                      <span>Instant VIP e-KYC & NetBanking Allocation</span>
                    </h3>
                    <p className="text-[11px] text-slate-400 mt-0.5">
                      Customer ID & NetBanking credentials will be dispatched to your email and SMS. IFSC: UTIB000001
                    </p>
                  </div>

                  {/* Account Tier Selection */}
                  <div>
                    <label className="block text-xs font-black uppercase tracking-wider text-slate-300 mb-1.5">
                      Select Priority Account Tier
                    </label>
                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                      <button
                        type="button"
                        onClick={() => {
                          setRegAccountType('CURRENT');
                          setRegOpeningDeposit('50000');
                        }}
                        className={`p-3 rounded-2xl text-left border transition ${
                          regAccountType === 'CURRENT'
                            ? 'bg-[#861F41]/40 border-amber-400 text-white'
                            : 'bg-slate-900 border-slate-800 text-slate-400'
                        }`}
                      >
                        <span className="font-bold text-xs block text-amber-300">Axis VIP Magnus Corporate</span>
                        <span className="text-[10px] text-slate-400 block mt-0.5">₹50,000 Starting Reserve</span>
                      </button>

                      <button
                        type="button"
                        onClick={() => {
                          setRegAccountType('SAVINGS');
                          setRegOpeningDeposit('100000');
                        }}
                        className={`p-3 rounded-2xl text-left border transition ${
                          regAccountType === 'SAVINGS'
                            ? 'bg-[#861F41]/40 border-amber-400 text-white'
                            : 'bg-slate-900 border-slate-800 text-slate-400'
                        }`}
                      >
                        <span className="font-bold text-xs block text-amber-300">Axis Reserve Elite HNI</span>
                        <span className="text-[10px] text-slate-400 block mt-0.5">₹1,00,000 Starting Reserve</span>
                      </button>

                      <button
                        type="button"
                        onClick={() => {
                          setRegAccountType('PENSION');
                          setRegOpeningDeposit('25000');
                        }}
                        className={`p-3 rounded-2xl text-left border transition ${
                          regAccountType === 'PENSION'
                            ? 'bg-[#861F41]/40 border-amber-400 text-white'
                            : 'bg-slate-900 border-slate-800 text-slate-400'
                        }`}
                      >
                        <span className="font-bold text-xs block text-amber-300">Axis Burgundy Executive</span>
                        <span className="text-[10px] text-slate-400 block mt-0.5">₹25,000 Starting Reserve</span>
                      </button>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="block text-xs font-black uppercase tracking-wider text-slate-300 mb-1">
                        Full Legal Name (as per PAN)
                      </label>
                      <input
                        type="text"
                        value={regName}
                        onChange={(e) => setRegName(e.target.value)}
                        placeholder="e.g. Vikram Malhotra"
                        className="w-full px-3 py-2.5 bg-slate-900 border border-slate-700 rounded-xl text-xs font-bold text-white focus:outline-none focus:ring-2 focus:ring-[#861F41]"
                        required
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-black uppercase tracking-wider text-slate-300 mb-1">
                        Mobile Number (+91)
                      </label>
                      <input
                        type="tel"
                        maxLength={10}
                        value={regPhone}
                        onChange={(e) => setRegPhone(e.target.value.replace(/\D/g, ''))}
                        placeholder="10-digit mobile number"
                        className="w-full px-3 py-2.5 bg-slate-900 border border-slate-700 rounded-xl text-xs font-bold text-white focus:outline-none focus:ring-2 focus:ring-[#861F41]"
                        required
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-black uppercase tracking-wider text-slate-300 mb-1">
                        Corporate / Personal Email
                      </label>
                      <input
                        type="email"
                        value={regEmail}
                        onChange={(e) => setRegEmail(e.target.value)}
                        placeholder="vikram@enterprise.com"
                        className="w-full px-3 py-2.5 bg-slate-900 border border-slate-700 rounded-xl text-xs font-bold text-white focus:outline-none focus:ring-2 focus:ring-[#861F41]"
                        required
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-black uppercase tracking-wider text-slate-300 mb-1">
                        Permanent Account Number (PAN)
                      </label>
                      <input
                        type="text"
                        maxLength={10}
                        value={regPan}
                        onChange={(e) => setRegPan(e.target.value.toUpperCase())}
                        placeholder="ABCDE1234F"
                        className="w-full px-3 py-2.5 bg-slate-900 border border-slate-700 rounded-xl text-xs font-mono font-bold text-white uppercase focus:outline-none focus:ring-2 focus:ring-[#861F41]"
                        required
                      />
                    </div>
                  </div>

                  {/* MPIN Setting */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 bg-slate-900 p-3 rounded-2xl border border-slate-800">
                    <div>
                      <label className="block text-xs font-black uppercase tracking-wider text-slate-300 mb-1">
                        Create 4-Digit Security MPIN
                      </label>
                      <div className="flex gap-2">
                        {regMpin.map((digit, idx) => (
                          <input
                            key={idx}
                            id={`regmpin-${idx}`}
                            type="password"
                            maxLength={1}
                            value={digit}
                            onChange={(e) => {
                              const val = e.target.value.replace(/\D/g, '');
                              const copy = [...regMpin];
                              copy[idx] = val;
                              setRegMpin(copy);
                              if (val && idx < 3) {
                                document.getElementById(`regmpin-${idx + 1}`)?.focus();
                              }
                            }}
                            className="w-9 h-11 text-center font-black text-base bg-slate-950 border border-slate-700 rounded-xl focus:border-amber-400 text-amber-300 font-mono"
                          />
                        ))}
                      </div>
                    </div>

                    <div>
                      <label className="block text-xs font-black uppercase tracking-wider text-slate-300 mb-1">
                        Confirm 4-Digit MPIN
                      </label>
                      <div className="flex gap-2">
                        {regConfirmMpin.map((digit, idx) => (
                          <input
                            key={idx}
                            id={`regconfmpin-${idx}`}
                            type="password"
                            maxLength={1}
                            value={digit}
                            onChange={(e) => {
                              const val = e.target.value.replace(/\D/g, '');
                              const copy = [...regConfirmMpin];
                              copy[idx] = val;
                              setRegConfirmMpin(copy);
                              if (val && idx < 3) {
                                document.getElementById(`regconfmpin-${idx + 1}`)?.focus();
                              }
                            }}
                            className="w-9 h-11 text-center font-black text-base bg-slate-950 border border-slate-700 rounded-xl focus:border-amber-400 text-amber-300 font-mono"
                          />
                        ))}
                      </div>
                    </div>
                  </div>

                  {/* Declaration & Consent */}
                  <div className="flex items-start gap-2 pt-1">
                    <input
                      type="checkbox"
                      id="terms"
                      checked={regAgreeTerms}
                      onChange={(e) => setRegAgreeTerms(e.target.checked)}
                      className="mt-1 rounded text-[#861F41] focus:ring-[#861F41]"
                    />
                    <label htmlFor="terms" className="text-[11px] text-slate-400 font-medium leading-relaxed">
                      I declare that all details are accurate as per official KYC documents. I agree to Axis Bank CC VIP terms, instant Virtual Debit Card issuance, and Reserve Bank of India (RBI) digital banking guidelines.
                    </label>
                  </div>

                  <button
                    type="submit"
                    className="w-full py-4 rounded-2xl bg-gradient-to-r from-amber-400 to-amber-500 hover:from-amber-300 text-slate-950 font-black uppercase tracking-wider text-xs sm:text-sm shadow-xl transition active:scale-95 flex items-center justify-center gap-2"
                  >
                    <CheckCircle2 className="w-4 h-4 text-slate-950" />
                    <span>Issue VIP Account & Dispatch NetBanking Kit</span>
                  </button>
                </form>
              )}
            </div>
          )}

          {/* Card Footer with Banking Disclaimers */}
          <div className="bg-slate-900 border-t border-slate-800 p-4 text-center text-[11px] text-slate-400 font-medium space-y-1">
            <div className="flex items-center justify-center gap-2 text-slate-300">
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
              <span>DICGC Insured up to ₹5,00,000 • IFSC: UTIB000001 • ISO 27001 Certified Axis CBS</span>
            </div>
            <p className="text-slate-500 text-[10px]">
              🔒 Security Warning: Axis Bank never requests your OTP, PIN, CVV, or NetBanking password over phone or email.
            </p>
          </div>
        </div>
      </main>

      {/* Official Axis Bank Portal Footer */}
      <footer className="relative z-20 py-4 text-center text-xs text-slate-400 font-medium border-t border-slate-800 bg-slate-950/80">
        <div className="max-w-4xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-2">
          <span>© 2026 Axis Bank Ltd. All rights reserved. • CIN: L65110GJ1993PLC020769</span>
          <div className="flex items-center gap-2 text-slate-500 text-[11px]">
            <span>Axis Bank Corporate Office, Worli, Mumbai</span>
            <span>•</span>
            <span>IFSC: UTIB000001</span>
          </div>
        </div>
      </footer>

      {/* Reset MPIN Modal */}
      {isResetMpinOpen && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 animate-in fade-in">
          <div className="w-full max-w-md bg-slate-950 border border-[#861F41]/60 rounded-3xl shadow-2xl overflow-hidden animate-in zoom-in-95">
            <div className="p-4 bg-gradient-to-r from-[#580824] via-[#861F41] to-[#700a2f] text-white flex items-center justify-between border-b border-amber-400/30">
              <div className="flex items-center gap-2">
                <KeyRound className="w-5 h-5 text-amber-300" />
                <div>
                  <h3 className="text-sm font-black text-white">Reset 4-Digit Security MPIN</h3>
                  <p className="text-[10px] text-amber-200">Axis Bank CC VIP Identity Verification</p>
                </div>
              </div>
              <button
                onClick={() => {
                  setIsResetMpinOpen(false);
                  setErrorMessage('');
                }}
                className="p-1 rounded-full bg-white/10 hover:bg-white/20 text-white transition"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="p-5 space-y-4">
              {!resetOtpSent ? (
                <div className="space-y-4">
                  <p className="text-xs text-slate-300 font-medium leading-relaxed">
                    Enter your registered 10-digit mobile number. We will dispatch a high-security SMS OTP to authorize the MPIN reset.
                  </p>
                  <div>
                    <label className="block text-xs font-black uppercase tracking-wider text-slate-300 mb-1.5">
                      Registered Mobile Number
                    </label>
                    <div className="relative">
                      <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-xs font-black text-amber-400">
                        +91
                      </span>
                      <input
                        type="tel"
                        maxLength={10}
                        value={resetPhone}
                        onChange={(e) => setResetPhone(e.target.value.replace(/\D/g, ''))}
                        placeholder="10-digit mobile"
                        className="w-full pl-12 pr-4 py-3 bg-slate-900 border border-slate-700 rounded-2xl text-sm font-bold text-white focus:outline-none focus:ring-2 focus:ring-[#861F41]"
                      />
                    </div>
                  </div>

                  <button
                    type="button"
                    onClick={handleSendResetOtp}
                    disabled={isResetSubmitting}
                    className="w-full py-3.5 rounded-2xl bg-gradient-to-r from-[#861F41] to-[#97144D] disabled:opacity-50 text-amber-300 font-black uppercase tracking-wider text-xs shadow-md transition active:scale-95 flex items-center justify-center gap-2 border border-amber-400/30"
                  >
                    {isResetSubmitting ? 'Verifying Account...' : 'Send Security OTP via SMS'}
                  </button>
                </div>
              ) : (
                <form onSubmit={handleVerifyResetOtp} className="space-y-4">
                  <div>
                    <div className="flex items-center justify-between mb-1.5">
                      <label className="text-xs font-black uppercase tracking-wider text-slate-300">
                        Enter 6-Digit SMS OTP
                      </label>
                      <span className="text-[11px] text-emerald-400 font-bold">
                        Sent to +91 {resetPhone.slice(-10)}
                      </span>
                    </div>
                    <div className="flex justify-between gap-1.5">
                      {resetOtpValues.map((digit, idx) => (
                        <input
                          key={idx}
                          id={`resetotp-${idx}`}
                          type="text"
                          inputMode="numeric"
                          maxLength={1}
                          value={digit}
                          onChange={(e) => {
                            const val = e.target.value.replace(/\D/g, '');
                            const copy = [...resetOtpValues];
                            copy[idx] = val;
                            setResetOtpValues(copy);
                            if (val && idx < 5) {
                              document.getElementById(`resetotp-${idx + 1}`)?.focus();
                            }
                          }}
                          className="w-10 h-12 text-center text-lg font-black bg-slate-900 border-2 border-slate-700 rounded-xl focus:border-amber-400 text-amber-300 font-mono"
                        />
                      ))}
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-2 bg-slate-900 p-3 rounded-2xl border border-slate-800">
                    <div>
                      <label className="block text-[11px] font-black uppercase tracking-wider text-slate-300 mb-1">
                        New 4-Digit MPIN
                      </label>
                      <div className="flex gap-1.5">
                        {resetNewMpin.map((digit, idx) => (
                          <input
                            key={idx}
                            id={`newmpin-${idx}`}
                            type="password"
                            maxLength={1}
                            value={digit}
                            onChange={(e) => {
                              const val = e.target.value.replace(/\D/g, '');
                              const copy = [...resetNewMpin];
                              copy[idx] = val;
                              setResetNewMpin(copy);
                              if (val && idx < 3) {
                                document.getElementById(`newmpin-${idx + 1}`)?.focus();
                              }
                            }}
                            className="w-9 h-11 text-center font-black text-base bg-slate-950 border border-slate-700 rounded-xl focus:border-amber-400 text-amber-300 font-mono"
                          />
                        ))}
                      </div>
                    </div>

                    <div>
                      <label className="block text-[11px] font-black uppercase tracking-wider text-slate-300 mb-1">
                        Confirm MPIN
                      </label>
                      <div className="flex gap-1.5">
                        {resetConfirmMpin.map((digit, idx) => (
                          <input
                            key={idx}
                            id={`confnewmpin-${idx}`}
                            type="password"
                            maxLength={1}
                            value={digit}
                            onChange={(e) => {
                              const val = e.target.value.replace(/\D/g, '');
                              const copy = [...resetConfirmMpin];
                              copy[idx] = val;
                              setResetConfirmMpin(copy);
                              if (val && idx < 3) {
                                document.getElementById(`confnewmpin-${idx + 1}`)?.focus();
                              }
                            }}
                            className="w-9 h-11 text-center font-black text-base bg-slate-950 border border-slate-700 rounded-xl focus:border-amber-400 text-amber-300 font-mono"
                          />
                        ))}
                      </div>
                    </div>
                  </div>

                  <button
                    type="submit"
                    disabled={isResetSubmitting}
                    className="w-full py-3.5 rounded-2xl bg-gradient-to-r from-[#861F41] to-[#97144D] disabled:opacity-50 text-amber-300 font-black uppercase tracking-wider text-xs shadow-md transition active:scale-95 flex items-center justify-center gap-2 border border-amber-400/30"
                  >
                    <ShieldCheck className="w-4 h-4 text-amber-400" />
                    <span>{isResetSubmitting ? 'Updating MPIN...' : 'Confirm & Save New MPIN'}</span>
                  </button>
                </form>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
