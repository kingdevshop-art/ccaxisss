import React, { useState } from 'react';
import {
  Smartphone,
  CheckCircle,
  Download,
  Copy,
  Check,
  Code,
  ShieldCheck,
  Terminal,
  FileCode,
  Sparkles,
  Layers,
  X,
  Play,
} from 'lucide-react';
import { usePWAInstall } from '../hooks/usePWAInstall';
import { AnimatedAndroidStudioGuide } from './AnimatedAndroidStudioGuide';

interface AndroidAppModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const AndroidAppModal: React.FC<AndroidAppModalProps> = ({ isOpen, onClose }) => {
  const { isInstallable, isInstalled, install } = usePWAInstall();
  const [copiedCode, setCopiedCode] = useState<string | null>(null);
  const [isVideoOpen, setIsVideoOpen] = useState(false);

  if (!isOpen) return null;

  const copyToClipboard = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedCode(id);
    setTimeout(() => setCopiedCode(null), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/70 backdrop-blur-xs p-3 sm:p-4 animate-in fade-in">
      <div className="w-full max-w-2xl bg-white rounded-3xl shadow-2xl border border-slate-200 overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="bg-[#861F41] text-white p-4 sm:p-5 flex items-center justify-between border-b border-amber-400/30">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-amber-400/20 border border-amber-400/40 flex items-center justify-center text-amber-300">
              <Smartphone className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-base font-black uppercase tracking-wide text-white">
                  Axis Bank CC VIP Android Application
                </h3>
                <span className="px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 text-[10px] font-bold border border-emerald-400/30">
                  Production Ready
                </span>
              </div>
              <p className="text-xs text-slate-300 font-medium">
                Install as Instant Android WebAPK or Build Native APK from Source
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-white/10 hover:bg-white/20 text-white flex items-center justify-center transition"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-4 sm:p-6 overflow-y-auto space-y-5 text-slate-800 text-xs">
          {/* Animated Video Guide Callout */}
          <div className="bg-gradient-to-r from-[#0a2540] via-[#0e3357] to-[#0a2540] border-2 border-amber-400/50 p-4 sm:p-5 rounded-3xl text-white flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 shadow-lg">
            <div className="flex items-center gap-3.5">
              <div className="w-12 h-12 rounded-2xl bg-amber-400 text-slate-950 flex items-center justify-center font-black shadow-md flex-shrink-0 animate-pulse">
                <Play className="w-6 h-6 fill-slate-950" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <span className="text-xs font-black uppercase tracking-wider text-amber-300">
                    Animated Video Guide
                  </span>
                  <span className="px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 text-[10px] font-bold border border-emerald-400/30">
                    Interactive Walkthrough
                  </span>
                </div>
                <h4 className="text-sm sm:text-base font-black text-white mt-0.5">
                  Watch: Step-by-Step Android Studio App Creation
                </h4>
                <p className="text-xs text-slate-300 mt-0.5 font-medium">
                  Follow along with live progress scrubber, terminal command copy, and code inspector.
                </p>
              </div>
            </div>

            <button
              onClick={() => setIsVideoOpen(true)}
              className="w-full sm:w-auto px-5 py-2.5 rounded-xl bg-amber-400 hover:bg-amber-300 text-slate-950 font-black uppercase tracking-wider text-xs shadow-md transition active:scale-95 flex items-center justify-center gap-2 flex-shrink-0"
            >
              <Play className="w-4 h-4 fill-slate-950" />
              <span>Play Video Guide</span>
            </button>
          </div>

          {/* Method 1: Instant PWA / WebAPK Installation */}
          <div className="bg-gradient-to-br from-amber-50 to-orange-50/50 border border-amber-200 p-4 rounded-2xl space-y-3 shadow-xs">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2 text-amber-900 font-black uppercase tracking-wider text-xs">
                <Sparkles className="w-4 h-4 text-amber-600" />
                <span>Method 1: Instant Android WebAPK (No App Store Needed)</span>
              </div>
              <span className="px-2 py-0.5 rounded-full bg-amber-200/80 text-amber-950 font-bold text-[10px]">
                Recommended
              </span>
            </div>
            <p className="text-slate-700 leading-relaxed">
              Google Chrome and Android OS automatically convert this Progressive Web App into a native Android WebAPK with app drawer icon, full screen standalone window, hardware-accelerated transitions, and offline passbook.
            </p>

            {isInstalled ? (
              <div className="flex items-center gap-2 text-emerald-800 font-bold bg-emerald-100/70 px-3 py-2 rounded-xl">
                <CheckCircle className="w-4 h-4 text-emerald-600 flex-shrink-0" />
                <span>Axis Bank CC VIP is already installed and running on this device!</span>
              </div>
            ) : (
              <div className="flex flex-wrap items-center gap-3 pt-1">
                {isInstallable ? (
                  <button
                    onClick={install}
                    className="px-4 py-2.5 rounded-xl bg-[#0a2540] hover:bg-[#071d34] text-amber-300 font-black uppercase tracking-wider transition shadow-sm flex items-center gap-2 active:scale-95"
                  >
                    <Download className="w-4 h-4" />
                    <span>Install Android App Now</span>
                  </button>
                ) : (
                  <div className="text-[11px] text-slate-600 font-medium bg-white/80 p-2.5 rounded-xl border border-amber-200/60">
                    💡 In mobile Chrome, tap the menu (<strong>⋮</strong>) &rarr; <strong>"Install app"</strong> or <strong>"Add to Home screen"</strong>.
                  </div>
                )}
              </div>
            )}
          </div>

          {/* Method 2: Native Android Source Code (`android/`) */}
          <div className="bg-slate-50 border border-slate-200 p-4 rounded-2xl space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2 text-[#0a2540] font-black uppercase tracking-wider text-xs">
                <Code className="w-4 h-4 text-blue-700" />
                <span>Method 2: Native Android Project Source Code (/android)</span>
              </div>
              <span className="px-2 py-0.5 rounded-full bg-blue-100 text-blue-900 font-bold text-[10px]">
                Kotlin 1.9 + Gradle
              </span>
            </div>
            <p className="text-slate-600 leading-relaxed">
              The project includes complete, production-grade Android Studio source code located in the <code className="bg-slate-200 px-1.5 py-0.5 rounded font-mono text-[11px] text-slate-900 font-bold">/android</code> directory:
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-[11px]">
              <div className="bg-white p-2.5 rounded-xl border border-slate-200 flex items-start gap-2">
                <FileCode className="w-4 h-4 text-emerald-600 flex-shrink-0 mt-0.5" />
                <div>
                  <strong className="text-slate-900 font-bold block">MainActivity.kt</strong>
                  <span className="text-slate-500">BiometricPrompt, Multilingual Soundbox TTS, GPS radar &amp; camera permissions</span>
                </div>
              </div>
              <div className="bg-white p-2.5 rounded-xl border border-slate-200 flex items-start gap-2">
                <ShieldCheck className="w-4 h-4 text-blue-600 flex-shrink-0 mt-0.5" />
                <div>
                  <strong className="text-slate-900 font-bold block">AndroidManifest.xml</strong>
                  <span className="text-slate-500">Target SDK 34, UPI queries, deep links (axis://, upi://pay), FLAG_SECURE</span>
                </div>
              </div>
              <div className="bg-white p-2.5 rounded-xl border border-slate-200 flex items-start gap-2">
                <Terminal className="w-4 h-4 text-amber-600 flex-shrink-0 mt-0.5" />
                <div>
                  <strong className="text-slate-900 font-bold block">build.gradle</strong>
                  <span className="text-slate-500">Target SDK 34, Min SDK 24, Version 2.5.0, Proguard obfuscation ready</span>
                </div>
              </div>
              <div className="bg-white p-2.5 rounded-xl border border-slate-200 flex items-start gap-2">
                <Layers className="w-4 h-4 text-purple-600 flex-shrink-0 mt-0.5" />
                <div>
                  <strong className="text-slate-900 font-bold block">Capacitor &amp; Native Bridge</strong>
                  <span className="text-slate-500">Multi-platform CLI sync with capacitor.config.json &amp; nativeBridge.ts</span>
                </div>
              </div>
            </div>

            {/* Terminal Build Commands */}
            <div className="space-y-1.5 pt-1">
              <span className="text-[11px] font-black uppercase tracking-wider text-slate-600">
                To build native APK / AAB in Android Studio:
              </span>
              <div className="bg-slate-900 text-slate-100 p-3 rounded-xl font-mono text-[11px] relative group">
                <pre className="overflow-x-auto">
{`# 1. Build the production web bundle
npm run build

# 2. Navigate to android directory and compile APK
cd android
./gradlew assembleRelease

# The generated APK will be at:
# android/app/build/outputs/apk/release/app-release.apk`}
                </pre>
                <button
                  onClick={() =>
                    copyToClipboard(
                      'npm run build && cd android && ./gradlew assembleRelease',
                      'gradle_cmd'
                    )
                  }
                  className="absolute top-2 right-2 p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 transition"
                  title="Copy command"
                >
                  {copiedCode === 'gradle_cmd' ? (
                    <Check className="w-3.5 h-3.5 text-emerald-400" />
                  ) : (
                    <Copy className="w-3.5 h-3.5" />
                  )}
                </button>
              </div>
            </div>
          </div>

          {/* Security & Regulatory Compliance */}
          <div className="bg-emerald-50 border border-emerald-200 p-3.5 rounded-2xl flex items-center gap-3">
            <ShieldCheck className="w-6 h-6 text-emerald-700 flex-shrink-0" />
            <div className="text-[11px] text-emerald-900">
              <strong>Bank-Grade Android Security:</strong> Cleartext HTTP is disabled via <code className="font-mono bg-emerald-100 px-1 py-0.5 rounded">network_security_config.xml</code>. Biometric tokens stay strictly on the hardware secure enclave.
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 bg-slate-50 border-t border-slate-100 flex items-center justify-between">
          <span className="text-[11px] text-slate-500 font-bold">
            Axis Bank CC VIP • Mobile Banking v2.4.0 Production
          </span>
          <button
            onClick={onClose}
            className="px-5 py-2 rounded-xl bg-[#861F41] text-amber-300 hover:bg-[#580824] text-xs font-black uppercase tracking-wider transition"
          >
            Close
          </button>
        </div>
      </div>

      {/* Interactive Animated Video Guide Modal */}
      <AnimatedAndroidStudioGuide
        isOpen={isVideoOpen}
        onClose={() => setIsVideoOpen(false)}
      />
    </div>
  );
};
