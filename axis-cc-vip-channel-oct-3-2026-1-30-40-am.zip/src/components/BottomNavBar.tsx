import React from 'react';
import {
  Home,
  QrCode,
  FileText,
  CreditCard,
  SlidersHorizontal,
  PieChart,
  Bot,
} from 'lucide-react';
import { LanguageCode } from '../types';
import { TRANSLATIONS } from '../i18n/translations';

export type UserDashboardTab = 'HOME' | 'CARDS' | 'PASSBOOK' | 'SERVICES' | 'BUDGET' | 'SAHAYAK';

interface BottomNavBarProps {
  currentTab: UserDashboardTab;
  language: LanguageCode;
  onSelectTab: (tab: UserDashboardTab) => void;
  onOpenQuickPay: () => void;
}

export const BottomNavBar: React.FC<BottomNavBarProps> = ({
  currentTab,
  language,
  onSelectTab,
  onOpenQuickPay,
}) => {
  const t = TRANSLATIONS[language] || TRANSLATIONS.en;

  return (
    <div className="fixed bottom-0 inset-x-0 z-40 bg-white/95 backdrop-blur-md border-t border-slate-200 text-slate-500 max-w-4xl mx-auto shadow-lg">
      <div className="flex items-center justify-around px-2 py-1.5 sm:py-2">
        {/* Home */}
        <button
          onClick={() => onSelectTab('HOME')}
          className={`flex flex-col items-center justify-center p-1.5 flex-1 transition ${
            currentTab === 'HOME'
              ? 'text-[#861F41] font-black'
              : 'text-slate-500 hover:text-slate-900 font-bold'
          }`}
        >
          <Home className={`w-5 h-5 ${currentTab === 'HOME' ? 'scale-110 stroke-[2.5]' : 'stroke-2'}`} />
          <span className="text-[10px] mt-0.5 uppercase tracking-wider">{t.home}</span>
        </button>

        {/* Virtual Debit Cards */}
        <button
          onClick={() => onSelectTab('CARDS')}
          className={`flex flex-col items-center justify-center p-1.5 flex-1 transition ${
            currentTab === 'CARDS'
              ? 'text-[#861F41] font-black'
              : 'text-slate-500 hover:text-slate-900 font-bold'
          }`}
          title="Virtual Debit Cards & Controls"
        >
          <CreditCard className={`w-5 h-5 ${currentTab === 'CARDS' ? 'scale-110 stroke-[2.5]' : 'stroke-2'}`} />
          <span className="text-[10px] mt-0.5 uppercase tracking-wider">VIP Cards</span>
        </button>

        {/* Floating Scan & Pay Central Action Button in Axis Dark Red */}
        <div className="flex-1 flex justify-center -mt-6">
          <button
            onClick={onOpenQuickPay}
            className="w-13 h-13 sm:w-14 sm:h-14 rounded-2xl bg-gradient-to-br from-[#861F41] to-[#5F0C2B] hover:from-[#700a2f] hover:to-[#861F41] text-white flex flex-col items-center justify-center shadow-lg shadow-[#861F41]/40 border-4 border-white active:scale-95 transition-transform"
            title="Scan Any QR or Pay UPI"
          >
            <QrCode className="w-6 h-6 stroke-[2.5] text-amber-300" />
            <span className="text-[8px] font-black uppercase tracking-wider text-amber-300">Pay</span>
          </button>
        </div>

        {/* Passbook */}
        <button
          onClick={() => onSelectTab('PASSBOOK')}
          className={`flex flex-col items-center justify-center p-1.5 flex-1 transition ${
            currentTab === 'PASSBOOK'
              ? 'text-[#861F41] font-black'
              : 'text-slate-500 hover:text-slate-900 font-bold'
          }`}
        >
          <FileText className={`w-5 h-5 ${currentTab === 'PASSBOOK' ? 'scale-110 stroke-[2.5]' : 'stroke-2'}`} />
          <span className="text-[10px] mt-0.5 uppercase tracking-wider">{t.passbook}</span>
        </button>

        {/* Banking Services & Profile Updates */}
        <button
          onClick={() => onSelectTab('SERVICES')}
          className={`flex flex-col items-center justify-center p-1.5 flex-1 transition ${
            currentTab === 'SERVICES'
              ? 'text-[#861F41] font-black'
              : 'text-slate-500 hover:text-slate-900 font-bold'
          }`}
          title="UPI Channels, Soundbox, Limits & Information Updates"
        >
          <SlidersHorizontal className={`w-5 h-5 ${currentTab === 'SERVICES' ? 'scale-110 stroke-[2.5]' : 'stroke-2'}`} />
          <span className="text-[10px] mt-0.5 uppercase tracking-wider">Services</span>
        </button>
      </div>
    </div>
  );
};
