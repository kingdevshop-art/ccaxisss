import React, { useState } from 'react';
import {
  X,
  CheckCircle2,
  Share2,
  Download,
  Copy,
  Check,
  ShieldCheck,
  ArrowDownLeft,
  ArrowUpRight,
  Volume2,
  Building,
} from 'lucide-react';
import { Transaction, LanguageCode } from '../types';
import { speakSoundboxAlert } from '../utils/audioAlert';
import { formatTransactionTimestamp } from '../utils/dateUtils';

interface TransactionReceiptModalProps {
  isOpen: boolean;
  onClose: () => void;
  transaction: Transaction | null;
  language: LanguageCode;
  onRepeatPay?: (tx: Transaction) => void;
}

export const TransactionReceiptModal: React.FC<TransactionReceiptModalProps> = ({
  isOpen,
  onClose,
  transaction,
  language,
  onRepeatPay,
}) => {
  const [copiedUtr, setCopiedUtr] = useState(false);
  const [copiedAll, setCopiedAll] = useState(false);

  if (!isOpen || !transaction) return null;

  const formattedTimestamp = formatTransactionTimestamp(
    transaction.timestamp,
    transaction.createdAt,
    transaction.id
  );
  const isDebit = transaction.type === 'debit';

  const handleCopyUtr = () => {
    navigator.clipboard?.writeText(transaction.upiRefId);
    setCopiedUtr(true);
    setTimeout(() => setCopiedUtr(false), 2000);
  };

  const handleCopyReceiptText = () => {
    const text = `--- AXIS BANK CC VIP TRANSACTION RECEIPT ---
Amount: ₹${transaction.amount.toFixed(2)}
Status: ${transaction.status}
UTR Ref: ${transaction.upiRefId}
Title: ${transaction.title}
Timestamp: ${formattedTimestamp}
Bank: Axis Bank CC VIP
IFSC: UTIB000001
--------------------------------------------`;
    navigator.clipboard?.writeText(text);
    setCopiedAll(true);
    setTimeout(() => setCopiedAll(false), 2000);
  };

  const handleDownloadReceipt = () => {
    const content = `AXIS BANK CC VIP
OFFICIAL TRANSACTION ADVICE & RECEIPT

Transaction Status: ${transaction.status}
UTR Reference Number: ${transaction.upiRefId}
Transaction Date/Time: ${formattedTimestamp}
Amount: INR ${transaction.amount.toFixed(2)}
Type: ${transaction.type.toUpperCase()}
Beneficiary / Remitter: ${transaction.title} (${transaction.subTitle})
Payment Channel: ${transaction.paymentMode}
Category: ${transaction.category}
Bank IFSC: UTIB000001

---------------------------------------------------------
This is a computer-generated bank advice. Verified by RBI & DICGC.`;

    const blob = new Blob([content], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `AXIS_Receipt_${transaction.upiRefId.replace(/[^a-zA-Z0-9]/g, '_')}.txt`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-slate-950/70 backdrop-blur-xs animate-in fade-in">
      <div className="bg-white rounded-3xl w-full max-w-md border border-slate-200 overflow-hidden shadow-2xl flex flex-col max-h-[92vh]">
        {/* Header */}
        <div className="bg-gradient-to-r from-[#4E061E] via-[#861F41] to-[#97144D] text-white p-4 sm:p-5 flex items-center justify-between border-b border-amber-400/30">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 flex items-center justify-center flex-shrink-0">
              <img
                src="/axis_logo.svg"
                alt="Axis Bank CC VIP Logo"
                className="w-full h-full object-contain filter drop-shadow-[0_2px_8px_rgba(0,0,0,0.4)]"
              />
            </div>
            <div>
              <h2 className="text-xs font-black uppercase tracking-wider text-white">
                Axis Bank CC VIP Advice
              </h2>
              <p className="text-[10px] text-amber-200 font-bold">
                Axis Bank Corporate HO (Mumbai)
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-full bg-white/10 hover:bg-white/20 text-slate-300 hover:text-white transition"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Receipt Content */}
        <div className="p-5 space-y-4 overflow-y-auto">
          {/* Status & Amount Badge */}
          <div className="text-center space-y-1.5 pt-2">
            <div className="w-12 h-12 rounded-2xl bg-emerald-100 text-emerald-600 flex items-center justify-center mx-auto shadow-xs">
              <CheckCircle2 className="w-7 h-7 stroke-[2.5]" />
            </div>
            <p className="text-xs font-black uppercase tracking-wider text-emerald-700">
              Payment Successful
            </p>
            <h1 className="text-3xl font-black text-slate-900 tracking-tight font-sans">
              {isDebit ? '-' : '+'}₹{transaction.amount.toFixed(2)}
            </h1>
            <p className="text-xs font-bold text-slate-600">{transaction.title}</p>
          </div>

          {/* Details Card */}
          <div className="bg-slate-50 border border-slate-200 rounded-2xl p-4 space-y-3 text-xs">
            <div className="flex items-center justify-between">
              <span className="text-slate-500 font-bold">UTR Reference:</span>
              <div className="flex items-center gap-1.5">
                <span className="font-mono font-black text-slate-900">{transaction.upiRefId}</span>
                <button
                  onClick={handleCopyUtr}
                  className="p-1 hover:bg-slate-200 rounded text-slate-500 transition"
                  title="Copy UTR"
                >
                  {copiedUtr ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                </button>
              </div>
            </div>

            <div className="flex items-center justify-between">
              <span className="text-slate-500 font-bold">Date & Time:</span>
              <span className="font-bold text-slate-800">{formattedTimestamp}</span>
            </div>

            <div className="flex items-center justify-between">
              <span className="text-slate-500 font-bold">Payment Method:</span>
              <span className="font-black text-[#861F41] bg-rose-50 px-2 py-0.5 rounded border border-rose-100 uppercase text-[10px]">
                {transaction.paymentMode || 'Axis Core'}
              </span>
            </div>

            <div className="flex items-center justify-between">
              <span className="text-slate-500 font-bold">Category:</span>
              <span className="font-bold text-slate-800 capitalize">{transaction.category}</span>
            </div>

            <div className="flex items-center justify-between border-t border-slate-200 pt-2 text-[11px]">
              <span className="text-slate-500 font-bold">Branch / Apex IFSC:</span>
              <span className="font-mono font-bold text-slate-700">WBSC0000001</span>
            </div>
          </div>

          <div className="flex items-center justify-center gap-2 text-[10px] text-slate-500 font-bold">
            <ShieldCheck className="w-4 h-4 text-emerald-600" />
            <span>Encrypted • RBI Core Banking Transaction Certificate</span>
          </div>

          {/* Action Row */}
          <div className="grid grid-cols-2 gap-2 pt-1">
            <button
              onClick={handleDownloadReceipt}
              className="py-2.5 px-3 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-800 font-black text-xs uppercase tracking-wider transition active:scale-95 flex items-center justify-center gap-1.5 border border-slate-200"
            >
              <Download className="w-3.5 h-3.5 text-[#0a2540]" />
              <span>Download Advice</span>
            </button>

            <button
              onClick={handleCopyReceiptText}
              className="py-2.5 px-3 rounded-xl bg-[#0a2540] hover:bg-[#071d34] text-amber-300 font-black text-xs uppercase tracking-wider transition active:scale-95 flex items-center justify-center gap-1.5 shadow-sm"
            >
              {copiedAll ? <Check className="w-3.5 h-3.5" /> : <Share2 className="w-3.5 h-3.5" />}
              <span>{copiedAll ? 'Copied' : 'Share Receipt'}</span>
            </button>
          </div>

          {onRepeatPay && isDebit && (
            <button
              onClick={() => {
                onClose();
                onRepeatPay(transaction);
              }}
              className="w-full py-2.5 rounded-xl border border-slate-300 hover:bg-slate-50 text-slate-800 font-black text-xs uppercase tracking-wider transition active:scale-95 flex items-center justify-center gap-1.5"
            >
              <ArrowUpRight className="w-3.5 h-3.5 text-[#0a2540]" />
              <span>Repeat Transfer to this Payee</span>
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
