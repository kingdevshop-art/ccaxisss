import React, { useState, useRef, useEffect, useCallback } from 'react';
import jsQR from 'jsqr';
import {
  QrCode,
  Smartphone,
  AtSign,
  Landmark,
  X,
  Camera,
  Search,
  User,
  ArrowRight,
  ShieldCheck,
  CheckCircle2,
  Sparkles,
  Zap,
  Share2,
  Download,
  Volume2,
  AlertCircle,
  Clock,
  ShieldAlert,
  Copy,
  Upload,
  RefreshCw,
} from 'lucide-react';
import {
  UserProfile,
  LanguageCode,
  Contact,
  Transaction,
  TransactionCategory,
} from '../types';
import { TRANSLATIONS } from '../i18n/translations';
import { UPIPinModal } from './UPIPinModal';
import { speakSoundboxTransactionAlert, playScannerBeep } from '../utils/audioAlert';
import { parseUpiQr } from '../utils/qrUtils';
import { getNowBankingTimestamp } from '../utils/dateUtils';

interface PayModalProps {
  isOpen: boolean;
  onClose: () => void;
  user: UserProfile;
  contacts: Contact[];
  language: LanguageCode;
  allUsers?: UserProfile[];
  initialTab?: 'qr' | 'contact' | 'upi' | 'bank' | 'bill';
  initialBillName?: string;
  onPaymentSuccess: (transaction: Transaction) => void;
  onOpenBiometrics: () => void;
}

export const PayModal: React.FC<PayModalProps> = ({
  isOpen,
  onClose,
  user,
  contacts,
  language,
  allUsers = [],
  initialTab = 'contact',
  initialBillName,
  onPaymentSuccess,
  onOpenBiometrics,
}) => {
  if (!isOpen) return null;

  const [activeTab, setActiveTab] = useState<'qr' | 'contact' | 'upi' | 'bank' | 'bill'>(
    initialBillName ? 'bill' : initialTab
  );

  const t = TRANSLATIONS[language] || TRANSLATIONS.en;

  // Form states
  const [recipientName, setRecipientName] = useState(initialBillName || '');
  const [recipientVpa, setRecipientVpa] = useState('');
  const [phone, setPhone] = useState('');
  const [bankAccount, setBankAccount] = useState('');
  const [ifsc, setIfsc] = useState('UTIB000001');
  const [amount, setAmount] = useState<string>('500');
  const [note, setNote] = useState('');
  const [paymentMode, setPaymentMode] = useState<'SAVINGS_AC' | 'WALLET' | 'UPI_LITE'>(
    'SAVINGS_AC'
  );
  const [category, setCategory] = useState<TransactionCategory>('transfer');
  const [capturedQrData, setCapturedQrData] = useState<string>('');

  // Flow states
  const [showPinModal, setShowPinModal] = useState(false);
  const [completedTx, setCompletedTx] = useState<Transaction | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [qrScanning, setQrScanning] = useState(true);
  const [cameraError, setCameraError] = useState<string | null>(null);
  const [isCameraActive, setIsCameraActive] = useState<boolean>(false);

  const videoRef = useRef<HTMLVideoElement | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const animationFrameRef = useRef<number | null>(null);
  const streamRef = useRef<MediaStream | null>(null);

  const stopCamera = useCallback(() => {
    if (animationFrameRef.current) {
      cancelAnimationFrame(animationFrameRef.current);
      animationFrameRef.current = null;
    }
    if (streamRef.current) {
      streamRef.current.getTracks().forEach((track) => track.stop());
      streamRef.current = null;
    }
    setIsCameraActive(false);
  }, []);

  const handleQrDecoded = useCallback((raw: string) => {
    playScannerBeep();
    stopCamera();
    const parsed = parseUpiQr(raw);
    const vpa = parsed.upiId || (raw.includes('@') ? raw.trim() : '');
    const payeeName =
      parsed.name ||
      (vpa ? vpa.split('@')[0].replace(/[._-]/g, ' ').toUpperCase() : 'Merchant / User');

    setRecipientName(payeeName);
    setRecipientVpa(vpa || 'merchant@axisbank');
    if (parsed.amount && parsed.amount > 0) {
      setAmount(String(parsed.amount));
    }
    if (parsed.accountNumber) {
      setBankAccount(parsed.accountNumber);
    }
    if (parsed.ifsc) {
      setIfsc(parsed.ifsc);
    }
    setCategory('shopping');
    setCapturedQrData(raw);
    setQrScanning(false);
  }, [stopCamera]);

  const scanFrame = useCallback(() => {
    if (!videoRef.current || !canvasRef.current) return;
    const video = videoRef.current;
    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d', { willReadFrequently: true });

    if (video.readyState === video.HAVE_ENOUGH_DATA && ctx) {
      canvas.height = video.videoHeight;
      canvas.width = video.videoWidth;
      ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
      const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
      const code = jsQR(imageData.data, imageData.width, imageData.height, {
        inversionAttempts: 'dontInvert',
      });

      if (code && code.data && code.data.trim()) {
        handleQrDecoded(code.data.trim());
        return;
      }
    }
    animationFrameRef.current = requestAnimationFrame(scanFrame);
  }, [handleQrDecoded]);

  const startCamera = useCallback(async () => {
    setCameraError(null);
    stopCamera();

    try {
      if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        setCameraError('Camera API is not supported in this browser. You can upload a QR image or select a contact.');
        return;
      }

      const stream = await navigator.mediaDevices.getUserMedia({
        video: {
          facingMode: { ideal: 'environment' },
          width: { ideal: 1280 },
          height: { ideal: 720 },
        },
      });

      streamRef.current = stream;
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        videoRef.current.setAttribute('playsinline', 'true');
        await videoRef.current.play();
        setIsCameraActive(true);
        animationFrameRef.current = requestAnimationFrame(scanFrame);
      }
    } catch (err: any) {
      console.warn('Camera stream error:', err);
      if (err.name === 'NotAllowedError' || err.name === 'PermissionDeniedError') {
        setCameraError('Camera permission denied. Please allow camera access in browser settings or upload a QR image.');
      } else {
        setCameraError('Camera unavailable or in use by another application. You can upload a QR image.');
      }
      setIsCameraActive(false);
    }
  }, [scanFrame, stopCamera]);

  // Activate / deactivate camera depending on active tab
  useEffect(() => {
    if (isOpen && activeTab === 'qr' && qrScanning && !completedTx) {
      startCamera();
    } else {
      stopCamera();
    }
    return () => {
      stopCamera();
    };
  }, [isOpen, activeTab, qrScanning, completedTx, startCamera, stopCamera]);

  const filteredContacts = contacts.filter(
    (c) =>
      c.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      c.phone.includes(searchTerm) ||
      c.upiId.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleSelectContact = (c: Contact) => {
    setRecipientName(c.name);
    setRecipientVpa(c.upiId);
    setPhone(c.phone);
    setCategory('transfer');
  };

  const handleQrFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const dataUrl = event.target?.result as string;
      setCapturedQrData(dataUrl);

      const img = new Image();
      img.onload = () => {
        const canvas = document.createElement('canvas');
        canvas.width = img.width;
        canvas.height = img.height;
        const ctx = canvas.getContext('2d');
        if (ctx) {
          ctx.drawImage(img, 0, 0);
          const imgData = ctx.getImageData(0, 0, img.width, img.height);
          const decoded = jsQR(imgData.data, imgData.width, imgData.height);
          if (decoded && decoded.data && decoded.data.trim()) {
            handleQrDecoded(decoded.data.trim());
            return;
          }
        }
        // If image decoding did not find a standard QR, offer manual input
        const manualPrompt = prompt(
          `QR code in "${file.name}" could not be auto-detected. Enter recipient UPI ID / VPA:`,
          'store@axisbank'
        );
        if (manualPrompt && manualPrompt.trim()) {
          handleQrDecoded(manualPrompt.trim());
        }
      };
      img.src = dataUrl;
    };
    reader.readAsDataURL(file);
  };

  const handleInitiatePayment = () => {
    const numAmount = parseFloat(amount);
    if (!numAmount || numAmount <= 0) {
      alert('Please enter a valid amount');
      return;
    }

    // Check balances
    if (paymentMode === 'SAVINGS_AC' && user.savingsBalance < numAmount) {
      alert('Insufficient balance in Corporate Account');
      return;
    }
    if (paymentMode === 'WALLET' && user.walletBalance < numAmount) {
      alert('Insufficient balance in Axis Bank CC VIP Corporate Wallet');
      return;
    }
    if (paymentMode === 'UPI_LITE' && (user.upiLiteBalance < numAmount || numAmount > 500)) {
      alert('UPI Lite limit is ₹500 per transaction and requires sufficient balance');
      return;
    }

    // If UPI Lite, bypass PIN directly for fast pay
    if (paymentMode === 'UPI_LITE') {
      finalizeTransaction();
    } else {
      setShowPinModal(true);
    }
  };

  const finalizeTransaction = () => {
    setShowPinModal(false);
    const numAmount = parseFloat(amount);
    const refId = `UPI/${Math.floor(100000000000 + Math.random() * 900000000000)}`;

    const cleanAccount = bankAccount.trim();
    const cleanIfsc = ifsc.trim().toUpperCase();
    const cleanVpa = recipientVpa.trim().toLowerCase();
    const cleanPhone = phone.replace(/\D/g, '');

    // Core Banking Rules:
    // 1. Same bank transfer (any account belonging to this application):
    //    Seamless immediate execution without any problem (SUCCESS).
    // 2. Transfers to other bank accounts (outside of this application):
    //    Placed in PROCESSED status until Admin marks paid/reject/hold.
    // 3. For UPI/QR:
    //    Same bank VPA/account -> immediate SUCCESS.
    //    Other bank valid QR / VPA -> PROCESSED status, Admin can view captured QR/VPA.

    let matchedUser: UserProfile | undefined;
    let isSameBank = false;

    if (activeTab === 'bank') {
      matchedUser = allUsers.find(
        (u) =>
          u.accountNumber === cleanAccount ||
          ((cleanIfsc.startsWith('UTIB') || cleanIfsc === 'UTIB000001') && cleanAccount.length >= 6 && u.accountNumber.endsWith(cleanAccount.slice(-6)))
      );
      isSameBank = Boolean(matchedUser);
    } else if (activeTab === 'upi' || activeTab === 'qr') {
      matchedUser = allUsers.find(
        (u) =>
          (u.upiId && u.upiId.toLowerCase() === cleanVpa) ||
          (cleanVpa && u.phone && cleanVpa.includes(u.phone)) ||
          (cleanVpa.includes('@axisbank') && allUsers.some((u) => cleanVpa.startsWith(u.phone) || cleanVpa.startsWith(u.accountNumber)))
      );
      isSameBank = Boolean(matchedUser);
    } else if (activeTab === 'contact') {
      matchedUser = allUsers.find((u) => u.phone.replace(/\D/g, '') === cleanPhone);
      isSameBank = Boolean(matchedUser);
    }

    let txTransferType: 'SAME_BANK' | 'OTHER_BANK' | 'UPI' = isSameBank
      ? 'SAME_BANK'
      : activeTab === 'bank'
      ? 'OTHER_BANK'
      : 'UPI';
    let txStatus: 'SUCCESS' | 'PROCESSED' = isSameBank ? 'SUCCESS' : 'PROCESSED';
    let txApprovalStatus: 'APPROVED' | 'AWAITING_ADMIN' = isSameBank ? 'APPROVED' : 'AWAITING_ADMIN';
    let txSubTitle = note || '';

    if (isSameBank) {
      txSubTitle = note || `Internal Direct Settlement to ${matchedUser?.name || recipientName || 'Axis Account'}`;
    } else if (activeTab === 'bank') {
      txSubTitle = note || `Inter-Bank Transfer to ${cleanIfsc} • Processed (Awaiting Admin Review)`;
    } else {
      txSubTitle = note || `UPI Payment to ${cleanVpa || 'Payee'} • Processed (Awaiting Admin Review)`;
    }

    const newTx: Transaction = {
      id: `tx_${Date.now()}`,
      userId: user.id,
      userPhone: user.phone,
      senderVpa: user.upiId,
      title: matchedUser?.name || recipientName || recipientVpa || phone || 'Beneficiary',
      subTitle: txSubTitle,
      amount: numAmount,
      type: 'debit',
      category: category,
      timestamp: getNowBankingTimestamp(),
      status: txStatus,
      paymentMode: paymentMode,
      upiRefId: refId,
      recipientVpa: recipientVpa || (phone ? `${phone.replace(/\D/g, '')}@axisbank` : undefined),
      fraudFlag: 'CLEAN',
      transferType: txTransferType,
      approvalStatus: txApprovalStatus,
      recipientIfsc: activeTab === 'bank' ? cleanIfsc : undefined,
      beneficiaryAccount: activeTab === 'bank' ? cleanAccount : (matchedUser?.accountNumber || undefined),
      beneficiaryName: matchedUser?.name || recipientName || undefined,
      scannerAddress: activeTab === 'qr' ? recipientVpa || 'QR Scanned Merchant' : undefined,
      qrData:
        capturedQrData ||
        (activeTab === 'qr'
          ? (recipientVpa.startsWith('upi://')
              ? recipientVpa
              : `upi://pay?pa=${recipientVpa || 'merchant@axisbank'}&pn=${encodeURIComponent(
                  recipientName || 'Verified Merchant'
                )}&am=${numAmount}&cu=INR`)
          : undefined),
    };

    setCompletedTx(newTx);
    onPaymentSuccess(newTx);

    // Speak real-time Soundbox voice alert every time while sending money
    speakSoundboxTransactionAlert({
      type: 'DEBIT',
      amount: numAmount,
      recipientName: matchedUser?.name || recipientName || 'Beneficiary',
      language: user.soundboxLanguage || language,
    });
  };

  const handleReset = () => {
    setCompletedTx(null);
    setRecipientName('');
    setRecipientVpa('');
    setPhone('');
    setAmount('500');
    setNote('');
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-xs flex items-end sm:items-center justify-center p-0 sm:p-4 animate-in fade-in">
      <div className="w-full sm:max-w-xl bg-white border border-slate-200 text-slate-900 rounded-t-3xl sm:rounded-3xl shadow-2xl max-h-[92vh] flex flex-col overflow-hidden animate-in slide-in-from-bottom duration-300">
        {/* Top Header */}
        <div className="p-4 sm:p-5 bg-gradient-to-r from-[#580824] via-[#861F41] to-[#700a2f] text-white flex items-center justify-between border-b border-[#143d6b]">
          <div className="flex items-center gap-3">
            <div className="w-13 h-13 sm:w-14 sm:h-14 flex items-center justify-center flex-shrink-0">
              <img
                src="/axis_logo.svg"
                alt="Axis Bank CC VIP Logo"
                referrerPolicy="no-referrer"
                className="w-full h-full object-contain filter drop-shadow-[0_2px_8px_rgba(0,0,0,0.4)]"
              />
            </div>
            <div>
              <h2 className="text-base font-black text-white tracking-tight">
                {completedTx ? (completedTx.status === 'SUCCESS' ? 'Payment Receipt' : 'Payment Awaited') : 'Instant Money Transfer'}
              </h2>
              <p className="text-[11px] text-amber-200/90 font-bold">
                AXIS BANK CC VIP • Direct Settlement
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-full bg-black/20 hover:bg-black/30 text-white transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* If Transaction Completed: Receipt View (Processed / Pending vs Success) */}
        {completedTx ? (
          <div className="p-5 overflow-y-auto flex-1 text-center space-y-4">
            {completedTx.status === 'PROCESSED' || completedTx.status === 'PENDING_APPROVAL' ? (
              <div className="w-16 h-16 mx-auto rounded-full bg-amber-100 text-amber-700 border-2 border-amber-500 flex items-center justify-center animate-pulse">
                <Clock className="w-9 h-9" />
              </div>
            ) : (
              <div className="w-16 h-16 mx-auto rounded-full bg-emerald-100 text-emerald-600 border-2 border-emerald-500 flex items-center justify-center animate-bounce">
                <CheckCircle2 className="w-9 h-9" />
              </div>
            )}

            <div>
              <div className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[11px] font-black uppercase tracking-wider mb-1 shadow-xs border">
                {completedTx.status === 'PROCESSED' || completedTx.status === 'PENDING_APPROVAL' ? (
                  <span className="bg-amber-100 text-amber-900 border-amber-300">
                    Payment Processed • Awaiting Admin Clearance
                  </span>
                ) : (
                  <span className="bg-emerald-100 text-emerald-900 border-emerald-300">
                    Payment Successful • Same-Bank Immediate Clearance
                  </span>
                )}
              </div>

              <h3 className="text-3xl sm:text-4xl font-black font-sans text-slate-900 mt-1 tracking-tight">
                ₹{completedTx.amount.toLocaleString('en-IN', { minimumFractionDigits: 2 })}
              </h3>
              <p className="text-xs text-slate-600 font-bold mt-1">
                {completedTx.status === 'PROCESSED' || completedTx.status === 'PENDING_APPROVAL' ? 'Payee: ' : 'Paid to '}{' '}
                <span className="font-black text-slate-900">{completedTx.title}</span>
              </p>

              {(completedTx.status === 'PROCESSED' || completedTx.status === 'PENDING_APPROVAL') && (
                <div className="mt-2.5 p-3 rounded-xl bg-amber-50/90 border border-amber-200 text-xs text-amber-900 font-medium text-left space-y-1">
                  <p className="font-black flex items-center gap-1.5 text-amber-950">
                    <ShieldAlert className="w-3.5 h-3.5 text-amber-600 flex-shrink-0" />
                    <span>Admin Clearance Review in Progress</span>
                  </p>
                  <p className="text-[11px] leading-relaxed text-amber-900">
                    {completedTx.transferType === 'OTHER_BANK'
                      ? `Transfers to external bank accounts (outside this application) are in processed status and will be finalized after branch admin marks it paid, reject, or hold.`
                      : `Transfers to external UPI VPAs / other bank QR codes are in processed status until verified and cleared by the Branch Admin.`}
                  </p>
                </div>
              )}
            </div>

            {/* Receipt Details Card */}
            <div className="bg-slate-50 rounded-2xl p-4 border border-slate-200 text-left text-xs space-y-2.5 shadow-2xs">
              <div className="flex justify-between items-center py-1 border-b border-slate-200">
                <span className="text-slate-500 font-bold">Status</span>
                <span
                  className={`font-black uppercase text-[11px] px-2 py-0.5 rounded ${
                    completedTx.status === 'SUCCESS'
                      ? 'bg-emerald-100 text-emerald-800'
                      : completedTx.status === 'HOLD'
                      ? 'bg-orange-100 text-orange-900'
                      : 'bg-amber-100 text-amber-900'
                  }`}
                >
                  {completedTx.status === 'SUCCESS' ? 'Completed / Cleared' : 'Processed (Awaiting Clearance)'}
                </span>
              </div>
              <div className="flex justify-between items-center py-1 border-b border-slate-200">
                <span className="text-slate-500 font-bold">Transfer Type</span>
                <span className="font-black text-slate-900">
                  {completedTx.transferType === 'SAME_BANK'
                    ? 'Same Bank (Axis Bank CC VIP Core)'
                    : completedTx.transferType === 'OTHER_BANK'
                    ? `Other Bank (${completedTx.recipientIfsc})`
                    : 'UPI / QR Payment'}
                </span>
              </div>
              {completedTx.recipientVpa && (
                <div className="flex justify-between items-center py-1 border-b border-slate-200">
                  <span className="text-slate-500 font-bold">UPI / Scanner Address</span>
                  <span className="font-mono font-black text-[#861F41]">
                    {completedTx.recipientVpa}
                  </span>
                </div>
              )}
              {completedTx.recipientIfsc && (
                <div className="flex justify-between items-center py-1 border-b border-slate-200">
                  <span className="text-slate-500 font-bold">Beneficiary IFSC</span>
                  <span className="font-mono font-black text-slate-900">
                    {completedTx.recipientIfsc}
                  </span>
                </div>
              )}
              <div className="flex justify-between items-center py-1 border-b border-slate-200">
                <span className="text-slate-500 font-bold">Ref / UTR Number</span>
                <span className="font-mono font-black text-slate-900">
                  {completedTx.upiRefId}
                </span>
              </div>
              <div className="flex justify-between items-center py-1 border-b border-slate-200">
                <span className="text-slate-500 font-bold">From Account</span>
                <span className="font-black text-slate-900">
                  Axis Bank CC VIP Corporate A/c •••• {user.accountNumber.slice(-4)}
                </span>
              </div>
              <div className="flex justify-between items-center py-1">
                <span className="text-slate-500 font-bold">Timestamp</span>
                <span className="text-slate-800 font-bold">{new Date().toLocaleString('en-IN')}</span>
              </div>
            </div>

            {/* Actions */}
            <div className="grid grid-cols-2 gap-3 pt-2">
              <button
                onClick={() =>
                  speakSoundboxTransactionAlert({
                    type: 'DEBIT',
                    amount: completedTx.amount,
                    recipientName: completedTx.title,
                    language: user.soundboxLanguage || language,
                  })
                }
                className="py-2.5 px-3 rounded-xl bg-amber-50 hover:bg-amber-100 border border-amber-300 text-amber-900 font-black uppercase tracking-wider text-xs flex items-center justify-center gap-1.5 transition active:scale-95 shadow-2xs"
              >
                <Volume2 className="w-4 h-4 text-amber-700" />
                <span>Voice Alert</span>
              </button>

              <button
                onClick={() => {
                  navigator.clipboard?.writeText(
                    `Axis Bank CC VIP: Transfer of ₹${completedTx.amount} to ${completedTx.title} (Status: ${completedTx.status}, Ref: ${completedTx.upiRefId})`
                  );
                  alert('Receipt summary copied to clipboard!');
                }}
                className={`py-2.5 px-3 rounded-xl bg-slate-100 hover:bg-slate-200 border border-slate-200 text-slate-800 font-black uppercase tracking-wider text-xs flex items-center justify-center gap-1.5 transition active:scale-95 shadow-2xs ${
                  completedTx.status !== 'SUCCESS' ? 'col-span-2' : ''
                }`}
              >
                <Share2 className="w-4 h-4 text-[#861F41]" />
                <span>Share Details</span>
              </button>
            </div>

            <button
              onClick={handleReset}
              className="w-full py-3 rounded-xl bg-[#861F41] hover:bg-[#580824] text-white font-black uppercase tracking-wider text-xs shadow-md transition active:scale-98"
            >
              Done / Return to Home
            </button>
          </div>
        ) : (
          /* Payment Preparation Form */
          <div className="flex-1 overflow-y-auto p-4 sm:p-5 space-y-4">
            {/* Mode Tabs */}
            <div className="grid grid-cols-4 gap-1 bg-slate-100 p-1 rounded-xl border border-slate-200 text-xs font-bold">
              <button
                onClick={() => setActiveTab('qr')}
                className={`py-2 rounded-lg flex flex-col sm:flex-row items-center justify-center gap-1 transition uppercase tracking-wider text-[11px] ${
                  activeTab === 'qr'
                    ? 'bg-[#861F41] text-amber-300 shadow font-black'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                <QrCode className="w-3.5 h-3.5" />
                <span>Scan QR</span>
              </button>
              <button
                onClick={() => setActiveTab('contact')}
                className={`py-2 rounded-lg flex flex-col sm:flex-row items-center justify-center gap-1 transition uppercase tracking-wider text-[11px] ${
                  activeTab === 'contact'
                    ? 'bg-[#861F41] text-amber-300 shadow font-black'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                <Smartphone className="w-3.5 h-3.5" />
                <span>Mobile</span>
              </button>
              <button
                onClick={() => setActiveTab('upi')}
                className={`py-2 rounded-lg flex flex-col sm:flex-row items-center justify-center gap-1 transition uppercase tracking-wider text-[11px] ${
                  activeTab === 'upi'
                    ? 'bg-[#861F41] text-amber-300 shadow font-black'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                <AtSign className="w-3.5 h-3.5" />
                <span>UPI ID</span>
              </button>
              <button
                onClick={() => setActiveTab('bank')}
                className={`py-2 rounded-lg flex flex-col sm:flex-row items-center justify-center gap-1 transition uppercase tracking-wider text-[11px] ${
                  activeTab === 'bank'
                    ? 'bg-[#861F41] text-amber-300 shadow font-black'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                <Landmark className="w-3.5 h-3.5" />
                <span>Bank / IFSC</span>
              </button>
            </div>

            {/* TAB 1: QR SCANNER */}
            {activeTab === 'qr' && (
              <div className="space-y-3">
                {/* Hidden processing canvas for jsQR analysis */}
                <canvas ref={canvasRef} className="hidden" />

                {qrScanning ? (
                  <div className="bg-slate-950 rounded-2xl p-4 border border-slate-800 text-center relative overflow-hidden shadow-xl">
                    {/* Viewfinder Frame */}
                    <div className="relative w-full max-w-[280px] h-64 mx-auto rounded-2xl border-2 border-emerald-400/80 bg-black flex flex-col items-center justify-center overflow-hidden shadow-[0_0_20px_rgba(16,185,129,0.15)]">
                      {/* Video Stream Element */}
                      <video
                        ref={videoRef}
                        autoPlay
                        playsInline
                        muted
                        className={`w-full h-full object-cover transition-opacity duration-300 ${
                          isCameraActive ? 'opacity-100' : 'opacity-0'
                        }`}
                      />

                      {/* Laser sweep animation across camera frame */}
                      {isCameraActive && (
                        <div className="absolute inset-x-0 top-0 h-1 bg-gradient-to-r from-transparent via-emerald-400 to-transparent animate-bounce shadow-[0_0_14px_#10b981] pointer-events-none" />
                      )}

                      {/* Corner Target Markers */}
                      <div className="absolute top-2 left-2 w-5 h-5 border-t-2 border-l-2 border-emerald-400 pointer-events-none" />
                      <div className="absolute top-2 right-2 w-5 h-5 border-t-2 border-r-2 border-emerald-400 pointer-events-none" />
                      <div className="absolute bottom-2 left-2 w-5 h-5 border-b-2 border-l-2 border-emerald-400 pointer-events-none" />
                      <div className="absolute bottom-2 right-2 w-5 h-5 border-b-2 border-r-2 border-emerald-400 pointer-events-none" />

                      {/* Placeholder / Error / Permission state */}
                      {!isCameraActive && (
                        <div className="absolute inset-0 flex flex-col items-center justify-center p-4 text-center bg-slate-900/90 z-10">
                          {cameraError ? (
                            <>
                              <Camera className="w-10 h-10 text-amber-400 mb-2" />
                              <p className="text-[11px] text-amber-200 font-bold leading-tight mb-2">
                                {cameraError}
                              </p>
                              <button
                                type="button"
                                onClick={startCamera}
                                className="px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold flex items-center gap-1 transition"
                              >
                                <RefreshCw className="w-3 h-3" />
                                <span>Retry Camera</span>
                              </button>
                            </>
                          ) : (
                            <>
                              <div className="w-8 h-8 border-2 border-emerald-400 border-t-transparent rounded-full animate-spin mb-2" />
                              <p className="text-[11px] text-emerald-300 font-bold uppercase tracking-wider">
                                Initializing Camera...
                              </p>
                            </>
                          )}
                        </div>
                      )}

                      <div className="absolute bottom-2 inset-x-2 bg-black/60 backdrop-blur-xs py-1 px-2 rounded-lg text-center pointer-events-none">
                        <p className="text-[10px] text-emerald-300 font-black uppercase tracking-wider">
                          {isCameraActive ? 'Scanning: Center QR Code in Frame' : 'Camera Ready'}
                        </p>
                      </div>
                    </div>

                    {/* Controls below viewfinder */}
                    <div className="mt-3 flex flex-wrap items-center justify-center gap-2">
                      <label className="inline-flex items-center gap-1.5 px-3 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold cursor-pointer transition active:scale-95">
                        <Upload className="w-3.5 h-3.5 text-amber-400" />
                        <span>Upload QR from Gallery</span>
                        <input
                          type="file"
                          accept="image/*"
                          className="hidden"
                          onChange={handleQrFileUpload}
                        />
                      </label>

                      <button
                        type="button"
                        onClick={startCamera}
                        className="inline-flex items-center gap-1 px-3 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold transition active:scale-95"
                      >
                        <RefreshCw className="w-3.5 h-3.5 text-emerald-400" />
                        <span>Refresh Cam</span>
                      </button>

                      <button
                        type="button"
                        onClick={() => {
                          const customVpa = prompt('Enter recipient UPI ID (e.g., store@axisbank):');
                          if (customVpa && customVpa.trim()) {
                            handleQrDecoded(customVpa.trim());
                          }
                        }}
                        className="px-3 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold transition active:scale-95"
                      >
                        Enter UPI ID
                      </button>
                    </div>

                    {/* Quick Demo: Pick any other account in the bank to test QR flow */}
                    {allUsers.filter((u) => u.id !== user.id).length > 0 && (
                      <div className="mt-3 pt-3 border-t border-slate-800 text-left">
                        <p className="text-[10px] font-black uppercase tracking-wider text-slate-400 mb-1.5 flex items-center justify-between">
                          <span>Or Test Quick Send to Registered User QR:</span>
                          <span className="text-amber-400 text-[9px] font-bold">1-Click Scan</span>
                        </p>
                        <div className="flex gap-2 overflow-x-auto pb-1 scrollbar-none">
                          {allUsers
                            .filter((u) => u.id !== user.id)
                            .slice(0, 4)
                            .map((otherUser) => (
                              <button
                                key={otherUser.id}
                                type="button"
                                onClick={() => {
                                  handleQrDecoded(
                                    `upi://pay?pa=${otherUser.upiId}&pn=${encodeURIComponent(
                                      otherUser.name
                                    )}&cu=INR`
                                  );
                                }}
                                className="flex-shrink-0 bg-slate-800/80 hover:bg-slate-750 border border-slate-700 rounded-xl px-2.5 py-1.5 text-left transition active:scale-95"
                              >
                                <p className="text-xs font-bold text-white truncate max-w-[120px]">
                                  {otherUser.name}
                                </p>
                                <p className="text-[10px] font-mono text-amber-300 truncate max-w-[120px]">
                                  {otherUser.upiId}
                                </p>
                              </button>
                            ))}
                        </div>
                      </div>
                    )}
                  </div>
                ) : (
                  <div className="p-3.5 bg-emerald-50/80 rounded-2xl border border-emerald-300 flex items-center justify-between animate-in zoom-in-95">
                    <div className="flex items-center gap-2.5">
                      <div className="w-8 h-8 rounded-xl bg-emerald-600 text-white flex items-center justify-center font-black">
                        <CheckCircle2 className="w-5 h-5" />
                      </div>
                      <div>
                        <p className="text-[10px] font-black uppercase tracking-wider text-emerald-800">
                          Active QR Verified
                        </p>
                        <p className="font-black text-slate-900 text-sm">{recipientName}</p>
                        <p className="text-[11px] text-slate-600 font-mono">{recipientVpa}</p>
                      </div>
                    </div>
                    <button
                      type="button"
                      onClick={() => {
                        setQrScanning(true);
                      }}
                      className="px-3 py-1.5 rounded-xl bg-[#861F41] hover:bg-[#580824] text-white text-xs font-black uppercase tracking-wider transition active:scale-95 shadow-xs"
                    >
                      Scan Another
                    </button>
                  </div>
                )}
              </div>
            )}

            {/* TAB 2: PAY CONTACTS / MOBILE */}
            {activeTab === 'contact' && (
              <div className="space-y-3">
                <div className="relative">
                  <Search className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
                  <input
                    type="text"
                    placeholder="Search name, mobile number, or UPI ID..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl pl-9 pr-3 py-2.5 text-xs text-slate-900 placeholder-slate-400 font-bold focus:outline-none focus:border-[#861F41]"
                  />
                </div>

                <div className="space-y-1.5 max-h-48 overflow-y-auto pr-1">
                  {filteredContacts.map((contact) => (
                    <button
                      key={contact.id}
                      onClick={() => handleSelectContact(contact)}
                      className={`w-full p-2.5 rounded-xl border flex items-center justify-between text-left transition ${
                        recipientVpa === contact.upiId
                          ? 'bg-blue-50 border-[#861F41]'
                          : 'bg-slate-50 hover:bg-slate-100 border-slate-200'
                      }`}
                    >
                      <div className="flex items-center gap-2.5">
                        <div
                          className={`w-9 h-9 rounded-xl ${contact.avatarBg} text-white font-black text-xs flex items-center justify-center`}
                        >
                          {contact.name.charAt(0)}
                        </div>
                        <div>
                          <p className="font-black text-xs text-slate-900">
                            {contact.name}
                          </p>
                          <p className="text-[11px] text-slate-500 font-mono font-bold">
                            {contact.phone} • {contact.upiId}
                          </p>
                        </div>
                      </div>
                      <ArrowRight className="w-4 h-4 text-slate-400" />
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* TAB 3: PAY UPI ID */}
            {activeTab === 'upi' && (
              <div className="space-y-3">
                <div>
                  <label className="text-xs font-black text-slate-700 uppercase tracking-wider block mb-1">
                    Enter Recipient UPI ID / VPA
                  </label>
                  <input
                    type="text"
                    placeholder="e.g. corp@axisbank or vendor@okhdfcbank"
                    value={recipientVpa}
                    onChange={(e) => {
                      setRecipientVpa(e.target.value);
                      setRecipientName(e.target.value.split('@')[0]);
                    }}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2.5 text-xs text-slate-900 placeholder-slate-400 font-bold focus:outline-none focus:border-[#861F41] font-mono"
                  />
                </div>
                <div className="flex gap-2 text-[11px]">
                  {['@axisbank', '@okhdfcbank', '@oksbi', '@paytm'].map((handle) => (
                    <button
                      key={handle}
                      onClick={() => {
                        const base = recipientVpa.split('@')[0] || 'vendor';
                        setRecipientVpa(base + handle);
                        setRecipientName(base);
                      }}
                      className="bg-slate-100 px-2.5 py-1 rounded-lg border border-slate-200 text-slate-700 hover:text-slate-900 font-bold"
                    >
                      {handle}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* TAB 4: BANK TRANSFER + IFSC */}
            {activeTab === 'bank' && (
              <div className="space-y-2.5">
                <div>
                  <label className="text-xs font-black text-slate-700 uppercase tracking-wider block mb-1">
                    Account Holder Name
                  </label>
                  <input
                    type="text"
                    placeholder="Enter Beneficiary Full Name"
                    value={recipientName}
                    onChange={(e) => setRecipientName(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-900 placeholder-slate-400 font-bold focus:outline-none focus:border-[#861F41]"
                  />
                </div>
                <div>
                  <label className="text-xs font-black text-slate-700 uppercase tracking-wider block mb-1">
                    Bank Account Number
                  </label>
                  <input
                    type="password"
                    placeholder="Enter Bank Account Number"
                    value={bankAccount}
                    onChange={(e) => setBankAccount(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-900 placeholder-slate-400 font-bold focus:outline-none focus:border-[#861F41] font-mono"
                  />
                </div>
                <div>
                  <label className="text-xs font-black text-slate-700 uppercase tracking-wider block mb-1">
                    IFSC Code
                  </label>
                  <input
                    type="text"
                    placeholder="e.g. UTIB000001 / SBIN0001234"
                    value={ifsc}
                    onChange={(e) => setIfsc(e.target.value.toUpperCase())}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-900 uppercase placeholder-slate-400 font-bold focus:outline-none focus:border-[#861F41] font-mono"
                  />
                </div>
              </div>
            )}

            {/* TAB 5: BILL PAYMENT */}
            {activeTab === 'bill' && (
              <div className="p-3 bg-blue-50 rounded-xl border border-blue-200 space-y-1">
                <p className="text-xs font-black text-[#861F41] uppercase tracking-wider">
                  Paying for {recipientName || 'Biller / Utility'}
                </p>
                <p className="text-[11px] text-slate-600 font-bold">
                  Bharat Bill Payment System (BBPS) Direct Settlement
                </p>
              </div>
            )}

            {/* Recipient summary pill if chosen */}
            {recipientName && (
              <div className="p-2.5 rounded-xl bg-slate-50 border border-slate-200 flex items-center justify-between text-xs shadow-2xs">
                <div>
                  <span className="text-slate-500 font-bold">Beneficiary: </span>
                  <span className="font-black text-slate-900">{recipientName}</span>
                </div>
                {recipientVpa && (
                  <span className="font-mono font-black text-[#861F41] text-[11px]">
                    {recipientVpa}
                  </span>
                )}
              </div>
            )}

            {/* Amount Input */}
            <div>
              <label className="text-xs font-black text-slate-700 uppercase tracking-wider block mb-1">
                Enter Amount (रुपये दर्ज करें)
              </label>
              <div className="relative">
                <span className="absolute left-3.5 top-2.5 text-2xl font-black text-[#861F41] font-sans">
                  ₹
                </span>
                <input
                  type="number"
                  value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                  placeholder="0.00"
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl pl-10 pr-4 py-3 text-2xl font-black text-slate-900 font-sans placeholder-slate-300 focus:outline-none focus:border-[#861F41]"
                />
              </div>

              {/* Quick Amount Chips */}
              <div className="flex gap-2 mt-2">
                {['100', '500', '1000', '2000', '5000'].map((val) => (
                  <button
                    key={val}
                    onClick={() => setAmount(val)}
                    className="flex-1 py-1 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 hover:text-slate-900 border border-slate-200 text-xs font-black uppercase"
                  >
                    +₹{val}
                  </button>
                ))}
              </div>
            </div>

            {/* Note Remark */}
            <div>
              <input
                type="text"
                placeholder="Add remark / note (e.g. Corporate Vendor, Supplies, Lease)"
                value={note}
                onChange={(e) => setNote(e.target.value)}
                className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-900 placeholder-slate-400 font-bold focus:outline-none focus:border-[#861F41]"
              />
            </div>

            {/* Payment Source Selection */}
            <div>
              <label className="text-xs font-black text-slate-700 uppercase tracking-wider block mb-1.5">
                Debiting from (खाता चुनें)
              </label>
              <div className="space-y-2">
                {/* Savings A/c */}
                <label className="flex items-center justify-between p-3 rounded-xl bg-slate-50 border border-slate-200 cursor-pointer hover:border-[#861F41]/40 shadow-2xs">
                  <div className="flex items-center gap-2.5">
                    <input
                      type="radio"
                      name="paymentMode"
                      value="SAVINGS_AC"
                      checked={paymentMode === 'SAVINGS_AC'}
                      onChange={() => setPaymentMode('SAVINGS_AC')}
                      className="text-[#861F41] focus:ring-[#861F41]"
                    />
                    <div>
                      <p className="text-xs font-black text-slate-900">
                        Axis Bank CC VIP Corporate Account (•••• {user.accountNumber.slice(-4)})
                      </p>
                      <p className="text-[11px] text-slate-500 font-bold">
                        Available: ₹{user.savingsBalance.toLocaleString('en-IN')}
                      </p>
                    </div>
                  </div>
                  <span className="text-[10px] bg-blue-100 text-[#861F41] font-black uppercase tracking-wider px-2 py-0.5 rounded-full">
                    Recommended
                  </span>
                </label>

                {/* Airtel Wallet */}
                <label className="flex items-center justify-between p-3 rounded-xl bg-slate-50 border border-slate-200 cursor-pointer hover:border-[#861F41]/40 shadow-2xs">
                  <div className="flex items-center gap-2.5">
                    <input
                      type="radio"
                      name="paymentMode"
                      value="WALLET"
                      checked={paymentMode === 'WALLET'}
                      onChange={() => setPaymentMode('WALLET')}
                      className="text-[#861F41] focus:ring-[#861F41]"
                    />
                    <div>
                      <p className="text-xs font-black text-slate-900">
                        Axis Bank CC VIP Corporate Wallet
                      </p>
                      <p className="text-[11px] text-slate-500 font-bold">
                        Available: ₹{user.walletBalance.toLocaleString('en-IN')}
                      </p>
                    </div>
                  </div>
                  <span className="text-[10px] text-slate-500 font-black uppercase tracking-wider">
                    Instant Pay
                  </span>
                </label>

                {/* UPI Lite */}
                {parseFloat(amount) <= 500 && (
                  <label className="flex items-center justify-between p-3 rounded-xl bg-slate-50 border border-emerald-300 cursor-pointer hover:border-emerald-500 shadow-2xs">
                    <div className="flex items-center gap-2.5">
                      <input
                        type="radio"
                        name="paymentMode"
                        value="UPI_LITE"
                        checked={paymentMode === 'UPI_LITE'}
                        onChange={() => setPaymentMode('UPI_LITE')}
                        className="text-emerald-600 focus:ring-emerald-500"
                      />
                      <div>
                        <p className="text-xs font-black text-emerald-800 flex items-center gap-1">
                          <Zap className="w-3 h-3 text-emerald-600 fill-emerald-600" />
                          UPI Lite (Zero PIN / Lightning Fast)
                        </p>
                        <p className="text-[11px] text-slate-500 font-bold">
                          Available: ₹{user.upiLiteBalance.toFixed(2)}
                        </p>
                      </div>
                    </div>
                    <span className="text-[10px] bg-emerald-100 text-emerald-800 font-black uppercase tracking-wider px-2 py-0.5 rounded-full">
                      No PIN Needed
                    </span>
                  </label>
                )}
              </div>
            </div>

            {/* Pay Button */}
            <button
              onClick={handleInitiatePayment}
              className="w-full py-3.5 rounded-xl bg-gradient-to-r from-[#580824] via-[#861F41] to-[#700a2f] hover:from-[#051424] hover:to-[#861F41] text-amber-300 font-black uppercase tracking-wider text-xs shadow-md shadow-blue-950/20 transition active:scale-98 flex items-center justify-center gap-2 border border-amber-400/30"
            >
              <span>
                Proceed to Pay ₹{parseFloat(amount || '0').toLocaleString('en-IN')}
              </span>
              <ArrowRight className="w-4 h-4 text-amber-300" />
            </button>
          </div>
        )}
      </div>

      {/* UPI PIN Modal */}
      {showPinModal && (
        <UPIPinModal
          amount={parseFloat(amount)}
          recipientTitle={recipientName || recipientVpa || 'Beneficiary'}
          recipientVpa={recipientVpa}
          language={language}
          paymentMode={paymentMode}
          biometricAvailable={user.biometricEnabled}
          expectedPin={user.mpin || '1234'}
          onSuccess={finalizeTransaction}
          onCancel={() => setShowPinModal(false)}
        />
      )}
    </div>
  );
};
