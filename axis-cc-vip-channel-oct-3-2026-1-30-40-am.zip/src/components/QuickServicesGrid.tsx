import React from 'react';
import {
  Smartphone,
  Zap,
  Car,
  Tv,
  Flame,
  Droplets,
  Coins,
  Landmark,
  Briefcase,
  CreditCard,
  Building,
  ShieldCheck,
  SlidersHorizontal,
} from 'lucide-react';
import { LanguageCode } from '../types';
import { TRANSLATIONS } from '../i18n/translations';

interface QuickServicesGridProps {
  language: LanguageCode;
  onSelectService: (serviceName: string) => void;
  onOpenScanQr: () => void;
  onOpenSendMoney: () => void;
  onOpenBusinessLoan?: () => void;
  onOpenVirtualCards?: () => void;
  onOpenServices?: () => void;
}

export const QuickServicesGrid: React.FC<QuickServicesGridProps> = ({
  language,
  onSelectService,
  onOpenScanQr,
  onOpenSendMoney,
  onOpenBusinessLoan,
  onOpenVirtualCards,
  onOpenServices,
}) => {
  const t = TRANSLATIONS[language] || TRANSLATIONS.en;

  const services = [
    {
      id: 'biz_loan',
      title: 'Business Loan',
      icon: Briefcase,
      color: 'text-[#861F41] bg-rose-50 border-rose-200/80',
      badge: 'Pre-Approved',
      onClick: () => {
        if (onOpenBusinessLoan) {
          onOpenBusinessLoan();
        } else {
          onSelectService('Business Loan');
        }
      },
    },
    {
      id: 'virtual_cards',
      title: 'Virtual Debit Cards',
      icon: CreditCard,
      color: 'text-[#861F41] bg-rose-50 border-rose-200/80',
      badge: '4 Tiers',
      onClick: () => {
        if (onOpenVirtualCards) {
          onOpenVirtualCards();
        } else {
          onSelectService('Virtual Debit Cards');
        }
      },
    },
    {
      id: 'banking_services',
      title: 'Manage Services',
      icon: SlidersHorizontal,
      color: 'text-purple-700 bg-purple-50 border-purple-200/80',
      badge: 'UPI & Updates',
      onClick: () => {
        if (onOpenServices) {
          onOpenServices();
        } else {
          onSelectService('Banking Services & Info Updates');
        }
      },
    },
    {
      id: 'recharge',
      title: t.rechargeMobile,
      icon: Smartphone,
      color: 'text-slate-800 bg-slate-50 border-slate-200',
      badge: 'Cashback',
      onClick: () => onSelectService('Mobile Recharge'),
    },
    {
      id: 'electricity',
      title: t.electricity,
      icon: Zap,
      color: 'text-amber-600 bg-amber-50 border-amber-200/80',
      badge: 'BBPS',
      onClick: () => onSelectService('Electricity Bill'),
    },
    {
      id: 'fastag',
      title: t.fastag,
      icon: Car,
      color: 'text-blue-600 bg-blue-50 border-blue-200/80',
      badge: 'NETC',
      onClick: () => onSelectService('FASTag Recharge'),
    },
    {
      id: 'fd',
      title: t.fixedDeposit,
      icon: Landmark,
      color: 'text-emerald-700 bg-emerald-50 border-emerald-200/80',
      badge: '7.5% p.a.',
      onClick: () => onSelectService('Fixed Deposit (7.5% p.a.)'),
    },
    {
      id: 'gold',
      title: t.goldSavings,
      icon: Coins,
      color: 'text-yellow-600 bg-yellow-50 border-yellow-200/80',
      badge: '24K Gold',
      onClick: () => onSelectService('Digital Gold (24K)'),
    },
  ];

  return (
    <div className="bg-white rounded-3xl p-4 sm:p-5 border border-slate-200 text-slate-900 shadow-sm">
      <div className="flex items-center justify-between mb-3.5 pb-2 border-b border-slate-100">
        <h2 className="text-sm font-black text-slate-900 flex items-center gap-2 uppercase tracking-wider">
          <span className="w-2.5 h-2.5 rounded-full bg-[#861F41]" />
          Axis Services & Commercial Finance
        </h2>
        <span className="text-[10px] font-black uppercase tracking-widest text-[#861F41] font-mono">
          IFSC: UTIB000001
        </span>
      </div>

      <div className="grid grid-cols-4 gap-2.5 sm:gap-3">
        {services.map((item) => {
          const Icon = item.icon;
          return (
            <button
              key={item.id}
              onClick={item.onClick}
              className="flex flex-col items-center justify-start p-2.5 rounded-2xl bg-slate-50 hover:bg-slate-100/90 border border-slate-200/80 transition-all text-center active:scale-95 group relative shadow-2xs"
            >
              {item.badge && (
                <span className="absolute -top-1.5 -right-1 bg-[#861F41] text-amber-300 text-[9px] font-black px-1.5 py-0.2 rounded-full shadow-xs tracking-tight scale-90 uppercase border border-amber-400/30">
                  {item.badge}
                </span>
              )}
              <div
                className={`w-11 h-11 rounded-xl flex items-center justify-center mb-1.5 border transition-transform group-hover:scale-110 shadow-xs ${item.color}`}
              >
                <Icon className="w-5 h-5" />
              </div>
              <span className="text-[11px] font-bold text-slate-800 leading-tight line-clamp-2 w-full">
                {item.title}
              </span>
            </button>
          );
        })}
      </div>
    </div>
  );
};
