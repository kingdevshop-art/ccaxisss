import React, { useState } from 'react';
import { usePWAInstall } from '../hooks/usePWAInstall';
import { Smartphone, Download, CheckCircle, X, ShieldCheck, QrCode, ArrowDown, Play } from 'lucide-react';

interface PWAInstallButtonProps {
  variant?: 'header' | 'banner' | 'card' | 'minimal';
  onOpenAndroidGuide?: () => void;
}

export const PWAInstallButton: React.FC<PWAInstallButtonProps> = ({
  variant = 'header',
  onOpenAndroidGuide,
}) => {
  const { isInstallable, isInstalled, isIOS, isAndroid, install } = usePWAInstall();
  const [showModal, setShowModal] = useState(false);
  const [installing, setInstalling] = useState(false);

  // If already installed and running standalone, hide the prompt or show verified badge
  if (isInstalled) {
    if (variant === 'minimal') return null;
    return (
      <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-emerald-500/20 text-emerald-300 text-[10px] font-bold border border-emerald-400/30">
        <CheckCircle className="w-3 h-3 text-emerald-400" />
        <span>App Installed</span>
      </div>
    );
  }

  const handleInstallClick = async () => {
    if (isInstallable) {
      setInstalling(true);
      try {
        await install();
      } finally {
        setInstalling(false);
      }
    } else {
      setShowModal(true);
    }
  };

  return (
    <>
      {variant === 'header' && (
        <button
          onClick={handleInstallClick}
          className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl bg-amber-400 hover:bg-amber-300 text-slate-950 text-xs font-black uppercase tracking-wider transition shadow-sm active:scale-95 flex-shrink-0"
          title="Install Axis Bank CC VIP Mobile App"
        >
          <Smartphone className="w-3.5 h-3.5 text-slate-950" />
          <span className="hidden sm:inline">Install Axis App</span>
          <span className="sm:hidden">Install</span>
        </button>
      )}

      {variant === 'banner' && (
        <div className="bg-gradient-to-r from-[#4E061E] via-[#861F41] to-[#97144D] border border-amber-400/30 text-white p-3.5 rounded-2xl flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 shadow-md">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-amber-400/20 border border-amber-400/40 flex items-center justify-center text-amber-300 flex-shrink-0">
              <Smartphone className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xs font-black uppercase tracking-wider text-amber-300">
                  Axis Bank CC VIP Mobile App
                </span>
                <span className="px-1.5 py-0.5 rounded bg-emerald-500/20 text-emerald-300 text-[9px] font-bold">
                  v2.4 VIP Edition
                </span>
              </div>
              <p className="text-xs text-slate-200 mt-0.5">
                Install as a full native PWA app with biometric authentication, instant UPI, and offline passbook.
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2 w-full sm:w-auto">
            <button
              onClick={handleInstallClick}
              disabled={installing}
              className="flex-1 sm:flex-initial px-4 py-2 rounded-xl bg-amber-400 hover:bg-amber-300 text-slate-950 text-xs font-black uppercase tracking-wider transition shadow-sm flex items-center justify-center gap-1.5 active:scale-95"
            >
              <Download className="w-3.5 h-3.5" />
              <span>{installing ? 'Installing...' : 'Install Now'}</span>
            </button>
            {onOpenAndroidGuide && (
              <button
                onClick={onOpenAndroidGuide}
                className="px-3.5 py-2 rounded-xl bg-white/10 hover:bg-white/20 text-amber-300 hover:text-amber-200 text-xs font-bold transition flex items-center gap-1.5 border border-amber-400/30 active:scale-95"
                title="Watch Animated Android Studio Video Guide & Native Build Steps"
              >
                <Play className="w-3.5 h-3.5 fill-amber-300" />
                <span>Video Guide & APK</span>
              </button>
            )}
          </div>
        </div>
      )}

      {/* Guide & Installation Modal for Non-Chromium or iOS */}
      {showModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/70 backdrop-blur-xs p-4 animate-in fade-in">
          <div className="w-full max-w-md bg-white rounded-3xl p-6 shadow-2xl border border-slate-200 text-slate-900 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-xl bg-[#861F41] text-amber-300 flex items-center justify-center">
                  <Smartphone className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-sm font-black text-[#861F41] uppercase tracking-wide">
                    Install Axis Bank CC VIP App
                  </h3>
                  <p className="text-[11px] text-slate-500 font-bold">Official Axis Bank Mobile VIP Banking Application</p>
                </div>
              </div>
              <button
                onClick={() => setShowModal(false)}
                className="w-8 h-8 rounded-full hover:bg-slate-100 flex items-center justify-center text-slate-400 hover:text-slate-700 transition"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {isIOS ? (
              <div className="space-y-3">
                <p className="text-xs text-slate-600 leading-relaxed">
                  To install Axis Bank CC VIP on your iPhone or iPad:
                </p>
                <ol className="space-y-2 text-xs text-slate-700 font-medium bg-slate-50 p-3.5 rounded-2xl border border-slate-200">
                  <li className="flex items-start gap-2">
                    <span className="w-5 h-5 rounded-full bg-[#861F41] text-amber-300 flex items-center justify-center text-[10px] font-bold flex-shrink-0">
                      1
                    </span>
                    <span>
                      Tap the <strong>Share</strong> button at the bottom of Safari (square icon with arrow pointing up).
                    </span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="w-5 h-5 rounded-full bg-[#861F41] text-amber-300 flex items-center justify-center text-[10px] font-bold flex-shrink-0">
                      2
                    </span>
                    <span>
                      Scroll down and select <strong>Add to Home Screen</strong>.
                    </span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="w-5 h-5 rounded-full bg-[#861F41] text-amber-300 flex items-center justify-center text-[10px] font-bold flex-shrink-0">
                      3
                    </span>
                    <span>
                      Tap <strong>Add</strong> in the top-right corner to launch directly from your home screen.
                    </span>
                  </li>
                </ol>
              </div>
            ) : (
              <div className="space-y-3">
                <div className="bg-rose-50 border border-rose-200 p-3.5 rounded-2xl space-y-2">
                  <div className="flex items-center gap-2 text-[#861F41] font-black text-xs uppercase">
                    <ShieldCheck className="w-4 h-4 text-[#861F41]" />
                    <span>Android / Chromium Installation</span>
                  </div>
                  <p className="text-xs text-rose-950 leading-relaxed">
                    1. Tap the browser menu (three dots <strong>⋮</strong> in top right).<br />
                    2. Select <strong>"Install app"</strong> or <strong>"Add to Home screen"</strong>.<br />
                    3. The app will install as an official Android WebAPK with full offline banking, biometric login, and hardware acceleration.
                  </p>
                </div>

                <div className="bg-slate-50 p-3 rounded-xl border border-slate-200 text-[11px] text-slate-600 flex items-center gap-2">
                  <CheckCircle className="w-4 h-4 text-emerald-600 flex-shrink-0" />
                  <span>Native Android Studio source code is also included in the <code className="bg-slate-200 px-1 py-0.5 rounded font-mono text-[10px]">/android</code> folder.</span>
                </div>
              </div>
            )}

            <div className="pt-2 flex justify-end gap-2">
              <button
                onClick={() => setShowModal(false)}
                className="w-full py-2.5 rounded-xl bg-[#861F41] text-amber-300 hover:bg-[#6e1834] text-xs font-black uppercase tracking-wider transition"
              >
                Got It
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
};
