import React, { useState } from 'react';
import {
  Settings,
  ShieldCheck,
  Smartphone,
  Mail,
  MapPin,
  FileText,
  Sliders,
  Check,
  AlertCircle,
  X,
  Volume2,
  Fingerprint,
  Globe,
  CreditCard,
  Building2,
  Clock,
  Send,
  Zap,
  Sparkles,
} from 'lucide-react';
import { UserProfile, ProfileUpdateRequest, UpiHandleDomain } from '../types';
import { emailService } from '../services/emailService';
import { smsService } from '../services/smsService';
import { dbService } from '../services/dbService';

interface ServicesAndUpdateModalProps {
  user: UserProfile;
  isOpen: boolean;
  onClose: () => void;
  onUpdateUser: (updatedUser: UserProfile) => void;
}

export const ServicesAndUpdateModal: React.FC<ServicesAndUpdateModalProps> = ({
  user,
  isOpen,
  onClose,
  onUpdateUser,
}) => {
  if (!isOpen) return null;

  const [activeTab, setActiveTab] = useState<'SERVICES' | 'REQUEST_UPDATE' | 'MY_REQUESTS'>('SERVICES');

  // Services States
  const [upiEnabled, setUpiEnabled] = useState(user.services?.upiEnabled ?? true);
  const [upiLiteEnabled, setUpiLiteEnabled] = useState(user.services?.upiLiteEnabled ?? true);
  const [soundboxEnabled, setSoundboxEnabled] = useState(user.services?.soundboxEnabled ?? true);
  const [biometricsEnabled, setBiometricsEnabled] = useState(user.services?.biometricsEnabled ?? true);
  const [intlEnabled, setIntlEnabled] = useState(user.services?.internationalTxEnabled ?? false);
  const [activeUpiHandle, setActiveUpiHandle] = useState<UpiHandleDomain>(user.activeUpiHandle || '@axisbank');

  // Cheque Book Request State
  const [chequeLeaves, setChequeLeaves] = useState<'25' | '50'>('25');
  const [isChequeRequested, setIsChequeRequested] = useState(false);

  // Profile Update Request States
  const [updateType, setUpdateType] = useState<'PHONE' | 'EMAIL' | 'ADDRESS' | 'LIMIT' | 'SERVICES'>('PHONE');
  const [newPhone, setNewPhone] = useState('');
  const [newEmail, setNewEmail] = useState('');
  const [newAddress, setNewAddress] = useState('');
  const [requestedLimit, setRequestedLimit] = useState('1000000');
  const [updateReason, setUpdateReason] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Status feedback
  const [successMessage, setSuccessMessage] = useState('');
  const [errorMessage, setErrorMessage] = useState('');

  // Handle Services Save
  const handleSaveServices = async () => {
    const updatedServices = {
      ...user.services,
      upiEnabled,
      upiLiteEnabled,
      soundboxEnabled,
      biometricsEnabled,
      internationalTxEnabled: intlEnabled,
      walletEnabled: true,
      termDepositEnabled: true,
      kccLoanEnabled: user.services?.kccLoanEnabled ?? false,
      businessLoanEnabled: true,
      smsAlertsEnabled: true,
    };

    // Calculate new UPI ID based on selected handle
    const username = (user.name || 'user').toLowerCase().replace(/[^a-z0-9]/g, '');
    const newUpiId = `${username}${activeUpiHandle}`;

    const updatedUser: UserProfile = {
      ...user,
      services: updatedServices,
      activeUpiHandle,
      upiId: newUpiId,
    };

    onUpdateUser(updatedUser);
    await dbService.updateUser(user.id, {
      services: updatedServices,
      activeUpiHandle,
      upiId: newUpiId,
    });

    setSuccessMessage('Axis VIP Banking Services updated successfully.');
    setTimeout(() => setSuccessMessage(''), 3000);
  };

  // Handle Cheque Book Request
  const handleRequestChequeBook = () => {
    setIsChequeRequested(true);
    const trackingNo = `CHQ${Math.floor(10000000 + Math.random() * 90000000)}`;

    // Add to requests
    const newReq: ProfileUpdateRequest = {
      id: `req_chq_${Date.now()}`,
      userId: user.id,
      userPhone: user.phone,
      userName: user.name,
      type: 'SERVICES',
      title: `Personalized Cheque Book (${chequeLeaves} Leaves)`,
      details: `Dispatched to registered address. Tracking No: ${trackingNo}. Deliverable within 3 banking days.`,
      requestedChanges: { chequeLeaves, trackingNo },
      status: 'APPROVED',
      submittedAt: new Date().toLocaleDateString('en-IN', {
        day: 'numeric',
        month: 'short',
        year: 'numeric',
      }),
    };

    const currentRequests = user.updateRequests || [];
    const updatedUser: UserProfile = {
      ...user,
      updateRequests: [newReq, ...currentRequests],
    };

    onUpdateUser(updatedUser);
    dbService.updateUser(user.id, { updateRequests: updatedUser.updateRequests });

    emailService.sendServiceUpdateEmail(
      user,
      `Cheque Book Requisition Approved (${chequeLeaves} Leaves)`,
      `Your CTS-2010 compliant personalized cheque book order (${trackingNo}) has been dispatched to your registered address.`
    ).catch(console.warn);

    setSuccessMessage(`Cheque Book Requisition ${trackingNo} dispatched!`);
    setTimeout(() => {
      setSuccessMessage('');
      setIsChequeRequested(false);
    }, 4000);
  };

  // Handle Submit Profile Update Request
  const handleSubmitUpdateRequest = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage('');
    setIsSubmitting(true);

    let detailsText = '';
    const changes: Record<string, any> = { reason: updateReason };

    if (updateType === 'PHONE') {
      const clean = newPhone.replace(/\D/g, '').slice(-10);
      if (clean.length < 10) {
        setErrorMessage('Please enter a valid 10-digit mobile number.');
        setIsSubmitting(false);
        return;
      }
      changes.newPhone = `+91 ${clean}`;
      detailsText = `Request to update registered mobile from ${user.phone} to +91 ${clean}. Reason: ${updateReason || 'Customer Request'}`;
    } else if (updateType === 'EMAIL') {
      if (!newEmail.includes('@')) {
        setErrorMessage('Please enter a valid email address.');
        setIsSubmitting(false);
        return;
      }
      changes.newEmail = newEmail.trim();
      detailsText = `Request to update registered email from ${user.email} to ${newEmail.trim()}.`;
    } else if (updateType === 'ADDRESS') {
      if (newAddress.trim().length < 10) {
        setErrorMessage('Please provide a complete address with pincode.');
        setIsSubmitting(false);
        return;
      }
      changes.newAddress = newAddress.trim();
      detailsText = `Request to update communication address to: ${newAddress.trim()}.`;
    } else if (updateType === 'LIMIT') {
      changes.requestedLimit = parseInt(requestedLimit, 10);
      detailsText = `Request to enhance daily transaction limits to ₹${parseInt(requestedLimit, 10).toLocaleString('en-IN')}.`;
    }

    const newReq: ProfileUpdateRequest = {
      id: `req_${Date.now()}_${Math.floor(Math.random() * 1000)}`,
      userId: user.id,
      userPhone: user.phone,
      userName: user.name,
      type: updateType,
      title: `Update ${updateType} Details`,
      details: detailsText,
      requestedChanges: changes,
      status: 'PENDING',
      submittedAt: new Date().toLocaleDateString('en-IN', {
        day: 'numeric',
        month: 'short',
        year: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
      }),
    };

    const currentRequests = user.updateRequests || [];
    const updatedUser: UserProfile = {
      ...user,
      updateRequests: [newReq, ...currentRequests],
    };

    onUpdateUser(updatedUser);
    await dbService.updateUser(user.id, { updateRequests: updatedUser.updateRequests });

    setIsSubmitting(false);
    setSuccessMessage('Your change request has been submitted for Branch Officer review & reconciliation.');

    // Dispatch acknowledgement email
    emailService.sendServiceUpdateEmail(
      user,
      `Change Request Logged: ${newReq.title}`,
      `Your request (Ref: ${newReq.id}) has been forwarded to the Axis Bank Core Operations desk. ${detailsText}`
    ).catch(console.warn);

    // Reset forms
    setNewPhone('');
    setNewEmail('');
    setNewAddress('');
    setUpdateReason('');
    setActiveTab('MY_REQUESTS');
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-3 sm:p-4 animate-in fade-in">
      <div className="w-full max-w-2xl bg-slate-950 border border-[#861F41]/60 rounded-3xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        {/* Modal Header */}
        <div className="bg-gradient-to-r from-[#580824] via-[#861F41] to-[#700a2f] p-4 sm:p-5 text-white flex items-center justify-between border-b border-amber-400/30">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-black/30 border border-amber-400/40 flex items-center justify-center">
              <Settings className="w-5 h-5 text-amber-300" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-base sm:text-lg font-black text-white uppercase tracking-tight">
                  Manage Services & Profile
                </h3>
                <span className="text-[10px] font-black text-amber-400 uppercase bg-black/40 px-2 py-0.5 rounded border border-amber-400/40">
                  Axis VIP
                </span>
              </div>
              <p className="text-[11px] text-amber-100/80">
                Configure payment channels, UPI handles, and submit official update requests
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-xl bg-white/10 hover:bg-white/20 text-white transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Navigation */}
        <div className="flex border-b border-slate-800 bg-slate-900/60 p-1.5 gap-1.5 text-xs font-bold">
          <button
            type="button"
            onClick={() => setActiveTab('SERVICES')}
            className={`flex-1 py-2 px-3 rounded-xl transition ${
              activeTab === 'SERVICES'
                ? 'bg-[#861F41] text-amber-300 font-black shadow-sm'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            Banking Services
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('REQUEST_UPDATE')}
            className={`flex-1 py-2 px-3 rounded-xl transition ${
              activeTab === 'REQUEST_UPDATE'
                ? 'bg-[#861F41] text-amber-300 font-black shadow-sm'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            Request Update
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('MY_REQUESTS')}
            className={`flex-1 py-2 px-3 rounded-xl transition flex items-center justify-center gap-1.5 ${
              activeTab === 'MY_REQUESTS'
                ? 'bg-[#861F41] text-amber-300 font-black shadow-sm'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <span>Track Requests</span>
            {(user.updateRequests || []).length > 0 && (
              <span className="bg-amber-400 text-slate-950 text-[10px] font-black px-1.5 py-0.2 rounded-full">
                {(user.updateRequests || []).length}
              </span>
            )}
          </button>
        </div>

        {/* Feedback Messages */}
        {successMessage && (
          <div className="mx-4 mt-3 p-3 bg-emerald-950/80 border border-emerald-500/50 rounded-2xl text-emerald-200 text-xs font-bold flex items-center gap-2">
            <Check className="w-4 h-4 text-emerald-400 flex-shrink-0" />
            <span>{successMessage}</span>
          </div>
        )}
        {errorMessage && (
          <div className="mx-4 mt-3 p-3 bg-rose-950/80 border border-rose-500/50 rounded-2xl text-rose-200 text-xs font-bold flex items-center gap-2">
            <AlertCircle className="w-4 h-4 text-rose-400 flex-shrink-0" />
            <span>{errorMessage}</span>
          </div>
        )}

        {/* Content Body */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-5">
          {/* TAB 1: BANKING SERVICES */}
          {activeTab === 'SERVICES' && (
            <div className="space-y-4">
              {/* UPI Channels Handle Selector */}
              <div className="p-4 bg-slate-900 rounded-2xl border border-slate-800 space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Zap className="w-4 h-4 text-amber-400" />
                    <span className="text-xs font-black uppercase tracking-wider text-white">
                      Active UPI VPA Channel
                    </span>
                  </div>
                  <span className="text-[11px] text-amber-400 font-mono font-bold">
                    {user.upiId}
                  </span>
                </div>
                <p className="text-[11px] text-slate-400">
                  Select your primary NPCI UPI handle for receiving instant inward transfers:
                </p>

                <div className="grid grid-cols-3 gap-2">
                  {(['@axisbank', '@okaxis', '@axissbs'] as UpiHandleDomain[]).map((handle) => (
                    <button
                      key={handle}
                      type="button"
                      onClick={() => setActiveUpiHandle(handle)}
                      className={`p-2.5 rounded-xl border text-xs font-mono font-bold transition flex items-center justify-center gap-1.5 ${
                        activeUpiHandle === handle
                          ? 'bg-[#861F41] border-amber-400 text-amber-300 shadow-sm'
                          : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-white'
                      }`}
                    >
                      <span>{handle}</span>
                      {activeUpiHandle === handle && <Check className="w-3.5 h-3.5 text-amber-300" />}
                    </button>
                  ))}
                </div>
              </div>

              {/* Service Toggles Grid */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {/* Domestic UPI */}
                <div className="p-3.5 bg-slate-900 rounded-2xl border border-slate-800 flex items-center justify-between">
                  <div>
                    <span className="text-xs font-bold text-white block">UPI 2.0 & QR Payments</span>
                    <span className="text-[10px] text-slate-400">Instant real-time NPCI transfers</span>
                  </div>
                  <input
                    type="checkbox"
                    checked={upiEnabled}
                    onChange={(e) => setUpiEnabled(e.target.checked)}
                    className="w-4 h-4 rounded text-[#861F41] bg-slate-800 border-slate-700"
                  />
                </div>

                {/* UPI Lite */}
                <div className="p-3.5 bg-slate-900 rounded-2xl border border-slate-800 flex items-center justify-between">
                  <div>
                    <span className="text-xs font-bold text-white block">UPI Lite (Pinless)</span>
                    <span className="text-[10px] text-slate-400">Fast 1-tap checkout under ₹500</span>
                  </div>
                  <input
                    type="checkbox"
                    checked={upiLiteEnabled}
                    onChange={(e) => setUpiLiteEnabled(e.target.checked)}
                    className="w-4 h-4 rounded text-[#861F41] bg-slate-800 border-slate-700"
                  />
                </div>

                {/* Soundbox Voice Alerts */}
                <div className="p-3.5 bg-slate-900 rounded-2xl border border-slate-800 flex items-center justify-between">
                  <div>
                    <span className="text-xs font-bold text-white block flex items-center gap-1">
                      <Volume2 className="w-3.5 h-3.5 text-amber-400" />
                      <span>VIP Soundbox Alerts</span>
                    </span>
                    <span className="text-[10px] text-slate-400">Real-time multi-lingual voice confirmation</span>
                  </div>
                  <input
                    type="checkbox"
                    checked={soundboxEnabled}
                    onChange={(e) => setSoundboxEnabled(e.target.checked)}
                    className="w-4 h-4 rounded text-[#861F41] bg-slate-800 border-slate-700"
                  />
                </div>

                {/* Biometrics */}
                <div className="p-3.5 bg-slate-900 rounded-2xl border border-slate-800 flex items-center justify-between">
                  <div>
                    <span className="text-xs font-bold text-white block flex items-center gap-1">
                      <Fingerprint className="w-3.5 h-3.5 text-amber-400" />
                      <span>Biometric Touch ID / Face ID</span>
                    </span>
                    <span className="text-[10px] text-slate-400">Hardware sensor authorization</span>
                  </div>
                  <input
                    type="checkbox"
                    checked={biometricsEnabled}
                    onChange={(e) => setBiometricsEnabled(e.target.checked)}
                    className="w-4 h-4 rounded text-[#861F41] bg-slate-800 border-slate-700"
                  />
                </div>

                {/* International Banking */}
                <div className="p-3.5 bg-slate-900 rounded-2xl border border-slate-800 flex items-center justify-between">
                  <div>
                    <span className="text-xs font-bold text-white block flex items-center gap-1">
                      <Globe className="w-3.5 h-3.5 text-amber-400" />
                      <span>International Banking & Forex</span>
                    </span>
                    <span className="text-[10px] text-slate-400">Cross-border inward & outward remittance</span>
                  </div>
                  <input
                    type="checkbox"
                    checked={intlEnabled}
                    onChange={(e) => setIntlEnabled(e.target.checked)}
                    className="w-4 h-4 rounded text-[#861F41] bg-slate-800 border-slate-700"
                  />
                </div>

                {/* Cheque Book Order Card */}
                <div className="p-3.5 bg-slate-900 rounded-2xl border border-slate-800 flex items-center justify-between">
                  <div>
                    <span className="text-xs font-bold text-white block">Cheque Book Requisition</span>
                    <span className="text-[10px] text-slate-400">CTS-2010 High-Security Leaves</span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <select
                      value={chequeLeaves}
                      onChange={(e) => setChequeLeaves(e.target.value as any)}
                      className="bg-slate-950 text-white text-[11px] rounded-lg px-2 py-1 border border-slate-700"
                    >
                      <option value="25">25 Leaves</option>
                      <option value="50">50 Leaves</option>
                    </select>
                    <button
                      type="button"
                      onClick={handleRequestChequeBook}
                      className="px-2.5 py-1 rounded-lg bg-amber-400 hover:bg-amber-300 text-slate-950 text-[10px] font-black uppercase transition"
                    >
                      Order
                    </button>
                  </div>
                </div>
              </div>

              <button
                type="button"
                onClick={handleSaveServices}
                className="w-full py-3 rounded-2xl bg-gradient-to-r from-[#861F41] to-[#97144D] text-amber-300 font-black uppercase tracking-wider text-xs shadow-md transition active:scale-95 flex items-center justify-center gap-2 border border-amber-400/30"
              >
                <Check className="w-4 h-4 text-amber-400" />
                <span>Save Service Preferences</span>
              </button>
            </div>
          )}

          {/* TAB 2: REQUEST UPDATE */}
          {activeTab === 'REQUEST_UPDATE' && (
            <form onSubmit={handleSubmitUpdateRequest} className="space-y-4">
              <div>
                <label className="block text-xs font-black uppercase tracking-wider text-slate-300 mb-1.5">
                  Select Information to Update
                </label>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                  {[
                    { id: 'PHONE', label: 'Mobile No.', icon: Smartphone },
                    { id: 'EMAIL', label: 'Email ID', icon: Mail },
                    { id: 'ADDRESS', label: 'Address', icon: MapPin },
                    { id: 'LIMIT', label: 'Daily Limits', icon: Sliders },
                  ].map((item) => {
                    const Icon = item.icon;
                    return (
                      <button
                        key={item.id}
                        type="button"
                        onClick={() => setUpdateType(item.id as any)}
                        className={`p-3 rounded-xl border text-xs font-bold transition flex flex-col items-center gap-1.5 ${
                          updateType === item.id
                            ? 'bg-[#861F41] border-amber-400 text-amber-300'
                            : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-white'
                        }`}
                      >
                        <Icon className="w-4 h-4 text-amber-400" />
                        <span>{item.label}</span>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Dynamic Inputs */}
              {updateType === 'PHONE' && (
                <div>
                  <label className="block text-xs font-bold text-slate-300 mb-1">
                    New 10-Digit Mobile Number
                  </label>
                  <div className="relative">
                    <span className="absolute left-3 top-1/2 -translate-y-1/2 text-xs font-bold text-amber-400">
                      +91
                    </span>
                    <input
                      type="tel"
                      maxLength={10}
                      value={newPhone}
                      onChange={(e) => setNewPhone(e.target.value.replace(/\D/g, ''))}
                      placeholder="Enter new 10-digit number"
                      className="w-full pl-12 pr-3 py-2.5 bg-slate-900 border border-slate-700 rounded-xl text-xs font-bold text-white focus:outline-none focus:ring-2 focus:ring-[#861F41]"
                      required
                    />
                  </div>
                </div>
              )}

              {updateType === 'EMAIL' && (
                <div>
                  <label className="block text-xs font-bold text-slate-300 mb-1">
                    New Email Address
                  </label>
                  <input
                    type="email"
                    value={newEmail}
                    onChange={(e) => setNewEmail(e.target.value)}
                    placeholder="new.email@company.com"
                    className="w-full px-3 py-2.5 bg-slate-900 border border-slate-700 rounded-xl text-xs font-bold text-white focus:outline-none focus:ring-2 focus:ring-[#861F41]"
                    required
                  />
                </div>
              )}

              {updateType === 'ADDRESS' && (
                <div>
                  <label className="block text-xs font-bold text-slate-300 mb-1">
                    New Permanent / Communication Address
                  </label>
                  <textarea
                    rows={3}
                    value={newAddress}
                    onChange={(e) => setNewAddress(e.target.value)}
                    placeholder="Flat/Premises, Street, City, State, and PIN code"
                    className="w-full px-3 py-2.5 bg-slate-900 border border-slate-700 rounded-xl text-xs font-bold text-white focus:outline-none focus:ring-2 focus:ring-[#861F41]"
                    required
                  />
                </div>
              )}

              {updateType === 'LIMIT' && (
                <div>
                  <label className="block text-xs font-bold text-slate-300 mb-1">
                    Requested Daily Limit (INR)
                  </label>
                  <select
                    value={requestedLimit}
                    onChange={(e) => setRequestedLimit(e.target.value)}
                    className="w-full px-3 py-2.5 bg-slate-900 border border-slate-700 rounded-xl text-xs font-bold text-white"
                  >
                    <option value="500000">₹5,00,000 / Day</option>
                    <option value="1000000">₹10,00,000 / Day</option>
                    <option value="1500000">₹15,00,000 / Day</option>
                    <option value="2500000">₹25,00,000 / Day (Ultra HNI)</option>
                  </select>
                </div>
              )}

              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1">
                  Reason for Modification (Optional)
                </label>
                <input
                  type="text"
                  value={updateReason}
                  onChange={(e) => setUpdateReason(e.target.value)}
                  placeholder="e.g. Relocated office / corporate expansion"
                  className="w-full px-3 py-2.5 bg-slate-900 border border-slate-700 rounded-xl text-xs text-white"
                />
              </div>

              <button
                type="submit"
                disabled={isSubmitting}
                className="w-full py-3.5 rounded-2xl bg-gradient-to-r from-amber-400 to-amber-500 hover:from-amber-300 text-slate-950 font-black uppercase tracking-wider text-xs shadow-md transition active:scale-95 flex items-center justify-center gap-2"
              >
                <Send className="w-4 h-4 fill-slate-950" />
                <span>{isSubmitting ? 'Submitting...' : 'Submit Request for Officer Review'}</span>
              </button>
            </form>
          )}

          {/* TAB 3: MY REQUESTS TRACKER */}
          {activeTab === 'MY_REQUESTS' && (
            <div className="space-y-3">
              {(user.updateRequests || []).length === 0 ? (
                <div className="text-center py-8 text-slate-500 text-xs">
                  <FileText className="w-8 h-8 text-slate-600 mx-auto mb-2" />
                  <p>No service or profile update requests logged yet.</p>
                </div>
              ) : (
                (user.updateRequests || []).map((req) => (
                  <div
                    key={req.id}
                    className="p-3.5 bg-slate-900 rounded-2xl border border-slate-800 space-y-2 text-xs"
                  >
                    <div className="flex items-center justify-between">
                      <span className="font-black text-white">{req.title}</span>
                      <span
                        className={`text-[9px] font-black uppercase px-2 py-0.5 rounded border ${
                          req.status === 'APPROVED'
                            ? 'bg-emerald-950 text-emerald-300 border-emerald-500/50'
                            : req.status === 'REJECTED'
                            ? 'bg-rose-950 text-rose-300 border-rose-500/50'
                            : 'bg-amber-950 text-amber-300 border-amber-500/50'
                        }`}
                      >
                        {req.status}
                      </span>
                    </div>

                    <p className="text-[11px] text-slate-300">{req.details}</p>

                    <div className="flex items-center justify-between text-[10px] text-slate-500 pt-1 border-t border-slate-800 font-mono">
                      <span>Ref: {req.id}</span>
                      <span>Submitted: {req.submittedAt}</span>
                    </div>
                  </div>
                ))
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
