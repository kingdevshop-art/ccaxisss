import React, { useState } from 'react';
import {
  X,
  LogOut,
  Check,
  Copy,
  Fingerprint,
  Lock,
  CheckCircle2,
  Building2,
  CreditCard,
  Camera,
  Upload,
  Calendar,
  MapPin,
  FileText,
  Eye,
  EyeOff,
  User,
  ShieldCheck,
  Download,
  Phone,
  Mail,
  KeyRound,
  Clock,
  AlertCircle,
} from 'lucide-react';
import { UserProfile, LanguageCode } from '../types';
import { AxisBankLogo } from './AxisBankLogo';
import { checkProfilePhotoEligibility } from '../utils/accountUtils.ts';
import { dbService } from '../services/dbService.ts';

interface CustomerAuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentUser: UserProfile | null;
  onLogout: () => void;
  onUpdateUser?: (updated: UserProfile) => void;
  language?: LanguageCode;
}

export const CustomerAuthModal: React.FC<CustomerAuthModalProps> = ({
  isOpen,
  onClose,
  currentUser,
  onLogout,
  onUpdateUser,
}) => {
  const [copiedField, setCopiedField] = useState<string | null>(null);
  const [showAadhaar, setShowAadhaar] = useState(false);
  const [downloadSuccess, setDownloadSuccess] = useState(false);

  // Change MPIN states
  const [isChangingMpin, setIsChangingMpin] = useState(false);
  const [currentPinInput, setCurrentPinInput] = useState('');
  const [newPinInput, setNewPinInput] = useState('');
  const [confirmPinInput, setConfirmPinInput] = useState('');
  const [mpinStatusMsg, setMpinStatusMsg] = useState<{ type: 'error' | 'success'; text: string } | null>(null);
  const [photoStatusMsg, setPhotoStatusMsg] = useState<{ type: 'error' | 'success'; text: string } | null>(null);

  if (!isOpen || !currentUser) return null;

  const photoEligibility = checkProfilePhotoEligibility(currentUser.profilePhotoUpdatedAt);

  const handleCopy = (text: string, label: string) => {
    navigator.clipboard?.writeText?.(text);
    setCopiedField(label);
    setTimeout(() => setCopiedField(null), 2000);
  };

  const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    setPhotoStatusMsg(null);
    const file = e.target.files?.[0];
    if (!file) return;

    if (!photoEligibility.eligible) {
      setPhotoStatusMsg({
        type: 'error',
        text: `Profile photo can only be updated once per month. Next eligible update: ${photoEligibility.nextEligibleDate} (${photoEligibility.daysRemaining} days remaining).`,
      });
      // Clear file input
      e.target.value = '';
      return;
    }

    if (onUpdateUser) {
      const reader = new FileReader();
      reader.onload = async (event) => {
        const base64 = event.target?.result as string;
        const nowIso = new Date().toISOString();
        const updatedUser: UserProfile = {
          ...currentUser,
          photoUrl: base64,
          profilePhotoUpdatedAt: nowIso,
        };
        onUpdateUser(updatedUser);
        await dbService.updateProfilePhoto(currentUser.id, base64, nowIso);
        await dbService.saveUser(updatedUser);
        setPhotoStatusMsg({
          type: 'success',
          text: 'Profile photo updated successfully! As per security guidelines, your next allowed photo update will be in 30 days.',
        });
      };
      reader.readAsDataURL(file);
    }
  };

  const handleDownloadSlip = () => {
    const slipData = `
=====================================================
                 AXIS BANK CC VIP
        CORE BANKING SYSTEM - CUSTOMER PROFILE
=====================================================
Date & Time Generated: ${new Date().toLocaleString('en-IN')}
Bank Branch          : ${currentUser.branchName || 'Axis Bank Corporate HO (Mumbai)'}
IFSC Code            : UTIB000001

--- CUSTOMER PERSONAL & KYC DETAILS ---
Customer Full Name   : ${currentUser.name}
Date of Birth (DOB)  : ${currentUser.dob || 'Not Specified'}
Registered Mobile    : ${currentUser.phone}
Email Address        : ${currentUser.email}
Address              : ${currentUser.address || 'Address on file in CBS branch records'}
Central KYC (CKYC)   : ${currentUser.ckycNumber || 'CKYC-2024-8891-2301'}
Aadhaar Number       : ${currentUser.aadhaarNumber}
PAN Number           : ${currentUser.panNumber}
KYC Status           : ${currentUser.kycStatus.toUpperCase()} (RBI Verified)

--- ACCOUNT & FINANCIAL SUMMARY ---
Account Number       : ${currentUser.accountNumber}
Customer CIF ID      : ${currentUser.cifNumber || 'CIF98471203'}
Account Type         : ${currentUser.accountType || 'SAVINGS'}
UPI VPA Handle       : ${currentUser.upiId}
Savings Balance      : Rs. ${currentUser.savingsBalance.toFixed(2)}
Fixed Deposit Balance: Rs. ${currentUser.fixedDepositBalance.toFixed(2)}
Wallet Balance       : Rs. ${currentUser.walletBalance.toFixed(2)}
UPI Lite Balance     : Rs. ${currentUser.upiLiteBalance.toFixed(2)}

-----------------------------------------------------
DICGC Insured up to Rs. 5,00,000 | 256-bit Encrypted
Toll-Free 24x7 Priority Helpline: 1860-419-5555
=====================================================
    `.trim();

    const blob = new Blob([slipData], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `Axis_Bank_VIP_Profile_${currentUser.accountNumber}.txt`;
    link.click();
    URL.revokeObjectURL(url);
    setDownloadSuccess(true);
    setTimeout(() => setDownloadSuccess(false), 3000);
  };

  // Mask Aadhaar e.g. "XXXX-XXXX-8921" or show raw
  const formattedAadhaar = showAadhaar
    ? currentUser.aadhaarNumber.replace('XXXX-XXXX-', '5821-9402-')
    : currentUser.aadhaarNumber;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/75 backdrop-blur-xs">
      <div className="bg-white border border-slate-200 text-slate-900 rounded-3xl w-full max-w-lg shadow-2xl overflow-hidden relative animate-in fade-in zoom-in-95 duration-200 flex flex-col max-h-[90vh]">
        
        {/* Header with Axis Bank CC VIP Branding */}
        <div className="bg-gradient-to-r from-[#580824] via-[#861F41] to-[#97144D] text-white p-4 sm:p-5 flex items-center justify-between border-b border-[#700a2f] flex-shrink-0">
          <div className="flex items-center gap-3">
            <AxisBankLogo size="lg" className="flex-shrink-0" />
            <div>
              <div className="flex items-center gap-1.5">
                <h3 className="font-black text-sm uppercase tracking-wider text-white">
                  Customer Profile & KYC
                </h3>
                <span className="bg-emerald-500 text-white text-[9px] font-black uppercase px-1.5 py-0.5 rounded-sm">
                  ACTIVE CBS
                </span>
              </div>
              <p className="text-[10px] sm:text-[11px] text-amber-200 font-bold">
                Axis Bank CC VIP Mobile Banking
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-white/10 hover:bg-white/20 text-white flex items-center justify-center transition active:scale-95"
            aria-label="Close Profile"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Scrollable Body Content */}
        <div className="p-4 sm:p-6 overflow-y-auto space-y-4 flex-1">
          
          {/* Main Account Identity Card with Photo */}
          <div className="bg-gradient-to-br from-[#580824] via-[#861F41] to-[#97144D] text-white p-4 sm:p-5 rounded-2xl shadow-md border border-[#700a2f] space-y-4 relative overflow-hidden">
            
            {/* Top Row: Photo + Name + KYC Badge */}
            <div className="flex items-start justify-between gap-3">
              <div className="flex items-center gap-3.5">
                {/* Photo with Change Photo Trigger */}
                <div className="relative group flex-shrink-0">
                  {currentUser.photoUrl ? (
                    <img
                      src={currentUser.photoUrl}
                      alt={currentUser.name}
                      referrerPolicy="no-referrer"
                      className="w-16 h-16 rounded-2xl object-cover border-2 border-amber-400 shadow-md"
                    />
                  ) : (
                    <div className="w-16 h-16 rounded-2xl bg-amber-400 text-slate-950 font-black text-2xl flex items-center justify-center shadow-md border-2 border-amber-300">
                      {currentUser.name.charAt(0)}
                    </div>
                  )}

                  {/* Upload/Change Photo overlay */}
                  <label
                    className="absolute -bottom-1 -right-1 p-1.5 bg-[#0a2540] text-amber-300 rounded-full shadow-md cursor-pointer border border-amber-400/80 hover:bg-amber-400 hover:text-slate-950 transition"
                    title="Change / Upload Photo"
                  >
                    <Camera className="w-3.5 h-3.5" />
                    <input
                      type="file"
                      accept="image/*"
                      onChange={handlePhotoUpload}
                      className="hidden"
                    />
                  </label>
                </div>

                <div className="min-w-0">
                  <div className="flex items-center gap-1.5 flex-wrap">
                    <h4 className="font-black text-base text-white truncate">
                      {currentUser.name}
                    </h4>
                    <span className="bg-emerald-500/20 text-emerald-300 border border-emerald-400/30 text-[9px] font-black uppercase px-2 py-0.5 rounded-full flex items-center gap-1">
                      <CheckCircle2 className="w-2.5 h-2.5" />
                      KYC Verified
                    </span>
                  </div>
                  <p className="text-xs text-slate-300 font-mono font-bold mt-0.5">
                    {currentUser.phone}
                  </p>
                  <p className="text-[11px] text-amber-200/90 font-bold truncate">
                    {currentUser.email}
                  </p>
                  
                  {/* Photo Update Rule Indicator */}
                  <div className="mt-1 flex items-center gap-1.5 flex-wrap">
                    {photoEligibility.eligible ? (
                      <span className="text-[10px] text-emerald-300 bg-emerald-950/60 border border-emerald-500/30 px-2 py-0.5 rounded-full font-bold flex items-center gap-1">
                        <Camera className="w-3 h-3 text-emerald-400" />
                        <span>Eligible for monthly photo update</span>
                      </span>
                    ) : (
                      <span className="text-[10px] text-amber-200 bg-amber-950/60 border border-amber-500/30 px-2 py-0.5 rounded-full font-bold flex items-center gap-1" title={`Updated on ${photoEligibility.lastUpdatedFormatted}`}>
                        <Clock className="w-3 h-3 text-amber-400" />
                        <span>Photo locked (1x/month): Next in {photoEligibility.daysRemaining}d ({photoEligibility.nextEligibleDate})</span>
                      </span>
                    )}
                  </div>
                </div>
              </div>

              <span className="text-[9px] sm:text-[10px] font-black uppercase tracking-wider bg-white/10 px-2.5 py-1 rounded-lg text-amber-300 border border-white/10 whitespace-nowrap">
                {currentUser.accountType || 'SAVINGS'}
              </span>
            </div>

            {/* Photo Feedback Message */}
            {photoStatusMsg && (
              <div
                className={`p-2.5 rounded-xl text-xs font-bold flex items-center gap-2 ${
                  photoStatusMsg.type === 'error'
                    ? 'bg-rose-500/20 border border-rose-400/40 text-rose-200'
                    : 'bg-emerald-500/20 border border-emerald-400/40 text-emerald-200'
                }`}
              >
                {photoStatusMsg.type === 'error' ? (
                  <AlertCircle className="w-4 h-4 text-rose-300 flex-shrink-0" />
                ) : (
                  <CheckCircle2 className="w-4 h-4 text-emerald-300 flex-shrink-0" />
                )}
                <span>{photoStatusMsg.text}</span>
              </div>
            )}

            {/* Account Number & IFSC Grid */}
            <div className="grid grid-cols-2 gap-2 pt-2 border-t border-white/10 text-xs">
              <div className="bg-white/5 p-2.5 rounded-xl border border-white/10">
                <span className="text-[9px] text-slate-300 font-bold uppercase block">
                  A/C Number
                </span>
                <div className="flex items-center justify-between font-mono font-black text-white text-xs mt-0.5">
                  <span className="truncate">{currentUser.accountNumber}</span>
                  <button
                    onClick={() => handleCopy(currentUser.accountNumber, 'ac')}
                    className="text-amber-300 hover:text-white p-1 ml-1 flex-shrink-0"
                    title="Copy Account Number"
                  >
                    {copiedField === 'ac' ? (
                      <Check className="w-3.5 h-3.5 text-emerald-400" />
                    ) : (
                      <Copy className="w-3.5 h-3.5" />
                    )}
                  </button>
                </div>
              </div>

              <div className="bg-white/5 p-2.5 rounded-xl border border-white/10">
                <span className="text-[9px] text-slate-300 font-bold uppercase block">
                  IFSC Code
                </span>
                <div className="flex items-center justify-between font-mono font-black text-white text-xs mt-0.5">
                  <span className="truncate">{currentUser.ifscCode}</span>
                  <button
                    onClick={() => handleCopy(currentUser.ifscCode, 'ifsc')}
                    className="text-amber-300 hover:text-white p-1 ml-1 flex-shrink-0"
                    title="Copy IFSC"
                  >
                    {copiedField === 'ifsc' ? (
                      <Check className="w-3.5 h-3.5 text-emerald-400" />
                    ) : (
                      <Copy className="w-3.5 h-3.5" />
                    )}
                  </button>
                </div>
              </div>
            </div>

            {/* Balances Summary */}
            <div className="flex items-center justify-between pt-1">
              <div>
                <span className="text-[9px] text-slate-300 uppercase font-black tracking-wider block">
                  Available Savings
                </span>
                <span className="text-xl font-black font-sans text-amber-300">
                  ₹{currentUser.savingsBalance.toLocaleString('en-IN', { minimumFractionDigits: 2 })}
                </span>
              </div>
              <div className="text-right">
                <span className="text-[9px] text-slate-300 uppercase font-black tracking-wider block">
                  Fixed Deposit (7.5%)
                </span>
                <span className="text-sm font-black font-sans text-white">
                  ₹{currentUser.fixedDepositBalance.toLocaleString('en-IN')}
                </span>
              </div>
            </div>
          </div>

          {/* Customer KYC & Personal Identity Details (DOB, Address, CKYC, Aadhaar, PAN) */}
          <div className="bg-slate-50 border border-slate-200 rounded-2xl p-4 space-y-3 text-xs">
            <div className="flex items-center justify-between pb-2 border-b border-slate-200 text-slate-800">
              <span className="text-[11px] font-black uppercase tracking-wider text-[#0a2540] flex items-center gap-1.5">
                <ShieldCheck className="w-4 h-4 text-emerald-600" />
                <span>Statutory Identity & KYC Records</span>
              </span>
              <span className="text-[9px] bg-emerald-100 text-emerald-800 font-bold px-2 py-0.5 rounded-md border border-emerald-200">
                RBI COMPLIANT
              </span>
            </div>

            {/* Date of Birth (DOB) */}
            <div className="flex items-center justify-between py-1 border-b border-slate-200/80">
              <span className="text-slate-500 font-bold flex items-center gap-1.5">
                <Calendar className="w-3.5 h-3.5 text-[#0a2540]" />
                <span>Date of Birth (DOB)</span>
              </span>
              <span className="font-black text-slate-900 font-sans">
                {currentUser.dob || '14 Nov 1991'}
              </span>
            </div>

            {/* Central KYC Number (CKYC No.) */}
            <div className="flex items-center justify-between py-1 border-b border-slate-200/80">
              <span className="text-slate-500 font-bold flex items-center gap-1.5">
                <FileText className="w-3.5 h-3.5 text-[#0a2540]" />
                <span>CKYC Registry No.</span>
              </span>
              <div className="flex items-center gap-1.5">
                <span className="font-mono font-black text-emerald-800 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200 text-[11px]">
                  {currentUser.ckycNumber || 'CKYC-2024-8891-2301'}
                </span>
                <button
                  onClick={() =>
                    handleCopy(
                      currentUser.ckycNumber || 'CKYC-2024-8891-2301',
                      'ckyc'
                    )
                  }
                  className="text-slate-500 hover:text-slate-900 p-0.5"
                  title="Copy CKYC Number"
                >
                  {copiedField === 'ckyc' ? (
                    <Check className="w-3.5 h-3.5 text-emerald-600" />
                  ) : (
                    <Copy className="w-3.5 h-3.5" />
                  )}
                </button>
              </div>
            </div>

            {/* Aadhaar Number with Toggle */}
            <div className="flex items-center justify-between py-1 border-b border-slate-200/80">
              <span className="text-slate-500 font-bold flex items-center gap-1.5">
                <CreditCard className="w-3.5 h-3.5 text-[#0a2540]" />
                <span>Aadhaar Number</span>
              </span>
              <div className="flex items-center gap-1.5">
                <span className="font-mono font-black text-slate-900 text-[11px]">
                  {formattedAadhaar}
                </span>
                <button
                  onClick={() => setShowAadhaar(!showAadhaar)}
                  className="text-slate-500 hover:text-slate-900 p-0.5"
                  title={showAadhaar ? 'Mask Aadhaar' : 'Show Aadhaar'}
                >
                  {showAadhaar ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                </button>
                <button
                  onClick={() => handleCopy(currentUser.aadhaarNumber, 'aadhaar')}
                  className="text-slate-500 hover:text-slate-900 p-0.5"
                  title="Copy Aadhaar"
                >
                  {copiedField === 'aadhaar' ? (
                    <Check className="w-3.5 h-3.5 text-emerald-600" />
                  ) : (
                    <Copy className="w-3.5 h-3.5" />
                  )}
                </button>
              </div>
            </div>

            {/* PAN Card Details */}
            <div className="flex items-center justify-between py-1 border-b border-slate-200/80">
              <span className="text-slate-500 font-bold flex items-center gap-1.5">
                <FileText className="w-3.5 h-3.5 text-[#0a2540]" />
                <span>PAN Card Number</span>
              </span>
              <div className="flex items-center gap-1.5">
                <span className="font-mono font-black text-slate-900 uppercase text-[11px] bg-slate-100 px-2 py-0.5 rounded">
                  {currentUser.panNumber}
                </span>
                <button
                  onClick={() => handleCopy(currentUser.panNumber, 'pan')}
                  className="text-slate-500 hover:text-slate-900 p-0.5"
                  title="Copy PAN Number"
                >
                  {copiedField === 'pan' ? (
                    <Check className="w-3.5 h-3.5 text-emerald-600" />
                  ) : (
                    <Copy className="w-3.5 h-3.5" />
                  )}
                </button>
              </div>
            </div>

            {/* Permanent & Communication Address */}
            <div className="py-1">
              <span className="text-slate-500 font-bold flex items-center gap-1.5 mb-1">
                <MapPin className="w-3.5 h-3.5 text-[#0a2540]" />
                <span>Registered Address</span>
              </span>
              <p className="text-slate-800 font-semibold bg-white p-2.5 rounded-xl border border-slate-200 leading-relaxed text-[11px]">
                {currentUser.address ||
                  'Flat 4B, Imperial Heights, Worli Sea Face, Mumbai, Maharashtra - 400018'}
              </p>
            </div>
          </div>

          {/* Extended Branch & CBS Infrastructure */}
          <div className="bg-slate-50 border border-slate-200 rounded-2xl p-4 space-y-2 text-xs">
            <div className="flex items-center justify-between py-1 border-b border-slate-200/80">
              <span className="text-slate-500 font-bold flex items-center gap-1.5">
                <Building2 className="w-3.5 h-3.5 text-[#0a2540]" />
                <span>Home Branch</span>
              </span>
              <span className="font-black text-slate-900">
                {currentUser.branchName || 'Axis Bank Corporate HO (Mumbai)'}
              </span>
            </div>

            <div className="flex items-center justify-between py-1 border-b border-slate-200/80">
              <span className="text-slate-500 font-bold">Customer ID (CIF)</span>
              <span className="font-mono font-black text-slate-900">
                {currentUser.cifNumber || 'CIF98471203'}
              </span>
            </div>

            <div className="flex items-center justify-between py-1 border-b border-slate-200/80">
              <span className="text-slate-500 font-bold">UPI VPA Handle</span>
              <span className="font-mono font-black text-[#0a2540]">
                {currentUser.upiId}
              </span>
            </div>

            <div className="flex items-center justify-between py-1">
              <span className="text-slate-500 font-bold">Biometric Authentication</span>
              <span className="font-black text-emerald-600 flex items-center gap-1">
                <Fingerprint className="w-3.5 h-3.5" />
                Active (Limit ₹{currentUser.biometricLimit.toLocaleString('en-IN')})
              </span>
            </div>
          </div>

          {/* 4-Digit Security MPIN Management (User can change/reset MPIN) */}
          <div className="bg-slate-50 border border-slate-200 rounded-2xl p-4 space-y-3 text-xs">
            <div className="flex items-center justify-between pb-2 border-b border-slate-200">
              <div className="flex items-center gap-1.5">
                <KeyRound className="w-4 h-4 text-[#0a2540]" />
                <span className="font-black uppercase tracking-wider text-slate-900 text-[11px]">
                  4-Digit Security MPIN
                </span>
              </div>
              <button
                type="button"
                onClick={() => {
                  setIsChangingMpin(!isChangingMpin);
                  setMpinStatusMsg(null);
                  setCurrentPinInput('');
                  setNewPinInput('');
                  setConfirmPinInput('');
                }}
                className="text-xs font-bold text-[#0a2540] hover:text-amber-700 hover:underline cursor-pointer"
              >
                {isChangingMpin ? 'Cancel' : 'Change MPIN'}
              </button>
            </div>

            {!isChangingMpin ? (
              <div className="flex items-center justify-between text-xs py-1">
                <span className="text-slate-500 font-medium">Account MPIN Protection</span>
                <span className="font-mono font-black text-slate-800 bg-slate-200/80 px-2.5 py-0.5 rounded tracking-widest text-xs">
                  ••••
                </span>
              </div>
            ) : (
              <form
                onSubmit={(e) => {
                  e.preventDefault();
                  setMpinStatusMsg(null);
                  const expected = (currentUser.mpin && currentUser.mpin.trim()) ? currentUser.mpin.trim() : '1234';
                  if (currentPinInput.trim() !== expected) {
                    setMpinStatusMsg({ type: 'error', text: 'Current MPIN is incorrect.' });
                    return;
                  }
                  if (newPinInput.length !== 4 || !/^\d{4}$/.test(newPinInput)) {
                    setMpinStatusMsg({ type: 'error', text: 'New MPIN must be exactly 4 numeric digits.' });
                    return;
                  }
                  if (newPinInput !== confirmPinInput) {
                    setMpinStatusMsg({ type: 'error', text: 'New MPIN and Confirm MPIN do not match.' });
                    return;
                  }
                  if (onUpdateUser) {
                    onUpdateUser({
                      ...currentUser,
                      mpin: newPinInput,
                    });
                    setMpinStatusMsg({ type: 'success', text: 'MPIN updated successfully!' });
                    setTimeout(() => {
                      setIsChangingMpin(false);
                      setMpinStatusMsg(null);
                    }, 1500);
                  }
                }}
                className="space-y-2.5 pt-1"
              >
                {mpinStatusMsg && (
                  <div
                    className={`p-2 rounded-xl text-xs font-bold ${
                      mpinStatusMsg.type === 'error'
                        ? 'bg-rose-50 text-rose-800 border border-rose-200'
                        : 'bg-emerald-50 text-emerald-800 border border-emerald-200'
                    }`}
                  >
                    {mpinStatusMsg.text}
                  </div>
                )}

                <div>
                  <label className="block text-[11px] font-bold text-slate-600 mb-1">
                    Current 4-Digit MPIN
                  </label>
                  <input
                    type="password"
                    maxLength={4}
                    inputMode="numeric"
                    value={currentPinInput}
                    onChange={(e) => setCurrentPinInput(e.target.value.replace(/\D/g, ''))}
                    placeholder="Enter current MPIN"
                    className="w-full px-3 py-2 bg-white border border-slate-200 rounded-xl text-xs font-black tracking-widest text-slate-900 focus:outline-none focus:ring-2 focus:ring-[#0a2540]"
                    required
                  />
                </div>

                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <label className="block text-[11px] font-bold text-slate-600 mb-1">
                      New MPIN
                    </label>
                    <input
                      type="password"
                      maxLength={4}
                      inputMode="numeric"
                      value={newPinInput}
                      onChange={(e) => setNewPinInput(e.target.value.replace(/\D/g, ''))}
                      placeholder="4 digits"
                      className="w-full px-3 py-2 bg-white border border-slate-200 rounded-xl text-xs font-black tracking-widest text-slate-900 focus:outline-none focus:ring-2 focus:ring-[#0a2540]"
                      required
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] font-bold text-slate-600 mb-1">
                      Confirm New
                    </label>
                    <input
                      type="password"
                      maxLength={4}
                      inputMode="numeric"
                      value={confirmPinInput}
                      onChange={(e) => setConfirmPinInput(e.target.value.replace(/\D/g, ''))}
                      placeholder="4 digits"
                      className="w-full px-3 py-2 bg-white border border-slate-200 rounded-xl text-xs font-black tracking-widest text-slate-900 focus:outline-none focus:ring-2 focus:ring-[#0a2540]"
                      required
                    />
                  </div>
                </div>

                <button
                  type="submit"
                  className="w-full py-2.5 rounded-xl bg-[#0a2540] hover:bg-[#071d34] text-amber-300 font-black uppercase tracking-wider text-xs transition active:scale-98 shadow-xs"
                >
                  Save New MPIN
                </button>
              </form>
            )}
          </div>

          {/* Action Buttons: Download Slip & Logout */}
          <div className="space-y-2 pt-1">
            <button
              onClick={handleDownloadSlip}
              className="w-full py-2.5 px-4 rounded-xl bg-slate-100 hover:bg-slate-200 border border-slate-300 text-slate-800 font-black uppercase tracking-wider text-xs flex items-center justify-center gap-2 transition active:scale-98"
            >
              {downloadSuccess ? (
                <>
                  <Check className="w-4 h-4 text-emerald-600" />
                  <span className="text-emerald-700">Downloaded Customer ID Slip</span>
                </>
              ) : (
                <>
                  <Download className="w-4 h-4 text-[#0a2540]" />
                  <span>Download Customer Profile & KYC Slip</span>
                </>
              )}
            </button>

            <button
              onClick={() => {
                onClose();
                onLogout();
              }}
              className="w-full py-3 px-4 rounded-xl bg-rose-50 hover:bg-rose-100 border border-rose-200 text-rose-700 font-black uppercase tracking-wider text-xs flex items-center justify-center gap-2 transition active:scale-98 shadow-2xs"
            >
              <LogOut className="w-4 h-4" />
              <span>Log Out of Mobile Banking</span>
            </button>
          </div>

          {/* Security Footer */}
          <div className="pt-2 border-t border-slate-100 flex items-center justify-center gap-2 text-[10px] text-slate-400 font-bold">
            <Lock className="w-3 h-3 text-[#0a2540]" />
            <span>Axis Bank CC VIP CBS 256-bit Encrypted Banking Session • RBI Licensed</span>
          </div>
        </div>
      </div>
    </div>
  );
};
