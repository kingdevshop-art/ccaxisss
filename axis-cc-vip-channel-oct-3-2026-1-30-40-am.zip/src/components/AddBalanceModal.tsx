import React, { useState } from 'react';
import {
  X,
  PlusCircle,
  Landmark,
  CreditCard,
  Zap,
  CheckCircle2,
  AlertCircle,
  IndianRupee,
  ShieldCheck,
  Smartphone,
  Building,
  ArrowRight,
  MessageSquare,
  Lock,
} from 'lucide-react';
import { UserProfile, LanguageCode } from '../types';
import { TRANSLATIONS } from '../i18n/translations';

interface AddBalanceModalProps {
  isOpen: boolean;
  onClose: () => void;
  user: UserProfile;
  language: LanguageCode;
  onAddBalance: (
    accountType: 'savings' | 'wallet' | 'upiLite',
    amount: number,
    paymentMethod: string,
    reference?: string
  ) => void;
}

export const AddBalanceModal: React.FC<AddBalanceModalProps> = ({
  isOpen,
  onClose,
  user,
  language,
  onAddBalance,
}) => {
  const [targetAccount, setTargetAccount] = useState<'savings' | 'wallet' | 'upiLite'>('savings');
  const [amount, setAmount] = useState<string>('1000');
  const [paymentMethod, setPaymentMethod] = useState<'UPI' | 'NETBANKING' | 'CASH_COUNTER'>('UPI');
  const [isProcessing, setIsProcessing] = useState(false);
  const [successInfo, setSuccessInfo] = useState<{
    amount: number;
    account: string;
    ref: string;
  } | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  if (!isOpen) return null;

  const t = TRANSLATIONS[language] || TRANSLATIONS.en;

  const getAccountLabel = (type: 'savings' | 'wallet' | 'upiLite') => {
    switch (type) {
      case 'savings':
        return `Axis VIP Savings A/c (•••• ${user.accountNumber.slice(-4)})`;
      case 'wallet':
        return 'Prepaid Digital Wallet';
      case 'upiLite':
        return 'UPI Lite (Zero PIN Wallet)';
    }
  };

  const getAccountCurrentBal = (type: 'savings' | 'wallet' | 'upiLite') => {
    switch (type) {
      case 'savings':
        return user.savingsBalance;
      case 'wallet':
        return user.walletBalance;
      case 'upiLite':
        return user.upiLiteBalance;
    }
  };

  const presetAmounts = targetAccount === 'upiLite' ? [200, 500, 1000, 2000] : [500, 1000, 2000, 5000];

  const handleDeposit = () => {
    setErrorMsg('Customer self-deposits are disabled. Under banking regulations, balance deposits can only be credited by authorized Branch Officers at the bank counter or via inward bank transfer.');
    return;
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-slate-950/70 backdrop-blur-xs animate-in fade-in">
      <div className="bg-white rounded-3xl w-full max-w-md border border-slate-200 overflow-hidden shadow-2xl flex flex-col">
        {/* Header */}
        <div className="bg-gradient-to-r from-[#071d34] via-[#0a2540] to-[#0d2e53] text-white p-4 sm:p-5 flex items-center justify-between border-b border-[#143d6b]">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-xl bg-amber-400 text-slate-950 flex items-center justify-center shadow-md">
              <PlusCircle className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-sm font-black uppercase tracking-wider text-white">
                Add Balance / Deposit
              </h2>
              <p className="text-[11px] text-amber-200 font-bold">
                Instant Credit • Twilio SMS Alert Guaranteed
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-full bg-white/10 hover:bg-white/20 text-slate-300 hover:text-white transition"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content */}
        {successInfo ? (
          <div className="p-6 text-center space-y-3 animate-in zoom-in-95">
            <div className="w-14 h-14 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mx-auto shadow-inner">
              <CheckCircle2 className="w-8 h-8" />
            </div>
            <h3 className="text-lg font-black text-slate-900">
              ₹{successInfo.amount.toLocaleString('en-IN')} Credited Successfully!
            </h3>
            <p className="text-xs text-slate-600 font-medium">
              Added to <strong className="text-slate-800">{successInfo.account}</strong>
            </p>
            <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl text-left space-y-1 text-xs">
              <div className="flex justify-between text-slate-500">
                <span>Reference UTR:</span>
                <span className="font-mono font-bold text-slate-700">{successInfo.ref}</span>
              </div>
              <div className="flex justify-between items-center text-slate-500 pt-1 border-t border-slate-200/60">
                <span className="flex items-center gap-1 text-emerald-700 font-bold">
                  <MessageSquare className="w-3.5 h-3.5 text-emerald-600" />
                  SMS Dispatched:
                </span>
                <span className="font-mono font-bold text-slate-800">
                  {user.phone ? `+91 •••••••${user.phone.replace(/\D/g, '').slice(-3)}` : 'Registered Mobile'}
                </span>
              </div>
            </div>
          </div>
        ) : (
          <div className="p-4 sm:p-5 space-y-4">
            {/* Target Account Selection */}
            <div>
              <label className="text-[11px] font-black text-slate-500 uppercase tracking-wider block mb-1.5">
                Deposit Into Account
              </label>
              <div className="grid grid-cols-3 gap-2">
                <button
                  type="button"
                  onClick={() => setTargetAccount('savings')}
                  className={`p-2.5 rounded-xl border text-left transition flex flex-col justify-between ${
                    targetAccount === 'savings'
                      ? 'bg-blue-50/80 border-[#0a2540] text-[#0a2540] ring-1 ring-[#0a2540]'
                      : 'bg-slate-50 border-slate-200 text-slate-600 hover:bg-slate-100'
                  }`}
                >
                  <Landmark className="w-4 h-4 mb-1 text-blue-700" />
                  <span className="text-[11px] font-black leading-tight block">Savings</span>
                  <span className="text-[10px] font-mono font-bold text-slate-500">
                    ₹{user.savingsBalance.toLocaleString('en-IN', { maximumFractionDigits: 0 })}
                  </span>
                </button>

                <button
                  type="button"
                  onClick={() => setTargetAccount('wallet')}
                  className={`p-2.5 rounded-xl border text-left transition flex flex-col justify-between ${
                    targetAccount === 'wallet'
                      ? 'bg-amber-50/80 border-amber-600 text-amber-900 ring-1 ring-amber-600'
                      : 'bg-slate-50 border-slate-200 text-slate-600 hover:bg-slate-100'
                  }`}
                >
                  <CreditCard className="w-4 h-4 mb-1 text-amber-700" />
                  <span className="text-[11px] font-black leading-tight block">Wallet</span>
                  <span className="text-[10px] font-mono font-bold text-slate-500">
                    ₹{user.walletBalance.toLocaleString('en-IN', { maximumFractionDigits: 0 })}
                  </span>
                </button>

                <button
                  type="button"
                  onClick={() => setTargetAccount('upiLite')}
                  className={`p-2.5 rounded-xl border text-left transition flex flex-col justify-between ${
                    targetAccount === 'upiLite'
                      ? 'bg-emerald-50/80 border-emerald-600 text-emerald-900 ring-1 ring-emerald-600'
                      : 'bg-slate-50 border-slate-200 text-slate-600 hover:bg-slate-100'
                  }`}
                >
                  <Zap className="w-4 h-4 mb-1 text-emerald-600 fill-emerald-600" />
                  <span className="text-[11px] font-black leading-tight block">UPI Lite</span>
                  <span className="text-[10px] font-mono font-bold text-slate-500">
                    ₹{user.upiLiteBalance.toLocaleString('en-IN', { maximumFractionDigits: 0 })}
                  </span>
                </button>
              </div>
            </div>

            {/* Amount Input */}
            <div>
              <label className="text-[11px] font-black text-slate-500 uppercase tracking-wider block mb-1.5">
                Amount to Add
              </label>
              <div className="relative">
                <IndianRupee className="w-5 h-5 text-slate-400 absolute left-3 top-3" />
                <input
                  type="number"
                  value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                  placeholder="Enter amount"
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl pl-10 pr-4 py-2.5 text-base font-mono font-black text-slate-900 focus:outline-none focus:border-[#0a2540] focus:ring-1 focus:ring-[#0a2540]"
                />
              </div>

              {/* Preset buttons */}
              <div className="grid grid-cols-4 gap-2 mt-2">
                {presetAmounts.map((amt) => (
                  <button
                    key={amt}
                    type="button"
                    onClick={() => setAmount(String(amt))}
                    className={`py-1.5 rounded-lg text-xs font-black transition ${
                      amount === String(amt)
                        ? 'bg-[#0a2540] text-amber-300'
                        : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                    }`}
                  >
                    +₹{amt.toLocaleString('en-IN')}
                  </button>
                ))}
              </div>
            </div>

            {/* Payment Method / Clearing Mode */}
            <div>
              <label className="text-[11px] font-black text-slate-500 uppercase tracking-wider block mb-1.5">
                Funding Source
              </label>
              <div className="space-y-1.5">
                <label className="flex items-center gap-3 p-2.5 rounded-xl border border-slate-200 hover:bg-slate-50 cursor-pointer">
                  <input
                    type="radio"
                    name="method"
                    checked={paymentMethod === 'UPI'}
                    onChange={() => setPaymentMethod('UPI')}
                    className="w-4 h-4 text-[#0a2540]"
                  />
                  <div className="flex-1">
                    <p className="text-xs font-bold text-slate-800">Instant UPI Collect</p>
                    <p className="text-[10px] text-slate-500">Google Pay, PhonePe, BHIM, Paytm</p>
                  </div>
                </label>

                <label className="flex items-center gap-3 p-2.5 rounded-xl border border-slate-200 hover:bg-slate-50 cursor-pointer">
                  <input
                    type="radio"
                    name="method"
                    checked={paymentMethod === 'NETBANKING'}
                    onChange={() => setPaymentMethod('NETBANKING')}
                    className="w-4 h-4 text-[#0a2540]"
                  />
                  <div className="flex-1">
                    <p className="text-xs font-bold text-slate-800">Corporate NetBanking / Debit Card</p>
                    <p className="text-[10px] text-slate-500">Direct interbank instant clearing</p>
                  </div>
                </label>

                <label className="flex items-center gap-3 p-2.5 rounded-xl border border-slate-200 hover:bg-slate-50 cursor-pointer">
                  <input
                    type="radio"
                    name="method"
                    checked={paymentMethod === 'CASH_COUNTER'}
                    onChange={() => setPaymentMethod('CASH_COUNTER')}
                    className="w-4 h-4 text-[#0a2540]"
                  />
                  <div className="flex-1">
                    <p className="text-xs font-bold text-slate-800">CBS Cash Deposit Counter</p>
                    <p className="text-[10px] text-slate-500">Branch Cashier / Terminal Deposit</p>
                  </div>
                </label>
              </div>
            </div>

            {/* Error Message */}
            {errorMsg && (
              <div className="p-2.5 bg-rose-50 border border-rose-200 text-rose-700 text-xs font-bold rounded-xl flex items-center gap-2">
                <AlertCircle className="w-4 h-4 shrink-0" />
                <span>{errorMsg}</span>
              </div>
            )}

            {/* Registered Mobile Notice */}
            <div className="p-3 bg-amber-50/70 border border-amber-200/80 rounded-xl flex items-start gap-2.5 text-amber-950">
              <Smartphone className="w-4 h-4 text-amber-600 mt-0.5 shrink-0" />
              <div className="text-[11px] leading-tight">
                <p className="font-bold">Twilio SMS Transaction Alert Channel</p>
                <p className="text-amber-800 font-medium mt-0.5">
                  SMS will be delivered to registered number{' '}
                  <strong className="font-mono">
                    {user.phone ? user.phone : 'Not registered'}
                  </strong>
                </p>
              </div>
            </div>

            {/* Self-Deposit Restriction Notice */}
            <div className="p-3 bg-red-50 border border-red-200 text-red-950 rounded-xl flex items-start gap-2.5 text-xs">
              <Lock className="w-4 h-4 text-red-600 mt-0.5 shrink-0" />
              <div>
                <p className="font-bold text-red-900">User Self-Deposit Disabled</p>
                <p className="text-[11px] text-red-700 font-medium">
                  Customers cannot add money to their own accounts directly. Please visit your branch cash counter or ask an authorized Branch Officer to credit funds into your account ledger.
                </p>
              </div>
            </div>

            {/* Submit Button (Disabled) */}
            <button
              type="button"
              disabled
              className="w-full py-3 bg-slate-200 text-slate-500 font-black text-xs uppercase tracking-wider rounded-xl cursor-not-allowed flex items-center justify-center gap-2 select-none"
            >
              <Lock className="w-4 h-4 text-slate-400" />
              <span>Self-Deposit Disabled (Branch Only)</span>
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
