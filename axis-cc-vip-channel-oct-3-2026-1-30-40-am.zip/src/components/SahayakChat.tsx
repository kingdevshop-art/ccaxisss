import React, { useState, useRef, useEffect } from 'react';
import {
  MessageSquare,
  Send,
  Mic,
  Volume2,
  PhoneCall,
  ShieldAlert,
  Sparkles,
  HelpCircle,
  X,
  User,
  Bot,
  CheckCircle,
} from 'lucide-react';
import { UserProfile, LanguageCode } from '../types';
import { TRANSLATIONS } from '../i18n/translations';

interface Message {
  id: string;
  sender: 'user' | 'assistant';
  text: string;
  time: string;
}

interface SahayakChatProps {
  isOpen: boolean;
  onClose: () => void;
  user: UserProfile;
  language: LanguageCode;
  onInitiateTransferFromChat?: (amount?: number) => void;
  inline?: boolean;
}

export const SahayakChat: React.FC<SahayakChatProps> = ({
  isOpen,
  onClose,
  user,
  language,
  onInitiateTransferFromChat,
  inline = false,
}) => {
  if (!isOpen && !inline) return null;

  const t = TRANSLATIONS[language] || TRANSLATIONS.en;

  const initialGreeting =
    language === 'hi'
      ? `नमस्ते ${user.name}! मैं आपका एक्सिस बैंक सीसी वीआईपी सहायता मित्र हूँ। आपको बिजनेस लोन, क्रेडिट कार्ड, फंड ट्रांसफर या बैलेंस में सहायता चाहिए?`
      : `Hello ${user.name}! I am your Axis Bank CC VIP Concierge. How can I assist your business today? You can ask about Business Loans, VIP Credit Card, UPI/NEFT transfers, or corporate accounts.`;

  const [messages, setMessages] = useState<Message[]>([
    {
      id: 'm1',
      sender: 'assistant',
      text: initialGreeting,
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    },
  ]);

  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [isListening, setIsListening] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const speakText = (text: string) => {
    if (!('speechSynthesis' in window)) return;
    window.speechSynthesis.cancel();
    const utt = new SpeechSynthesisUtterance(text);
    utt.lang = language === 'hi' ? 'hi-IN' : 'en-IN';
    utt.rate = 0.95;
    window.speechSynthesis.speak(utt);
  };

  const handleSendMessage = async (textToSend?: string) => {
    const messageText = (textToSend || input).trim();
    if (!messageText) return;

    const userMsg: Message = {
      id: `usr_${Date.now()}`,
      sender: 'user',
      text: messageText,
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setMessages((prev) => [...prev, userMsg]);
    setInput('');
    setIsLoading(true);

    try {
      const res = await fetch('/api/gemini/sahayak', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: messageText,
          language: language === 'hi' ? 'Hindi' : 'English',
          context: {
            userName: user.name,
            savingsBalance: user.savingsBalance,
            upiId: user.upiId,
          },
        }),
      });

      const data = await res.json();
      const botMsg: Message = {
        id: `bot_${Date.now()}`,
        sender: 'assistant',
        text: data.reply || 'I am happy to assist you with Axis Bank CC VIP Corporate Banking.',
        time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };

      setMessages((prev) => [...prev, botMsg]);
      // Optional voice readout for elderly
      if (user.soundboxVoiceAlerts) {
        speakText(botMsg.text);
      }
    } catch (err) {
      const fallbackMsg: Message = {
        id: `bot_${Date.now()}`,
        sender: 'assistant',
        text:
          language === 'hi'
            ? 'फंड ट्रांसफर के लिए होम स्क्रीन पर "पैसे भेजें" या "स्कैन क्यूआर" बटन दबाएं। सहायता के लिए 1800-345-3000 पर कॉल करें।'
            : 'To transfer funds, tap "Send Money" or "Scan QR" on the dashboard. For support, call 1800-345-3000.',
        time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };
      setMessages((prev) => [...prev, fallbackMsg]);
    } finally {
      setIsLoading(false);
    }
  };

  // Voice speech-to-text simulation / Web Speech API
  const handleToggleVoiceInput = () => {
    const SpeechRecognition =
      (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;

    if (!SpeechRecognition) {
      alert('Speech recognition is not supported in this browser. Please type your query.');
      return;
    }

    try {
      const recognition = new SpeechRecognition();
      recognition.lang = language === 'hi' ? 'hi-IN' : 'en-IN';
      recognition.onstart = () => setIsListening(true);
      recognition.onresult = (e: any) => {
        const transcript = e.results[0][0].transcript;
        setInput(transcript);
        setIsListening(false);
        handleSendMessage(transcript);
      };
      recognition.onerror = () => setIsListening(false);
      recognition.onend = () => setIsListening(false);
      recognition.start();
    } catch (e) {
      setIsListening(false);
    }
  };

  const quickQuestions =
    language === 'hi'
      ? [
          'पैसे कैसे भेजें?',
          'मेरा बैलेंस कितना है?',
          'बिजली बिल कैसे भरें?',
          'संदिग्ध फोन कॉल की शिकायत करें',
          'यूपीआई पिन कैसे रीसेट करें?',
        ]
      : [
          'How do I send money?',
          'Check my account balance',
          'How to pay electricity bill?',
          'Report a suspicious scam call',
          'How to reset UPI PIN?',
        ];

  const content = (
    <div className={`w-full ${inline ? 'rounded-2xl border border-slate-200 h-[72vh] shadow-sm' : 'sm:max-w-lg rounded-t-3xl sm:rounded-3xl shadow-2xl h-[90vh] sm:h-[80vh] border border-slate-200'} bg-white text-slate-900 flex flex-col overflow-hidden animate-in fade-in duration-300`}>
      {/* Header */}
      <div className="p-4 bg-gradient-to-r from-[#071d34] via-[#0a2540] to-[#0d2e53] text-white flex items-center justify-between shadow-xs border-b border-[#143d6b]">
        <div className="flex items-center gap-2.5">
          <div className="w-10 h-10 rounded-2xl bg-white/10 border border-amber-400/40 text-amber-300 flex items-center justify-center font-black shadow-xs">
            <Bot className="w-6 h-6 text-amber-300" />
          </div>
          <div>
            <h3 className="font-black text-sm text-white flex items-center gap-1.5 uppercase tracking-wider">
              <span>{t.sahayakTitle}</span>
              <span className="bg-emerald-400 text-slate-950 text-[9px] px-1.5 py-0.2 rounded-full font-black uppercase">
                Online
              </span>
            </h3>
            <p className="text-[11px] text-slate-300 font-bold">
              {t.sahayakSubtitle}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <a
            href="tel:18003453000"
            className="px-2.5 py-1 rounded-full bg-white/10 hover:bg-white/20 text-white text-xs font-black uppercase tracking-wider flex items-center gap-1 border border-white/20 transition"
            title="Call Axis VIP Priority Helpline (1860-419-5555)"
          >
            <PhoneCall className="w-3.5 h-3.5 text-emerald-300" />
            <span>1800-345-3000</span>
          </a>
          {!inline && (
            <button
              onClick={onClose}
              className="p-1.5 rounded-full bg-white/10 hover:bg-white/20 text-white transition"
            >
              <X className="w-4 h-4" />
            </button>
          )}
        </div>
      </div>

        {/* Chat Message Stream */}
        <div className="flex-1 overflow-y-auto p-4 space-y-3 bg-slate-50">
          {messages.map((m) => {
            const isBot = m.sender === 'assistant';
            return (
              <div
                key={m.id}
                className={`flex gap-2.5 ${isBot ? 'justify-start' : 'justify-end'}`}
              >
                {isBot && (
                  <div className="w-7 h-7 rounded-xl bg-blue-100 border border-blue-200 text-[#0a2540] flex items-center justify-center flex-shrink-0 text-xs font-black mt-1">
                    सहायक
                  </div>
                )}
                <div
                  className={`max-w-[82%] rounded-2xl p-3.5 text-xs leading-relaxed relative ${
                    isBot
                      ? 'bg-white text-slate-900 border border-slate-200 shadow-2xs font-semibold'
                      : 'bg-[#0a2540] text-white font-bold shadow-md shadow-blue-950/20'
                  }`}
                >
                  <p className="text-[13px]">{m.text}</p>
                  <div className={`flex items-center justify-between mt-1.5 pt-1.5 border-t text-[10px] ${
                    isBot ? 'border-slate-100 text-slate-500 font-bold' : 'border-white/20 text-white/80 font-bold'
                  }`}>
                    <span>{m.time}</span>
                    {isBot && (
                      <button
                        onClick={() => speakText(m.text)}
                        className="text-[#0a2540] hover:text-[#071d34] flex items-center gap-0.5 font-black uppercase tracking-wider"
                      >
                        <Volume2 className="w-3 h-3" />
                        <span>Listen / सुनें</span>
                      </button>
                    )}
                  </div>
                </div>
              </div>
            );
          })}

          {isLoading && (
            <div className="flex items-center gap-2 text-xs text-[#0a2540] font-black uppercase tracking-wider p-2">
              <div className="w-3 h-3 border-2 border-[#0a2540] border-t-transparent rounded-full animate-spin" />
              <span>Axis Sahayak VIP is typing response...</span>
            </div>
          )}
          <div ref={messagesEndRef} />
        </div>

        {/* Quick Suggestion Chips */}
        <div className="px-3 py-2 bg-slate-100 border-t border-slate-200 flex gap-1.5 overflow-x-auto">
          {quickQuestions.map((q, idx) => (
            <button
              key={idx}
              onClick={() => handleSendMessage(q)}
              className="px-2.5 py-1 rounded-lg bg-white hover:bg-slate-200 text-slate-700 hover:text-slate-900 border border-slate-200 text-[11px] whitespace-nowrap font-black uppercase tracking-wider transition active:scale-95 shadow-2xs"
            >
              {q}
            </button>
          ))}
        </div>

        {/* Input Bar */}
        <div className="p-3 bg-white border-t border-slate-200 flex items-center gap-2">
          <button
            onClick={handleToggleVoiceInput}
            className={`p-2.5 rounded-xl border transition active:scale-95 ${
              isListening
                ? 'bg-[#0a2540] text-amber-300 border-[#0a2540] animate-pulse'
                : 'bg-slate-100 text-slate-700 border-slate-200 hover:bg-slate-200'
            }`}
            title="Speak into Microphone"
          >
            <Mic className="w-4 h-4" />
          </button>

          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleSendMessage()}
            placeholder={
              language === 'hi'
                ? 'अपना सवाल यहाँ पूछें (उदा. पैसे कैसे भेजें?)...'
                : 'Ask Axis Sahayak VIP anything in simple terms...'
            }
            className="flex-1 bg-slate-50 border border-slate-200 rounded-xl px-3.5 py-2.5 text-xs text-slate-900 font-bold placeholder-slate-400 focus:outline-none focus:border-[#0a2540]"
          />

          <button
            onClick={() => handleSendMessage()}
            disabled={!input.trim() || isLoading}
            className="p-2.5 rounded-xl bg-[#0a2540] hover:bg-[#071d34] text-white disabled:opacity-50 transition active:scale-95 shadow-md shadow-blue-950/20 font-black"
          >
            <Send className="w-4 h-4" />
          </button>
        </div>
      </div>
  );

  if (inline) {
    return content;
  }

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-xs flex items-end sm:items-center justify-center p-0 sm:p-4 animate-in fade-in">
      {content}
    </div>
  );
};
