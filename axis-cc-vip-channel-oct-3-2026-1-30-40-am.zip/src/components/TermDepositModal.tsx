import React, { useState } from 'react';
import {
  X,
  Landmark,
  TrendingUp,
  ShieldCheck,
  Calendar,
  CheckCircle2,
  Sparkles,
  Percent,
  IndianRupee,
  FileCheck,
} from 'lucide-react';
import { UserProfile, LanguageCode, SavingsPot } from '../types';

interface TermDepositModalProps {
  isOpen: boolean;
  onClose: () => void;
  user: UserProfile;
  language: LanguageCode;
  onOpenDeposit: (pot: SavingsPot, amount: number) => void;
}

export const TermDepositModal: React.FC<TermDepositModalProps> = ({
  isOpen,
  onClose,
  user,
  language,
  onOpenDeposit,
}) => {
  const [depositType, setDepositType] = useState<'FD' | 'RD' | 'KISAN'>('FD');
  const [principalAmount, setPrincipalAmount] = useState<number>(25000);
  const [tenureMonths, setTenureMonths] = useState<number>(12);
  const [successCert, setSuccessCert] = useState<{
    fdNumber: string;
    maturityAmount: number;
    interestEarned: number;
    maturityDate: string;
  } | null>(null);

  if (!isOpen) return null;

  // Senior citizen gets +0.50% extra interest
  const isSenior = user.seniorMode;
  let interestRate = 7.5;
  if (tenureMonths === 6) interestRate = 6.5;
  else if (tenureMonths === 12) interestRate = 7.5;
  else if (tenureMonths === 24) interestRate = 7.65;
  else if (tenureMonths === 36) interestRate = 7.8;
  else if (tenureMonths === 60) interestRate = 7.9;

  if (isSenior) interestRate += 0.5;

  // Calculate quarterly compound interest
  const years = tenureMonths / 12;
  const n = 4; // quarterly compounding
  const r = interestRate / 100;
  const maturityAmount = Math.round(principalAmount * Math.pow(1 + r / n, n * years));
  const interestEarned = maturityAmount - principalAmount;

  // Maturity Date
  const matDate = new Date();
  matDate.setMonth(matDate.getMonth() + tenureMonths);
  const formattedMatDate = matDate.toLocaleDateString('en-IN', {
    day: 'numeric',
    month: 'short',
    year: 'numeric',
  });

  const handleBookDeposit = () => {
    if (principalAmount > user.savingsBalance) {
      alert(`Insufficient savings balance. Available: ₹${user.savingsBalance.toLocaleString('en-IN')}`);
      return;
    }

    const newPotId = `fd_${Date.now()}`;
    const newPot: SavingsPot = {
      id: newPotId,
      title: depositType === 'KISAN' ? 'Kisan Sahayak Term Deposit' : `Axis VIP Fixed Deposit (${interestRate}% p.a.)`,
      targetAmount: maturityAmount,
      currentAmount: principalAmount,
      category: depositType === 'KISAN' ? 'Agriculture' : 'Term Deposit',
      interestRate,
      emoji: depositType === 'KISAN' ? '🌾' : '🏛️',
    };

    onOpenDeposit(newPot, principalAmount);

    setSuccessCert({
      fdNumber: `AXIS/FD/${Math.floor(100000000 + Math.random() * 900000000)}`,
      maturityAmount,
      interestEarned,
      maturityDate: formattedMatDate,
    });
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-slate-950/70 backdrop-blur-xs animate-in fade-in">
      <div className="bg-white rounded-3xl w-full max-w-lg border border-slate-200 overflow-hidden shadow-2xl flex flex-col max-h-[92vh]">
        {/* Header */}
        <div className="bg-gradient-to-r from-[#580824] via-[#861F41] to-[#97144D] text-white p-4 sm:p-5 flex items-center justify-between border-b border-amber-400/30">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-amber-400/20 border border-amber-400/40 flex items-center justify-center text-amber-300">
              <Landmark className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-sm font-black uppercase tracking-wider text-white">
                Axis VIP High-Yield Term Deposits
              </h2>
              <p className="text-[10px] text-amber-200 font-bold">
                RBI DICGC Insured • Axis Bank CC VIP Corporate HO
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-full bg-white/10 hover:bg-white/20 text-slate-300 hover:text-white transition"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content */}
        <div className="p-4 sm:p-6 space-y-4 overflow-y-auto">
          {successCert ? (
            /* Certificate of Deposit Success Card */
            <div className="bg-gradient-to-b from-emerald-50 to-white border-2 border-emerald-300 rounded-3xl p-6 text-center space-y-4 animate-in zoom-in-95">
              <div className="w-14 h-14 rounded-2xl bg-emerald-600 text-white flex items-center justify-center mx-auto shadow-md">
                <FileCheck className="w-8 h-8" />
              </div>
              <div className="space-y-1">
                <span className="text-[10px] font-black uppercase tracking-widest text-emerald-800 bg-emerald-100 px-2.5 py-0.5 rounded-full">
                  Certificate Generated
                </span>
                <h3 className="text-lg font-black text-slate-900">
                  Deposit Successfully Booked!
                </h3>
                <p className="text-xs font-mono font-bold text-slate-500">
                  A/c: {successCert.fdNumber}
                </p>
              </div>

              <div className="bg-white border border-emerald-200 rounded-2xl p-4 text-left space-y-2 text-xs">
                <div className="flex justify-between">
                  <span className="text-slate-500">Principal Deposited:</span>
                  <span className="font-black text-slate-900">₹{principalAmount.toLocaleString('en-IN')}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Interest Rate:</span>
                  <span className="font-black text-emerald-700">{interestRate}% p.a.</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Total Interest Earned:</span>
                  <span className="font-black text-emerald-600">+₹{successCert.interestEarned.toLocaleString('en-IN')}</span>
                </div>
                <div className="flex justify-between border-t border-slate-100 pt-2 text-sm">
                  <span className="font-black text-slate-900">Maturity Value:</span>
                  <span className="font-black text-emerald-700">₹{successCert.maturityAmount.toLocaleString('en-IN')}</span>
                </div>
                <div className="flex justify-between text-[11px]">
                  <span className="text-slate-500">Maturity Date:</span>
                  <span className="font-bold text-slate-700">{successCert.maturityDate}</span>
                </div>
              </div>

              <button
                onClick={onClose}
                className="w-full py-3 rounded-xl bg-[#0a2540] hover:bg-[#071d34] text-amber-300 font-black text-xs uppercase tracking-wider shadow-md transition active:scale-95"
              >
                Done & View in Reserves
              </button>
            </div>
          ) : (
            <>
              {/* Product Scheme Tabs */}
              <div className="grid grid-cols-3 gap-2">
                <button
                  type="button"
                  onClick={() => setDepositType('FD')}
                  className={`p-2.5 rounded-xl border text-center transition ${
                    depositType === 'FD'
                      ? 'bg-[#0a2540] text-amber-300 border-[#0a2540] shadow-sm'
                      : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                  }`}
                >
                  <p className="text-xs font-black uppercase">Fixed Deposit</p>
                  <p className="text-[10px] font-bold opacity-80">Up to 7.8%</p>
                </button>

                <button
                  type="button"
                  onClick={() => setDepositType('KISAN')}
                  className={`p-2.5 rounded-xl border text-center transition ${
                    depositType === 'KISAN'
                      ? 'bg-[#0a2540] text-amber-300 border-[#0a2540] shadow-sm'
                      : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                  }`}
                >
                  <p className="text-xs font-black uppercase">Kisan Sahayak</p>
                  <p className="text-[10px] font-bold opacity-80">Agri Benefit</p>
                </button>

                <button
                  type="button"
                  onClick={() => setDepositType('RD')}
                  className={`p-2.5 rounded-xl border text-center transition ${
                    depositType === 'RD'
                      ? 'bg-[#0a2540] text-amber-300 border-[#0a2540] shadow-sm'
                      : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                  }`}
                >
                  <p className="text-xs font-black uppercase">Recurring (RD)</p>
                  <p className="text-[10px] font-bold opacity-80">Monthly Plan</p>
                </button>
              </div>

              {/* Deposit Principal Amount */}
              <div className="space-y-2">
                <div className="flex justify-between items-center">
                  <label className="text-[11px] font-black uppercase tracking-wider text-slate-700">
                    Deposit Amount (₹)
                  </label>
                  <span className="text-[10px] text-slate-500 font-bold">
                    Available: ₹{user.savingsBalance.toLocaleString('en-IN')}
                  </span>
                </div>
                <div className="relative">
                  <IndianRupee className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
                  <input
                    type="number"
                    value={principalAmount}
                    onChange={(e) => setPrincipalAmount(Math.max(1000, Number(e.target.value)))}
                    className="w-full bg-slate-50 border border-slate-300 rounded-xl pl-9 pr-3 py-2.5 text-sm font-black text-slate-900 focus:outline-none focus:border-[#0a2540]"
                  />
                </div>
                <div className="flex gap-2">
                  {[10000, 25000, 50000, 100000].map((val) => (
                    <button
                      key={val}
                      type="button"
                      onClick={() => setPrincipalAmount(val)}
                      className={`flex-1 py-1 rounded-lg border text-[11px] font-bold uppercase transition ${
                        principalAmount === val
                          ? 'bg-slate-900 text-white border-slate-900'
                          : 'bg-white text-slate-600 border-slate-200 hover:bg-slate-100'
                      }`}
                    >
                      ₹{val / 1000}k
                    </button>
                  ))}
                </div>
              </div>

              {/* Tenure Selection */}
              <div className="space-y-1.5">
                <label className="text-[11px] font-black uppercase tracking-wider text-slate-700 block">
                  Select Tenure
                </label>
                <div className="grid grid-cols-4 gap-2">
                  {[
                    { m: 6, label: '6 Mos', rate: isSenior ? '7.0%' : '6.5%' },
                    { m: 12, label: '1 Year', rate: isSenior ? '8.0%' : '7.5%' },
                    { m: 24, label: '2 Years', rate: isSenior ? '8.15%' : '7.65%' },
                    { m: 36, label: '3 Years', rate: isSenior ? '8.3%' : '7.8%' },
                  ].map((ten) => (
                    <button
                      key={ten.m}
                      type="button"
                      onClick={() => setTenureMonths(ten.m)}
                      className={`p-2 rounded-xl border text-center transition ${
                        tenureMonths === ten.m
                          ? 'bg-[#0a2540] text-amber-300 border-[#0a2540] shadow-xs'
                          : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50'
                      }`}
                    >
                      <p className="text-xs font-black">{ten.label}</p>
                      <p className="text-[10px] font-bold text-emerald-600">{ten.rate}</p>
                    </button>
                  ))}
                </div>
              </div>

              {/* Live Yield Calculation Preview */}
              <div className="bg-gradient-to-br from-slate-900 to-[#0a2540] text-white rounded-2xl p-4 space-y-3 shadow-md">
                <div className="flex items-center justify-between border-b border-white/15 pb-2">
                  <span className="text-[10px] font-black uppercase tracking-wider text-amber-300 flex items-center gap-1">
                    <TrendingUp className="w-3.5 h-3.5" />
                    Guaranteed Corporate Yield
                  </span>
                  <span className="text-xs font-black text-amber-300">
                    {interestRate}% p.a.
                  </span>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <span className="text-[10px] text-slate-400 font-bold block">Interest Earned</span>
                    <p className="text-base sm:text-lg font-black text-emerald-400">
                      +₹{interestEarned.toLocaleString('en-IN')}
                    </p>
                  </div>
                  <div>
                    <span className="text-[10px] text-slate-400 font-bold block">Maturity Payout</span>
                    <p className="text-base sm:text-lg font-black text-white">
                      ₹{maturityAmount.toLocaleString('en-IN')}
                    </p>
                  </div>
                </div>

                <div className="flex justify-between text-[11px] text-slate-300 pt-1 border-t border-white/10">
                  <span>Matures on:</span>
                  <span className="font-bold text-amber-200">{formattedMatDate}</span>
                </div>
              </div>

              {/* Book Button */}
              <button
                onClick={handleBookDeposit}
                className="w-full py-3.5 rounded-2xl bg-amber-400 hover:bg-amber-300 text-slate-950 font-black uppercase tracking-wider text-xs shadow-md transition active:scale-95 flex items-center justify-center gap-2"
              >
                <Landmark className="w-4 h-4 text-slate-950" />
                <span>Book Deposit & Lock Yield</span>
              </button>
            </>
          )}
        </div>
      </div>
    </div>
  );
};
