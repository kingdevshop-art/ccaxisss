import React, { useState, useEffect } from 'react';
import {
  CreditCard,
  ShieldCheck,
  Eye,
  EyeOff,
  Copy,
  Check,
  Lock,
  Unlock,
  Globe,
  Radio,
  Sliders,
  Sparkles,
  Zap,
  Plus,
  RefreshCw,
  AlertCircle,
  HelpCircle,
  ChevronRight,
  Wifi,
  ExternalLink,
} from 'lucide-react';
import { UserProfile, VirtualDebitCard, VirtualDebitCardVariant } from '../types';
import {
  VIRTUAL_CARD_CONFIGS,
  createVirtualDebitCard,
  getDefaultVirtualCards,
} from '../utils/cardUtils';
import { AxisBankLogo } from './AxisBankLogo';
import { emailService } from '../services/emailService';

interface VirtualCardsManagerProps {
  user: UserProfile;
  onUpdateUser: (updatedUser: UserProfile) => void;
  onClose?: () => void;
}

export const VirtualCardsManager: React.FC<VirtualCardsManagerProps> = ({
  user,
  onUpdateUser,
  onClose,
}) => {
  // Ensure user has virtual cards or initialize default ones
  const userCards =
    user.virtualCards && user.virtualCards.length > 0
      ? user.virtualCards
      : getDefaultVirtualCards(user.name);

  const [cards, setCards] = useState<VirtualDebitCard[]>(userCards);
  const [selectedCardId, setSelectedCardId] = useState<string>(userCards[0]?.id || '');
  const [showSensitiveDetails, setShowSensitiveDetails] = useState<boolean>(false);
  const [cvvCountdown, setCvvCountdown] = useState<number>(0);
  const [copiedField, setCopiedField] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<'MANAGE' | 'APPLY_NEW' | 'BENEFITS'>('MANAGE');
  const [successMessage, setSuccessMessage] = useState<string>('');
  const [isSettingPin, setIsSettingPin] = useState<boolean>(false);
  const [newPin, setNewPin] = useState<string[]>(['', '', '', '']);

  const activeCard = cards.find((c) => c.id === selectedCardId) || cards[0];
  const activeConfig = activeCard ? VIRTUAL_CARD_CONFIGS[activeCard.variant] : VIRTUAL_CARD_CONFIGS.BURGUNDY_PRESTIGE;

  // Auto-hide CVV after 30 seconds
  useEffect(() => {
    let timer: any;
    if (showSensitiveDetails && cvvCountdown > 0) {
      timer = setTimeout(() => {
        setCvvCountdown((prev) => prev - 1);
      }, 1000);
    } else if (cvvCountdown === 0 && showSensitiveDetails) {
      setShowSensitiveDetails(false);
    }
    return () => clearTimeout(timer);
  }, [showSensitiveDetails, cvvCountdown]);

  const handleRevealToggle = () => {
    if (!showSensitiveDetails) {
      setShowSensitiveDetails(true);
      setCvvCountdown(30);
    } else {
      setShowSensitiveDetails(false);
      setCvvCountdown(0);
    }
  };

  const handleCopy = (text: string, field: string) => {
    navigator.clipboard.writeText(text.replace(/\s+/g, ''));
    setCopiedField(field);
    setTimeout(() => setCopiedField(null), 2000);
  };

  const updateCurrentCard = (updates: Partial<VirtualDebitCard>) => {
    if (!activeCard) return;
    const updatedCards = cards.map((c) =>
      c.id === activeCard.id ? { ...c, ...updates } : c
    );
    setCards(updatedCards);
    const updatedUser = { ...user, virtualCards: updatedCards };
    onUpdateUser(updatedUser);
  };

  // Toggle Card Freeze
  const handleToggleFreeze = () => {
    if (!activeCard) return;
    const newStatus = activeCard.status === 'ACTIVE' ? 'FROZEN' : 'ACTIVE';
    updateCurrentCard({ status: newStatus });
    setSuccessMessage(
      newStatus === 'FROZEN'
        ? 'Card frozen successfully. All online transactions are temporarily disabled.'
        : 'Card unfrozen. Online transactions are now active.'
    );
    setTimeout(() => setSuccessMessage(''), 3500);
  };

  // Issue / Apply for New Card Variant
  const handleIssueNewCard = (variant: VirtualDebitCardVariant) => {
    const existing = cards.find((c) => c.variant === variant);
    if (existing) {
      setSelectedCardId(existing.id);
      setActiveTab('MANAGE');
      setSuccessMessage(`You already hold an active ${existing.variantName}.`);
      setTimeout(() => setSuccessMessage(''), 3000);
      return;
    }

    const newCard = createVirtualDebitCard(user.name, variant);
    const updatedCards = [...cards, newCard];
    setCards(updatedCards);
    setSelectedCardId(newCard.id);
    setActiveTab('MANAGE');

    const updatedUser = { ...user, virtualCards: updatedCards };
    onUpdateUser(updatedUser);

    // Dispatch Virtual Card Activation Email
    emailService.sendVirtualCardEmail(user, newCard).catch((err) =>
      console.warn('[Virtual Card Email Notice]:', err)
    );

    setSuccessMessage(
      `Instant Issuance Approved! Your new ${newCard.variantName} is ready for transactions.`
    );
    setTimeout(() => setSuccessMessage(''), 4000);
  };

  // Set / Reset 4-Digit Debit Card PIN
  const handleSavePin = () => {
    const pinStr = newPin.join('');
    if (pinStr.length !== 4) return;
    updateCurrentCard({ pin: pinStr });
    setIsSettingPin(false);
    setNewPin(['', '', '', '']);
    setSuccessMessage('4-Digit Card PIN updated successfully.');
    setTimeout(() => setSuccessMessage(''), 3000);
  };

  return (
    <div className="bg-slate-950 border border-slate-800 rounded-3xl p-4 sm:p-6 text-white shadow-2xl relative overflow-hidden">
      {/* Background Graphic */}
      <div className="absolute top-0 right-0 w-80 h-80 bg-[#861F41]/15 rounded-full blur-3xl pointer-events-none" />

      {/* Header */}
      <div className="flex items-center justify-between pb-4 border-b border-slate-800 relative z-10">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-2xl bg-gradient-to-br from-[#861F41] to-[#580824] flex items-center justify-center border border-amber-400/30">
            <CreditCard className="w-5 h-5 text-amber-300" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-base sm:text-lg font-black tracking-tight text-white uppercase">
                Axis Virtual Debit Cards
              </h2>
              <span className="text-[10px] font-black text-amber-400 uppercase bg-[#861F41]/60 px-2 py-0.5 rounded border border-amber-400/40">
                VIP Desk
              </span>
            </div>
            <p className="text-[11px] text-slate-400">
              High-security digital debit cards with zero forex markup & instant controls
            </p>
          </div>
        </div>

        {onClose && (
          <button
            onClick={onClose}
            className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition"
          >
            ✕
          </button>
        )}
      </div>

      {/* Navigation Tabs */}
      <div className="flex items-center gap-2 mt-4 p-1 bg-slate-900 rounded-2xl border border-slate-800 text-xs">
        <button
          type="button"
          onClick={() => setActiveTab('MANAGE')}
          className={`flex-1 py-2 px-3 rounded-xl font-black uppercase tracking-wider transition ${
            activeTab === 'MANAGE'
              ? 'bg-[#861F41] text-amber-300 shadow-md border border-amber-400/30'
              : 'text-slate-400 hover:text-white'
          }`}
        >
          My Virtual Cards ({cards.length})
        </button>
        <button
          type="button"
          onClick={() => setActiveTab('APPLY_NEW')}
          className={`flex-1 py-2 px-3 rounded-xl font-black uppercase tracking-wider transition flex items-center justify-center gap-1.5 ${
            activeTab === 'APPLY_NEW'
              ? 'bg-[#861F41] text-amber-300 shadow-md border border-amber-400/30'
              : 'text-slate-400 hover:text-white'
          }`}
        >
          <Plus className="w-3.5 h-3.5 text-amber-400" />
          <span>Apply Card Variant</span>
        </button>
        <button
          type="button"
          onClick={() => setActiveTab('BENEFITS')}
          className={`flex-1 py-2 px-3 rounded-xl font-black uppercase tracking-wider transition ${
            activeTab === 'BENEFITS'
              ? 'bg-[#861F41] text-amber-300 shadow-md border border-amber-400/30'
              : 'text-slate-400 hover:text-white'
          }`}
        >
          Charges & Schedule
        </button>
      </div>

      {/* Success Banner */}
      {successMessage && (
        <div className="mt-3 p-3 bg-emerald-950/80 border border-emerald-500/50 rounded-2xl text-emerald-200 text-xs font-bold flex items-center gap-2 animate-in fade-in">
          <Check className="w-4 h-4 text-emerald-400 flex-shrink-0" />
          <span>{successMessage}</span>
        </div>
      )}

      {/* TAB 1: MANAGE CARDS */}
      {activeTab === 'MANAGE' && activeCard && (
        <div className="mt-4 space-y-6">
          {/* Card Carousel Selector */}
          {cards.length > 1 && (
            <div className="flex gap-2 overflow-x-auto pb-1 scrollbar-none">
              {cards.map((c) => (
                <button
                  key={c.id}
                  type="button"
                  onClick={() => setSelectedCardId(c.id)}
                  className={`px-3 py-2 rounded-xl text-xs font-bold whitespace-nowrap border transition ${
                    selectedCardId === c.id
                      ? 'bg-[#861F41] border-amber-400 text-amber-200 shadow-md'
                      : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-white'
                  }`}
                >
                  <span>{c.variantName.replace('Virtual Debit', '')}</span>
                  <span className="font-mono text-[10px] ml-1.5 opacity-80">
                    ••{c.cardNumber.slice(-4)}
                  </span>
                </button>
              ))}
            </div>
          )}

          {/* Realistic Virtual Debit Card Face */}
          <div className="relative max-w-md mx-auto">
            <div
              className={`w-full aspect-[1.586] rounded-3xl p-5 sm:p-6 shadow-2xl relative overflow-hidden flex flex-col justify-between border ${
                activeCard.status === 'FROZEN'
                  ? 'bg-slate-900 border-rose-500/50 grayscale-[0.6]'
                  : `bg-gradient-to-br ${activeConfig.gradientClass} border-amber-400/40`
              }`}
            >
              {/* Card Holographic Background Ornaments */}
              <div className="absolute top-0 right-0 w-56 h-56 bg-white/5 rounded-full blur-2xl pointer-events-none" />
              <div className="absolute bottom-0 left-0 w-44 h-44 bg-amber-400/10 rounded-full blur-xl pointer-events-none" />

              {/* Top Row */}
              <div className="flex items-center justify-between relative z-10">
                <div className="flex items-center gap-2">
                  <AxisBankLogo size={32} />
                  <div>
                    <span className="font-black text-xs sm:text-sm tracking-wider uppercase text-white block">
                      AXIS BANK
                    </span>
                    <span className="text-[9px] font-bold text-amber-300 uppercase tracking-widest block">
                      CC VIP DEBIT
                    </span>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <Wifi className="w-4 h-4 text-amber-300 rotate-90" />
                  <span
                    className={`text-[9px] font-black uppercase px-2 py-0.5 rounded border ${
                      activeCard.status === 'ACTIVE'
                        ? 'bg-emerald-950/80 text-emerald-300 border-emerald-500/50'
                        : 'bg-rose-950/80 text-rose-300 border-rose-500/50'
                    }`}
                  >
                    {activeCard.status}
                  </span>
                </div>
              </div>

              {/* EMV Chip & Contactless */}
              <div className="flex items-center justify-between my-2 relative z-10">
                <div className="w-11 h-8 rounded-lg bg-gradient-to-r from-amber-300 via-amber-200 to-amber-400 border border-amber-500/60 shadow-inner flex items-center justify-center">
                  <div className="w-8 h-5 border border-amber-600/50 rounded grid grid-cols-2" />
                </div>

                <button
                  type="button"
                  onClick={handleRevealToggle}
                  className="px-2.5 py-1 rounded-xl bg-black/40 hover:bg-black/60 border border-white/20 text-[10px] font-bold text-amber-300 flex items-center gap-1.5 transition backdrop-blur-xs"
                >
                  {showSensitiveDetails ? (
                    <>
                      <EyeOff className="w-3 h-3 text-amber-400" />
                      <span>Hide ({cvvCountdown}s)</span>
                    </>
                  ) : (
                    <>
                      <Eye className="w-3 h-3 text-amber-400" />
                      <span>View Card Details</span>
                    </>
                  )}
                </button>
              </div>

              {/* 16-Digit Card Number */}
              <div className="relative z-10">
                <div className="flex items-center justify-between">
                  <span className="text-[9px] text-amber-200/80 uppercase font-mono tracking-widest font-bold">
                    Virtual Card Number
                  </span>
                  <button
                    type="button"
                    onClick={() => handleCopy(activeCard.cardNumber, 'card')}
                    className="text-[10px] text-amber-300 hover:text-white flex items-center gap-1"
                  >
                    {copiedField === 'card' ? (
                      <>
                        <Check className="w-3 h-3 text-emerald-400" />
                        <span className="text-emerald-400">Copied</span>
                      </>
                    ) : (
                      <>
                        <Copy className="w-3 h-3" />
                        <span>Copy</span>
                      </>
                    )}
                  </button>
                </div>
                <div className="font-mono text-base sm:text-xl font-black tracking-widest text-white drop-shadow-md">
                  {showSensitiveDetails
                    ? activeCard.cardNumber
                    : `${activeCard.cardNumber.slice(0, 4)} •••• •••• ${activeCard.cardNumber.slice(-4)}`}
                </div>
              </div>

              {/* Bottom Row: Holder, Expiry, CVV, Network */}
              <div className="flex items-end justify-between relative z-10 pt-1">
                <div>
                  <span className="text-[8px] text-slate-300 uppercase block font-bold">
                    Card Holder
                  </span>
                  <span className="text-xs font-black uppercase text-white tracking-wider truncate max-w-[150px] block">
                    {activeCard.cardHolderName}
                  </span>
                </div>

                <div className="text-center">
                  <span className="text-[8px] text-slate-300 uppercase block font-bold">
                    Expires
                  </span>
                  <span className="font-mono text-xs font-black text-white">
                    {activeCard.expiryMonth}/{activeCard.expiryYear}
                  </span>
                </div>

                <div className="text-center">
                  <span className="text-[8px] text-amber-300 uppercase block font-bold">
                    CVV
                  </span>
                  <span className="font-mono text-xs font-black text-amber-300 bg-black/40 px-2 py-0.5 rounded border border-amber-400/30">
                    {showSensitiveDetails ? activeCard.cvv : '•••'}
                  </span>
                </div>

                <div className="text-right">
                  <span className="text-xs sm:text-sm font-black italic tracking-tighter text-white">
                    {activeCard.network.replace('_', ' ')}
                  </span>
                </div>
              </div>
            </div>
          </div>

          {/* Interactive Controls & Limit Sliders */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* Control Panel: Toggles */}
            <div className="p-4 bg-slate-900 rounded-2xl border border-slate-800 space-y-3.5">
              <div className="flex items-center justify-between pb-2 border-b border-slate-800">
                <span className="text-xs font-black uppercase tracking-wider text-slate-300">
                  Instant Payment Controls
                </span>
                <button
                  type="button"
                  onClick={handleToggleFreeze}
                  className={`px-3 py-1 rounded-xl text-xs font-black uppercase tracking-wider transition flex items-center gap-1.5 ${
                    activeCard.status === 'ACTIVE'
                      ? 'bg-rose-950 text-rose-300 border border-rose-500/50 hover:bg-rose-900'
                      : 'bg-emerald-950 text-emerald-300 border border-emerald-500/50 hover:bg-emerald-900'
                  }`}
                >
                  {activeCard.status === 'ACTIVE' ? (
                    <>
                      <Lock className="w-3.5 h-3.5" />
                      <span>Freeze Card</span>
                    </>
                  ) : (
                    <>
                      <Unlock className="w-3.5 h-3.5" />
                      <span>Unfreeze Card</span>
                    </>
                  )}
                </button>
              </div>

              {/* Online Transactions */}
              <div className="flex items-center justify-between">
                <div>
                  <span className="text-xs font-bold text-white block">Online / E-Commerce Transactions</span>
                  <span className="text-[10px] text-slate-400">Domestic shopping, bills & digital merchant payments</span>
                </div>
                <input
                  type="checkbox"
                  checked={activeCard.onlineTransactionsEnabled}
                  onChange={(e) =>
                    updateCurrentCard({ onlineTransactionsEnabled: e.target.checked })
                  }
                  className="w-4 h-4 rounded text-[#861F41] focus:ring-[#861F41] bg-slate-800 border-slate-700"
                />
              </div>

              {/* International Forex */}
              <div className="flex items-center justify-between">
                <div>
                  <span className="text-xs font-bold text-white block flex items-center gap-1.5">
                    <Globe className="w-3.5 h-3.5 text-amber-400" />
                    <span>International / Global Usage</span>
                  </span>
                  <span className="text-[10px] text-slate-400">Foreign currency & global digital services (Zero Forex Markup)</span>
                </div>
                <input
                  type="checkbox"
                  checked={activeCard.internationalUsageEnabled}
                  onChange={(e) =>
                    updateCurrentCard({ internationalUsageEnabled: e.target.checked })
                  }
                  className="w-4 h-4 rounded text-[#861F41] focus:ring-[#861F41] bg-slate-800 border-slate-700"
                />
              </div>

              {/* Contactless / NFC */}
              <div className="flex items-center justify-between">
                <div>
                  <span className="text-xs font-bold text-white block">Contactless / Tap & Pay</span>
                  <span className="text-[10px] text-slate-400">NFC phone payments & tokenized wallet checkout</span>
                </div>
                <input
                  type="checkbox"
                  checked={activeCard.contactlessEnabled}
                  onChange={(e) =>
                    updateCurrentCard({ contactlessEnabled: e.target.checked })
                  }
                  className="w-4 h-4 rounded text-[#861F41] focus:ring-[#861F41] bg-slate-800 border-slate-700"
                />
              </div>

              {/* Set PIN Trigger */}
              <div className="pt-2 border-t border-slate-800 flex items-center justify-between">
                <div>
                  <span className="text-xs font-bold text-white block">4-Digit ATM / Card PIN</span>
                  <span className="text-[10px] text-slate-400">Current PIN: {activeCard.pin || '1234'}</span>
                </div>
                <button
                  type="button"
                  onClick={() => setIsSettingPin(!isSettingPin)}
                  className="px-2.5 py-1 rounded-xl bg-slate-800 hover:bg-slate-700 text-amber-300 text-xs font-bold border border-slate-700"
                >
                  Change PIN
                </button>
              </div>

              {/* Inline PIN Editor */}
              {isSettingPin && (
                <div className="p-3 bg-slate-950 rounded-xl border border-amber-400/40 space-y-2 animate-in fade-in">
                  <span className="text-[11px] font-bold text-slate-300 block">Enter New 4-Digit Card PIN:</span>
                  <div className="flex gap-2">
                    {newPin.map((val, idx) => (
                      <input
                        key={idx}
                        id={`card-newpin-${idx}`}
                        type="password"
                        maxLength={1}
                        value={val}
                        onChange={(e) => {
                          const digit = e.target.value.replace(/\D/g, '');
                          const copy = [...newPin];
                          copy[idx] = digit;
                          setNewPin(copy);
                          if (digit && idx < 3) {
                            document.getElementById(`card-newpin-${idx + 1}`)?.focus();
                          }
                        }}
                        className="w-9 h-10 text-center font-mono font-black text-lg bg-slate-900 border border-slate-700 rounded-lg text-amber-300 focus:border-amber-400"
                      />
                    ))}
                    <button
                      type="button"
                      onClick={handleSavePin}
                      className="px-3 py-1.5 rounded-lg bg-amber-400 hover:bg-amber-300 text-slate-950 text-xs font-black uppercase transition ml-auto"
                    >
                      Save
                    </button>
                  </div>
                </div>
              )}
            </div>

            {/* Daily Transaction Limit Slider */}
            <div className="p-4 bg-slate-900 rounded-2xl border border-slate-800 space-y-4 flex flex-col justify-between">
              <div>
                <div className="flex items-center justify-between mb-1">
                  <span className="text-xs font-black uppercase tracking-wider text-slate-300">
                    Daily E-Commerce Limit
                  </span>
                  <span className="text-base font-black font-mono text-amber-300">
                    ₹{activeCard.dailyEcomLimit.toLocaleString('en-IN')}
                  </span>
                </div>
                <p className="text-[10px] text-slate-400 mb-3">
                  Maximum allowed transactions per calendar day for online shopping
                </p>

                <input
                  type="range"
                  min={5000}
                  max={activeCard.maxDailyLimit}
                  step={5000}
                  value={activeCard.dailyEcomLimit}
                  onChange={(e) =>
                    updateCurrentCard({ dailyEcomLimit: parseInt(e.target.value, 10) })
                  }
                  className="w-full h-2 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-[#861F41]"
                />

                <div className="flex justify-between text-[10px] text-slate-500 font-mono mt-1">
                  <span>Min: ₹5,000</span>
                  <span>Max: ₹{activeCard.maxDailyLimit.toLocaleString('en-IN')}</span>
                </div>
              </div>

              {/* Card Tier Benefits Summary */}
              <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 space-y-1.5">
                <span className="text-[10px] uppercase font-black text-amber-400 tracking-wider block">
                  {activeCard.variantName} Privileges
                </span>
                <ul className="text-[11px] text-slate-300 space-y-1">
                  {activeCard.benefits.slice(0, 3).map((b, idx) => (
                    <li key={idx} className="flex items-start gap-1.5">
                      <Sparkles className="w-3 h-3 text-amber-400 flex-shrink-0 mt-0.5" />
                      <span>{b}</span>
                    </li>
                  ))}
                </ul>
              </div>

              <div className="text-[10px] text-slate-400 flex items-center justify-between pt-2 border-t border-slate-800">
                <span>Annual Maintenance Fee:</span>
                <span className="font-bold text-white">{activeCard.feeScheduleText}</span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TAB 2: APPLY FOR NEW VIRTUAL CARD VARIANT */}
      {activeTab === 'APPLY_NEW' && (
        <div className="mt-4 space-y-4">
          <div className="text-center max-w-md mx-auto mb-2">
            <h3 className="text-sm font-black text-white uppercase tracking-wider">
              Issue an Additional Axis VIP Virtual Card
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">
              Select a specialized card tailored for shopping, luxury travel, or zero forex international spends.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
            {(Object.keys(VIRTUAL_CARD_CONFIGS) as VirtualDebitCardVariant[]).map((variantKey) => {
              const cfg = VIRTUAL_CARD_CONFIGS[variantKey];
              const isAlreadyHeld = cards.some((c) => c.variant === variantKey);

              return (
                <div
                  key={variantKey}
                  className={`p-4 rounded-2xl border transition relative overflow-hidden flex flex-col justify-between ${
                    isAlreadyHeld
                      ? 'bg-slate-900/60 border-slate-800 opacity-90'
                      : 'bg-slate-900 border-slate-800 hover:border-amber-400/50'
                  }`}
                >
                  <div>
                    <div className="flex items-center justify-between mb-2">
                      <span className="font-black text-xs sm:text-sm text-white">{cfg.name}</span>
                      <span className={`text-[9px] font-bold px-2 py-0.5 rounded border ${cfg.badgeColor}`}>
                        {cfg.network.replace('_', ' ')}
                      </span>
                    </div>

                    <div className="text-xs font-bold text-amber-400 font-mono mb-2">
                      {cfg.feeScheduleText}
                    </div>

                    <ul className="text-[11px] text-slate-300 space-y-1 mb-4">
                      {cfg.benefits.map((b, idx) => (
                        <li key={idx} className="flex items-start gap-1.5">
                          <Check className="w-3.5 h-3.5 text-emerald-400 flex-shrink-0 mt-0.5" />
                          <span>{b}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  <div>
                    {isAlreadyHeld ? (
                      <button
                        type="button"
                        onClick={() => {
                          const held = cards.find((c) => c.variant === variantKey);
                          if (held) setSelectedCardId(held.id);
                          setActiveTab('MANAGE');
                        }}
                        className="w-full py-2.5 rounded-xl bg-slate-800 text-slate-300 text-xs font-bold transition hover:bg-slate-700"
                      >
                        Active Card • View Controls
                      </button>
                    ) : (
                      <button
                        type="button"
                        onClick={() => handleIssueNewCard(variantKey)}
                        className="w-full py-2.5 rounded-xl bg-gradient-to-r from-amber-400 to-amber-500 hover:from-amber-300 text-slate-950 text-xs font-black uppercase tracking-wider transition active:scale-95 shadow-md flex items-center justify-center gap-1.5"
                      >
                        <Zap className="w-3.5 h-3.5 fill-slate-950" />
                        <span>Instant Issue & Activate</span>
                      </button>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* TAB 3: CHARGES & BENEFITS SCHEDULE */}
      {activeTab === 'BENEFITS' && (
        <div className="mt-4 space-y-4">
          <div className="p-4 bg-slate-900 rounded-2xl border border-slate-800 text-xs space-y-3">
            <h4 className="font-black text-amber-300 uppercase tracking-wider">
              Official Schedule of Charges & Fee Reversal Criteria
            </h4>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs border-collapse">
                <thead>
                  <tr className="border-b border-slate-800 text-[10px] text-slate-400 uppercase font-mono">
                    <th className="pb-2">Card Variant</th>
                    <th className="pb-2">Annual Fee</th>
                    <th className="pb-2">Daily E-Com Limit</th>
                    <th className="pb-2">Forex Markup</th>
                    <th className="pb-2">Lounge Access</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800 text-[11px]">
                  <tr>
                    <td className="py-2.5 font-bold text-white">Axis Burgundy Prestige</td>
                    <td className="py-2.5 font-mono text-amber-300">₹2,999 p.a. (Free for VIP)</td>
                    <td className="py-2.5 font-mono">₹10,00,000</td>
                    <td className="py-2.5 font-bold text-emerald-400">0% (Zero Forex)</td>
                    <td className="py-2.5">4 Visits / Quarter</td>
                  </tr>
                  <tr>
                    <td className="py-2.5 font-bold text-white">Axis Titanium Rewards</td>
                    <td className="py-2.5 font-mono text-amber-300">₹499 p.a. + GST</td>
                    <td className="py-2.5 font-mono">₹5,00,000</td>
                    <td className="py-2.5">2.5%</td>
                    <td className="py-2.5">Railway Lounge (2/yr)</td>
                  </tr>
                  <tr>
                    <td className="py-2.5 font-bold text-white">Axis Magnus Metal Elite</td>
                    <td className="py-2.5 font-mono text-amber-300">₹9,999 p.a. (Waived UHNW)</td>
                    <td className="py-2.5 font-mono">₹25,00,000</td>
                    <td className="py-2.5 font-bold text-emerald-400">1% (Discounted)</td>
                    <td className="py-2.5 text-amber-300 font-bold">Unlimited Domestic & Global</td>
                  </tr>
                  <tr>
                    <td className="py-2.5 font-bold text-white">Axis Neo Shopping Card</td>
                    <td className="py-2.5 font-mono text-emerald-400 font-bold">₹0 (Lifetime Free)</td>
                    <td className="py-2.5 font-mono">₹3,00,000</td>
                    <td className="py-2.5">3.5%</td>
                    <td className="py-2.5">Not Applicable</td>
                  </tr>
                </tbody>
              </table>
            </div>

            <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 text-[11px] text-slate-400 space-y-1">
              <p><strong>Fee Reversal:</strong> Titanium Rewards annual fee is 100% reversed if annual online spend exceeds ₹50,000.</p>
              <p><strong>Cyber Cover:</strong> All Axis Bank CC VIP Virtual Cards include zero liability protection upon immediate freeze via app.</p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
