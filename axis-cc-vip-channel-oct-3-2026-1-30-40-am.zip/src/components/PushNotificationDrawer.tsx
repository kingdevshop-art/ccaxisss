import React from 'react';
import {
  Bell,
  X,
  ShieldAlert,
  CheckCircle2,
  Sparkles,
  ArrowRight,
  Radio,
  Clock,
} from 'lucide-react';
import { PushAlert, LanguageCode } from '../types';

interface PushNotificationDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  alerts: PushAlert[];
  onMarkAllRead: () => void;
  onClearAlert: (id: string) => void;
}

export const PushNotificationDrawer: React.FC<PushNotificationDrawerProps> = ({
  isOpen,
  onClose,
  alerts,
  onMarkAllRead,
  onClearAlert,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-xs flex justify-end animate-in fade-in">
      <div className="w-full sm:max-w-md bg-white border-l border-slate-200 text-slate-900 h-full flex flex-col p-4 sm:p-5 shadow-2xl animate-in slide-in-from-right duration-300">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-slate-100">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-rose-50 border border-rose-200 flex items-center justify-center text-[#861F41]">
              <Bell className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-black text-sm text-slate-900 uppercase tracking-wider">
                Notifications & Alerts
              </h3>
              <p className="text-[10px] text-slate-500 font-bold">
                Axis Bank CC VIP Direct Alerts
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-full bg-slate-100 text-slate-400 hover:text-slate-900 hover:bg-slate-200 transition"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Action Controls */}
        <div className="flex items-center justify-between py-2.5 text-xs">
          <span className="text-slate-500 font-bold">
            {alerts.length} Total Notifications
          </span>
          <button
            onClick={onMarkAllRead}
            className="text-[#0a2540] font-black uppercase tracking-wider text-[11px] hover:underline"
          >
            Mark all as read
          </button>
        </div>

        {/* Alerts Stream */}
        <div className="flex-1 overflow-y-auto space-y-2.5 pr-1">
          {alerts.length === 0 ? (
            <div className="text-center py-12 text-slate-400 text-xs font-bold">
              No new alerts. Your account is secure.
            </div>
          ) : (
            alerts.map((alert) => {
              const isSecurity = alert.type === 'SECURITY';
              const isBroadcast = alert.type === 'ADMIN_BROADCAST';
              return (
                <div
                  key={alert.id}
                  className={`p-3.5 rounded-2xl border transition relative shadow-2xs ${
                    alert.read
                      ? 'bg-slate-50 border-slate-200'
                      : isSecurity
                      ? 'bg-rose-50 border-rose-300'
                      : isBroadcast
                      ? 'bg-blue-50 border-blue-300'
                      : 'bg-white border-slate-200'
                  }`}
                >
                  <div className="flex items-start justify-between gap-2">
                    <div className="flex items-center gap-2">
                      {isSecurity ? (
                        <ShieldAlert className="w-4 h-4 text-rose-600 flex-shrink-0" />
                      ) : isBroadcast ? (
                        <Radio className="w-4 h-4 text-[#0a2540] flex-shrink-0 animate-pulse" />
                      ) : (
                        <CheckCircle2 className="w-4 h-4 text-emerald-600 flex-shrink-0" />
                      )}
                      <p className="font-black text-xs text-slate-900">
                        {alert.title}
                      </p>
                    </div>
                    <button
                      onClick={() => onClearAlert(alert.id)}
                      className="text-slate-400 hover:text-slate-700 p-0.5"
                    >
                      <X className="w-3.5 h-3.5" />
                    </button>
                  </div>

                  <p className="text-xs text-slate-600 font-medium mt-1 leading-relaxed">
                    {alert.body}
                  </p>

                  <div className="flex items-center justify-between mt-2 pt-1.5 border-t border-slate-200/60 text-[10px] text-slate-400">
                    <span className="flex items-center gap-1 font-mono font-bold">
                      <Clock className="w-3 h-3" />
                      {alert.time}
                    </span>
                    <span className="font-black text-slate-700 uppercase tracking-wider">
                      {alert.type}
                    </span>
                  </div>
                </div>
              );
            })
          )}
        </div>
      </div>
    </div>
  );
};
