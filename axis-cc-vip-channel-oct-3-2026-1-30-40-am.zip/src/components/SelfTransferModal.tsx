import React, { useState } from 'react';
import {
  X,
  ArrowRightLeft,
  ShieldCheck,
  Zap,
  CreditCard,
  Landmark,
  CheckCircle2,
  AlertCircle,
  IndianRupee,
  ArrowDown,
} from 'lucide-react';
import { UserProfile, LanguageCode } from '../types';

interface SelfTransferModalProps {
  isOpen: boolean;
  onClose: () => void;
  user: UserProfile;
  language: LanguageCode;
  onTransfer: (from: 'SAVINGS' | 'WALLET' | 'UPI_LITE', to: 'SAVINGS' | 'WALLET' | 'UPI_LITE', amount: number) => void;
}

export const SelfTransferModal: React.FC<SelfTransferModalProps> = ({
  isOpen,
  onClose,
  user,
  language,
  onTransfer,
}) => {
  const [fromAccount, setFromAccount] = useState<'SAVINGS' | 'WALLET' | 'UPI_LITE'>('SAVINGS');
  const [toAccount, setToAccount] = useState<'SAVINGS' | 'WALLET' | 'UPI_LITE'>('UPI_LITE');
  const [amount, setAmount] = useState<string>('500');
  const [successMsg, setSuccessMsg] = useState<string | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  if (!isOpen) return null;

  const getBalance = (ac: 'SAVINGS' | 'WALLET' | 'UPI_LITE') => {
    switch (ac) {
      case 'SAVINGS':
        return user.savingsBalance;
      case 'WALLET':
        return user.walletBalance;
      case 'UPI_LITE':
        return user.upiLiteBalance;
    }
  };

  const getAccountLabel = (ac: 'SAVINGS' | 'WALLET' | 'UPI_LITE') => {
    switch (ac) {
      case 'SAVINGS':
        return `Axis VIP Savings A/c (•••• ${user.accountNumber.slice(-4)})`;
      case 'WALLET':
        return 'Prepaid Digital Wallet';
      case 'UPI_LITE':
        return 'UPI Lite (Zero PIN Wallet)';
    }
  };

  const handleSwap = () => {
    const temp = fromAccount;
    setFromAccount(toAccount);
    setToAccount(temp);
  };

  const handleExecuteTransfer = () => {
    setErrorMsg(null);
    const numAmount = parseFloat(amount);
    if (!numAmount || numAmount <= 0) {
      setErrorMsg('Please enter a valid transfer amount.');
      return;
    }

    if (fromAccount === toAccount) {
      setErrorMsg('Source and destination accounts must be different.');
      return;
    }

    const currentBal = getBalance(fromAccount);
    if (numAmount > currentBal) {
      setErrorMsg(`Insufficient balance in ${getAccountLabel(fromAccount)}. Available: ₹${currentBal.toFixed(2)}`);
      return;
    }

    if (toAccount === 'UPI_LITE' && (user.upiLiteBalance + numAmount) > 2000) {
      setErrorMsg('UPI Lite maximum limit is ₹2,000 as per RBI guidelines.');
      return;
    }

    onTransfer(fromAccount, toAccount, numAmount);
    setSuccessMsg(`Successfully transferred ₹${numAmount.toLocaleString('en-IN')}!`);
    setTimeout(() => {
      setSuccessMsg(null);
      onClose();
    }, 1500);
  };

  const presetAmounts = [200, 500, 1000, 2000];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-slate-950/70 backdrop-blur-xs animate-in fade-in">
      <div className="bg-white rounded-3xl w-full max-w-md border border-slate-200 overflow-hidden shadow-2xl flex flex-col">
        {/* Header */}
        <div className="bg-gradient-to-r from-[#071d34] via-[#0a2540] to-[#0d2e53] text-white p-4 sm:p-5 flex items-center justify-between border-b border-[#143d6b]">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-amber-400/20 border border-amber-400/40 flex items-center justify-center text-amber-300">
              <ArrowRightLeft className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-sm font-black uppercase tracking-wider text-white">
                Transfer Between Accounts
              </h2>
              <p className="text-[10px] text-amber-200 font-bold">
                Zero Charges • Instant Internal Clearing
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-full bg-white/10 hover:bg-white/20 text-slate-300 hover:text-white transition"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Form Body */}
        <div className="p-4 sm:p-5 space-y-4">
          {successMsg && (
            <div className="bg-emerald-50 border border-emerald-300 text-emerald-900 p-3 rounded-2xl flex items-center gap-2 text-xs font-bold animate-in fade-in">
              <CheckCircle2 className="w-4 h-4 text-emerald-600 flex-shrink-0" />
              <span>{successMsg}</span>
            </div>
          )}

          {errorMsg && (
            <div className="bg-rose-50 border border-rose-300 text-rose-900 p-3 rounded-2xl flex items-center gap-2 text-xs font-bold animate-in fade-in">
              <AlertCircle className="w-4 h-4 text-rose-600 flex-shrink-0" />
              <span>{errorMsg}</span>
            </div>
          )}

          {/* Transfer Flow Cards */}
          <div className="space-y-2 relative">
            {/* From Account */}
            <div className="bg-slate-50 border border-slate-200 rounded-2xl p-3.5 space-y-1">
              <div className="flex items-center justify-between text-[10px] font-black uppercase tracking-wider text-slate-500">
                <span>From Account</span>
                <span className="text-emerald-700 font-bold font-mono">
                  Bal: ₹{getBalance(fromAccount).toFixed(2)}
                </span>
              </div>
              <select
                value={fromAccount}
                onChange={(e) => setFromAccount(e.target.value as any)}
                className="w-full bg-white border border-slate-300 rounded-xl px-3 py-2 text-xs font-black text-slate-900 focus:outline-none focus:border-[#0a2540]"
              >
                <option value="SAVINGS">Savings Account (•••• {user.accountNumber.slice(-4)})</option>
                <option value="WALLET">Prepaid Digital Wallet</option>
                <option value="UPI_LITE">UPI Lite Zero-PIN Wallet</option>
              </select>
            </div>

            {/* Swap Button */}
            <div className="flex justify-center -my-2 relative z-10">
              <button
                type="button"
                onClick={handleSwap}
                className="w-8 h-8 rounded-full bg-[#0a2540] text-amber-300 border-2 border-white shadow-md flex items-center justify-center hover:scale-110 active:scale-95 transition"
                title="Swap Direction"
              >
                <ArrowDown className="w-4 h-4" />
              </button>
            </div>

            {/* To Account */}
            <div className="bg-slate-50 border border-slate-200 rounded-2xl p-3.5 space-y-1">
              <div className="flex items-center justify-between text-[10px] font-black uppercase tracking-wider text-slate-500">
                <span>To Account</span>
                <span className="text-emerald-700 font-bold font-mono">
                  Bal: ₹{getBalance(toAccount).toFixed(2)}
                </span>
              </div>
              <select
                value={toAccount}
                onChange={(e) => setToAccount(e.target.value as any)}
                className="w-full bg-white border border-slate-300 rounded-xl px-3 py-2 text-xs font-black text-slate-900 focus:outline-none focus:border-[#0a2540]"
              >
                <option value="UPI_LITE">UPI Lite Zero-PIN Wallet</option>
                <option value="WALLET">Prepaid Digital Wallet</option>
                <option value="SAVINGS">Savings Account (•••• {user.accountNumber.slice(-4)})</option>
              </select>
            </div>
          </div>

          {/* Amount Input */}
          <div className="space-y-1.5">
            <label className="text-[11px] font-black uppercase tracking-wider text-slate-700 block">
              Transfer Amount (₹)
            </label>
            <div className="relative">
              <IndianRupee className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
              <input
                type="number"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                placeholder="Enter amount"
                className="w-full bg-slate-50 border border-slate-300 rounded-xl pl-9 pr-3 py-2.5 text-sm font-black text-slate-900 focus:outline-none focus:border-[#0a2540]"
              />
            </div>

            {/* Preset Amount Chips */}
            <div className="flex gap-2 pt-1">
              {presetAmounts.map((amt) => (
                <button
                  key={amt}
                  type="button"
                  onClick={() => setAmount(amt.toString())}
                  className={`flex-1 py-1.5 rounded-lg border text-xs font-black uppercase transition active:scale-95 ${
                    amount === amt.toString()
                      ? 'bg-[#0a2540] text-amber-300 border-[#0a2540]'
                      : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-100'
                  }`}
                >
                  ₹{amt}
                </button>
              ))}
            </div>
          </div>

          <div className="bg-blue-50 border border-blue-200 rounded-2xl p-3 flex items-center gap-2 text-[11px] text-blue-900 font-medium">
            <ShieldCheck className="w-4 h-4 text-[#0a2540] flex-shrink-0" />
            <span>Instant intra-bank transfer. No UPI PIN required for self-account reallocations.</span>
          </div>

          {/* Action Submit */}
          <button
            onClick={handleExecuteTransfer}
            className="w-full py-3 rounded-2xl bg-[#0a2540] hover:bg-[#071d34] text-amber-300 font-black uppercase tracking-wider text-xs shadow-md shadow-blue-950/20 transition active:scale-95 flex items-center justify-center gap-2"
          >
            <ArrowRightLeft className="w-4 h-4" />
            <span>Transfer Instantly</span>
          </button>
        </div>
      </div>
    </div>
  );
};
