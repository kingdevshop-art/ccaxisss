import React, { useState } from 'react';
import {
  Search,
  ArrowDownLeft,
  ArrowUpRight,
  Download,
  Filter,
  CheckCircle2,
  Clock,
  AlertCircle,
  FileText,
  Share2,
  X,
  Volume2,
  Sparkles,
  Check,
} from 'lucide-react';
import { Transaction, LanguageCode } from '../types';
import { TRANSLATIONS } from '../i18n/translations';
import { speakSoundboxAlert } from '../utils/audioAlert';
import { TransactionReceiptModal } from './TransactionReceiptModal';
import { formatTransactionTimestamp } from '../utils/dateUtils';

interface PassbookViewProps {
  transactions: Transaction[];
  language: LanguageCode;
  onOpenReceipt?: (tx: Transaction) => void;
}

export const PassbookView: React.FC<PassbookViewProps> = ({
  transactions,
  language,
}) => {
  const [filterType, setFilterType] = useState<'ALL' | 'DEBIT' | 'CREDIT' | 'BILLS'>('ALL');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedTx, setSelectedTx] = useState<Transaction | null>(null);
  const [downloadSuccess, setDownloadSuccess] = useState(false);

  const t = TRANSLATIONS[language] || TRANSLATIONS.en;

  const filteredTransactions = transactions.filter((tx) => {
    // Filter type
    if (filterType === 'DEBIT' && tx.type !== 'debit') return false;
    if (filterType === 'CREDIT' && tx.type !== 'credit') return false;
    if (filterType === 'BILLS' && tx.category !== 'bills' && tx.category !== 'recharge')
      return false;

    // Search query
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      return (
        tx.title.toLowerCase().includes(q) ||
        tx.upiRefId.toLowerCase().includes(q) ||
        (tx.recipientVpa && tx.recipientVpa.toLowerCase().includes(q)) ||
        (tx.senderVpa && tx.senderVpa.toLowerCase().includes(q)) ||
        tx.amount.toString().includes(q)
      );
    }
    return true;
  });

  const handleDownloadStatement = () => {
    const csvHeader = 'Transaction ID,Date & Time,Type,Description,SubTitle,Payment Mode,Amount (INR),Status\n';
    const csvRows = transactions.map((tx) => {
      const formattedTime = formatTransactionTimestamp(tx.timestamp, tx.createdAt, tx.id);
      return `"${tx.upiRefId}","${formattedTime}","${tx.type.toUpperCase()}","${tx.title.replace(/"/g, '""')}","${tx.subTitle.replace(/"/g, '""')}","${tx.paymentMode}",${tx.amount.toFixed(2)},"${tx.status}"`;
    }).join('\n');

    const fullCsv = `AXIS BANK CC VIP - ACCOUNT STATEMENT\n` +
      `Generated Date: ${new Date().toLocaleDateString('en-IN')}\n` +
      `IFSC: UTIB000001 | Corporate VIP Banking Division\n\n` +
      csvHeader + csvRows;

    const blob = new Blob([fullCsv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `AXIS_VIP_Statement_${Date.now()}.csv`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);

    setDownloadSuccess(true);
    setTimeout(() => setDownloadSuccess(false), 3000);
  };

  return (
    <div className="bg-white border border-slate-200 rounded-2xl p-4 sm:p-5 text-slate-900 shadow-sm space-y-4">
      {/* Header & Controls */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-100">
        <div>
          <h2 className="text-sm font-black text-slate-900 uppercase tracking-wider flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-[#0a2540]" />
            {t.passbook}
          </h2>
          <p className="text-[11px] font-bold text-slate-500">
            Real-time Account Statement & UTR Tracker
          </p>
        </div>

        <div className="flex items-center gap-2">
          {downloadSuccess && (
            <span className="text-[10px] font-black text-emerald-700 bg-emerald-50 border border-emerald-200 px-2 py-1 rounded-lg flex items-center gap-1 animate-in fade-in">
              <Check className="w-3 h-3" />
              Statement CSV Saved!
            </span>
          )}
          <button
            onClick={handleDownloadStatement}
            className="self-start sm:self-auto px-3.5 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-800 border border-slate-200 text-xs font-black uppercase tracking-wider flex items-center gap-1.5 transition active:scale-95"
          >
            <Download className="w-3.5 h-3.5 text-[#0a2540]" />
            <span>Download Statement</span>
          </button>
        </div>
      </div>

      {/* Search Bar */}
      <div className="relative">
        <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
        <input
          type="text"
          placeholder="Search merchant, remark, UTR ref, or amount..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="w-full bg-slate-50 border border-slate-200 rounded-xl pl-10 pr-3 py-2 text-xs font-bold text-slate-900 placeholder-slate-400 focus:outline-none focus:border-[#0a2540]"
        />
      </div>

      {/* Filter Tabs */}
      <div className="flex gap-1.5 overflow-x-auto pb-1">
        {[
          { id: 'ALL', label: 'All Transactions' },
          { id: 'DEBIT', label: 'Debits (Paid)' },
          { id: 'CREDIT', label: 'Credits (Received)' },
          { id: 'BILLS', label: 'Bills & Recharges' },
        ].map((f) => (
          <button
            key={f.id}
            onClick={() => setFilterType(f.id as any)}
            className={`px-3 py-1.5 rounded-lg text-xs font-black uppercase tracking-wider whitespace-nowrap transition ${
              filterType === f.id
                ? 'bg-[#0a2540] text-amber-300 shadow-xs'
                : 'bg-slate-100 text-slate-600 hover:text-slate-900 border border-slate-200/80'
            }`}
          >
            {f.label}
          </button>
        ))}
      </div>

      {/* Transactions List */}
      <div className="space-y-2">
        {filteredTransactions.length === 0 ? (
          <div className="text-center py-8 text-slate-400 text-xs font-bold">
            No transactions found matching your filter criteria.
          </div>
        ) : (
          filteredTransactions.map((tx) => {
            const isCredit = tx.type === 'credit';
            return (
              <div
                key={tx.id}
                onClick={() => setSelectedTx(tx)}
                className="p-3.5 rounded-xl bg-slate-50 hover:bg-slate-100/90 border border-slate-200/80 transition flex items-center justify-between cursor-pointer group shadow-2xs"
              >
                <div className="flex items-center gap-3">
                  <div
                    className={`w-10 h-10 rounded-xl flex items-center justify-center font-bold ${
                      isCredit
                        ? 'bg-green-100 text-green-700 border border-green-200'
                        : 'bg-blue-50 text-[#0a2540] border border-blue-100'
                    }`}
                  >
                    {isCredit ? (
                      <ArrowDownLeft className="w-5 h-5" />
                    ) : (
                      <ArrowUpRight className="w-5 h-5" />
                    )}
                  </div>

                  <div>
                    <p className="font-black text-xs text-slate-900 group-hover:text-[#0a2540] transition">
                      {tx.title}
                    </p>
                    <p className="text-[10px] text-slate-500 font-bold uppercase tracking-tight">
                      {formatTransactionTimestamp(tx.timestamp, tx.createdAt, tx.id)} • {tx.paymentMode}
                    </p>
                  </div>
                </div>

                <div className="text-right">
                  <p
                    className={`text-sm font-black font-mono ${
                      isCredit ? 'text-green-600' : 'text-slate-900'
                    }`}
                  >
                    {isCredit ? '+' : '-'}₹
                    {tx.amount.toLocaleString('en-IN', {
                      minimumFractionDigits: 2,
                    })}
                  </p>
                  <span className="text-[9px] font-black text-emerald-700 uppercase tracking-widest bg-emerald-50 px-1.5 py-0.5 rounded border border-emerald-100">
                    {tx.status}
                  </span>
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* Transaction Receipt Modal */}
      <TransactionReceiptModal
        isOpen={!!selectedTx}
        onClose={() => setSelectedTx(null)}
        transaction={selectedTx}
        language={language}
      />
    </div>
  );
};
