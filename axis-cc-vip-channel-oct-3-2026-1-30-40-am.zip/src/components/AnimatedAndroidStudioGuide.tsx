import React, { useState, useEffect } from 'react';
import {
  Play,
  Pause,
  RotateCcw,
  SkipForward,
  SkipBack,
  CheckCircle2,
  Copy,
  Check,
  Smartphone,
  Terminal,
  FileCode,
  Layers,
  ShieldCheck,
  ExternalLink,
  Sparkles,
  Download,
  FolderOpen,
  ChevronRight,
  Maximize2,
  Minimize2,
  X,
  BookOpen,
} from 'lucide-react';

interface StepData {
  id: number;
  time: string;
  title: string;
  subtitle: string;
  badge: string;
  command?: string;
  targetFile?: string;
  description: string;
  actionPoints: string[];
  codeSnippet?: string;
  tip: string;
}

const STEPS: StepData[] = [
  {
    id: 1,
    time: '00:00 - 00:30',
    title: 'Download & Extract Project Code',
    subtitle: 'Get source code from AI Studio to your local machine',
    badge: 'Step 1 / 7',
    description:
      'In Google AI Studio, click the project menu in the top-right corner and select "Export as ZIP", or clone the repository to your desktop machine.',
    actionPoints: [
      'Export or clone the repository into your development folder (e.g. ~/Projects/axis-cc-vip-banking)',
      'Extract the ZIP file completely into a clean working directory',
      'Verify the presence of package.json, vite.config.ts, and src/',
    ],
    command: 'cd ~/Projects/axis-cc-vip-banking\nls -la',
    tip: 'Ensure Node.js (v18+ or v20+) and JDK 17 or JDK 21 are installed on your workstation.',
  },
  {
    id: 2,
    time: '00:30 - 01:15',
    title: 'Install Dependencies & Build Web Assets',
    subtitle: 'Generate optimized static assets in dist/ directory',
    badge: 'Step 2 / 7',
    description:
      'Before running Android Studio or Capacitor, you must build the single-page application distribution bundle containing all compiled HTML, JS, and CSS.',
    actionPoints: [
      'Run npm install to populate node_modules',
      'Execute npm run build to run Vite production compilation',
      'Ensure the dist/ directory is generated with index.html and assets/',
    ],
    command: 'npm install\nnpm run build',
    tip: 'Never skip the build step; Android Studio loads assets directly from this dist/ directory.',
  },
  {
    id: 3,
    time: '01:15 - 02:00',
    title: 'Initialize Capacitor & Add Android Platform',
    subtitle: 'Scaffold the native Android Studio project structure',
    badge: 'Step 3 / 7',
    description:
      'Capacitor bridges the modern React banking web application with native Android operating system APIs like BiometricPrompt, Camera, and Haptics.',
    actionPoints: [
      'Install @capacitor/core and @capacitor/cli',
      'Initialize project with your bank package name (e.g. com.axisbank.vipmobile)',
      'Install @capacitor/android and run npx cap add android to generate the android/ folder',
    ],
    command:
      'npm install @capacitor/core @capacitor/cli --save\nnpx cap init "Axis Bank CC VIP" "com.axisbank.vipmobile" --web-dir "dist"\nnpm install @capacitor/android --save\nnpx cap add android',
    tip: 'The pre-configured android/ folder in this repository already contains custom Kotlin biometric bridges and security configurations.',
  },
  {
    id: 4,
    time: '02:00 - 02:45',
    title: 'Install Native Biometrics & Hardware Plugins',
    subtitle: 'Enable hardware fingerprint scanner & camera for UPI QR scanning',
    badge: 'Step 4 / 7',
    description:
      'Banking security mandates hardware-backed biometric verification and camera controls. Capacitor plugins bridge these directly into React hooks.',
    actionPoints: [
      'Install @capacitor-community/biometric-auth for AndroidX BiometricPrompt',
      'Install @capacitor/camera for instant QR code payment scanner',
      'Run npx cap sync to link native Gradle dependencies into android/app/build.gradle',
    ],
    command:
      'npm install @capacitor-community/biometric-auth @capacitor/camera\nnpx cap sync',
    tip: 'Always run npx cap sync whenever you install a new Capacitor plugin or rebuild dist/.',
  },
  {
    id: 5,
    time: '02:45 - 03:30',
    title: 'Open in Android Studio & Sync Gradle',
    subtitle: 'Inspect AndroidManifest.xml and verify Java / Gradle JDK',
    badge: 'Step 5 / 7',
    description:
      'Open Android Studio. You can launch it directly from the terminal or manually select the android/ folder inside Android Studio.',
    actionPoints: [
      'Launch Android Studio by typing npx cap open android',
      'Wait for Gradle Sync to complete in the bottom status bar',
      'Ensure JDK 17 or JDK 21 is selected in Settings > Build, Execution > Build Tools > Gradle',
    ],
    command: 'npx cap open android',
    targetFile: 'android/app/src/main/AndroidManifest.xml',
    codeSnippet: `<!-- android/app/src/main/AndroidManifest.xml -->
<uses-permission android:name="android.permission.INTERNET" />
<uses-permission android:name="android.permission.ACCESS_NETWORK_STATE" />
<uses-permission android:name="android.permission.CAMERA" />
<uses-permission android:name="android.permission.USE_BIOMETRIC" />
<uses-permission android:name="android.permission.USE_FINGERPRINT" />`,
    tip: 'Check that usesCleartextTraffic="false" is set in the application tag for RBI security compliance.',
  },
  {
    id: 6,
    time: '03:30 - 04:15',
    title: 'Test on Physical Phone or Android Emulator',
    subtitle: 'Deploy debug build and test hardware features live',
    badge: 'Step 6 / 7',
    description:
      'Connect an Android smartphone via USB cable or start an Android Virtual Device (AVD) from Android Studio Device Manager.',
    actionPoints: [
      'Enable Developer Options and USB Debugging on your Android phone',
      'Select your connected phone from the top device dropdown in Android Studio',
      'Click the green Run (▶) button or press Shift + F10 to compile and launch',
    ],
    command: 'cd android\n./gradlew assembleDebug',
    tip: 'Test camera QR scanning and fingerprint unlock directly on physical hardware for realistic performance.',
  },
  {
    id: 7,
    time: '04:15 - 05:00',
    title: 'Generate Signed APK / Play Store Bundle (.AAB)',
    subtitle: 'Export production-ready release package for distribution',
    badge: 'Step 7 / 7',
    description:
      'Create the final cryptographically signed Android App Bundle (.aab) for Google Play Store upload or standalone APK for direct sideloading.',
    actionPoints: [
      'In Android Studio menu, click Build > Generate Signed Bundle / APK...',
      'Select Android App Bundle (.aab) for Play Store or APK for direct download',
      'Create or choose your bank release keystore (.jks) and set key aliases',
      'Select Release build variant, check V1 and V2 signatures, and click Finish',
    ],
    command: 'cd android\n./gradlew assembleRelease',
    codeSnippet: `# Release APK Location:
android/app/build/outputs/apk/release/app-release.apk

# Play Store Bundle Location:
android/app/build/outputs/bundle/release/app-release.aab`,
    tip: 'Store your release.jks keystore and passwords in a secure vault. You will need the exact same key to release future updates on Google Play.',
  },
];

interface AnimatedAndroidStudioGuideProps {
  isOpen: boolean;
  onClose: () => void;
}

export const AnimatedAndroidStudioGuide: React.FC<AnimatedAndroidStudioGuideProps> = ({
  isOpen,
  onClose,
}) => {
  const [currentStepIndex, setCurrentStepIndex] = useState(0);
  const [isPlaying, setIsPlaying] = useState(true);
  const [progress, setProgress] = useState(0); // 0 to 100%
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [playbackSpeed, setPlaybackSpeed] = useState<number>(1); // 1x, 1.5x, 2x

  const activeStep = STEPS[currentStepIndex];
  const stepDurationMs = 12000 / playbackSpeed; // 12 seconds per step at 1x

  // Auto-play timer loop simulating an interactive animated video player
  useEffect(() => {
    if (!isOpen || !isPlaying) return;

    const intervalMs = 100;
    const progressIncrement = (intervalMs / stepDurationMs) * 100;

    const timer = setInterval(() => {
      setProgress((prev) => {
        if (prev + progressIncrement >= 100) {
          // Move to next step or loop
          setCurrentStepIndex((cur) => (cur + 1 < STEPS.length ? cur + 1 : 0));
          return 0;
        }
        return prev + progressIncrement;
      });
    }, intervalMs);

    return () => clearInterval(timer);
  }, [isOpen, isPlaying, currentStepIndex, stepDurationMs]);

  if (!isOpen) return null;

  const handleSeekStep = (index: number) => {
    setCurrentStepIndex(index);
    setProgress(0);
  };

  const handleNextStep = () => {
    setCurrentStepIndex((prev) => (prev + 1 < STEPS.length ? prev + 1 : 0));
    setProgress(0);
  };

  const handlePrevStep = () => {
    setCurrentStepIndex((prev) => (prev > 0 ? prev - 1 : STEPS.length - 1));
    setProgress(0);
  };

  const handleCopy = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  // Overall progress calculation across all 7 steps
  const totalProgressPercent = Math.round(
    ((currentStepIndex + progress / 100) / STEPS.length) * 100
  );

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/80 backdrop-blur-sm p-2 sm:p-4 animate-in fade-in">
      <div
        className={`w-full bg-slate-900 rounded-3xl shadow-2xl border border-slate-700 text-white overflow-hidden flex flex-col transition-all duration-300 ${
          isFullscreen
            ? 'fixed inset-2 max-w-none max-h-none h-[calc(100vh-16px)]'
            : 'max-w-5xl max-h-[92vh]'
        }`}
      >
        {/* Top Video Player Bar */}
        <div className="bg-[#071728] px-4 py-3 sm:px-6 sm:py-3.5 flex items-center justify-between border-b border-slate-800">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-amber-400 text-slate-950 flex items-center justify-center font-black shadow-md flex-shrink-0">
              <Play className="w-5 h-5 fill-slate-950" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-black text-sm sm:text-base text-white uppercase tracking-wider">
                  Android Studio App Creation Guide
                </span>
                <span className="px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 text-[10px] font-black uppercase border border-emerald-400/30 flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping" />
                  Interactive Video
                </span>
              </div>
              <p className="text-xs text-slate-400 hidden sm:block">
                Step-by-step animated walkthrough to build, run, and export the native Android APK
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setIsFullscreen(!isFullscreen)}
              className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition"
              title={isFullscreen ? 'Exit Fullscreen' : 'Fullscreen'}
            >
              {isFullscreen ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
            </button>
            <button
              onClick={onClose}
              className="p-2 rounded-xl bg-slate-800 hover:bg-rose-900/60 text-slate-300 hover:text-white transition"
              title="Close Player"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Interactive Simulated Video Screen */}
        <div className="relative bg-slate-950 flex-1 overflow-hidden flex flex-col min-h-[380px]">
          {/* Simulated IDE / Studio Screen Backdrop */}
          <div className="absolute inset-0 bg-radial from-slate-900 via-slate-950 to-slate-950 opacity-90" />

          {/* IDE Window Frame */}
          <div className="relative flex-1 p-4 sm:p-6 overflow-y-auto flex flex-col justify-between space-y-4">
            {/* Header of Active Step */}
            <div className="space-y-2">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div className="flex items-center gap-2">
                  <span className="px-2.5 py-1 rounded-lg bg-amber-400 text-slate-950 font-black text-xs uppercase tracking-wider shadow-sm">
                    {activeStep.badge}
                  </span>
                  <span className="text-xs font-mono text-slate-400">
                    Timestamp: <strong className="text-amber-300">{activeStep.time}</strong>
                  </span>
                </div>
                <div className="text-xs font-mono text-slate-400">
                  Total Course: <strong className="text-white">{totalProgressPercent}% Complete</strong>
                </div>
              </div>

              <h2 className="text-xl sm:text-2xl font-black text-white tracking-tight flex items-center gap-2">
                <span>{activeStep.title}</span>
              </h2>
              <p className="text-xs sm:text-sm text-slate-300 font-medium">
                {activeStep.subtitle}
              </p>
            </div>

            {/* Visual Step Canvas / Studio Preview Box */}
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 my-2">
              {/* Left Column: Visual Action Breakdown */}
              <div className="lg:col-span-7 bg-slate-900/90 border border-slate-800 p-4 sm:p-5 rounded-2xl space-y-3 shadow-inner">
                <div className="flex items-center gap-2 text-xs font-black uppercase tracking-wider text-amber-400 border-b border-slate-800 pb-2">
                  <Sparkles className="w-4 h-4" />
                  <span>Interactive Action Checklist</span>
                </div>

                <p className="text-xs text-slate-200 leading-relaxed font-medium">
                  {activeStep.description}
                </p>

                <div className="space-y-2 pt-1">
                  {activeStep.actionPoints.map((point, idx) => (
                    <div
                      key={idx}
                      className="flex items-start gap-2.5 text-xs text-slate-300 font-medium bg-slate-950/60 p-2.5 rounded-xl border border-slate-800/80"
                    >
                      <CheckCircle2 className="w-4 h-4 text-emerald-400 flex-shrink-0 mt-0.5" />
                      <span>{point}</span>
                    </div>
                  ))}
                </div>

                {/* Pro-Tip Box */}
                <div className="bg-amber-400/10 border border-amber-400/20 p-3 rounded-xl flex items-start gap-2.5 text-xs text-amber-200">
                  <ShieldCheck className="w-4 h-4 text-amber-400 flex-shrink-0 mt-0.5" />
                  <div>
                    <strong className="font-bold text-amber-300">Banking Security Note:</strong>{' '}
                    <span>{activeStep.tip}</span>
                  </div>
                </div>
              </div>

              {/* Right Column: Terminal Command & Code Inspector */}
              <div className="lg:col-span-5 flex flex-col space-y-3">
                {activeStep.command && (
                  <div className="bg-black/90 border border-slate-800 rounded-2xl p-4 flex-1 flex flex-col justify-between font-mono text-xs">
                    <div>
                      <div className="flex items-center justify-between text-[11px] text-slate-400 border-b border-slate-800 pb-2 mb-2">
                        <span className="flex items-center gap-1.5 text-slate-300 font-bold uppercase tracking-wider">
                          <Terminal className="w-3.5 h-3.5 text-amber-400" />
                          Terminal Command
                        </span>
                        <button
                          onClick={() => handleCopy(activeStep.command!, `cmd_${activeStep.id}`)}
                          className="flex items-center gap-1 text-slate-400 hover:text-white px-2 py-1 rounded bg-slate-800 hover:bg-slate-700 transition"
                        >
                          {copiedId === `cmd_${activeStep.id}` ? (
                            <>
                              <Check className="w-3 h-3 text-emerald-400" />
                              <span className="text-[10px] text-emerald-400">Copied</span>
                            </>
                          ) : (
                            <>
                              <Copy className="w-3 h-3" />
                              <span className="text-[10px]">Copy</span>
                            </>
                          )}
                        </button>
                      </div>
                      <pre className="text-emerald-400 overflow-x-auto whitespace-pre-wrap leading-relaxed py-1">
                        {activeStep.command}
                      </pre>
                    </div>

                    <div className="text-[10px] text-slate-500 pt-2 border-t border-slate-800/80">
                      💡 Run this in your computer terminal inside project root
                    </div>
                  </div>
                )}

                {activeStep.codeSnippet && (
                  <div className="bg-black/90 border border-slate-800 rounded-2xl p-4 flex-1 font-mono text-xs">
                    <div className="flex items-center justify-between text-[11px] text-slate-400 border-b border-slate-800 pb-2 mb-2">
                      <span className="flex items-center gap-1.5 text-slate-300 font-bold uppercase tracking-wider">
                        <FileCode className="w-3.5 h-3.5 text-blue-400" />
                        {activeStep.targetFile || 'Code Snippet'}
                      </span>
                      <button
                        onClick={() => handleCopy(activeStep.codeSnippet!, `code_${activeStep.id}`)}
                        className="flex items-center gap-1 text-slate-400 hover:text-white px-2 py-1 rounded bg-slate-800 hover:bg-slate-700 transition"
                      >
                        {copiedId === `code_${activeStep.id}` ? (
                          <>
                            <Check className="w-3 h-3 text-emerald-400" />
                            <span className="text-[10px] text-emerald-400">Copied</span>
                          </>
                        ) : (
                          <>
                            <Copy className="w-3 h-3" />
                            <span className="text-[10px]">Copy</span>
                          </>
                        )}
                      </button>
                    </div>
                    <pre className="text-blue-300 overflow-x-auto whitespace-pre-wrap leading-relaxed text-[11px] max-h-40">
                      {activeStep.codeSnippet}
                    </pre>
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* Animated Progress Timeline Bar (Scrubber) */}
          <div className="relative w-full bg-slate-800 h-2 cursor-pointer group">
            <div
              className="h-full bg-gradient-to-r from-amber-500 via-amber-400 to-emerald-400 transition-all duration-100 ease-linear shadow-sm"
              style={{ width: `${totalProgressPercent}%` }}
            />
            {/* Step Markers */}
            <div className="absolute inset-0 flex justify-between px-1 pointer-events-none">
              {STEPS.map((s, idx) => (
                <div
                  key={s.id}
                  className={`w-1 h-full ${
                    idx <= currentStepIndex ? 'bg-white/40' : 'bg-slate-700'
                  }`}
                />
              ))}
            </div>
          </div>

          {/* Video Control Deck */}
          <div className="bg-[#071728] px-4 py-3 sm:px-6 flex flex-wrap items-center justify-between gap-3 border-t border-slate-800">
            {/* Playback Controls */}
            <div className="flex items-center gap-2 sm:gap-3">
              <button
                onClick={handlePrevStep}
                className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-white transition active:scale-95"
                title="Previous Step"
              >
                <SkipBack className="w-4 h-4" />
              </button>

              <button
                onClick={() => setIsPlaying(!isPlaying)}
                className="px-4 py-2 rounded-xl bg-amber-400 hover:bg-amber-300 text-slate-950 font-black text-xs uppercase tracking-wider flex items-center gap-2 shadow-md transition active:scale-95"
              >
                {isPlaying ? (
                  <>
                    <Pause className="w-4 h-4 fill-slate-950" />
                    <span>Pause</span>
                  </>
                ) : (
                  <>
                    <Play className="w-4 h-4 fill-slate-950" />
                    <span>Play</span>
                  </>
                )}
              </button>

              <button
                onClick={handleNextStep}
                className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-white transition active:scale-95"
                title="Next Step"
              >
                <SkipForward className="w-4 h-4" />
              </button>

              <button
                onClick={() => {
                  setCurrentStepIndex(0);
                  setProgress(0);
                  setIsPlaying(true);
                }}
                className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition"
                title="Restart From Step 1"
              >
                <RotateCcw className="w-4 h-4" />
              </button>
            </div>

            {/* Playback Speed Selector */}
            <div className="flex items-center gap-1 text-xs">
              <span className="text-slate-400 text-[11px] font-bold mr-1">Speed:</span>
              {[1, 1.5, 2].map((spd) => (
                <button
                  key={spd}
                  onClick={() => setPlaybackSpeed(spd)}
                  className={`px-2 py-1 rounded-lg text-xs font-bold transition ${
                    playbackSpeed === spd
                      ? 'bg-amber-400 text-slate-950 font-black'
                      : 'bg-slate-800 text-slate-400 hover:text-white'
                  }`}
                >
                  {spd}x
                </button>
              ))}
            </div>

            {/* Quick Step Buttons */}
            <div className="hidden md:flex items-center gap-1.5 overflow-x-auto">
              {STEPS.map((s, idx) => (
                <button
                  key={s.id}
                  onClick={() => handleSeekStep(idx)}
                  className={`px-2.5 py-1 rounded-lg text-xs font-bold transition whitespace-nowrap ${
                    idx === currentStepIndex
                      ? 'bg-amber-400 text-slate-950 font-black ring-2 ring-amber-300/40'
                      : idx < currentStepIndex
                      ? 'bg-emerald-950/80 text-emerald-400 border border-emerald-800/60'
                      : 'bg-slate-800 text-slate-400 hover:text-slate-200'
                  }`}
                >
                  {s.id}. {s.title.split(' ')[0]}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Bottom Documentation & Quick Resource Footer */}
        <div className="bg-[#050f1a] p-3 sm:p-4 border-t border-slate-800/80 flex flex-col sm:flex-row items-center justify-between gap-2 text-xs text-slate-400">
          <div className="flex items-center gap-2">
            <BookOpen className="w-4 h-4 text-amber-400 flex-shrink-0" />
            <span>
              Official Documentation: Read detailed instructions in{' '}
              <code className="text-amber-300 font-mono font-bold bg-slate-800 px-1.5 py-0.5 rounded">
                ANDROID_BUILD_GUIDE.md
              </code>
            </span>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => {
                const guideText = `# Axis Bank CC VIP Android App Build Cheat Sheet\n\n` +
                  STEPS.map(
                    (s) =>
                      `## ${s.badge}: ${s.title}\n${s.description}\n\nCommand:\n${s.command || 'N/A'}\n\n`
                  ).join('\n');
                handleCopy(guideText, 'full_guide');
              }}
              className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold flex items-center gap-1.5 transition active:scale-95"
            >
              {copiedId === 'full_guide' ? (
                <>
                  <Check className="w-3.5 h-3.5 text-emerald-400" />
                  <span className="text-emerald-400">Full Cheat Sheet Copied!</span>
                </>
              ) : (
                <>
                  <Copy className="w-3.5 h-3.5 text-amber-400" />
                  <span>Copy All Build Commands</span>
                </>
              )}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
