import React from 'react';

interface AxisBankLogoProps {
  className?: string;
  size?: 'xs' | 'sm' | 'md' | 'lg' | 'xl' | '2xl' | number;
  showText?: boolean;
  variant?: 'light' | 'dark';
}

export const AxisBankLogo: React.FC<AxisBankLogoProps> = ({
  className = '',
  size = 'md',
  showText = false,
  variant = 'light',
}) => {
  const sizeMap: Record<string, { className: string; px: number }> = {
    xs: { className: 'w-8 h-8 max-w-8 max-h-8', px: 32 },
    sm: { className: 'w-10 h-10 max-w-10 max-h-10', px: 40 },
    md: { className: 'w-12 h-12 max-w-12 max-h-12', px: 48 },
    lg: { className: 'w-16 h-16 max-w-16 max-h-16', px: 64 },
    xl: { className: 'w-24 h-24 max-w-24 max-h-24', px: 96 },
    '2xl': { className: 'w-32 h-32 max-w-32 max-h-32', px: 128 },
  };

  const isNumber = typeof size === 'number';
  const sizeConfig = !isNumber && sizeMap[size] ? sizeMap[size] : null;
  const pixelDim = isNumber ? size : sizeConfig ? sizeConfig.px : 48;
  const tailwindClass = sizeConfig ? sizeConfig.className : '';

  return (
    <div className={`inline-flex items-center gap-2.5 flex-shrink-0 ${className}`}>
      <div
        style={{
          width: `${pixelDim}px`,
          height: `${pixelDim}px`,
          maxWidth: `${pixelDim}px`,
          maxHeight: `${pixelDim}px`,
          minWidth: `${pixelDim}px`,
          minHeight: `${pixelDim}px`,
        }}
        className={`relative flex items-center justify-center flex-shrink-0 rounded-2xl overflow-hidden shadow-sm shadow-[#861F41]/30 ${tailwindClass}`}
      >
        <svg
          viewBox="0 0 120 120"
          className="w-full h-full object-contain filter drop-shadow-[0_2px_6px_rgba(0,0,0,0.3)] transition-transform group-hover:scale-105"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
        >
          <defs>
            <linearGradient id="axis_bg_sym" x1="0" y1="0" x2="120" y2="120" gradientUnits="userSpaceOnUse">
              <stop stopColor="#97144D" />
              <stop offset="0.5" stopColor="#861F41" />
              <stop offset="1" stopColor="#580824" />
            </linearGradient>
            <linearGradient id="gold_accent_sym" x1="0" y1="0" x2="1" y2="1">
              <stop offset="0%" stopColor="#FDE047" />
              <stop offset="50%" stopColor="#EAB308" />
              <stop offset="100%" stopColor="#CA8A04" />
            </linearGradient>
          </defs>
          <rect width="120" height="120" rx="26" fill="url(#axis_bg_sym)" />
          <rect x="2" y="2" width="116" height="116" rx="24" stroke="url(#gold_accent_sym)" strokeWidth="1.5" strokeOpacity="0.5" />
          <path d="M60 18L96 82H74L60 55L46 82H24L60 18Z" fill="#FFFFFF" />
          <path d="M60 22L76 56H44L60 22Z" fill="url(#gold_accent_sym)" />
          <path d="M52 64H68L60 49L52 64Z" fill="#861F41" />
          <g transform="translate(60, 99)">
            <text textAnchor="middle" y="4" fontFamily="-apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif" fontSize="11" fontWeight="900" fill="#FDE047" letterSpacing="2">
              CC VIP
            </text>
          </g>
        </svg>
      </div>

      {showText && (
        <div className="leading-tight">
          <div className="flex items-center gap-1.5">
            <span className={`font-black text-base tracking-tight uppercase ${variant === 'dark' ? 'text-slate-900' : 'text-white'}`}>
              AXIS BANK
            </span>
            <span className="text-[10px] font-black text-amber-300 uppercase tracking-wider bg-[#861F41] border border-amber-400/40 px-2 py-0.5 rounded shadow-2xs">
              CC VIP
            </span>
          </div>
          <span className={`text-[9px] uppercase tracking-widest font-bold block mt-0.5 ${variant === 'dark' ? 'text-slate-500' : 'text-amber-100/80'}`}>
            Mobile Banking & Corporate VIP Portal
          </span>
        </div>
      )}
    </div>
  );
};

// Aliased export for compatibility
export { AxisBankLogo as AxisVipLogo };
export default AxisBankLogo;
