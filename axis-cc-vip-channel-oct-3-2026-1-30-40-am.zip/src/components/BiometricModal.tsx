import React, { useState } from 'react';
import {
  Fingerprint,
  ShieldCheck,
  CheckCircle2,
  X,
  Sliders,
  Sparkles,
  Smartphone,
  Lock,
} from 'lucide-react';
import { UserProfile, LanguageCode } from '../types';
import { TRANSLATIONS } from '../i18n/translations';

interface BiometricModalProps {
  isOpen: boolean;
  onClose: () => void;
  user: UserProfile;
  language: LanguageCode;
  onUpdateBiometrics: (enabled: boolean, limit: number) => void;
}

export const BiometricModal: React.FC<BiometricModalProps> = ({
  isOpen,
  onClose,
  user,
  language,
  onUpdateBiometrics,
}) => {
  if (!isOpen) return null;

  const [enabled, setEnabled] = useState(user.biometricEnabled);
  const [limit, setLimit] = useState(user.biometricLimit || 5000);
  const [isScanning, setIsScanning] = useState(false);
  const [scannedSuccess, setScannedSuccess] = useState(false);
  const t = TRANSLATIONS[language] || TRANSLATIONS.en;

  const handleSimulateScan = () => {
    setIsScanning(true);
    setScannedSuccess(false);
    setTimeout(() => {
      setIsScanning(false);
      setScannedSuccess(true);
      setTimeout(() => {
        setScannedSuccess(false);
      }, 2000);
    }, 1200);
  };

  const handleSave = () => {
    onUpdateBiometrics(enabled, limit);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-xs flex items-end sm:items-center justify-center p-0 sm:p-4 animate-in fade-in">
      <div className="w-full sm:max-w-md bg-white border border-slate-200 text-slate-900 rounded-t-3xl sm:rounded-3xl p-5 sm:p-6 shadow-2xl relative animate-in slide-in-from-bottom duration-300">
        <div className="flex items-center justify-between pb-3 border-b border-slate-100">
          <div className="flex items-center gap-2">
            <div className="w-9 h-9 rounded-xl bg-blue-50 border border-blue-200 flex items-center justify-center text-[#0a2540]">
              <Fingerprint className="w-5 h-5 text-[#0a2540]" />
            </div>
            <div>
              <h3 className="font-black text-sm text-slate-900 uppercase tracking-wider">
                {t.biometricTitle}
              </h3>
              <p className="text-[11px] text-slate-500 font-bold">
                Fingerprint & Face ID Touch Pay
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-full bg-slate-100 text-slate-500 hover:text-slate-900 hover:bg-slate-200 transition"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Interactive Biometric Sensor Touch Pad */}
        <div className="my-5 text-center">
          <div
            onClick={handleSimulateScan}
            className={`relative w-28 h-28 mx-auto rounded-full flex items-center justify-center cursor-pointer transition-all duration-300 select-none ${
              scannedSuccess
                ? 'bg-emerald-50 border-2 border-emerald-500 scale-105 shadow-lg shadow-emerald-500/20'
                : isScanning
                ? 'bg-blue-50 border-2 border-[#0a2540] scale-105 shadow-lg shadow-blue-500/20'
                : 'bg-slate-50 border-2 border-slate-200 hover:border-[#0a2540]/60'
            }`}
          >
            {/* Ripple rings */}
            {isScanning && (
              <div className="absolute inset-0 rounded-full border-2 border-[#0a2540] animate-ping opacity-75" />
            )}

            {scannedSuccess ? (
              <CheckCircle2 className="w-12 h-12 text-emerald-600 animate-in zoom-in-50" />
            ) : (
              <Fingerprint
                className={`w-14 h-14 transition-colors ${
                  isScanning ? 'text-[#0a2540] animate-pulse' : 'text-slate-400'
                }`}
              />
            )}
          </div>

          <p className="text-xs font-black uppercase tracking-wider text-slate-700 mt-3">
            {scannedSuccess
              ? 'Biometric Verified Successfully!'
              : isScanning
              ? 'Scanning Fingerprint Sensor...'
              : 'Tap to test biometric sensor simulation'}
          </p>
        </div>

        {/* Toggle Controls */}
        <div className="space-y-3.5">
          <div className="flex items-center justify-between p-3.5 rounded-xl bg-slate-50 border border-slate-200 shadow-2xs">
            <div>
              <p className="text-xs font-black text-slate-900 uppercase tracking-wider">
                Enable 1-Touch Biometrics
              </p>
              <p className="text-[11px] text-slate-500 font-bold">
                Unlock app & approve UPI payments without PIN
              </p>
            </div>
            <label className="relative inline-flex items-center cursor-pointer">
              <input
                type="checkbox"
                checked={enabled}
                onChange={(e) => setEnabled(e.target.checked)}
                className="sr-only peer"
              />
              <div className="w-11 h-6 bg-slate-300 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-[#0a2540]" />
            </label>
          </div>

          {/* Limit Slider */}
          {enabled && (
            <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 space-y-2.5 shadow-2xs">
              <div className="flex items-center justify-between text-xs">
                <span className="text-slate-700 font-black uppercase tracking-wider flex items-center gap-1">
                  <Sliders className="w-3.5 h-3.5 text-[#0a2540]" />
                  Max PIN-less Biometric Limit
                </span>
                <span className="font-black text-[#0a2540] font-sans text-sm">
                  ₹{limit.toLocaleString('en-IN')}
                </span>
              </div>
              <input
                type="range"
                min="500"
                max="10000"
                step="500"
                value={limit}
                onChange={(e) => setLimit(parseInt(e.target.value))}
                className="w-full h-1.5 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-[#0a2540]"
              />
              <p className="text-[10px] text-slate-500 font-bold">
                Transactions above ₹{limit.toLocaleString('en-IN')} will mandate 4-digit UPI PIN for security.
              </p>
            </div>
          )}
        </div>

        <div className="mt-5 flex gap-2">
          <button
            onClick={onClose}
            className="flex-1 py-2.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-black uppercase tracking-wider text-xs transition"
          >
            Cancel
          </button>
          <button
            onClick={handleSave}
            className="flex-1 py-2.5 rounded-xl bg-[#0a2540] hover:bg-[#071d34] text-white font-black uppercase tracking-wider text-xs shadow-md shadow-blue-950/20 transition active:scale-98"
          >
            Save Security Settings
          </button>
        </div>
      </div>
    </div>
  );
};
