import React, { useState, useMemo, useEffect } from 'react';
import {
  ShieldCheck,
  Users,
  UserPlus,
  Activity,
  Radio,
  FileCheck,
  Lock,
  Unlock,
  PlusCircle,
  MinusCircle,
  ArrowRight,
  Search,
  Filter,
  CheckCircle2,
  XCircle,
  AlertTriangle,
  TrendingUp,
  Landmark,
  Sliders,
  Smartphone,
  Sparkles,
  RefreshCw,
  CreditCard,
  ArrowDownLeft,
  ArrowUpRight,
  Ban,
  Check,
  X,
  ChevronRight,
  Info,
  ExternalLink,
  ShieldAlert,
  Volume2,
  RotateCcw,
  DollarSign,
  Wallet,
  Send,
  UserCheck,
  Shield,
  HelpCircle,
  Eye,
  Clock,
  KeyRound,
  Edit3,
  Trash2,
  QrCode,
  PauseCircle,
  MapPin,
  Navigation,
  Mail,
  MessageSquare,
  Inbox,
  FileText,
  AlertCircle,
  Copy,
  Server,
  Save,
} from 'lucide-react';
import {
  UserProfile,
  UserServices,
  KYCApplication,
  Transaction,
  TransactionCategory,
  PushAlert,
  LanguageCode,
} from '../types';
import { DEFAULT_SERVICES } from '../data/mockData';
import { generateRandomAccountNumber } from '../utils/accountUtils.ts';
import { dbService } from '../services/dbService.ts';
import { emailService, SentEmailLog } from '../services/emailService.ts';
import { smsService } from '../services/smsService';
import { generateAdminCustomEmail } from '../utils/emailTemplates.ts';
import { generateNetbankingCredentials, getDefaultVirtualCards, VIRTUAL_CARD_CONFIGS } from '../utils/cardUtils';
import { formatTransactionTimestamp, getNowBankingTimestamp } from '../utils/dateUtils';
import { AdminUserLocationTracker } from './AdminUserLocationTracker';
import { AdminAccountManagement } from './AdminAccountManagement';
import { AxisBankLogo } from './AxisBankLogo';

interface AdminDashboardProps {
  isOpen: boolean;
  onClose: () => void;
  users: UserProfile[];
  currentUser: UserProfile | null;
  onSelectUser: (user: UserProfile) => void;
  onUpdateUser: (updatedUser: UserProfile) => void;
  onCreateUser: (newUser: UserProfile, initialDepositTx?: Transaction) => void;
  onBlockUser: (userId: string, isBlocked: boolean, reason?: string) => void;
  onAdjustBalance: (action: {
    userId: string;
    type: 'CREDIT' | 'DEBIT';
    balanceType: 'savings' | 'wallet' | 'upiLite' | 'fixedDeposit';
    amount: number;
    reason: string;
    reference: string;
  }) => void;
  onToggleUserService: (userId: string, serviceKey: keyof UserServices, enabled: boolean) => void;
  onUpdateKycStatus: (userId: string, kycStatus: 'verified' | 'pending' | 'rejected') => void;
  kycApplications: KYCApplication[];
  onApproveKyc: (id: string) => void;
  onRejectKyc: (id: string, reason?: string) => void;
  transactions: Transaction[];
  onRollbackTransaction: (txId: string) => void;
  onBroadcastAlert: (alert: PushAlert, targetSegment?: string) => void;
  onApproveTransaction?: (txId: string) => void;
  onRejectTransaction?: (txId: string, reason?: string) => void;
  onHoldTransaction?: (txId: string, reason?: string) => void;
  onEditTransaction?: (txId: string, updates: Partial<Transaction>) => void;
  onDeleteTransaction?: (txId: string) => void;
  onSetUserMpin?: (userId: string, newMpin: string) => void;
  onDeleteUser?: (userId: string) => void;
}

type AdminTab =
  | 'USERS'
  | 'APPROVALS'
  | 'CREATE_USER'
  | 'TELLER'
  | 'KYC'
  | 'SERVICES'
  | 'TRANSACTIONS'
  | 'LOCATIONS'
  | 'ADMIN_MANAGEMENT'
  | 'BROADCAST';

const BRANCH_OPTIONS = [
  'Axis Bank Corporate HO (Mumbai)',
  'Axis Bank Nariman Point Corporate Branch',
  'Axis Bank Kolkata Corporate Branch',
  'Axis Bank Bengaluru Tech-Commercial Hub',
  'Axis Bank New Delhi Corporate Branch',
  'Axis Bank Hyderabad Financial District Branch',
];

export const AdminDashboard: React.FC<AdminDashboardProps> = ({
  isOpen,
  onClose,
  users,
  currentUser,
  onSelectUser,
  onUpdateUser,
  onCreateUser,
  onBlockUser,
  onAdjustBalance,
  onToggleUserService,
  onUpdateKycStatus,
  kycApplications,
  onApproveKyc,
  onRejectKyc,
  transactions,
  onRollbackTransaction,
  onBroadcastAlert,
  onApproveTransaction,
  onRejectTransaction,
  onHoldTransaction,
  onEditTransaction,
  onDeleteTransaction,
  onSetUserMpin,
  onDeleteUser,
}) => {
  if (!isOpen) return null;

  // Active Navigation Tab
  const [activeTab, setActiveTab] = useState<AdminTab>('USERS');

  // Global search in admin
  const [globalSearch, setGlobalSearch] = useState('');

  // Approvals Tab States
  const [approvalFilter, setApprovalFilter] = useState<'ALL' | 'OTHER_BANK' | 'UPI'>('ALL');
  const [rejectionModalTx, setRejectionModalTx] = useState<Transaction | null>(null);
  const [rejectionReasonInput, setRejectionReasonInput] = useState('Recipient address verification failed');
  const [approvalSuccessMsg, setApprovalSuccessMsg] = useState<string | null>(null);

  // Hold Modal States
  const [holdModalTx, setHoldModalTx] = useState<Transaction | null>(null);
  const [holdReasonInput, setHoldReasonInput] = useState('Under administrative review');

  // QR & Beneficiary Inspection Modal State
  const [viewQrModalTx, setViewQrModalTx] = useState<Transaction | null>(null);

  // Edit Transaction History States
  const [editingTransaction, setEditingTransaction] = useState<Transaction | null>(null);
  const [editFormData, setEditFormData] = useState<{
    title: string;
    subTitle: string;
    amount: string;
    type: 'credit' | 'debit';
    category: TransactionCategory;
    timestamp: string;
    status: Transaction['status'];
    paymentMode: Transaction['paymentMode'];
    upiRefId: string;
    beneficiaryName: string;
    beneficiaryAccount: string;
    recipientIfsc: string;
    recipientVpa: string;
    fraudFlag: 'CLEAN' | 'REVIEW' | 'SUSPICIOUS';
  }>({
    title: '',
    subTitle: '',
    amount: '0',
    type: 'debit',
    category: 'transfer',
    timestamp: '',
    status: 'SUCCESS',
    paymentMode: 'SAVINGS_AC',
    upiRefId: '',
    beneficiaryName: '',
    beneficiaryAccount: '',
    recipientIfsc: '',
    recipientVpa: '',
    fraudFlag: 'CLEAN',
  });

  const openEditModal = (tx: Transaction) => {
    setEditingTransaction(tx);
    setEditFormData({
      title: tx.title || '',
      subTitle: tx.subTitle || '',
      amount: tx.amount.toString(),
      type: tx.type || 'debit',
      category: tx.category || 'transfer',
      timestamp: formatTransactionTimestamp(tx.timestamp, tx.createdAt, tx.id),
      status: tx.status || 'SUCCESS',
      paymentMode: tx.paymentMode || 'SAVINGS_AC',
      upiRefId: tx.upiRefId || '',
      beneficiaryName: tx.beneficiaryName || '',
      beneficiaryAccount: tx.beneficiaryAccount || '',
      recipientIfsc: tx.recipientIfsc || '',
      recipientVpa: tx.recipientVpa || '',
      fraudFlag: tx.fraudFlag || 'CLEAN',
    });
  };

  const handleSaveTransactionEdit = () => {
    if (!editingTransaction) return;
    const numAmount = parseFloat(editFormData.amount);
    if (isNaN(numAmount) || numAmount < 0) {
      alert('Please enter a valid transaction amount');
      return;
    }

    const updates: Partial<Transaction> = {
      title: editFormData.title,
      subTitle: editFormData.subTitle,
      amount: numAmount,
      type: editFormData.type,
      category: editFormData.category,
      timestamp: editFormData.timestamp,
      status: editFormData.status,
      paymentMode: editFormData.paymentMode,
      upiRefId: editFormData.upiRefId,
      beneficiaryName: editFormData.beneficiaryName || undefined,
      beneficiaryAccount: editFormData.beneficiaryAccount || undefined,
      recipientIfsc: editFormData.recipientIfsc || undefined,
      recipientVpa: editFormData.recipientVpa || undefined,
      fraudFlag: editFormData.fraudFlag,
    };

    if (onEditTransaction) {
      onEditTransaction(editingTransaction.id, updates);
    }
    setApprovalSuccessMsg(`Transaction ${editFormData.upiRefId || editingTransaction.id} modified successfully in database.`);
    setEditingTransaction(null);
    setTimeout(() => setApprovalSuccessMsg(null), 4000);
  };

  const handleDeleteTx = (tx: Transaction) => {
    if (
      window.confirm(
        `Are you sure you want to permanently delete transaction "${tx.title}" (Ref: ${tx.upiRefId}, ₹${tx.amount.toFixed(
          2
        )}) from the audit ledger and database?`
      )
    ) {
      if (onDeleteTransaction) {
        onDeleteTransaction(tx.id);
      }
      setApprovalSuccessMsg(`Transaction ${tx.upiRefId} deleted permanently.`);
      setTimeout(() => setApprovalSuccessMsg(null), 4000);
    }
  };

  // Admin Set MPIN State
  const [mpinModalUser, setMpinModalUser] = useState<UserProfile | null>(null);
  const [adminMpinInput, setAdminMpinInput] = useState('');
  const [adminMpinMsg, setAdminMpinMsg] = useState('');

  // Tab 1: Users Filter & Search
  const [userSearchQuery, setUserSearchQuery] = useState('');
  const [userStatusFilter, setUserStatusFilter] = useState<'ALL' | 'ACTIVE' | 'BLOCKED'>('ALL');
  const [userKycFilter, setUserKycFilter] = useState<'ALL' | 'VERIFIED' | 'PENDING' | 'REJECTED'>('ALL');
  const [userTypeFilter, setUserTypeFilter] = useState<string>('ALL');

  // Quick Action Modals State
  const [activeActionUser, setActiveActionUser] = useState<UserProfile | null>(null);
  const [actionModalType, setActionModalType] = useState<
    'MONEY' | 'BLOCK' | 'SERVICES' | 'KYC_EDIT' | 'DELETE_USER' | 'EDIT_DETAILS' | 'SEND_COMMUNICATION' | 'ISSUE_NETBANKING' | null
  >(null);

  // Issue Cust ID / NetBanking Credentials Modal State
  const [issueCifNumber, setIssueCifNumber] = useState('');
  const [issueNetbankingLoginId, setIssueNetbankingLoginId] = useState('');
  const [issueNetbankingPassword, setIssueNetbankingPassword] = useState('');
  const [issueMpin, setIssueMpin] = useState('1234');
  const [issueVirtualCardVariant, setIssueVirtualCardVariant] = useState<
    'BURGUNDY_PRESTIGE' | 'TITANIUM_REWARDS' | 'MAGNUS_METAL' | 'NEO_SHOPPING'
  >('BURGUNDY_PRESTIGE');
  const [issueDispatchEmail, setIssueDispatchEmail] = useState(true);
  const [issueDispatchSms, setIssueDispatchSms] = useState(true);
  const [issueIsSubmitting, setIssueIsSubmitting] = useState(false);
  const [issueStatusMsg, setIssueStatusMsg] = useState<{ type: 'success' | 'error'; text: string } | null>(null);
  const [issueCopiedField, setIssueCopiedField] = useState<string | null>(null);

  // Individual Communication State (SMS & Modern Banking Email)
  const [commChannel, setCommChannel] = useState<'EMAIL' | 'SMS' | 'BOTH'>('BOTH');
  const [commRecipientName, setCommRecipientName] = useState('');
  const [commRecipientPhone, setCommRecipientPhone] = useState('');
  const [commRecipientEmail, setCommRecipientEmail] = useState('');
  const [commRecipientAccount, setCommRecipientAccount] = useState('');
  const [commSubject, setCommSubject] = useState('Official Notice: Important Account Update from Axis Bank CC VIP');
  const [commTitle, setCommTitle] = useState('Official Institutional Notification');
  const [commMessage, setCommMessage] = useState('');
  const [commPreset, setCommPreset] = useState<'CUSTOM' | 'KYC' | 'SECURITY' | 'BALANCE' | 'WELCOME' | 'AGRI'>('CUSTOM');
  const [commIsSending, setCommIsSending] = useState(false);
  const [commStatusMsg, setCommStatusMsg] = useState<{ type: 'success' | 'error'; text: string } | null>(null);
  const [commShowPreview, setCommShowPreview] = useState(false);

  // Communications Hub Tab States
  const [commHubSubTab, setCommHubSubTab] = useState<'INDIVIDUAL' | 'BROADCAST' | 'OUTBOX' | 'SETTINGS'>('INDIVIDUAL');
  const [commSelectedUserIdForHub, setCommSelectedUserIdForHub] = useState<string>('');
  const [commOutboxLogs, setCommOutboxLogs] = useState<SentEmailLog[]>([]);
  const [commViewingEmailHtml, setCommViewingEmailHtml] = useState<string | null>(null);
  const [smtpStatus, setSmtpStatus] = useState<{
    host: string;
    port: number;
    user: string;
    hasPass: boolean;
    secure: boolean;
    from: string;
    isConfigured: boolean;
  } | null>(null);
  const [smtpTesting, setSmtpTesting] = useState(false);
  const [smtpTestResult, setSmtpTestResult] = useState<{ success: boolean; message: string } | null>(null);

  // SMTP Gateway Edit Form State
  const [smtpFormHost, setSmtpFormHost] = useState('smtp.hostinger.com');
  const [smtpFormPort, setSmtpFormPort] = useState('465');
  const [smtpFormSecure, setSmtpFormSecure] = useState('true');
  const [smtpFormUser, setSmtpFormUser] = useState('');
  const [smtpFormPass, setSmtpFormPass] = useState('');
  const [smtpFormFrom, setSmtpFormFrom] = useState('"Axis Bank CC VIP" <vip.support@axisbank.com>');
  const [smtpSaving, setSmtpSaving] = useState(false);
  const [smtpSaveMessage, setSmtpSaveMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  // Twilio Gateway Edit Form State
  const [twilioStatus, setTwilioStatus] = useState<{
    accountSid: string;
    hasAuthToken: boolean;
    fromPhone: string;
    isConfigured: boolean;
  } | null>(null);
  const [twilioFormAccountSid, setTwilioFormAccountSid] = useState('');
  const [twilioFormAuthToken, setTwilioFormAuthToken] = useState('');
  const [twilioFormFromPhone, setTwilioFormFromPhone] = useState('');
  const [twilioSaving, setTwilioSaving] = useState(false);
  const [twilioSaveMessage, setTwilioSaveMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);
  const [twilioTestPhone, setTwilioTestPhone] = useState('+919830012345');
  const [twilioTesting, setTwilioTesting] = useState(false);
  const [twilioTestResult, setTwilioTestResult] = useState<{ success: boolean; message: string } | null>(null);

  const loadCommunicationsSettings = async () => {
    try {
      const settings = await emailService.getCommunicationsSettings();
      if (settings.smtp) {
        setSmtpStatus(settings.smtp);
        setSmtpFormHost(settings.smtp.host || 'smtp.hostinger.com');
        setSmtpFormPort(String(settings.smtp.port || 465));
        setSmtpFormSecure(settings.smtp.secure ? 'true' : 'false');
        setSmtpFormUser(settings.smtp.user || '');
        setSmtpFormFrom(settings.smtp.from || '"Axis Bank CC VIP" <vip.support@axisbank.com>');
      }
      if (settings.twilio) {
        setTwilioStatus(settings.twilio);
        setTwilioFormAccountSid(settings.twilio.accountSid || '');
        setTwilioFormFromPhone(settings.twilio.fromPhone || '');
      }
    } catch {
      // ignore
    }
  };

  useEffect(() => {
    emailService.getOutbox().then(setCommOutboxLogs).catch(() => {});
    loadCommunicationsSettings();
  }, [activeTab]);

  // Edit Customer Details Modal Form State
  const [editUserName, setEditUserName] = useState('');
  const [editUserPhone, setEditUserPhone] = useState('');
  const [editUserEmail, setEditUserEmail] = useState('');
  const [editUserAccountType, setEditUserAccountType] = useState<'SAVINGS' | 'CURRENT' | 'KCC_FARMER' | 'PENSION'>('SAVINGS');
  const [editUserBranch, setEditUserBranch] = useState(BRANCH_OPTIONS[0]);
  const [editUserAccountNumber, setEditUserAccountNumber] = useState('');
  const [editUserCifNumber, setEditUserCifNumber] = useState('');
  const [editUserIfscCode, setEditUserIfscCode] = useState('UTIB000001');
  const [editUserUpiId, setEditUserUpiId] = useState('');
  const [editUserDob, setEditUserDob] = useState('');
  const [editUserAddress, setEditUserAddress] = useState('');
  const [editUserAadhaar, setEditUserAadhaar] = useState('');
  const [editUserPan, setEditUserPan] = useState('');
  const [editUserCkyc, setEditUserCkyc] = useState('');
  const [editUserKycStatus, setEditUserKycStatus] = useState<'verified' | 'pending' | 'rejected'>('verified');
  const [editUserSeniorMode, setEditUserSeniorMode] = useState(false);
  const [editAuditReason, setEditAuditReason] = useState('Administrative correction of account details');
  const [editDetailsSuccessMsg, setEditDetailsSuccessMsg] = useState<string | null>(null);
  const [editDetailsErrorMsg, setEditDetailsErrorMsg] = useState<string | null>(null);

  // Quick Money Adjustment in modal or teller tab
  const [moneyActionType, setMoneyActionType] = useState<'CREDIT' | 'DEBIT'>('CREDIT');
  const [moneyTargetBalance, setMoneyTargetBalance] = useState<
    'savings' | 'wallet' | 'upiLite' | 'fixedDeposit'
  >('savings');
  const [moneyAmount, setMoneyAmount] = useState<string>('5000');
  const [moneyReason, setMoneyReason] = useState<string>('Cash Deposit at Branch Counter');
  const [moneySuccessMsg, setMoneySuccessMsg] = useState<string | null>(null);

  // Block Modal State
  const [blockReasonInput, setBlockReasonInput] = useState<string>(
    'Suspicious Transaction Pattern / Re-KYC Audit Required'
  );

  // Tab 2: Create User Form State
  const [newUserName, setNewUserName] = useState('');
  const [newUserPhone, setNewUserPhone] = useState('');
  const [newUserEmail, setNewUserEmail] = useState('');
  const [newUserAccountType, setNewUserAccountType] = useState<'SAVINGS' | 'CURRENT' | 'KCC_FARMER' | 'PENSION'>('SAVINGS');
  const [newUserBranch, setNewUserBranch] = useState(BRANCH_OPTIONS[0]);
  const [newUserAadhaar, setNewUserAadhaar] = useState('');
  const [newUserPan, setNewUserPan] = useState('');
  const [newUserPhoto, setNewUserPhoto] = useState('');
  const [newUserDob, setNewUserDob] = useState('1992-05-15');
  const [newUserAddress, setNewUserAddress] = useState('Worli, Mumbai, Maharashtra - 400025');
  const [newUserCkyc, setNewUserCkyc] = useState(`CKYC-2026-${Math.floor(10000000 + Math.random() * 90000000)}`);
  const [newSavingsDeposit, setNewSavingsDeposit] = useState('5000');
  const [newWalletDeposit, setNewWalletDeposit] = useState('500');
  const [newUpiLiteDeposit, setNewUpiLiteDeposit] = useState('200');
  const [newFdDeposit, setNewFdDeposit] = useState('0');
  const [newUserKycStatus, setNewUserKycStatus] = useState<'verified' | 'pending'>('verified');
  const [newUserMpin, setNewUserMpin] = useState('1234');
  const [newUserServices, setNewUserServices] = useState<UserServices>({
    ...DEFAULT_SERVICES,
  });
  const [userCreatedSuccess, setUserCreatedSuccess] = useState<UserProfile | null>(null);

  // Tab 3: Dedicated Teller State
  const [tellerSelectedUserId, setTellerSelectedUserId] = useState<string>(
    users[0]?.id || ''
  );

  // Tab 4: KYC Hub States
  const [kycFilter, setKycFilter] = useState<'ALL' | 'PENDING' | 'APPROVED' | 'REJECTED'>('PENDING');
  const [rejectModalAppId, setRejectModalAppId] = useState<string | null>(null);
  const [rejectionReason, setRejectionReason] = useState('Aadhaar and PAN details could not be matched with NSDL registry');
  const [verifyingAppId, setVerifyingAppId] = useState<string | null>(null);

  // Tab 5: Services Matrix Global switches
  const [globalUpiSwitch, setGlobalUpiSwitch] = useState(true);
  const [globalImpsGateway, setGlobalImpsGateway] = useState(true);
  const [globalAepsSwitch, setGlobalAepsSwitch] = useState(true);
  const [globalSoundboxEngine, setGlobalSoundboxEngine] = useState(true);
  const [globalAiSahayak, setGlobalAiSahayak] = useState(true);

  // Tab 6: Transaction Ledger
  const [txSearch, setTxSearch] = useState('');
  const [txTypeFilter, setTxTypeFilter] = useState<'ALL' | 'CREDIT' | 'DEBIT' | 'SUSPICIOUS'>('ALL');
  const [rollbackSuccessMsg, setRollbackSuccessMsg] = useState<string | null>(null);

  // Tab 7: Push Alert Broadcast State
  const [broadcastTitle, setBroadcastTitle] = useState('Axis Bank CC VIP Security Advisory: Never Share UPI PIN or OTP');
  const [broadcastBody, setBroadcastBody] = useState(
    'Officials of Axis Bank CC VIP will never ask for your passwords, OTP, or CVV over call or SMS.'
  );
  const [broadcastType, setBroadcastType] = useState<'SECURITY' | 'TRANSACTION' | 'OFFER' | 'ADMIN_BROADCAST'>('SECURITY');
  const [broadcastTarget, setBroadcastTarget] = useState<'ALL' | 'FARMERS' | 'SENIORS' | 'MERCHANTS'>('ALL');
  const [broadcastSuccess, setBroadcastSuccess] = useState(false);

  // Calculated Metrics
  const totalLiquidity = useMemo(() => {
    return users.reduce((acc, u) => {
      return acc + (u.savingsBalance || 0) + (u.walletBalance || 0) + (u.upiLiteBalance || 0) + (u.fixedDepositBalance || 0);
    }, 0);
  }, [users]);

  const activeUsersCount = useMemo(() => users.filter((u) => !u.isBlocked).length, [users]);
  const blockedUsersCount = useMemo(() => users.filter((u) => u.isBlocked).length, [users]);
  const pendingKycCount = useMemo(() => kycApplications.filter((k) => k.status === 'PENDING_VERIFICATION').length, [kycApplications]);

  // Pending Inter-Bank and UPI Approvals (External transfers in Processed, Hold, or Awaiting Admin status)
  const pendingApprovals = useMemo(() => {
    return transactions.filter(
      (tx) =>
        tx.status === 'PROCESSED' ||
        tx.status === 'PENDING_APPROVAL' ||
        tx.status === 'HOLD' ||
        tx.approvalStatus === 'AWAITING_ADMIN' ||
        tx.approvalStatus === 'HOLD'
    );
  }, [transactions]);
  const pendingApprovalsCount = pendingApprovals.length;
  const otherBankPendingCount = useMemo(() => {
    return pendingApprovals.filter((t) => t.transferType === 'OTHER_BANK').length;
  }, [pendingApprovals]);
  const upiPendingCount = useMemo(() => {
    return pendingApprovals.filter((t) => t.transferType === 'UPI').length;
  }, [pendingApprovals]);

  // Filtered Users List
  const filteredUsers = useMemo(() => {
    return users.filter((u) => {
      const q = (userSearchQuery || globalSearch).toLowerCase();
      const matchesSearch =
        u.name.toLowerCase().includes(q) ||
        u.phone.toLowerCase().includes(q) ||
        u.accountNumber.toLowerCase().includes(q) ||
        (u.upiId && u.upiId.toLowerCase().includes(q)) ||
        (u.cifNumber && u.cifNumber.toLowerCase().includes(q));

      const matchesStatus =
        userStatusFilter === 'ALL' ||
        (userStatusFilter === 'ACTIVE' && !u.isBlocked) ||
        (userStatusFilter === 'BLOCKED' && u.isBlocked);

      const matchesKyc =
        userKycFilter === 'ALL' ||
        (userKycFilter === 'VERIFIED' && u.kycStatus === 'verified') ||
        (userKycFilter === 'PENDING' && u.kycStatus === 'pending') ||
        (userKycFilter === 'REJECTED' && u.kycStatus === 'rejected');

      const matchesType =
        userTypeFilter === 'ALL' || u.accountType === userTypeFilter;

      return matchesSearch && matchesStatus && matchesKyc && matchesType;
    });
  }, [users, userSearchQuery, globalSearch, userStatusFilter, userKycFilter, userTypeFilter]);

  // Execute Money Adjustment (from modal or teller tab)
  const handleExecuteMoneyAdjustment = (targetUserId: string) => {
    const amt = parseFloat(moneyAmount);
    if (isNaN(amt) || amt <= 0) {
      alert('Please enter a valid amount greater than zero.');
      return;
    }

    const ref = `CBS/${moneyActionType === 'CREDIT' ? 'DEP' : 'WDL'}/${Math.floor(10000000 + Math.random() * 90000000)}`;

    onAdjustBalance({
      userId: targetUserId,
      type: moneyActionType,
      balanceType: moneyTargetBalance,
      amount: amt,
      reason: moneyReason || (moneyActionType === 'CREDIT' ? 'Branch Counter Deposit' : 'Branch Teller Debit'),
      reference: ref,
    });

    const targetUser = users.find((u) => u.id === targetUserId);
    setMoneySuccessMsg(
      `Successfully ${moneyActionType === 'CREDIT' ? 'credited' : 'debited'} ₹${amt.toLocaleString('en-IN', { minimumFractionDigits: 2 })} for ${targetUser?.name || 'Customer'}`
    );

    setTimeout(() => {
      setMoneySuccessMsg(null);
      if (actionModalType === 'MONEY') {
        setActionModalType(null);
        setActiveActionUser(null);
      }
    }, 2000);
  };

  // Handle Toggle Block User
  const handleToggleBlock = (targetUser: UserProfile) => {
    if (targetUser.isBlocked) {
      // Unblock
      onBlockUser(targetUser.id, false);
      setActionModalType(null);
      setActiveActionUser(null);
    } else {
      // Open block confirmation with reason
      setActiveActionUser(targetUser);
      setActionModalType('BLOCK');
    }
  };

  const handleConfirmBlock = () => {
    if (!activeActionUser) return;
    onBlockUser(activeActionUser.id, true, blockReasonInput);
    setActionModalType(null);
    setActiveActionUser(null);
  };

  const handleConfirmDeleteUser = () => {
    if (!activeActionUser) return;
    const targetId = activeActionUser.id;
    if (onDeleteUser) {
      onDeleteUser(targetId);
    }
    setActionModalType(null);
    setActiveActionUser(null);
  };

  // Open Edit Customer Details Modal
  const handleOpenEditUserModal = (targetUser: UserProfile) => {
    setActiveActionUser(targetUser);
    setEditUserName(targetUser.name || '');
    setEditUserPhone(targetUser.phone || '');
    setEditUserEmail(targetUser.email || '');
    setEditUserAccountType(targetUser.accountType || 'SAVINGS');
    setEditUserBranch(targetUser.branchName || BRANCH_OPTIONS[0]);
    setEditUserAccountNumber(targetUser.accountNumber || '');
    setEditUserCifNumber(targetUser.cifNumber || '');
    setEditUserIfscCode(targetUser.ifscCode || 'UTIB000001');
    setEditUserUpiId(targetUser.upiId || '');
    setEditUserDob(targetUser.dob || '');
    setEditUserAddress(targetUser.address || '');
    setEditUserAadhaar(targetUser.aadhaarNumber || '');
    setEditUserPan(targetUser.panNumber || '');
    setEditUserCkyc(targetUser.ckycNumber || '');
    setEditUserKycStatus(targetUser.kycStatus || 'verified');
    setEditUserSeniorMode(Boolean(targetUser.seniorMode));
    setEditAuditReason('Administrative correction of account details');
    setEditDetailsSuccessMsg(null);
    setEditDetailsErrorMsg(null);
    setActionModalType('EDIT_DETAILS');
  };

  // Save Edited Customer Details
  const handleSaveEditUserDetails = (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeActionUser) return;

    if (!editUserName.trim()) {
      setEditDetailsErrorMsg('Customer full legal name cannot be empty.');
      return;
    }
    if (!editUserPhone.trim()) {
      setEditDetailsErrorMsg('Registered mobile number cannot be empty.');
      return;
    }
    if (!editUserAccountNumber.trim()) {
      setEditDetailsErrorMsg('Account number cannot be empty.');
      return;
    }

    const updatedUser: UserProfile = {
      ...activeActionUser,
      name: editUserName.trim(),
      phone: editUserPhone.trim(),
      email: editUserEmail.trim() || activeActionUser.email,
      accountType: editUserAccountType,
      branchName: editUserBranch.trim() || activeActionUser.branchName,
      accountNumber: editUserAccountNumber.trim() || activeActionUser.accountNumber,
      cifNumber: editUserCifNumber.trim() || activeActionUser.cifNumber,
      ifscCode: editUserIfscCode.trim() || activeActionUser.ifscCode,
      upiId: editUserUpiId.trim() || activeActionUser.upiId,
      dob: editUserDob.trim() || activeActionUser.dob,
      address: editUserAddress.trim() || activeActionUser.address,
      aadhaarNumber: editUserAadhaar.trim() || activeActionUser.aadhaarNumber,
      panNumber: editUserPan.trim() || activeActionUser.panNumber,
      ckycNumber: editUserCkyc.trim() || activeActionUser.ckycNumber,
      kycStatus: editUserKycStatus,
      seniorMode: editUserSeniorMode,
    };

    onUpdateUser(updatedUser);
    setEditDetailsErrorMsg(null);
    setEditDetailsSuccessMsg(`Successfully saved updates for ${updatedUser.name} (A/C ${updatedUser.accountNumber})`);

    setTimeout(() => {
      setEditDetailsSuccessMsg(null);
      setActionModalType(null);
      setActiveActionUser(null);
    }, 1200);
  };

  // Open Issue Cust ID / NetBanking Credentials Modal
  const handleOpenIssueNetbankingModal = (u: UserProfile) => {
    setActiveActionUser(u);
    const creds = generateNetbankingCredentials(u.name, u.phone);
    setIssueCifNumber(u.cifNumber || creds.cifNumber);
    setIssueNetbankingLoginId(u.netbankingLoginId || creds.netbankingLoginId);
    setIssueNetbankingPassword(u.netbankingPassword || creds.netbankingPassword);
    setIssueMpin(u.mpin || '1234');
    const existingVariant = (u.virtualCards && u.virtualCards[0]?.variant) || 'BURGUNDY_PRESTIGE';
    setIssueVirtualCardVariant(existingVariant);
    setIssueDispatchEmail(Boolean(u.email));
    setIssueDispatchSms(Boolean(u.phone));
    setIssueStatusMsg(null);
    setIssueCopiedField(null);
    setActionModalType('ISSUE_NETBANKING');
  };

  const handleRegenerateNetbankingCreds = () => {
    if (!activeActionUser) return;
    const creds = generateNetbankingCredentials(activeActionUser.name, activeActionUser.phone);
    setIssueCifNumber(creds.cifNumber);
    setIssueNetbankingLoginId(creds.netbankingLoginId);
    setIssueNetbankingPassword(creds.netbankingPassword);
    setIssueMpin(Math.floor(1000 + Math.random() * 9000).toString());
  };

  const handleConfirmIssueNetbanking = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeActionUser) return;
    setIssueIsSubmitting(true);
    setIssueStatusMsg(null);

    try {
      const existingCards =
        activeActionUser.virtualCards && activeActionUser.virtualCards.length > 0
          ? activeActionUser.virtualCards
          : getDefaultVirtualCards(activeActionUser.name);

      const updatedUser: UserProfile = {
        ...activeActionUser,
        cifNumber: issueCifNumber.trim(),
        netbankingLoginId: issueNetbankingLoginId.trim(),
        netbankingPassword: issueNetbankingPassword.trim(),
        netbankingStatus: 'ACTIVE',
        mpin: issueMpin.trim() || activeActionUser.mpin || '1234',
        virtualCards: existingCards,
      };

      onUpdateUser(updatedUser);
      await dbService.saveUser(updatedUser);

      // Dispatch Welcome / NetBanking Kit via Email
      if (issueDispatchEmail && updatedUser.email) {
        await emailService.sendWelcomeEmail(updatedUser).catch((err) =>
          console.warn('[Admin Welcome Email Notice]', err)
        );
      }

      // Dispatch Welcome / NetBanking Kit via SMS
      if (issueDispatchSms && updatedUser.phone) {
        const cleanPhone = updatedUser.phone.replace(/\D/g, '').slice(-10);
        await smsService.sendTransactionalSms(
          cleanPhone,
          `Dear ${updatedUser.name}, Welcome to Axis Bank CC VIP! Your Customer ID is ${updatedUser.cifNumber}, NetBanking Login ID: ${updatedUser.netbankingLoginId}, Temp Password: ${updatedUser.netbankingPassword}, MPIN: ${updatedUser.mpin}. A/C: ••${updatedUser.accountNumber?.slice(-4)}, IFSC: UTIB000001. Keep confidential.`
        ).catch((err) => console.warn('[Admin Welcome SMS Notice]', err));
      }

      setIssueStatusMsg({
        type: 'success',
        text: `NetBanking credentials successfully issued for ${updatedUser.name}! Customer ID: ${updatedUser.cifNumber}. Dispatched to Email & SMS.`,
      });

      setTimeout(() => {
        setActionModalType(null);
        setActiveActionUser(null);
      }, 1800);
    } catch (err: any) {
      setIssueStatusMsg({
        type: 'error',
        text: err?.message || 'Failed to issue NetBanking credentials.',
      });
    } finally {
      setIssueIsSubmitting(false);
    }
  };

  // Open Individual Communication Modal
  const handleOpenIndividualCommModal = (u: UserProfile) => {
    setActiveActionUser(u);
    setCommRecipientName(u.name);
    setCommRecipientPhone(u.phone);
    setCommRecipientEmail(u.email || '');
    setCommRecipientAccount(u.accountNumber || '');
    setCommChannel('BOTH');
    setCommSubject(`Axis Bank CC VIP Official Notice: Account Communication regarding A/C ••${u.accountNumber?.slice(-4) || '••••'}`);
    setCommTitle('Axis Bank CC VIP Official Customer Advisory');
    setCommMessage(
      `Dear ${u.name},\n\nWe are writing to you regarding your Corporate & Mobile Banking account with Axis Bank CC VIP.\n\nPlease review your active account services and contact your home branch at ${u.branchName || 'Axis Bank Corporate HO (Mumbai)'} if you require any assistance.`
    );
    setCommPreset('CUSTOM');
    setCommStatusMsg(null);
    setCommShowPreview(false);
    setActionModalType('SEND_COMMUNICATION');
  };

  const handleSelectCommPreset = (preset: 'CUSTOM' | 'KYC' | 'SECURITY' | 'BALANCE' | 'WELCOME' | 'AGRI', u?: UserProfile | null) => {
    const target = u || activeActionUser;
    const name = target?.name || commRecipientName || 'Customer';
    const acct = target?.accountNumber || commRecipientAccount || 'Account';
    const branch = target?.branchName || 'Home Branch';
    setCommPreset(preset);

    if (preset === 'KYC') {
      setCommSubject(`Axis Bank CC VIP Official Notice: Account Re-KYC Verification Required`);
      setCommTitle('Mandatory Regulatory KYC Notice');
      setCommMessage(
        `Dear ${name},\n\nThis is an official notice regarding your account ending in ••${acct.slice(-4)}. As per regulatory guidelines, your KYC records require verification. Please upload updated identity credentials or visit your home branch (${branch}) to ensure uninterrupted corporate digital banking services.`
      );
    } else if (preset === 'SECURITY') {
      setCommSubject(`Axis Bank CC VIP Security Advisory: Critical Fraud Prevention Alert`);
      setCommTitle('Urgent Banking Security Warning');
      setCommMessage(
        `Dear ${name},\n\nAxis Bank reminds you to stay vigilant against fraudulent calls, links, and fake verification requests. Bank staff will NEVER ask for your 4-digit MPIN, OTP, or CVV. If you suspect any fraudulent attempt on A/C ••${acct.slice(-4)}, immediately freeze your account or call our 24x7 toll-free helpline 1860-419-5555.`
      );
    } else if (preset === 'BALANCE') {
      setCommSubject(`Axis Bank CC VIP Account Advisory: Official Ledger Review Notice`);
      setCommTitle('CBS Account Balance & Transaction Advisory');
      setCommMessage(
        `Dear ${name},\n\nYour Corporate & Mobile Banking account statement has been reconciled for this period. Please verify your ledger balance and transaction receipts in the Axis Bank Mobile Banking App. For inquiries, contact ${branch}.`
      );
    } else if (preset === 'WELCOME') {
      setCommSubject(`Welcome to Axis Bank CC VIP Corporate & Mobile Banking, ${name}!`);
      setCommTitle('Official Onboarding & Activation Notice');
      setCommMessage(
        `Dear ${name},\n\nWelcome to Axis Bank CC VIP Corporate & Priority Banking. Your NetBanking and Mobile Banking account (••${acct.slice(-4)}) has been verified and activated. You can now execute UPI transfers, QR payments, and access treasury services 24x7.`
      );
    } else if (preset === 'AGRI') {
      setCommSubject(`Axis Bank CC VIP Priority Lending: Kisan Credit Card & MSME Advisory`);
      setCommTitle('Institutional Agriculture & MSME Facility Notice');
      setCommMessage(
        `Dear ${name},\n\nSpecial corporate financing facilities and working capital credit are now available at your branch (${branch}). Please contact your Relationship Manager to avail of preferential interest subvention and customized credit limits.`
      );
    } else {
      setCommSubject(`Axis Bank CC VIP Official Communication regarding A/C ••${acct.slice(-4)}`);
      setCommTitle('Official Branch Officer Advisory');
      setCommMessage(
        `Dear ${name},\n\nWe are writing to you regarding your account with Axis Bank CC VIP Corporate & Mobile Banking.`
      );
    }
  };

  const handleSendIndividualCommunication = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeActionUser) return;
    if (!commMessage.trim()) {
      setCommStatusMsg({ type: 'error', text: 'Message body cannot be empty.' });
      return;
    }
    if ((commChannel === 'EMAIL' || commChannel === 'BOTH') && !commRecipientEmail.trim()) {
      setCommStatusMsg({ type: 'error', text: 'Recipient email address is required for Email dispatch.' });
      return;
    }
    if ((commChannel === 'SMS' || commChannel === 'BOTH') && !commRecipientPhone.trim()) {
      setCommStatusMsg({ type: 'error', text: 'Recipient mobile number is required for SMS dispatch.' });
      return;
    }

    setCommIsSending(true);
    setCommStatusMsg(null);

    try {
      const targetUser: UserProfile = {
        ...activeActionUser,
        name: commRecipientName.trim() || activeActionUser.name,
        phone: commRecipientPhone.trim() || activeActionUser.phone,
        email: commRecipientEmail.trim() || activeActionUser.email,
        accountNumber: commRecipientAccount.trim() || activeActionUser.accountNumber,
      };

      const res = await emailService.sendAdminIndividualNotification({
        user: targetUser,
        channel: commChannel,
        subject: commSubject.trim() || 'Official Notice from Axis Bank CC VIP',
        title: commTitle.trim() || 'Axis Bank CC VIP Official Advisory',
        message: commMessage.trim(),
      });

      setCommStatusMsg({
        type: 'success',
        text: `Successfully dispatched communication via ${res.channelsDispatched?.join(' & ') || commChannel} to ${targetUser.name}!`,
      });

      // Also trigger a local push alert to the user's notifications
      if (onBroadcastAlert) {
        onBroadcastAlert({
          id: `alert_admin_direct_${Date.now()}`,
          userId: targetUser.id,
          title: commSubject.trim(),
          body: commMessage.trim().slice(0, 140),
          time: getNowBankingTimestamp(),
          read: false,
          type: 'SECURITY',
        });
      }

      // Reload outbox
      emailService.getOutbox().then(setCommOutboxLogs).catch(() => {});

      setTimeout(() => {
        setCommIsSending(false);
        setActionModalType(null);
        setActiveActionUser(null);
        setCommStatusMsg(null);
      }, 1600);
    } catch (err: any) {
      setCommStatusMsg({
        type: 'error',
        text: `Dispatch failed: ${err.message || 'Check network / SMTP configuration'}`,
      });
      setCommIsSending(false);
    }
  };

  // Handle Create User Submit
  const handleCreateUserSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newUserName.trim() || !newUserPhone.trim()) {
      alert('Name and Mobile Number are required.');
      return;
    }

    const cleanPhone = newUserPhone.replace(/\D/g, '');
    const existingAccounts = users.map((u) => u.accountNumber).filter(Boolean);
    const accountNum = generateRandomAccountNumber(existingAccounts);
    const newUserId = `usr_axis_vip_${Date.now().toString().slice(-6)}`;
    const cleanName = newUserName.toLowerCase().replace(/[^a-z0-9]/g, '.').replace(/\.+/g, '.');
    const vpa = `${cleanName.slice(0, 10)}@axisbank`;
    
    // Generate NetBanking Credentials & Default Virtual Debit Cards
    const creds = generateNetbankingCredentials(newUserName, newUserPhone);
    const virtualCards = getDefaultVirtualCards(newUserName);

    const sBal = parseFloat(newSavingsDeposit) || 0;
    const wBal = parseFloat(newWalletDeposit) || 0;
    const lBal = parseFloat(newUpiLiteDeposit) || 0;
    const fdBal = parseFloat(newFdDeposit) || 0;
    const nowIso = new Date().toISOString();

    const newUser: UserProfile = {
      id: newUserId,
      name: newUserName.trim(),
      phone: newUserPhone.startsWith('+91') ? newUserPhone : `+91 ${cleanPhone.slice(-10)}`,
      email: newUserEmail || `${cleanName}@axisbank.com`,
      upiId: vpa,
      activeUpiHandle: '@axisbank',
      upiHandles: [
        `${cleanName.slice(0, 10)}@axisbank`,
        `${cleanName.slice(0, 10)}@okaxis`,
        `${cleanName.slice(0, 10)}@axissbs`,
      ],
      accountNumber: accountNum,
      ifscCode: 'UTIB000001',
      branchName: newUserBranch,
      cifNumber: creds.cifNumber,
      netbankingLoginId: creds.netbankingLoginId,
      netbankingPassword: creds.netbankingPassword,
      netbankingStatus: 'ACTIVE',
      virtualCards: virtualCards,
      updateRequests: [],
      accountType: newUserAccountType,
      savingsBalance: sBal,
      walletBalance: wBal,
      upiLiteBalance: lBal,
      fixedDepositBalance: fdBal,
      digitalGoldGrams: 0,
      kycStatus: newUserKycStatus,
      accountStatus: 'APPROVED',
      profilePhotoUpdatedAt: newUserPhoto ? nowIso : undefined,
      aadhaarNumber: newUserAadhaar ? `XXXX-XXXX-${newUserAadhaar.slice(-4)}` : 'XXXX-XXXX-9901',
      panNumber: newUserPan ? newUserPan.toUpperCase() : 'AXISB1234F',
      photoUrl: newUserPhoto || undefined,
      dob: newUserDob || undefined,
      address: newUserAddress || undefined,
      ckycNumber: newUserCkyc || undefined,
      biometricEnabled: true,
      biometricLimit: 5000,
      soundboxVoiceAlerts: true,
      soundboxLanguage: 'en',
      seniorMode: newUserAccountType === 'PENSION',
      highContrast: false,
      isBlocked: false,
      services: { ...newUserServices },
      mpin: newUserMpin || '1234',
      createdAt: 'Today',
    };

    let initialTx: Transaction | undefined;
    if (sBal > 0) {
      initialTx = {
        id: `tx_init_${Date.now()}`,
        userId: newUser.id,
        userPhone: newUser.phone,
        title: 'Account Opening Cash Deposit',
        subTitle: `Credited at ${newUserBranch}`,
        amount: sBal,
        type: 'credit',
        category: 'transfer',
        timestamp: getNowBankingTimestamp(),
        status: 'SUCCESS',
        paymentMode: 'SAVINGS_AC',
        upiRefId: `CBS/OPN/${Math.floor(100000000000 + Math.random() * 900000000000)}`,
        fraudFlag: 'CLEAN',
        beneficiaryAccount: newUser.accountNumber,
        beneficiaryName: newUser.name,
      };
    }

    onCreateUser(newUser, initialTx);
    setUserCreatedSuccess(newUser);

    // Dispatch NetBanking credentials to email & SMS
    if (newUser.email) {
      emailService.sendWelcomeEmail(newUser).catch((err) =>
        console.warn('[Admin Create User Welcome Email Notice]', err)
      );
    }
    if (newUser.phone) {
      const cleanPhoneDigits = newUser.phone.replace(/\D/g, '').slice(-10);
      smsService.sendTransactionalSms(
        cleanPhoneDigits,
        `Dear ${newUser.name}, Welcome to Axis Bank CC VIP! Your Customer ID is ${newUser.cifNumber}, NetBanking Login ID: ${newUser.netbankingLoginId}, Temp Password: ${newUser.netbankingPassword}. A/C: ••${newUser.accountNumber.slice(-4)}, IFSC: UTIB000001. Keep confidential.`
      ).catch((err) => console.warn('[Admin Create User SMS Notice]', err));
    }

    // Reset Form
    setTimeout(() => {
      setNewUserName('');
      setNewUserPhone('');
      setNewUserEmail('');
      setNewUserAadhaar('');
      setNewUserPan('');
      setNewSavingsDeposit('5000');
      setNewWalletDeposit('500');
      setNewUpiLiteDeposit('200');
      setNewFdDeposit('0');
    }, 500);
  };

  const handleApproveUserAccount = async (targetUser: UserProfile) => {
    const approved: UserProfile = {
      ...targetUser,
      accountStatus: 'APPROVED',
      kycStatus: 'verified',
    };
    onUpdateUser(approved);
    await dbService.saveUser(approved);
    await dbService.updateUserStatus(targetUser.id, 'APPROVED');

    // Also approve associated KYC application if exists
    const matchingKyc = kycApplications.find(
      (k) =>
        k.id === `kyc_${targetUser.id}` ||
        (k.phone && targetUser.phone && k.phone.replace(/\D/g, '').slice(-10) === targetUser.phone.replace(/\D/g, '').slice(-10))
    );
    if (matchingKyc) {
      onApproveKyc(matchingKyc.id);
    }
  };

  const handleRejectUserAccount = async (targetUser: UserProfile, reason?: string) => {
    const rejReason = reason || 'Rejected by Branch Officer during documentation verification';
    const rejected: UserProfile = {
      ...targetUser,
      accountStatus: 'REJECTED',
      rejectionReason: rejReason,
      kycStatus: 'rejected',
    };
    onUpdateUser(rejected);
    await dbService.saveUser(rejected);
    await dbService.updateUserStatus(targetUser.id, 'REJECTED', rejReason);

    const matchingKyc = kycApplications.find(
      (k) =>
        k.id === `kyc_${targetUser.id}` ||
        (k.phone && targetUser.phone && k.phone.replace(/\D/g, '').slice(-10) === targetUser.phone.replace(/\D/g, '').slice(-10))
    );
    if (matchingKyc) {
      onRejectKyc(matchingKyc.id, rejReason);
    }
  };

  // Handle Verify App with UIDAI / NSDL Simulation
  const handleSimulateUidaiCheck = (appId: string) => {
    setVerifyingAppId(appId);
    setTimeout(() => {
      setVerifyingAppId(null);
      alert('UIDAI Aadhaar & NSDL PAN Biometric Handshake: Status VALID. Checksum Verified.');
    }, 1200);
  };

  // Handle Broadcast Dispatch
  const handleDispatchBroadcast = (e: React.FormEvent) => {
    e.preventDefault();
    if (!broadcastTitle || !broadcastBody) return;

    const alertItem: PushAlert = {
      id: `alert_admin_${Date.now()}`,
      title: broadcastTitle,
      body: broadcastBody,
      time: getNowBankingTimestamp(),
      read: false,
      type: broadcastType,
    };

    onBroadcastAlert(alertItem, broadcastTarget);
    setBroadcastSuccess(true);
    setTimeout(() => setBroadcastSuccess(false), 2500);
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-xs flex items-center justify-center p-1 sm:p-3 animate-in fade-in">
      <div className="w-full max-w-6xl bg-white border border-slate-200 text-slate-900 rounded-2xl shadow-2xl h-[96vh] flex flex-col overflow-hidden">
        
        {/* =========================================================================
            1. TOP ADMIN HEADER
        ========================================================================= */}
        <div className="p-3.5 sm:p-4 bg-gradient-to-r from-[#580824] via-[#861F41] to-[#97144D] text-white border-b border-[#700a2f] flex items-center justify-between shadow-xs">
          <div className="flex items-center gap-3">
            <AxisBankLogo size={44} />
            <div>
              <div className="flex items-center gap-2 flex-wrap">
                <h2 className="text-sm sm:text-base font-black text-white tracking-tight uppercase">
                  AXIS BANK CC VIP • Administration Terminal
                </h2>
                <span className="bg-amber-400 text-slate-950 text-[10px] font-black uppercase tracking-wider px-2 py-0.5 rounded-full shadow-xs">
                  CBS Master Admin
                </span>
                <span className="bg-emerald-500/20 text-emerald-300 border border-emerald-400/30 text-[9px] font-black uppercase px-2 py-0.5 rounded-full flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                  CBS Gateway Live (UTIB000001)
                </span>
              </div>
              <p className="text-[11px] text-amber-100 font-bold hidden sm:block">
                Axis Bank Mobile Banking & Corporate VIP Management Console
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => {
                setActiveTab('CREATE_USER');
                setUserCreatedSuccess(null);
              }}
              className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-amber-400 hover:bg-amber-300 text-slate-950 text-xs font-black uppercase tracking-wider transition shadow-sm active:scale-95"
            >
              <UserPlus className="w-3.5 h-3.5" />
              <span>+ New Customer</span>
            </button>

            <button
              onClick={onClose}
              className="px-3.5 py-1.5 rounded-xl bg-white/10 hover:bg-white/20 text-xs font-black uppercase tracking-wider text-white transition border border-white/20 shadow-xs flex items-center gap-1"
            >
              <X className="w-3.5 h-3.5" />
              <span>Exit Admin</span>
            </button>
          </div>
        </div>

        {/* =========================================================================
            2. SYSTEM KPI METRICS BANNER
        ========================================================================= */}
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2 p-2.5 sm:p-3 bg-slate-50 border-b border-slate-200 text-xs">
          {/* Liquidity */}
          <div className="bg-white p-2.5 rounded-xl border border-slate-200 shadow-2xs">
            <p className="text-[10px] text-slate-400 font-black uppercase tracking-widest flex items-center gap-1">
              <Landmark className="w-3 h-3 text-[#0a2540]" />
              Total Bank Liquidity
            </p>
            <p className="text-base sm:text-lg font-black font-sans text-slate-900 mt-0.5">
              ₹{(totalLiquidity / 100000).toFixed(2)} Lakh
            </p>
            <span className="text-[9px] text-emerald-700 font-bold">Sum of all managed deposits</span>
          </div>

          {/* Customer Base */}
          <div className="bg-white p-2.5 rounded-xl border border-slate-200 shadow-2xs">
            <p className="text-[10px] text-slate-400 font-black uppercase tracking-widest flex items-center gap-1">
              <Users className="w-3 h-3 text-blue-600" />
              Customer Accounts
            </p>
            <p className="text-base sm:text-lg font-black font-sans text-slate-900 mt-0.5">
              {users.length} <span className="text-xs text-slate-500 font-bold">({activeUsersCount} Active)</span>
            </p>
            <span className="text-[9px] text-red-600 font-bold">
              {blockedUsersCount > 0 ? `${blockedUsersCount} Frozen/Blocked` : '0 Blocked'}
            </span>
          </div>

          {/* Pending Inter-Bank & UPI Approvals (Admin review) */}
          <button
            type="button"
            onClick={() => setActiveTab('APPROVALS')}
            className={`p-2.5 rounded-xl border text-left shadow-2xs transition active:scale-98 ${
              pendingApprovalsCount > 0
                ? 'bg-amber-50 border-amber-300 ring-2 ring-amber-400/40'
                : 'bg-white border-slate-200'
            }`}
          >
            <p className="text-[10px] font-black uppercase tracking-widest flex items-center gap-1 text-amber-900">
              <Clock className="w-3 h-3 text-amber-700" />
              <span>Pending Approvals</span>
            </p>
            <p className="text-base sm:text-lg font-black font-sans text-amber-950 mt-0.5 flex items-center gap-1.5">
              <span>{pendingApprovalsCount}</span>
              <span className="text-xs font-bold text-amber-800">Queued</span>
            </p>
            <span className="text-[9px] font-bold text-amber-800 truncate block">
              {pendingApprovalsCount > 0 ? 'NEFT / UPI clearance needed' : 'All transfers cleared'}
            </span>
          </button>

          {/* Pending KYC */}
          <div className="bg-white p-2.5 rounded-xl border border-slate-200 shadow-2xs">
            <p className="text-[10px] text-slate-400 font-black uppercase tracking-widest flex items-center gap-1">
              <FileCheck className="w-3 h-3 text-amber-600" />
              Pending KYC Queue
            </p>
            <p className="text-base sm:text-lg font-black font-sans text-[#0a2540] mt-0.5">
              {pendingKycCount} Applications
            </p>
            <span className="text-[9px] text-amber-700 font-bold">UIDAI / NSDL checks needed</span>
          </div>

          {/* NPCI UPI Switch */}
          <div className="bg-white p-2.5 rounded-xl border border-slate-200 shadow-2xs">
            <p className="text-[10px] text-slate-400 font-black uppercase tracking-widest flex items-center gap-1">
              <Activity className="w-3 h-3 text-emerald-600" />
              NPCI UPI Switch
            </p>
            <p className="text-base sm:text-lg font-black font-sans text-emerald-700 mt-0.5 flex items-center gap-1">
              <span className="w-2 h-2 rounded-full bg-emerald-500" />
              ONLINE (99.99%)
            </p>
            <span className="text-[9px] text-slate-500 font-bold">Lat: 18ms • TPS: 450</span>
          </div>

          {/* Quick Branch Mode */}
          <div className="bg-white p-2.5 rounded-xl border border-slate-200 shadow-2xs flex flex-col justify-between">
            <div>
              <p className="text-[10px] text-slate-400 font-black uppercase tracking-widest">Active Operator</p>
              <p className="text-xs font-black text-slate-900 truncate">HO Chief Manager #KOL-01</p>
            </div>
            <div className="flex items-center gap-1.5 pt-1">
              <span className="text-[9px] bg-blue-50 text-blue-800 px-2 py-0.5 rounded font-black border border-blue-200">
                AUDIT LOGS ACTIVE
              </span>
            </div>
          </div>
        </div>

        {/* =========================================================================
            3. TAB NAVIGATION BAR
        ========================================================================= */}
        <div className="flex border-b border-slate-200 bg-slate-50 px-2 sm:px-4 gap-1 sm:gap-2 pt-2 overflow-x-auto scrollbar-none">
          {[
            { id: 'USERS', label: `Users & Accounts (${users.length})`, icon: Users },
            {
              id: 'APPROVALS',
              label: `Pending Approvals (${pendingApprovalsCount})`,
              icon: Clock,
              badge: pendingApprovalsCount > 0 ? pendingApprovalsCount : undefined,
            },
            { id: 'CREATE_USER', label: 'Create User', icon: UserPlus },
            { id: 'TELLER', label: 'Add / Deduct Money', icon: DollarSign },
            { id: 'KYC', label: `KYC Verification (${pendingKycCount})`, icon: FileCheck },
            { id: 'SERVICES', label: 'Services Matrix', icon: Sliders },
            { id: 'TRANSACTIONS', label: 'Audit Radar', icon: Activity },
            { id: 'LOCATIONS', label: 'Live GPS Tracking', icon: MapPin },
            { id: 'ADMIN_MANAGEMENT', label: 'Admin Management', icon: Shield },
            { id: 'BROADCAST', label: 'SMS & Email Hub', icon: Mail },
          ].map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as AdminTab)}
                className={`py-2 px-2.5 sm:px-3 text-xs font-black uppercase tracking-wider flex items-center gap-1.5 border-b-2 whitespace-nowrap transition ${
                  isActive
                    ? 'border-[#0a2540] text-[#0a2540] bg-white rounded-t-xl shadow-2xs font-black'
                    : 'border-transparent text-slate-500 hover:text-slate-900 font-bold'
                }`}
              >
                <Icon className="w-3.5 h-3.5" />
                <span>{tab.label}</span>
                {tab.badge && (
                  <span className="ml-0.5 px-1.5 py-0.2 text-[10px] font-black rounded-full bg-amber-500 text-white animate-pulse">
                    {tab.badge}
                  </span>
                )}
              </button>
            );
          })}
        </div>

        {/* =========================================================================
            4. TAB BODY CONTENT
        ========================================================================= */}
        <div className="flex-1 overflow-y-auto p-3 sm:p-5 bg-white">
          
          {/* -------------------------------------------------------------------
              TAB 1: USERS & ACCOUNT DIRECTORY (Block, Balances, Services)
          ------------------------------------------------------------------- */}
          {activeTab === 'USERS' && (
            <div className="space-y-4">
              {/* Filter & Search Bar */}
              <div className="flex flex-col sm:flex-row gap-2.5 sm:items-center justify-between pb-2 border-b border-slate-100">
                <div className="relative flex-1 max-w-md">
                  <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    value={userSearchQuery}
                    onChange={(e) => setUserSearchQuery(e.target.value)}
                    placeholder="Search by Name, Phone, A/c Number, VPA, CIF..."
                    className="w-full pl-9 pr-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-900 focus:outline-none focus:border-[#0a2540]"
                  />
                </div>

                <div className="flex items-center gap-2 flex-wrap">
                  {/* Status Filter */}
                  <select
                    value={userStatusFilter}
                    onChange={(e) => setUserStatusFilter(e.target.value as any)}
                    className="bg-slate-50 border border-slate-200 rounded-xl px-2.5 py-2 text-xs font-black text-slate-700 uppercase tracking-wider focus:outline-none"
                  >
                    <option value="ALL">Status: All</option>
                    <option value="ACTIVE">Active Accounts</option>
                    <option value="BLOCKED">Blocked / Frozen</option>
                  </select>

                  {/* KYC Filter */}
                  <select
                    value={userKycFilter}
                    onChange={(e) => setUserKycFilter(e.target.value as any)}
                    className="bg-slate-50 border border-slate-200 rounded-xl px-2.5 py-2 text-xs font-black text-slate-700 uppercase tracking-wider focus:outline-none"
                  >
                    <option value="ALL">KYC: All</option>
                    <option value="VERIFIED">KYC Verified</option>
                    <option value="PENDING">KYC Pending</option>
                    <option value="REJECTED">KYC Rejected</option>
                  </select>

                  {/* Account Type Filter */}
                  <select
                    value={userTypeFilter}
                    onChange={(e) => setUserTypeFilter(e.target.value)}
                    className="bg-slate-50 border border-slate-200 rounded-xl px-2.5 py-2 text-xs font-black text-slate-700 uppercase tracking-wider focus:outline-none"
                  >
                    <option value="ALL">Type: All</option>
                    <option value="SAVINGS">Savings</option>
                    <option value="CURRENT">Current/Merchant</option>
                    <option value="KCC_FARMER">Kisan Credit (KCC)</option>
                    <option value="PENSION">Senior Pension</option>
                  </select>
                </div>
              </div>

              {/* Users Cards / Table */}
              <div className="space-y-3">
                {filteredUsers.length === 0 ? (
                  <div className="text-center py-12 bg-slate-50 rounded-2xl border border-dashed border-slate-300 space-y-2">
                    <Users className="w-10 h-10 text-slate-400 mx-auto" />
                    <p className="text-xs font-black uppercase tracking-wider text-slate-600">
                      No matching customer accounts found
                    </p>
                    <p className="text-[11px] text-slate-400 font-bold">
                      Try clearing filters or search queries
                    </p>
                  </div>
                ) : (
                  filteredUsers.map((u) => {
                    const isSelected = currentUser?.id === u.id;
                    const totalBal =
                      (u.savingsBalance || 0) +
                      (u.walletBalance || 0) +
                      (u.upiLiteBalance || 0) +
                      (u.fixedDepositBalance || 0);

                    return (
                      <div
                        key={u.id}
                        className={`p-4 rounded-2xl border transition-all ${
                          u.isBlocked
                            ? 'bg-red-50/40 border-red-200 shadow-2xs'
                            : isSelected
                            ? 'bg-blue-50/50 border-[#0a2540] shadow-sm'
                            : 'bg-white border-slate-200 hover:border-slate-300 shadow-2xs'
                        }`}
                      >
                        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-3">
                          {/* User Identity Column */}
                          <div className="flex items-start gap-3">
                            <div
                              className={`w-11 h-11 rounded-2xl font-black text-base flex items-center justify-center flex-shrink-0 shadow-xs ${
                                u.isBlocked
                                  ? 'bg-red-600 text-white'
                                  : isSelected
                                  ? 'bg-[#0a2540] text-amber-300'
                                  : 'bg-slate-100 text-slate-800'
                              }`}
                            >
                              {u.name.charAt(0)}
                            </div>

                            <div className="space-y-1">
                              <div className="flex items-center gap-2 flex-wrap">
                                <span className="font-black text-sm text-slate-900">
                                  {u.name}
                                </span>

                                {/* Account Type Badge */}
                                <span className="text-[10px] font-black uppercase tracking-wider px-2 py-0.5 rounded-md bg-slate-100 text-slate-700 border border-slate-200">
                                  {u.accountType || 'SAVINGS'}
                                </span>

                                {/* Status Badge */}
                                {u.isBlocked ? (
                                  <span className="text-[10px] font-black uppercase tracking-wider px-2 py-0.5 rounded-md bg-red-100 text-red-700 border border-red-200 flex items-center gap-1">
                                    <Lock className="w-3 h-3" />
                                    BLOCKED / FROZEN
                                  </span>
                                ) : (
                                  <span className="text-[10px] font-black uppercase tracking-wider px-2 py-0.5 rounded-md bg-emerald-100 text-emerald-800 border border-emerald-200 flex items-center gap-1">
                                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-600 animate-pulse" />
                                    ACTIVE
                                  </span>
                                )}

                                {/* KYC Badge */}
                                <button
                                  onClick={() => {
                                    const nextStatus =
                                      u.kycStatus === 'verified'
                                        ? 'pending'
                                        : u.kycStatus === 'pending'
                                        ? 'rejected'
                                        : 'verified';
                                    onUpdateKycStatus(u.id, nextStatus);
                                  }}
                                  title="Click to toggle KYC status"
                                  className={`text-[10px] font-black uppercase tracking-wider px-2 py-0.5 rounded-md border transition active:scale-95 ${
                                    u.kycStatus === 'verified'
                                      ? 'bg-emerald-50 text-emerald-700 border-emerald-200'
                                      : u.kycStatus === 'pending'
                                      ? 'bg-amber-50 text-amber-800 border-amber-200'
                                      : 'bg-red-50 text-red-700 border-red-200'
                                  }`}
                                >
                                  KYC: {u.kycStatus}
                                </button>

                                {u.accountStatus === 'PENDING_APPROVAL' && (
                                  <span className="text-[10px] font-black uppercase tracking-wider px-2 py-0.5 rounded-md bg-amber-100 text-amber-900 border border-amber-300 animate-pulse flex items-center gap-1">
                                    <Clock className="w-3 h-3" />
                                    <span>Awaiting Approval</span>
                                  </span>
                                )}

                                {u.accountStatus === 'REJECTED' && (
                                  <span className="text-[10px] font-black uppercase tracking-wider px-2 py-0.5 rounded-md bg-red-100 text-red-800 border border-red-300">
                                    Registration Rejected
                                  </span>
                                )}

                                {isSelected && (
                                  <span className="text-[9px] font-black uppercase bg-[#0a2540] text-white px-1.5 py-0.5 rounded">
                                    CURRENTLY VIEWING
                                  </span>
                                )}
                              </div>

                              <p className="text-xs text-slate-600 font-mono font-bold flex items-center gap-2 flex-wrap">
                                <span>A/C: {u.accountNumber}</span>
                                <span>•</span>
                                <span>Phone: {u.phone}</span>
                                <span>•</span>
                                <span className="text-slate-500 font-sans">{u.branchName || 'Axis Bank Corporate HO (Mumbai)'}</span>
                              </p>

                              {/* Customer ID, NetBanking ID & MPIN Badges */}
                              <div className="flex items-center gap-1.5 flex-wrap pt-0.5">
                                <span className="text-[10px] font-mono font-black bg-amber-50 text-amber-900 border border-amber-300 px-2 py-0.5 rounded-md flex items-center gap-1 shadow-2xs">
                                  <ShieldCheck className="w-3 h-3 text-amber-700" />
                                  <span>Cust ID: {u.cifNumber || 'Not Issued'}</span>
                                </span>
                                {u.netbankingLoginId && (
                                  <span className="text-[10px] font-mono font-black bg-rose-50 text-[#861F41] border border-rose-200 px-2 py-0.5 rounded-md flex items-center gap-1 shadow-2xs">
                                    <KeyRound className="w-3 h-3 text-[#861F41]" />
                                    <span>NetBanking: {u.netbankingLoginId}</span>
                                  </span>
                                )}
                                <span className="text-[10px] font-mono font-black bg-slate-100 text-slate-700 border border-slate-300 px-2 py-0.5 rounded-md flex items-center gap-1 shadow-2xs">
                                  <span>MPIN: {u.mpin || '1234'}</span>
                                </span>
                                {u.virtualCards && u.virtualCards.length > 0 && (
                                  <span className="text-[10px] font-mono font-black bg-emerald-50 text-emerald-800 border border-emerald-300 px-2 py-0.5 rounded-md flex items-center gap-1 shadow-2xs">
                                    <CreditCard className="w-3 h-3 text-emerald-700" />
                                    <span>{u.virtualCards.length} Virtual Card{u.virtualCards.length > 1 ? 's' : ''}</span>
                                  </span>
                                )}
                              </div>

                              {u.isBlocked && u.blockReason && (
                                <p className="text-[11px] text-red-700 font-bold bg-red-100/60 px-2 py-0.5 rounded border border-red-200 inline-block">
                                  Freeze Reason: {u.blockReason}
                                </p>
                              )}
                            </div>
                          </div>

                          {/* Balances Column */}
                          <div className="bg-slate-50 p-2.5 rounded-xl border border-slate-200 grid grid-cols-2 sm:grid-cols-4 gap-2 text-right">
                            <div>
                              <p className="text-[9px] text-slate-400 font-black uppercase tracking-wider">Savings A/C</p>
                              <p className="font-sans font-black text-xs text-slate-900">
                                ₹{(u.savingsBalance || 0).toLocaleString('en-IN', { minimumFractionDigits: 2 })}
                              </p>
                            </div>
                            <div>
                              <p className="text-[9px] text-slate-400 font-black uppercase tracking-wider">Wallet</p>
                              <p className="font-sans font-black text-xs text-blue-700">
                                ₹{(u.walletBalance || 0).toLocaleString('en-IN', { minimumFractionDigits: 2 })}
                              </p>
                            </div>
                            <div>
                              <p className="text-[9px] text-slate-400 font-black uppercase tracking-wider">UPI Lite</p>
                              <p className="font-sans font-black text-xs text-purple-700">
                                ₹{(u.upiLiteBalance || 0).toLocaleString('en-IN', { minimumFractionDigits: 2 })}
                              </p>
                            </div>
                            <div>
                              <p className="text-[9px] text-slate-400 font-black uppercase tracking-wider">Fixed Deposit</p>
                              <p className="font-sans font-black text-xs text-amber-700">
                                ₹{(u.fixedDepositBalance || 0).toLocaleString('en-IN', { minimumFractionDigits: 2 })}
                              </p>
                            </div>
                          </div>

                          {/* Action Buttons Column */}
                          <div className="flex items-center gap-1.5 flex-wrap self-end lg:self-auto">
                            {/* Approve / Reject for Pending Online Registrations */}
                            {u.accountStatus === 'PENDING_APPROVAL' && (
                              <>
                                <button
                                  onClick={() => handleApproveUserAccount(u)}
                                  className="px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-black uppercase tracking-wider transition shadow-sm flex items-center gap-1 active:scale-95"
                                  title="Approve and activate customer CBS account"
                                >
                                  <CheckCircle2 className="w-3.5 h-3.5" />
                                  <span>Approve A/C</span>
                                </button>
                                <button
                                  onClick={() => {
                                    const reason = prompt('Enter rejection reason for this registration:', 'KYC document verification incomplete');
                                    if (reason) handleRejectUserAccount(u, reason);
                                  }}
                                  className="px-3 py-1.5 rounded-xl bg-red-50 hover:bg-red-100 text-red-700 border border-red-200 text-xs font-black uppercase tracking-wider transition flex items-center gap-1 active:scale-95"
                                  title="Reject online application"
                                >
                                  <XCircle className="w-3.5 h-3.5" />
                                  <span>Reject</span>
                                </button>
                              </>
                            )}

                            {/* Add / Deduct Money Button */}
                            <button
                              onClick={() => {
                                setActiveActionUser(u);
                                setMoneyActionType('CREDIT');
                                setMoneyAmount('5000');
                                setMoneyTargetBalance('savings');
                                setMoneyReason('Cash Deposit at Branch Counter');
                                setActionModalType('MONEY');
                              }}
                              className="px-2.5 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-black uppercase tracking-wider transition shadow-2xs flex items-center gap-1 active:scale-95"
                              title="Add Money (Credit) to customer balance"
                            >
                              <PlusCircle className="w-3.5 h-3.5" />
                              <span>Add ₹</span>
                            </button>

                            <button
                              onClick={() => {
                                setActiveActionUser(u);
                                setMoneyActionType('DEBIT');
                                setMoneyAmount('1000');
                                setMoneyTargetBalance('savings');
                                setMoneyReason('Branch Teller Cash Withdrawal / Debit');
                                setActionModalType('MONEY');
                              }}
                              className="px-2.5 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-900 text-white text-xs font-black uppercase tracking-wider transition shadow-2xs flex items-center gap-1 active:scale-95"
                              title="Deduct Money (Debit) from customer balance"
                            >
                              <MinusCircle className="w-3.5 h-3.5" />
                              <span>Deduct ₹</span>
                            </button>

                            {/* Block / Unblock Button */}
                            <button
                              onClick={() => handleToggleBlock(u)}
                              className={`px-2.5 py-1.5 rounded-xl text-xs font-black uppercase tracking-wider transition border shadow-2xs flex items-center gap-1 active:scale-95 ${
                                u.isBlocked
                                  ? 'bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border-emerald-300'
                                  : 'bg-red-50 hover:bg-red-100 text-red-700 border-red-200'
                              }`}
                              title={u.isBlocked ? 'Unblock customer account' : 'Block / freeze account'}
                            >
                              {u.isBlocked ? (
                                <>
                                  <Unlock className="w-3.5 h-3.5" />
                                  <span>Unblock</span>
                                </>
                              ) : (
                                <>
                                  <Lock className="w-3.5 h-3.5" />
                                  <span>Block</span>
                                </>
                              )}
                            </button>

                            {/* Edit Customer Details Button */}
                            <button
                              onClick={() => handleOpenEditUserModal(u)}
                              className="px-2.5 py-1.5 rounded-xl bg-blue-50 hover:bg-blue-100 text-blue-900 border border-blue-200 text-xs font-black uppercase tracking-wider transition active:scale-95 flex items-center gap-1 shadow-2xs"
                              title="Edit account holder name, phone, email, address, account number, branch or KYC details"
                            >
                              <Edit3 className="w-3.5 h-3.5 text-blue-700" />
                              <span className="hidden sm:inline">Edit Details</span>
                            </button>

                            {/* Issue Cust ID & NetBanking Credentials Button */}
                            <button
                              onClick={() => handleOpenIssueNetbankingModal(u)}
                              className="px-2.5 py-1.5 rounded-xl bg-gradient-to-r from-[#861F41] to-[#580824] hover:from-[#700a2f] hover:to-[#450519] text-amber-300 border border-amber-400/40 text-xs font-black uppercase tracking-wider transition shadow-2xs flex items-center gap-1 active:scale-95"
                              title="Issue or Re-issue Customer ID and NetBanking Credentials with instant Email and SMS welcome kit"
                            >
                              <KeyRound className="w-3.5 h-3.5 text-amber-400" />
                              <span>Issue Cust ID / NetBanking</span>
                            </button>

                            {/* Send Individual SMS / Modern Email Button */}
                            <button
                              onClick={() => handleOpenIndividualCommModal(u)}
                              className="px-2.5 py-1.5 rounded-xl bg-purple-50 hover:bg-purple-100 text-purple-900 border border-purple-200 text-xs font-black uppercase tracking-wider transition active:scale-95 flex items-center gap-1 shadow-2xs"
                              title="Send individual SMS and modern banking styled email to this customer"
                            >
                              <Mail className="w-3.5 h-3.5 text-purple-700" />
                              <span className="hidden sm:inline">Send SMS/Email</span>
                            </button>

                            {/* Manage Services Button */}
                            <button
                              onClick={() => {
                                setActiveActionUser(u);
                                setActionModalType('SERVICES');
                              }}
                              className="px-2.5 py-1.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-800 border border-slate-200 text-xs font-black uppercase tracking-wider transition active:scale-95 flex items-center gap-1"
                              title="Toggle UPI, Soundbox, KCC, Biometrics"
                            >
                              <Sliders className="w-3.5 h-3.5 text-blue-700" />
                              <span className="hidden sm:inline">Services</span>
                            </button>

                            {/* Set / Change MPIN Button */}
                            <button
                              onClick={() => {
                                setMpinModalUser(u);
                                setAdminMpinInput(u.mpin || '1234');
                                setAdminMpinMsg('');
                              }}
                              className="px-2.5 py-1.5 rounded-xl bg-amber-50 hover:bg-amber-100 text-amber-900 border border-amber-300 text-xs font-black uppercase tracking-wider transition active:scale-95 flex items-center gap-1"
                              title="Set or reset customer's 4-digit security MPIN"
                            >
                              <KeyRound className="w-3.5 h-3.5 text-amber-700" />
                              <span className="hidden sm:inline">Set MPIN</span>
                            </button>

                            {/* Switch to Customer View */}
                            <button
                              onClick={() => {
                                if (u.isBlocked) {
                                  alert(`⚠️ Cannot access blocked account: A/C ${u.accountNumber} (${u.name}) is currently frozen / blocked by administration.\nReason: ${u.blockReason || 'Administrative Freeze'}.\nYou must unblock the account first before logging in.`);
                                  return;
                                }
                                onSelectUser(u);
                                onClose();
                              }}
                              className={`px-2.5 py-1.5 rounded-xl text-xs font-black uppercase tracking-wider transition shadow-2xs active:scale-95 flex items-center gap-1 ${
                                u.isBlocked
                                  ? 'bg-slate-200 text-slate-400 cursor-not-allowed'
                                  : 'bg-[#0a2540] hover:bg-[#071d34] text-white'
                              }`}
                              title={u.isBlocked ? 'Cannot log in to a blocked/frozen account' : 'View and test app as this customer'}
                            >
                              <Eye className={`w-3.5 h-3.5 ${u.isBlocked ? 'text-slate-400' : 'text-amber-300'}`} />
                              <span className="hidden sm:inline">Switch</span>
                            </button>

                            {/* Delete Account Completely */}
                            <button
                              onClick={() => {
                                setActiveActionUser(u);
                                setActionModalType('DELETE_USER');
                              }}
                              className="px-2.5 py-1.5 rounded-xl bg-red-50 hover:bg-red-100 text-red-700 border border-red-200 text-xs font-black uppercase tracking-wider transition active:scale-95 flex items-center gap-1 shadow-2xs"
                              title="Completely delete account and records from CBS"
                            >
                              <Trash2 className="w-3.5 h-3.5 text-red-600" />
                              <span className="hidden sm:inline">Delete</span>
                            </button>
                          </div>
                        </div>
                      </div>
                    );
                  })
                )}
              </div>
            </div>
          )}

          {/* -------------------------------------------------------------------
              TAB: PENDING APPROVALS (Other Bank NEFT/RTGS & UPI Clearance)
          ------------------------------------------------------------------- */}
          {activeTab === 'APPROVALS' && (
            <div className="space-y-4">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-100 pb-3">
                <div>
                  <h3 className="text-sm font-black text-slate-900 uppercase tracking-wider flex items-center gap-2">
                    <Clock className="w-4 h-4 text-amber-600" />
                    <span>Pending Transfer Approvals & Clearance Queue</span>
                  </h3>
                  <p className="text-xs text-slate-500 font-bold">
                    Mandatory Officer Verification for Inter-Bank (Other Bank NEFT/RTGS/IMPS) and Outward UPI Scanner Payments
                  </p>
                </div>

                <div className="flex items-center gap-1 bg-slate-100 p-1 rounded-xl">
                  <button
                    onClick={() => setApprovalFilter('ALL')}
                    className={`px-3 py-1 text-xs font-black uppercase tracking-wider rounded-lg transition ${
                      approvalFilter === 'ALL'
                        ? 'bg-white text-slate-900 shadow-2xs'
                        : 'text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    All ({pendingApprovalsCount})
                  </button>
                  <button
                    onClick={() => setApprovalFilter('OTHER_BANK')}
                    className={`px-3 py-1 text-xs font-black uppercase tracking-wider rounded-lg transition ${
                      approvalFilter === 'OTHER_BANK'
                        ? 'bg-white text-slate-900 shadow-2xs'
                        : 'text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    Other Bank ({otherBankPendingCount})
                  </button>
                  <button
                    onClick={() => setApprovalFilter('UPI')}
                    className={`px-3 py-1 text-xs font-black uppercase tracking-wider rounded-lg transition ${
                      approvalFilter === 'UPI'
                        ? 'bg-white text-slate-900 shadow-2xs'
                        : 'text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    UPI / QR ({upiPendingCount})
                  </button>
                </div>
              </div>

              {approvalSuccessMsg && (
                <div className="p-3 bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs font-bold rounded-xl flex items-center justify-between animate-in fade-in">
                  <span>{approvalSuccessMsg}</span>
                  <button
                    onClick={() => setApprovalSuccessMsg(null)}
                    className="text-emerald-700 hover:text-emerald-900 text-xs uppercase font-black"
                  >
                    Dismiss
                  </button>
                </div>
              )}

              {/* Transactions List */}
              {pendingApprovals.length === 0 ? (
                <div className="text-center py-12 bg-slate-50 rounded-2xl border border-slate-200 space-y-3">
                  <CheckCircle2 className="w-10 h-10 text-emerald-600 mx-auto" />
                  <p className="text-sm font-black text-slate-800">Clearance Queue is Empty</p>
                  <p className="text-xs text-slate-500 font-bold max-w-sm mx-auto">
                    All inter-bank and UPI transactions have been verified and processed by the treasury desk.
                  </p>
                </div>
              ) : (
                <div className="space-y-3">
                  {pendingApprovals
                    .filter((tx) => {
                      if (approvalFilter === 'OTHER_BANK') return tx.transferType === 'OTHER_BANK';
                      if (approvalFilter === 'UPI') return tx.transferType === 'UPI';
                      return true;
                    })
                    .map((tx) => {
                      const sender = users.find((u) => u.id === tx.userId);
                      return (
                        <div
                          key={tx.id}
                          className="p-4 bg-white rounded-2xl border-2 border-amber-200 hover:border-amber-400 shadow-sm transition space-y-3"
                        >
                          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-100 pb-3">
                            <div className="flex items-center gap-3">
                              <span
                                className={`px-2.5 py-1 rounded-lg text-xs font-black uppercase tracking-wider ${
                                  tx.transferType === 'OTHER_BANK'
                                    ? 'bg-purple-100 text-purple-900 border border-purple-200'
                                    : 'bg-blue-100 text-blue-900 border border-blue-200'
                                }`}
                              >
                                {tx.transferType === 'OTHER_BANK' ? 'Other Bank (NEFT / RTGS)' : 'UPI / Scanner QR'}
                              </span>

                              <span className="text-xs font-mono font-bold text-slate-500">
                                Ref: {tx.utrNumber || tx.id}
                              </span>

                              <span className="text-xs font-bold text-slate-400">
                                {formatTransactionTimestamp(tx.timestamp, tx.createdAt, tx.id)}
                              </span>
                            </div>

                            <div className="flex items-center gap-1.5">
                              {tx.status === 'HOLD' ? (
                                <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-black bg-orange-100 text-orange-900 border border-orange-300">
                                  <PauseCircle className="w-3.5 h-3.5 text-orange-700" />
                                  <span>ON HOLD • {tx.approvalReason || 'Review Pending'}</span>
                                </span>
                              ) : tx.status === 'PROCESSED' ? (
                                <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-black bg-blue-100 text-blue-900 border border-blue-300 animate-pulse">
                                  <Clock className="w-3 h-3 text-blue-700" />
                                  <span>PROCESSED • Awaiting Admin Clearance</span>
                                </span>
                              ) : (
                                <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-black bg-amber-100 text-amber-900 border border-amber-300 animate-pulse">
                                  <Clock className="w-3 h-3 text-amber-700" />
                                  <span>Awaiting Admin Clearance</span>
                                </span>
                              )}
                            </div>
                          </div>

                          {/* Details Grid */}
                          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
                            {/* Sender Info */}
                            <div className="bg-slate-50 p-3 rounded-xl border border-slate-200 space-y-1">
                              <p className="text-[10px] font-black uppercase text-slate-400">Payer / Customer</p>
                              <p className="font-black text-slate-900 text-sm">{sender?.name || 'Customer'}</p>
                              <p className="font-mono text-slate-600">A/C: {sender?.accountNumber || 'N/A'}</p>
                              <p className="font-mono text-slate-500 text-[11px]">CIF: {sender?.cifNumber || 'N/A'}</p>
                            </div>

                            {/* Recipient Info */}
                            <div className="bg-slate-50 p-3 rounded-xl border border-slate-200 space-y-1">
                              <p className="text-[10px] font-black uppercase text-slate-400">Beneficiary / Destination</p>
                              <p className="font-black text-slate-900 text-sm">
                                {tx.beneficiaryName || tx.title}
                              </p>
                              {tx.beneficiaryAccount && (
                                <p className="font-mono text-slate-600">A/C: {tx.beneficiaryAccount}</p>
                              )}
                              {tx.recipientIfsc && (
                                <p className="font-mono text-slate-600">IFSC: {tx.recipientIfsc}</p>
                              )}
                              {(tx.recipientVpa || tx.scannerAddress) && (
                                <p className="font-mono text-blue-700 font-bold">
                                  VPA: {tx.recipientVpa || tx.scannerAddress}
                                </p>
                              )}
                            </div>

                            {/* Transfer Amount & Purpose */}
                            <div className="bg-slate-50 p-3 rounded-xl border border-slate-200 flex flex-col justify-between">
                              <div>
                                <p className="text-[10px] font-black uppercase text-slate-400">Amount & Remarks</p>
                                <p className="text-xl font-black font-sans text-[#0a2540] mt-0.5">
                                  ₹{tx.amount.toLocaleString('en-IN', { minimumFractionDigits: 2 })}
                                </p>
                                <p className="text-slate-600 font-bold mt-1 text-[11px] truncate">
                                  {tx.subTitle || 'External fund settlement'}
                                </p>
                              </div>

                              <div className="pt-2 text-[10px] text-slate-500 font-bold flex items-center justify-between">
                                <span>Status: {tx.status}</span>
                                {tx.qrData && (
                                  <span className="text-emerald-700 font-black flex items-center gap-0.5">
                                    <QrCode className="w-3 h-3" /> QR Captured
                                  </span>
                                )}
                              </div>
                            </div>
                          </div>

                          {/* Action Buttons: View QR, Edit, Hold, Reject, Mark Paid, Delete */}
                          <div className="flex flex-wrap items-center justify-between gap-2 pt-2 border-t border-slate-100">
                            <div className="flex items-center gap-1.5">
                              {(tx.qrData || tx.scannerAddress || tx.recipientVpa) && (
                                <button
                                  type="button"
                                  onClick={() => setViewQrModalTx(tx)}
                                  className="px-3 py-1.5 rounded-xl bg-blue-50 hover:bg-blue-100 text-blue-700 border border-blue-200 text-xs font-black uppercase tracking-wider transition active:scale-95 flex items-center gap-1.5"
                                  title="View captured QR code or VPA details"
                                >
                                  <QrCode className="w-3.5 h-3.5 text-blue-600" />
                                  <span>View QR / VPA</span>
                                </button>
                              )}

                              <button
                                type="button"
                                onClick={() => openEditModal(tx)}
                                className="px-3 py-1.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-black uppercase tracking-wider transition active:scale-95 flex items-center gap-1"
                                title="Edit transaction history"
                              >
                                <Edit3 className="w-3.5 h-3.5 text-slate-600" />
                                <span>Edit</span>
                              </button>

                              <button
                                type="button"
                                onClick={() => handleDeleteTx(tx)}
                                className="px-2.5 py-1.5 rounded-xl bg-slate-100 hover:bg-red-50 text-slate-600 hover:text-red-700 text-xs font-black uppercase tracking-wider transition active:scale-95 flex items-center gap-1"
                                title="Delete transaction from database"
                              >
                                <Trash2 className="w-3.5 h-3.5 text-red-500" />
                                <span>Delete</span>
                              </button>
                            </div>

                            <div className="flex items-center gap-1.5">
                              <button
                                type="button"
                                onClick={() => {
                                  setHoldModalTx(tx);
                                  setHoldReasonInput(tx.approvalReason || 'Under administrative review');
                                }}
                                className="px-3 py-1.5 rounded-xl bg-orange-50 hover:bg-orange-100 text-orange-800 border border-orange-200 text-xs font-black uppercase tracking-wider transition active:scale-95 flex items-center gap-1.5"
                                title="Put transaction on hold"
                              >
                                <PauseCircle className="w-3.5 h-3.5 text-orange-600" />
                                <span>{tx.status === 'HOLD' ? 'Modify Hold' : 'Put on Hold'}</span>
                              </button>

                              <button
                                type="button"
                                onClick={() => {
                                  setRejectionModalTx(tx);
                                  setRejectionReasonInput('Recipient account verification mismatch');
                                }}
                                className="px-3 py-1.5 rounded-xl bg-red-50 hover:bg-red-100 text-red-700 border border-red-200 text-xs font-black uppercase tracking-wider transition active:scale-95 flex items-center gap-1.5"
                                title="Reject transaction and refund customer"
                              >
                                <XCircle className="w-3.5 h-3.5 text-red-600" />
                                <span>Reject & Refund</span>
                              </button>

                              <button
                                type="button"
                                onClick={() => {
                                  if (onApproveTransaction) {
                                    onApproveTransaction(tx.id);
                                    setApprovalSuccessMsg(
                                      `Transaction ${tx.upiRefId || tx.id} for ₹${tx.amount.toLocaleString(
                                        'en-IN'
                                      )} marked as PAID and settled successfully!`
                                    );
                                    setTimeout(() => setApprovalSuccessMsg(null), 4000);
                                  }
                                }}
                                className="px-4 py-1.5 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-black uppercase tracking-wider transition shadow-sm active:scale-95 flex items-center gap-1.5"
                                title="Mark transaction as Paid / Completed"
                              >
                                <CheckCircle2 className="w-4 h-4 text-amber-300" />
                                <span>Mark Paid</span>
                              </button>
                            </div>
                          </div>
                        </div>
                      );
                    })}
                </div>
              )}
            </div>
          )}

          {/* -------------------------------------------------------------------
              TAB 2: CREATE USER (CBS Manual Onboarding)
          ------------------------------------------------------------------- */}
          {activeTab === 'CREATE_USER' && (
            <div className="max-w-2xl mx-auto space-y-4">
              <div className="border-b border-slate-100 pb-3 flex items-center justify-between">
                <div>
                  <h3 className="text-sm font-black text-slate-900 uppercase tracking-wider flex items-center gap-2">
                    <UserPlus className="w-4 h-4 text-[#861F41]" />
                    <span>Customer Account Opening & Onboarding</span>
                  </h3>
                  <p className="text-xs text-slate-500 font-bold">
                    Provision instant core banking account, NPCI UPI ID, and Axis CC VIP credit limits
                  </p>
                </div>
                <span className="text-[10px] font-black uppercase tracking-wider bg-emerald-50 text-emerald-800 border border-emerald-200 px-2 py-1 rounded-lg">
                  Instant CBS Provisioning
                </span>
              </div>

              {userCreatedSuccess ? (
                <div className="p-6 bg-emerald-50 border border-emerald-200 rounded-3xl text-center space-y-4 animate-in zoom-in-95">
                  <CheckCircle2 className="w-12 h-12 text-emerald-600 mx-auto" />
                  <div className="space-y-1">
                    <h4 className="text-base font-black text-emerald-900">
                      Customer Account Created Successfully!
                    </h4>
                    <p className="text-xs text-emerald-700 font-bold">
                      Account has been added to Axis Bank CC VIP CBS Core Ledger.
                    </p>
                  </div>

                  <div className="bg-white p-4 rounded-2xl border border-emerald-200 max-w-md mx-auto text-left space-y-2 text-xs">
                    <div className="flex justify-between">
                      <span className="text-slate-500 font-bold">Customer Name:</span>
                      <span className="font-black text-slate-900">{userCreatedSuccess.name}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-500 font-bold">Account Number:</span>
                      <span className="font-mono font-black text-slate-900">{userCreatedSuccess.accountNumber}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-500 font-bold">NPCI UPI ID:</span>
                      <span className="font-mono font-black text-blue-700">{userCreatedSuccess.upiId}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-500 font-bold">CIF Number:</span>
                      <span className="font-mono font-black text-slate-900">{userCreatedSuccess.cifNumber}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-500 font-bold">Opening Balance:</span>
                      <span className="font-mono font-black text-emerald-700">
                        ₹{(userCreatedSuccess.savingsBalance || 0).toLocaleString('en-IN', { minimumFractionDigits: 2 })}
                      </span>
                    </div>
                  </div>

                  <div className="flex items-center justify-center gap-3 pt-2">
                    <button
                      onClick={() => {
                        onSelectUser(userCreatedSuccess);
                        onClose();
                      }}
                      className="px-5 py-2.5 rounded-xl bg-[#0a2540] hover:bg-[#071d34] text-white font-black uppercase tracking-wider text-xs shadow-md flex items-center gap-1.5"
                    >
                      <Eye className="w-4 h-4 text-amber-300" />
                      <span>Switch to This Customer Now</span>
                    </button>

                    <button
                      onClick={() => setUserCreatedSuccess(null)}
                      className="px-4 py-2.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-800 font-black uppercase tracking-wider text-xs"
                    >
                      Create Another Customer
                    </button>
                  </div>
                </div>
              ) : (
                <form onSubmit={handleCreateUserSubmit} className="space-y-4">
                  {/* Name & Phone */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="text-xs font-black text-slate-700 uppercase tracking-wider block mb-1">
                        Full Name (as per Aadhaar / Official ID) *
                      </label>
                      <input
                        type="text"
                        required
                        placeholder="e.g. Soumitra Chatterjee"
                        value={newUserName}
                        onChange={(e) => setNewUserName(e.target.value)}
                        className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs font-bold text-slate-900 focus:outline-none focus:border-[#0a2540]"
                      />
                    </div>

                    <div>
                      <label className="text-xs font-black text-slate-700 uppercase tracking-wider block mb-1">
                        Mobile Number (10 Digits) *
                      </label>
                      <input
                        type="tel"
                        required
                        placeholder="9830012345"
                        value={newUserPhone}
                        onChange={(e) => setNewUserPhone(e.target.value)}
                        className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs font-bold text-slate-900 font-mono focus:outline-none focus:border-[#0a2540]"
                      />
                    </div>
                  </div>

                  {/* Email & Branch */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="text-xs font-black text-slate-700 uppercase tracking-wider block mb-1">
                        Email Address (Optional)
                      </label>
                      <input
                        type="email"
                        placeholder="soumitra@example.com"
                        value={newUserEmail}
                        onChange={(e) => setNewUserEmail(e.target.value)}
                        className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs font-bold text-slate-900 focus:outline-none focus:border-[#0a2540]"
                      />
                    </div>

                    <div>
                      <label className="text-xs font-black text-slate-700 uppercase tracking-wider block mb-1">
                        Home Branch
                      </label>
                      <select
                        value={newUserBranch}
                        onChange={(e) => setNewUserBranch(e.target.value)}
                        className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs font-bold text-slate-900 focus:outline-none focus:border-[#0a2540]"
                      >
                        {BRANCH_OPTIONS.map((br) => (
                          <option key={br} value={br}>
                            {br}
                          </option>
                        ))}
                      </select>
                    </div>
                  </div>

                  {/* Account Type Selector */}
                  <div>
                    <label className="text-xs font-black text-slate-700 uppercase tracking-wider block mb-1">
                      Account Classification
                    </label>
                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                      {[
                        { id: 'SAVINGS', label: 'Regular Savings' },
                        { id: 'CURRENT', label: 'Current / Merchant' },
                        { id: 'KCC_FARMER', label: 'Kisan Credit (KCC)' },
                        { id: 'PENSION', label: 'Senior Pension' },
                      ].map((type) => (
                        <button
                          key={type.id}
                          type="button"
                          onClick={() => setNewUserAccountType(type.id as any)}
                          className={`py-2 text-xs font-black uppercase tracking-wider rounded-xl border transition ${
                            newUserAccountType === type.id
                              ? 'bg-[#0a2540] border-[#0a2540] text-amber-300 shadow-xs'
                              : 'bg-slate-50 border-slate-200 text-slate-700 hover:bg-slate-100'
                          }`}
                        >
                          {type.label}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Government KYC Identifiers */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="text-xs font-black text-slate-700 uppercase tracking-wider block mb-1">
                        Aadhaar Number (12 Digits)
                      </label>
                      <input
                        type="text"
                        placeholder="XXXX-XXXX-8921"
                        value={newUserAadhaar}
                        onChange={(e) => setNewUserAadhaar(e.target.value)}
                        className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs font-bold text-slate-900 font-mono focus:outline-none focus:border-[#0a2540]"
                      />
                    </div>

                    <div>
                      <label className="text-xs font-black text-slate-700 uppercase tracking-wider block mb-1">
                        PAN Card Number (10 Alphanumeric)
                      </label>
                      <input
                        type="text"
                        placeholder="ABCPS8912K"
                        value={newUserPan}
                        onChange={(e) => setNewUserPan(e.target.value.toUpperCase())}
                        className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs font-bold text-slate-900 font-mono uppercase focus:outline-none focus:border-[#0a2540]"
                      />
                    </div>
                  </div>

                  {/* KYC Details: Photo, DOB, CKYC & Address */}
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                    <div>
                      <label className="text-xs font-black text-slate-700 uppercase tracking-wider block mb-1">
                        Date of Birth (DOB)
                      </label>
                      <input
                        type="date"
                        value={newUserDob}
                        onChange={(e) => setNewUserDob(e.target.value)}
                        className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs font-bold text-slate-900 focus:outline-none focus:border-[#0a2540]"
                      />
                    </div>

                    <div>
                      <label className="text-xs font-black text-slate-700 uppercase tracking-wider block mb-1">
                        Central KYC No. (CKYC)
                      </label>
                      <input
                        type="text"
                        value={newUserCkyc}
                        onChange={(e) => setNewUserCkyc(e.target.value)}
                        className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs font-bold text-slate-900 font-mono focus:outline-none focus:border-[#0a2540]"
                      />
                    </div>

                    <div>
                      <label className="text-xs font-black text-slate-700 uppercase tracking-wider block mb-1">
                        Customer Photo URL
                      </label>
                      <input
                        type="url"
                        placeholder="https://... (or leave blank)"
                        value={newUserPhoto}
                        onChange={(e) => setNewUserPhoto(e.target.value)}
                        className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs font-bold text-slate-900 focus:outline-none focus:border-[#0a2540]"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="text-xs font-black text-slate-700 uppercase tracking-wider block mb-1">
                      Permanent Residential Address
                    </label>
                    <input
                      type="text"
                      placeholder="Street, City, District, PIN Code"
                      value={newUserAddress}
                      onChange={(e) => setNewUserAddress(e.target.value)}
                      className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs font-bold text-slate-900 focus:outline-none focus:border-[#0a2540]"
                    />
                  </div>

                  {/* Initial Deposits Grid */}
                  <div className="p-3.5 bg-slate-50 rounded-2xl border border-slate-200 space-y-2">
                    <p className="text-xs font-black text-slate-800 uppercase tracking-wider">
                      Initial Deposit Allocation (₹)
                    </p>
                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                      <div>
                        <label className="text-[10px] text-slate-500 font-bold uppercase block">Savings A/C</label>
                        <input
                          type="number"
                          value={newSavingsDeposit}
                          onChange={(e) => setNewSavingsDeposit(e.target.value)}
                          className="w-full bg-white border border-slate-200 rounded-lg px-2.5 py-1.5 text-xs font-bold text-slate-900 font-mono"
                        />
                      </div>
                      <div>
                        <label className="text-[10px] text-slate-500 font-bold uppercase block">Wallet</label>
                        <input
                          type="number"
                          value={newWalletDeposit}
                          onChange={(e) => setNewWalletDeposit(e.target.value)}
                          className="w-full bg-white border border-slate-200 rounded-lg px-2.5 py-1.5 text-xs font-bold text-slate-900 font-mono"
                        />
                      </div>
                      <div>
                        <label className="text-[10px] text-slate-500 font-bold uppercase block">UPI Lite</label>
                        <input
                          type="number"
                          value={newUpiLiteDeposit}
                          onChange={(e) => setNewUpiLiteDeposit(e.target.value)}
                          className="w-full bg-white border border-slate-200 rounded-lg px-2.5 py-1.5 text-xs font-bold text-slate-900 font-mono"
                        />
                      </div>
                      <div>
                        <label className="text-[10px] text-slate-500 font-bold uppercase block">Fixed Deposit</label>
                        <input
                          type="number"
                          value={newFdDeposit}
                          onChange={(e) => setNewFdDeposit(e.target.value)}
                          className="w-full bg-white border border-slate-200 rounded-lg px-2.5 py-1.5 text-xs font-bold text-slate-900 font-mono"
                        />
                      </div>
                    </div>
                  </div>

                  {/* Initial Services Checklist */}
                  <div className="p-3.5 bg-slate-50 rounded-2xl border border-slate-200 space-y-2">
                    <p className="text-xs font-black text-slate-800 uppercase tracking-wider">
                      Pre-Activate Banking Services
                    </p>
                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs">
                      {[
                        { key: 'upiEnabled', label: 'UPI QR Scan' },
                        { key: 'upiLiteEnabled', label: 'UPI Lite' },
                        { key: 'walletEnabled', label: 'Digital Wallet' },
                        { key: 'soundboxEnabled', label: 'Soundbox TTS' },
                        { key: 'biometricsEnabled', label: 'Biometrics' },
                        { key: 'termDepositEnabled', label: 'Term Deposits' },
                        { key: 'kccLoanEnabled', label: 'KCC Loans' },
                        { key: 'smsAlertsEnabled', label: 'SMS Alerts' },
                      ].map((svc) => (
                        <label
                          key={svc.key}
                          className="flex items-center gap-2 p-2 bg-white rounded-lg border border-slate-200 cursor-pointer text-slate-800 font-bold"
                        >
                          <input
                            type="checkbox"
                            checked={(newUserServices as any)[svc.key]}
                            onChange={(e) =>
                              setNewUserServices((prev) => ({
                                ...prev,
                                [svc.key]: e.target.checked,
                              }))
                            }
                            className="rounded text-[#0a2540] focus:ring-0"
                          />
                          <span className="text-[11px]">{svc.label}</span>
                        </label>
                      ))}
                    </div>
                  </div>

                  {/* Initial Security MPIN */}
                  <div className="p-3.5 bg-slate-50 rounded-2xl border border-slate-200 space-y-1.5">
                    <div className="flex items-center gap-1.5">
                      <KeyRound className="w-3.5 h-3.5 text-amber-700" />
                      <label className="text-xs font-black text-slate-800 uppercase tracking-wider">
                        Initial 4-Digit Security MPIN
                      </label>
                    </div>
                    <p className="text-[11px] text-slate-500 font-bold">
                      Customer will use this MPIN for all Fund Transfers, Inter-bank settlements, and Profile Login.
                    </p>
                    <input
                      type="password"
                      maxLength={4}
                      inputMode="numeric"
                      value={newUserMpin}
                      onChange={(e) => setNewUserMpin(e.target.value.replace(/\D/g, ''))}
                      className="w-48 bg-white border border-slate-200 rounded-xl px-3 py-2 text-sm font-black font-mono tracking-widest text-slate-900 focus:outline-none focus:border-[#0a2540]"
                      placeholder="1234"
                      required
                    />
                  </div>

                  {/* Submit Button */}
                  <button
                    type="submit"
                    className="w-full py-3.5 rounded-xl bg-[#0a2540] hover:bg-[#071d34] text-white font-black uppercase tracking-wider text-xs shadow-md transition active:scale-98 flex items-center justify-center gap-2"
                  >
                    <UserPlus className="w-4 h-4 text-amber-300" />
                    <span>Authorize & Create Customer Account</span>
                  </button>
                </form>
              )}
            </div>
          )}

          {/* -------------------------------------------------------------------
              TAB 3: DEDICATED TELLER WINDOW (Add Money / Deduct Money)
          ------------------------------------------------------------------- */}
          {activeTab === 'TELLER' && (
            <div className="max-w-2xl mx-auto space-y-4">
              <div className="border-b border-slate-100 pb-3 flex items-center justify-between">
                <div>
                  <h3 className="text-sm font-black text-slate-900 uppercase tracking-wider flex items-center gap-2">
                    <DollarSign className="w-4 h-4 text-emerald-600" />
                    <span>Branch Teller Terminal • Cash & Balance Management</span>
                  </h3>
                  <p className="text-xs text-slate-500 font-bold">
                    Credit (Add Money) or Debit (Deduct Money) directly to/from any customer ledger
                  </p>
                </div>
                <span className="text-[10px] font-black uppercase tracking-wider bg-blue-50 text-blue-800 border border-blue-200 px-2 py-1 rounded-lg">
                  CBS Voucher Mode
                </span>
              </div>

              {moneySuccessMsg && (
                <div className="p-4 bg-emerald-50 border border-emerald-200 rounded-2xl text-center space-y-1 animate-in zoom-in-95">
                  <CheckCircle2 className="w-6 h-6 text-emerald-600 mx-auto" />
                  <p className="text-xs font-black text-emerald-900 uppercase tracking-wider">
                    {moneySuccessMsg}
                  </p>
                  <p className="text-[11px] text-emerald-700 font-bold">
                    Ledger entries posted and push notifications dispatched.
                  </p>
                </div>
              )}

              <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200 space-y-4">
                {/* 1. Select Customer */}
                <div>
                  <label className="text-xs font-black text-slate-700 uppercase tracking-wider block mb-1">
                    Select Target Customer
                  </label>
                  <select
                    value={tellerSelectedUserId}
                    onChange={(e) => setTellerSelectedUserId(e.target.value)}
                    className="w-full bg-white border border-slate-200 rounded-xl px-3 py-2.5 text-xs font-bold text-slate-900 focus:outline-none focus:border-[#0a2540]"
                  >
                    {users.map((u) => (
                      <option key={u.id} value={u.id}>
                        {u.name} (A/C: *{u.accountNumber.slice(-4)}) — Bal: ₹
                        {(u.savingsBalance || 0).toLocaleString('en-IN', { minimumFractionDigits: 2 })}
                        {u.isBlocked ? ' [FROZEN]' : ''}
                      </option>
                    ))}
                  </select>
                </div>

                {/* 2. Action Type (Credit vs Debit) */}
                <div>
                  <label className="text-xs font-black text-slate-700 uppercase tracking-wider block mb-1">
                    Teller Operation
                  </label>
                  <div className="grid grid-cols-2 gap-2">
                    <button
                      type="button"
                      onClick={() => {
                        setMoneyActionType('CREDIT');
                        setMoneyReason('Cash Deposit at Branch Counter');
                      }}
                      className={`py-2.5 text-xs font-black uppercase tracking-wider rounded-xl border flex items-center justify-center gap-1.5 transition ${
                        moneyActionType === 'CREDIT'
                          ? 'bg-emerald-600 border-emerald-600 text-white shadow-xs'
                          : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-100'
                      }`}
                    >
                      <PlusCircle className="w-4 h-4" />
                      <span>Add Money (Credit / Deposit)</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => {
                        setMoneyActionType('DEBIT');
                        setMoneyReason('Cash Withdrawal / Service Debit');
                      }}
                      className={`py-2.5 text-xs font-black uppercase tracking-wider rounded-xl border flex items-center justify-center gap-1.5 transition ${
                        moneyActionType === 'DEBIT'
                          ? 'bg-slate-900 border-slate-900 text-white shadow-xs'
                          : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-100'
                      }`}
                    >
                      <MinusCircle className="w-4 h-4" />
                      <span>Deduct Money (Debit / Charge)</span>
                    </button>
                  </div>
                </div>

                {/* 3. Target Account Balance */}
                <div>
                  <label className="text-xs font-black text-slate-700 uppercase tracking-wider block mb-1">
                    Target Balance Bucket
                  </label>
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                    {[
                      { id: 'savings', label: 'Savings A/C' },
                      { id: 'wallet', label: 'Business Wallet' },
                      { id: 'upiLite', label: 'UPI Lite' },
                      { id: 'fixedDeposit', label: 'Fixed Deposit' },
                    ].map((b) => (
                      <button
                        key={b.id}
                        type="button"
                        onClick={() => setMoneyTargetBalance(b.id as any)}
                        className={`py-2 text-xs font-black uppercase tracking-wider rounded-xl border transition ${
                          moneyTargetBalance === b.id
                            ? 'bg-[#0a2540] border-[#0a2540] text-amber-300'
                            : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-100'
                        }`}
                      >
                        {b.label}
                      </button>
                    ))}
                  </div>
                </div>

                {/* 4. Amount Input + Quick Pills */}
                <div>
                  <label className="text-xs font-black text-slate-700 uppercase tracking-wider block mb-1">
                    Amount (INR ₹)
                  </label>
                  <div className="relative">
                    <span className="absolute left-3 top-1/2 -translate-y-1/2 font-black text-base text-slate-400">
                      ₹
                    </span>
                    <input
                      type="number"
                      required
                      value={moneyAmount}
                      onChange={(e) => setMoneyAmount(e.target.value)}
                      placeholder="5000"
                      className="w-full pl-8 pr-3 py-2.5 bg-white border border-slate-200 rounded-xl text-base font-black text-slate-900 font-mono focus:outline-none focus:border-[#0a2540]"
                    />
                  </div>

                  {/* Quick Pills */}
                  <div className="flex items-center gap-1.5 pt-2 flex-wrap">
                    {['500', '1000', '5000', '10000', '25000', '50000', '100000'].map((amt) => (
                      <button
                        key={amt}
                        type="button"
                        onClick={() => setMoneyAmount(amt)}
                        className="px-2.5 py-1 rounded-lg bg-white border border-slate-200 text-[11px] font-mono font-bold text-slate-700 hover:bg-slate-100 transition"
                      >
                        +₹{parseInt(amt).toLocaleString('en-IN')}
                      </button>
                    ))}
                  </div>
                </div>

                {/* 5. Reason / Voucher Narration */}
                <div>
                  <label className="text-xs font-black text-slate-700 uppercase tracking-wider block mb-1">
                    Voucher Reason / Narration
                  </label>
                  <input
                    type="text"
                    required
                    value={moneyReason}
                    onChange={(e) => setMoneyReason(e.target.value)}
                    placeholder="e.g. Counter Cash Deposit / Government DBT Subsidy"
                    className="w-full bg-white border border-slate-200 rounded-xl px-3 py-2 text-xs font-bold text-slate-900 focus:outline-none focus:border-[#0a2540]"
                  />
                </div>

                {/* 6. Balance Preview Box */}
                {(() => {
                  const selUser = users.find((u) => u.id === tellerSelectedUserId);
                  if (!selUser) return null;
                  const currentVal =
                    moneyTargetBalance === 'savings'
                      ? selUser.savingsBalance || 0
                      : moneyTargetBalance === 'wallet'
                      ? selUser.walletBalance || 0
                      : moneyTargetBalance === 'upiLite'
                      ? selUser.upiLiteBalance || 0
                      : selUser.fixedDepositBalance || 0;

                  const delta = parseFloat(moneyAmount) || 0;
                  const resulting =
                    moneyActionType === 'CREDIT'
                      ? currentVal + delta
                      : Math.max(0, currentVal - delta);

                  return (
                    <div className="p-3 bg-white rounded-xl border border-slate-200 text-xs flex items-center justify-between font-mono">
                      <div>
                        <span className="text-[10px] text-slate-400 uppercase font-black block font-sans">Current Balance</span>
                        <span className="font-bold text-slate-800">₹{currentVal.toLocaleString('en-IN', { minimumFractionDigits: 2 })}</span>
                      </div>
                      <div className="text-center font-sans font-black text-slate-400">
                        →
                      </div>
                      <div className="text-right">
                        <span className="text-[10px] text-slate-400 uppercase font-black block font-sans">Post-Transaction Balance</span>
                        <span className={`font-black ${moneyActionType === 'CREDIT' ? 'text-emerald-700' : 'text-slate-900'}`}>
                          ₹{resulting.toLocaleString('en-IN', { minimumFractionDigits: 2 })}
                        </span>
                      </div>
                    </div>
                  );
                })()}

                {/* Submit Action */}
                <button
                  type="button"
                  onClick={() => handleExecuteMoneyAdjustment(tellerSelectedUserId)}
                  className={`w-full py-3.5 rounded-xl font-black uppercase tracking-wider text-xs shadow-md transition active:scale-98 flex items-center justify-center gap-2 ${
                    moneyActionType === 'CREDIT'
                      ? 'bg-emerald-600 hover:bg-emerald-700 text-white'
                      : 'bg-[#0a2540] hover:bg-[#071d34] text-white'
                  }`}
                >
                  {moneyActionType === 'CREDIT' ? (
                    <>
                      <PlusCircle className="w-4 h-4" />
                      <span>Post Credit (Add Funds to Account)</span>
                    </>
                  ) : (
                    <>
                      <MinusCircle className="w-4 h-4" />
                      <span>Post Debit (Deduct Funds from Account)</span>
                    </>
                  )}
                </button>
              </div>
            </div>
          )}

          {/* -------------------------------------------------------------------
              TAB 4: KYC VERIFICATION HUB
          ------------------------------------------------------------------- */}
          {activeTab === 'KYC' && (
            <div className="space-y-4">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-2 border-b border-slate-100 gap-2">
                <div>
                  <h3 className="text-xs font-black text-slate-900 uppercase tracking-wider flex items-center gap-1.5">
                    <FileCheck className="w-4 h-4 text-[#0a2540]" />
                    <span>UIDAI Aadhaar & NSDL PAN Identity Verification Queue</span>
                  </h3>
                  <p className="text-[11px] text-slate-500 font-bold">
                    Review incoming KYC applications, fraud risk assessments, and approve/reject with audit log
                  </p>
                </div>

                {/* KYC Filter Tabs */}
                <div className="flex items-center gap-1 bg-slate-100 p-1 rounded-xl">
                  {(['ALL', 'PENDING', 'APPROVED', 'REJECTED'] as const).map((kf) => (
                    <button
                      key={kf}
                      onClick={() => setKycFilter(kf)}
                      className={`px-3 py-1 rounded-lg text-[10px] font-black uppercase tracking-wider transition ${
                        kycFilter === kf
                          ? 'bg-white text-[#0a2540] shadow-2xs font-black'
                          : 'text-slate-600 hover:text-slate-900'
                      }`}
                    >
                      {kf}
                    </button>
                  ))}
                </div>
              </div>

              {/* KYC Applications List */}
              <div className="space-y-3">
                {kycApplications
                  .filter((app) => {
                    if (kycFilter === 'PENDING') return app.status === 'PENDING_VERIFICATION' || app.status === 'PENDING';
                    if (kycFilter === 'APPROVED') return app.status === 'APPROVED';
                    if (kycFilter === 'REJECTED') return app.status === 'REJECTED';
                    return true;
                  })
                  .map((app) => {
                    const isPending = app.status === 'PENDING_VERIFICATION' || app.status === 'PENDING';
                    const isVerifying = verifyingAppId === app.id;

                    return (
                      <div
                        key={app.id}
                        className="p-4 rounded-2xl bg-slate-50 border border-slate-200 flex flex-col md:flex-row md:items-center justify-between gap-3 shadow-2xs"
                      >
                        <div className="space-y-1.5">
                          <div className="flex items-center gap-2 flex-wrap">
                            <span className="font-black text-sm text-slate-900">
                              {app.applicantName}
                            </span>

                            <span
                              className={`text-[10px] font-black uppercase tracking-wider px-2 py-0.5 rounded-full ${
                                app.status === 'APPROVED'
                                  ? 'bg-emerald-100 text-emerald-800 border border-emerald-200'
                                  : app.status === 'REJECTED'
                                  ? 'bg-red-100 text-red-700 border border-red-200'
                                  : 'bg-amber-100 text-amber-800 border border-amber-200'
                              }`}
                            >
                              {app.status}
                            </span>

                            {/* Risk Score Indicator */}
                            <span
                              className={`text-[10px] font-black uppercase px-2 py-0.5 rounded-full border ${
                                app.riskScore < 20
                                  ? 'bg-emerald-50 text-emerald-700 border-emerald-200'
                                  : app.riskScore < 50
                                  ? 'bg-amber-50 text-amber-800 border-amber-200'
                                  : 'bg-red-50 text-red-700 border-red-200'
                              }`}
                            >
                              Risk Score: {app.riskScore}/100 ({app.riskScore < 20 ? 'Low' : 'Review'})
                            </span>
                          </div>

                          <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 text-xs font-mono text-slate-600 font-bold">
                            <span className="bg-white px-2 py-1 rounded border border-slate-200">
                              Phone: {app.phone}
                            </span>
                            <span className="bg-white px-2 py-1 rounded border border-slate-200">
                              Aadhaar: {app.aadhaarNumber}
                            </span>
                            <span className="bg-white px-2 py-1 rounded border border-slate-200">
                              PAN: {app.panNumber}
                            </span>
                          </div>

                          <p className="text-[11px] text-slate-500 font-bold">
                            Submitted: {app.submittedAt} • Document Type: {app.documentType} • Account Type:{' '}
                            <span className="font-black text-slate-800 uppercase">
                              {app.accountType} (Initial Deposit: ₹{app.initialDeposit})
                            </span>
                          </p>
                        </div>

                        {/* Action Buttons */}
                        <div className="flex items-center gap-2 self-end md:self-auto flex-wrap">
                          {/* Simulated UIDAI Check */}
                          <button
                            onClick={() => handleSimulateUidaiCheck(app.id)}
                            disabled={isVerifying}
                            className="px-3 py-1.5 rounded-lg bg-blue-50 hover:bg-blue-100 text-[#0a2540] border border-blue-200 text-xs font-black uppercase tracking-wider transition flex items-center gap-1 active:scale-95"
                          >
                            <RefreshCw className={`w-3.5 h-3.5 ${isVerifying ? 'animate-spin' : ''}`} />
                            <span>{isVerifying ? 'Verifying...' : 'Verify Registry'}</span>
                          </button>

                          {isPending && (
                            <>
                              <button
                                onClick={() => {
                                  setRejectModalAppId(app.id);
                                }}
                                className="px-3 py-1.5 rounded-lg bg-red-50 hover:bg-red-100 text-red-700 border border-red-200 text-xs font-black uppercase tracking-wider transition flex items-center gap-1 active:scale-95"
                              >
                                <XCircle className="w-3.5 h-3.5" />
                                <span>Reject</span>
                              </button>

                              <button
                                onClick={() => onApproveKyc(app.id)}
                                className="px-4 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-black uppercase tracking-wider transition shadow-sm flex items-center gap-1 active:scale-95"
                              >
                                <CheckCircle2 className="w-3.5 h-3.5" />
                                <span>Approve & Authorize</span>
                              </button>
                            </>
                          )}

                          {(() => {
                            const matchedUser = users.find(
                              (u) =>
                                u.phone === app.phone ||
                                (u.aadhaarNumber && u.aadhaarNumber === app.aadhaarNumber) ||
                                (u.panNumber && u.panNumber === app.panNumber)
                            );
                            if (!matchedUser) return null;
                            return (
                              <>
                                <button
                                  onClick={() => handleOpenEditUserModal(matchedUser)}
                                  className="px-3 py-1.5 rounded-lg bg-blue-50 hover:bg-blue-100 text-blue-900 border border-blue-200 text-xs font-black uppercase tracking-wider transition flex items-center gap-1 active:scale-95"
                                  title="Edit user details and fix mistakes"
                                >
                                  <Edit3 className="w-3.5 h-3.5 text-blue-700" />
                                  <span>Edit Account</span>
                                </button>
                                <button
                                  onClick={() => handleOpenIndividualCommModal(matchedUser)}
                                  className="px-3 py-1.5 rounded-lg bg-purple-50 hover:bg-purple-100 text-purple-900 border border-purple-200 text-xs font-black uppercase tracking-wider transition flex items-center gap-1 active:scale-95"
                                  title="Send individual SMS & modern banking email to applicant"
                                >
                                  <Mail className="w-3.5 h-3.5 text-purple-700" />
                                  <span>Send SMS/Email</span>
                                </button>
                              </>
                            );
                          })()}
                        </div>
                      </div>
                    );
                  })}
              </div>

              {/* Reject Application Modal */}
              {rejectModalAppId && (
                <div className="fixed inset-0 z-50 bg-slate-950/60 backdrop-blur-xs flex items-center justify-center p-4">
                  <div className="w-full max-w-md bg-white rounded-2xl p-5 border border-slate-200 shadow-2xl space-y-3 animate-in zoom-in-95">
                    <div className="flex items-center justify-between border-b border-slate-100 pb-2">
                      <h4 className="text-xs font-black uppercase tracking-wider text-slate-900 flex items-center gap-1.5">
                        <AlertTriangle className="w-4 h-4 text-red-600" />
                        <span>Reject KYC Application</span>
                      </h4>
                      <button
                        onClick={() => setRejectModalAppId(null)}
                        className="p-1 rounded-full bg-slate-100 text-slate-500 hover:text-slate-900"
                      >
                        <X className="w-4 h-4" />
                      </button>
                    </div>

                    <div>
                      <label className="text-xs font-black text-slate-700 uppercase tracking-wider block mb-1">
                        Reason for Rejection (Visible to Applicant)
                      </label>
                      <textarea
                        rows={3}
                        value={rejectionReason}
                        onChange={(e) => setRejectionReason(e.target.value)}
                        className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs font-bold text-slate-900 focus:outline-none focus:border-red-500"
                      />
                    </div>

                    <div className="flex items-center justify-end gap-2 pt-2">
                      <button
                        onClick={() => setRejectModalAppId(null)}
                        className="px-3.5 py-1.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-black uppercase tracking-wider"
                      >
                        Cancel
                      </button>
                      <button
                        onClick={() => {
                          onRejectKyc(rejectModalAppId, rejectionReason);
                          setRejectModalAppId(null);
                        }}
                        className="px-4 py-1.5 rounded-xl bg-red-600 hover:bg-red-700 text-white text-xs font-black uppercase tracking-wider shadow-sm"
                      >
                        Confirm Rejection
                      </button>
                    </div>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* -------------------------------------------------------------------
              TAB 5: SERVICES ACTIVATION MATRIX
          ------------------------------------------------------------------- */}
          {activeTab === 'SERVICES' && (
            <div className="space-y-5">
              <div>
                <h3 className="text-xs font-black text-slate-900 uppercase tracking-wider flex items-center gap-1.5">
                  <Sliders className="w-4 h-4 text-[#0a2540]" />
                  <span>Global Bank Gateway & Service Matrix</span>
                </h3>
                <p className="text-[11px] text-slate-500 font-bold">
                  Toggle system-wide clearing gateways or manage individual customer service entitlements
                </p>
              </div>

              {/* 1. System Master Switches */}
              <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200 space-y-3">
                <p className="text-xs font-black text-slate-800 uppercase tracking-wider">
                  Core Clearing & Settlement Switches (System-Wide)
                </p>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  {/* UPI Switch */}
                  <div className="bg-white p-3.5 rounded-xl border border-slate-200 flex items-center justify-between shadow-2xs">
                    <div>
                      <p className="text-xs font-black text-slate-900">NPCI UPI Switch</p>
                      <p className="text-[10px] text-slate-500 font-bold">Inward/Outward UPI</p>
                    </div>
                    <button
                      onClick={() => setGlobalUpiSwitch(!globalUpiSwitch)}
                      className={`px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-wider transition ${
                        globalUpiSwitch
                          ? 'bg-emerald-100 text-emerald-800 border border-emerald-300'
                          : 'bg-red-100 text-red-800 border border-red-300'
                      }`}
                    >
                      {globalUpiSwitch ? 'Online' : 'Disabled'}
                    </button>
                  </div>

                  {/* IMPS Gateway */}
                  <div className="bg-white p-3.5 rounded-xl border border-slate-200 flex items-center justify-between shadow-2xs">
                    <div>
                      <p className="text-xs font-black text-slate-900">IMPS / NEFT Settlement</p>
                      <p className="text-[10px] text-slate-500 font-bold">Inter-Bank Wire Engine</p>
                    </div>
                    <button
                      onClick={() => setGlobalImpsGateway(!globalImpsGateway)}
                      className={`px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-wider transition ${
                        globalImpsGateway
                          ? 'bg-emerald-100 text-emerald-800 border border-emerald-300'
                          : 'bg-red-100 text-red-800 border border-red-300'
                      }`}
                    >
                      {globalImpsGateway ? 'Online' : 'Disabled'}
                    </button>
                  </div>

                  {/* Multilingual Soundbox Engine */}
                  <div className="bg-white p-3.5 rounded-xl border border-slate-200 flex items-center justify-between shadow-2xs">
                    <div>
                      <p className="text-xs font-black text-slate-900">Audio Soundbox TTS</p>
                      <p className="text-[10px] text-slate-500 font-bold">Voice alerts in 10 langs</p>
                    </div>
                    <button
                      onClick={() => setGlobalSoundboxEngine(!globalSoundboxEngine)}
                      className={`px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-wider transition ${
                        globalSoundboxEngine
                          ? 'bg-emerald-100 text-emerald-800 border border-emerald-300'
                          : 'bg-red-100 text-red-800 border border-red-300'
                      }`}
                    >
                      {globalSoundboxEngine ? 'Active' : 'Disabled'}
                    </button>
                  </div>
                </div>
              </div>

              {/* 2. User Service Entitlements Table */}
              <div className="space-y-2">
                <p className="text-xs font-black text-slate-800 uppercase tracking-wider">
                  Customer Service Activation Grid
                </p>

                <div className="overflow-x-auto border border-slate-200 rounded-2xl">
                  <table className="w-full text-left text-xs border-collapse">
                    <thead className="bg-slate-50 border-b border-slate-200 text-slate-500 font-black text-[10px] uppercase tracking-wider">
                      <tr>
                        <th className="p-3">Customer</th>
                        <th className="p-3 text-center">UPI Scan</th>
                        <th className="p-3 text-center">UPI Lite</th>
                        <th className="p-3 text-center">Wallet</th>
                        <th className="p-3 text-center">Soundbox</th>
                        <th className="p-3 text-center">Biometrics</th>
                        <th className="p-3 text-center">Fixed Deposit</th>
                        <th className="p-3 text-center">KCC Agri</th>
                        <th className="p-3 text-center">SMS Alerts</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {users.map((u) => {
                        const svcs = u.services || DEFAULT_SERVICES;
                        return (
                          <tr key={u.id} className="hover:bg-slate-50/50">
                            <td className="p-3">
                              <span className="font-black text-slate-900 block">{u.name}</span>
                              <span className="text-[10px] text-slate-400 font-mono">*{u.accountNumber.slice(-4)}</span>
                            </td>

                            {([
                              'upiEnabled',
                              'upiLiteEnabled',
                              'walletEnabled',
                              'soundboxEnabled',
                              'biometricsEnabled',
                              'termDepositEnabled',
                              'kccLoanEnabled',
                              'smsAlertsEnabled',
                            ] as (keyof UserServices)[]).map((svcKey) => (
                              <td key={svcKey} className="p-3 text-center">
                                <button
                                  onClick={() => onToggleUserService(u.id, svcKey, !svcs[svcKey])}
                                  className={`p-1 rounded-lg border transition ${
                                    svcs[svcKey]
                                      ? 'bg-emerald-100 text-emerald-800 border-emerald-200 hover:bg-emerald-200'
                                      : 'bg-slate-100 text-slate-400 border-slate-200 hover:bg-slate-200'
                                  }`}
                                  title={`Toggle ${svcKey}`}
                                >
                                  {svcs[svcKey] ? (
                                    <Check className="w-3.5 h-3.5" />
                                  ) : (
                                    <X className="w-3.5 h-3.5" />
                                  )}
                                </button>
                              </td>
                            ))}
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}

          {/* -------------------------------------------------------------------
              TAB 6: AUDIT RADAR & TRANSACTION LEDGER
          ------------------------------------------------------------------- */}
          {activeTab === 'TRANSACTIONS' && (
            <div className="space-y-3">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-2 border-b border-slate-100 gap-2">
                <div>
                  <h3 className="text-xs font-black text-slate-900 uppercase tracking-wider flex items-center gap-1.5">
                    <Activity className="w-4 h-4 text-[#0a2540]" />
                    <span>Live Audit Ledger & Transaction Stream</span>
                  </h3>
                  <p className="text-[11px] text-slate-500 font-bold">
                    Monitor NPCI UTR refs, branch deposits, reversals, and suspicious flags
                  </p>
                </div>

                <div className="flex items-center gap-2">
                  <div className="relative">
                    <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-1/2 -translate-y-1/2" />
                    <input
                      type="text"
                      placeholder="Filter by UTR or Title..."
                      value={txSearch}
                      onChange={(e) => setTxSearch(e.target.value)}
                      className="pl-8 pr-2.5 py-1.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-900 focus:outline-none focus:border-[#0a2540]"
                    />
                  </div>
                </div>
              </div>

              {rollbackSuccessMsg && (
                <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-xl text-center text-xs font-black text-emerald-900 uppercase tracking-wider">
                  {rollbackSuccessMsg}
                </div>
              )}

              {/* Transactions List */}
              <div className="space-y-2">
                {transactions
                  .filter((tx) => {
                    const q = txSearch.toLowerCase();
                    return (
                      tx.title.toLowerCase().includes(q) ||
                      tx.upiRefId.toLowerCase().includes(q) ||
                      tx.amount.toString().includes(q)
                    );
                  })
                  .map((tx) => (
                    <div
                      key={tx.id}
                      className="p-3 rounded-xl bg-slate-50 border border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-2 shadow-2xs"
                    >
                      <div className="space-y-0.5">
                        <div className="flex items-center gap-2">
                          <span className="font-black text-xs text-slate-900">
                            {tx.title}
                          </span>

                          <span
                            className={`text-[9px] font-black uppercase px-1.5 py-0.2 rounded ${
                              tx.type === 'credit'
                                ? 'bg-emerald-100 text-emerald-800'
                                : 'bg-slate-200 text-slate-800'
                            }`}
                          >
                            {tx.type}
                          </span>

                          <span className="text-[9px] font-mono bg-blue-50 text-blue-800 px-1.5 py-0.2 rounded border border-blue-100 font-bold">
                            {tx.paymentMode}
                          </span>

                          {tx.fraudFlag && tx.fraudFlag !== 'CLEAN' && (
                            <span className="text-[9px] bg-red-100 text-red-700 px-1.5 py-0.2 rounded font-black uppercase">
                              {tx.fraudFlag}
                            </span>
                          )}
                        </div>

                        <p className="text-[11px] text-slate-500 font-mono font-bold">
                          UTR: {tx.upiRefId} • {formatTransactionTimestamp(tx.timestamp, tx.createdAt, tx.id)}
                        </p>
                      </div>

                      <div className="flex items-center gap-3 self-end sm:self-auto">
                        <div className="text-right">
                          <p
                            className={`font-mono font-black text-sm ${
                              tx.type === 'credit' ? 'text-emerald-700' : 'text-slate-900'
                            }`}
                          >
                            {tx.type === 'credit' ? '+' : '-'}₹{tx.amount.toFixed(2)}
                          </p>
                          <span className="text-[9px] text-slate-400 uppercase font-black">
                            {tx.status}
                          </span>
                        </div>

                        <div className="flex items-center gap-1.5">
                          {/* QR / VPA Inspection */}
                          {(tx.qrData || tx.scannerAddress || tx.recipientVpa) && (
                            <button
                              type="button"
                              onClick={() => setViewQrModalTx(tx)}
                              className="px-2 py-1 rounded-lg bg-blue-50 hover:bg-blue-100 text-blue-700 border border-blue-200 text-[10px] font-black uppercase tracking-wider transition flex items-center gap-1"
                              title="View captured QR code or VPA details"
                            >
                              <QrCode className="w-3 h-3" />
                              <span>QR</span>
                            </button>
                          )}

                          {/* Edit Transaction History */}
                          <button
                            type="button"
                            onClick={() => openEditModal(tx)}
                            className="px-2 py-1 rounded-lg bg-white hover:bg-amber-50 text-slate-700 hover:text-amber-800 border border-slate-200 hover:border-amber-300 text-[10px] font-black uppercase tracking-wider transition flex items-center gap-1"
                            title="Edit transaction amount, date/time, or status"
                          >
                            <Edit3 className="w-3 h-3 text-amber-600" />
                            <span>Edit</span>
                          </button>

                          {/* Delete Transaction History */}
                          <button
                            type="button"
                            onClick={() => handleDeleteTx(tx)}
                            className="px-2 py-1 rounded-lg bg-white hover:bg-red-50 text-slate-700 hover:text-red-700 border border-slate-200 hover:border-red-200 text-[10px] font-black uppercase tracking-wider transition flex items-center gap-1"
                            title="Delete transaction permanently from database"
                          >
                            <Trash2 className="w-3 h-3 text-red-500" />
                            <span>Delete</span>
                          </button>

                          {/* Rollback button */}
                          <button
                            onClick={() => {
                              onRollbackTransaction(tx.id);
                              setRollbackSuccessMsg(`Transaction ${tx.upiRefId} reversed successfully.`);
                              setTimeout(() => setRollbackSuccessMsg(null), 2500);
                            }}
                            className="px-2 py-1 rounded-lg bg-white hover:bg-red-50 text-slate-600 hover:text-red-700 border border-slate-200 hover:border-red-200 text-[10px] font-black uppercase tracking-wider transition flex items-center gap-1"
                            title="Reverse / Rollback this transaction"
                          >
                            <RotateCcw className="w-3 h-3" />
                            <span>Reverse</span>
                          </button>
                        </div>
                      </div>
                    </div>
                  ))}
              </div>
            </div>
          )}

          {/* -------------------------------------------------------------------
              TAB 7: SMS & EMAIL COMMUNICATIONS HUB
          ------------------------------------------------------------------- */}
          {activeTab === 'BROADCAST' && (
            <div className="max-w-4xl mx-auto space-y-5">
              {/* Hub Top Bar */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 pb-3">
                <div>
                  <h3 className="text-base font-black text-slate-900 uppercase tracking-wider flex items-center gap-2">
                    <Mail className="w-5 h-5 text-purple-700" />
                    <span>Axis Bank CC VIP SMS & Modern Email Communications Hub</span>
                  </h3>
                  <p className="text-xs text-slate-500 font-bold">
                    Direct Customer Messaging via Hostinger SMTP SSL (support@axisbank.com) & Twilio Real SMS
                  </p>
                </div>

                {/* Sub Tab Navigation */}
                <div className="flex items-center gap-1 bg-slate-100 p-1 rounded-xl self-start sm:self-auto border border-slate-200">
                  <button
                    type="button"
                    onClick={() => setCommHubSubTab('INDIVIDUAL')}
                    className={`px-3 py-1.5 rounded-lg text-xs font-black uppercase tracking-wider transition ${
                      commHubSubTab === 'INDIVIDUAL'
                        ? 'bg-purple-700 text-white shadow-xs'
                        : 'text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    1. Send to Customer
                  </button>
                  <button
                    type="button"
                    onClick={() => setCommHubSubTab('BROADCAST')}
                    className={`px-3 py-1.5 rounded-lg text-xs font-black uppercase tracking-wider transition ${
                      commHubSubTab === 'BROADCAST'
                        ? 'bg-[#0a2540] text-amber-300 shadow-xs'
                        : 'text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    2. Push Broadcast
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setCommHubSubTab('OUTBOX');
                      emailService.getOutbox().then(setCommOutboxLogs).catch(() => {});
                    }}
                    className={`px-3 py-1.5 rounded-lg text-xs font-black uppercase tracking-wider transition flex items-center gap-1 ${
                      commHubSubTab === 'OUTBOX'
                        ? 'bg-blue-900 text-white shadow-xs'
                        : 'text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    <Inbox className="w-3.5 h-3.5" />
                    <span>3. Outbox Logs ({commOutboxLogs.length})</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setCommHubSubTab('SETTINGS');
                      loadCommunicationsSettings();
                    }}
                    className={`px-3 py-1.5 rounded-lg text-xs font-black uppercase tracking-wider transition flex items-center gap-1 ${
                      commHubSubTab === 'SETTINGS'
                        ? 'bg-[#861F41] text-amber-300 shadow-xs'
                        : 'text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    <Server className="w-3.5 h-3.5" />
                    <span>4. Gateway Settings</span>
                  </button>
                </div>
              </div>

              {/* Status Banner */}
              {commStatusMsg && (
                <div
                  className={`p-3.5 rounded-2xl flex items-center gap-2.5 text-xs font-bold animate-in zoom-in-95 ${
                    commStatusMsg.type === 'success'
                      ? 'bg-emerald-50 border border-emerald-200 text-emerald-800'
                      : 'bg-red-50 border border-red-200 text-red-700'
                  }`}
                >
                  {commStatusMsg.type === 'success' ? (
                    <CheckCircle2 className="w-5 h-5 text-emerald-600 flex-shrink-0" />
                  ) : (
                    <AlertTriangle className="w-5 h-5 text-red-600 flex-shrink-0" />
                  )}
                  <span>{commStatusMsg.text}</span>
                </div>
              )}

              {/* -------------------------------------------------------------
                  SUBTAB 1: INDIVIDUAL CUSTOMER DISPATCHER
              ------------------------------------------------------------- */}
              {commHubSubTab === 'INDIVIDUAL' && (
                <div className="bg-white border border-slate-200 rounded-3xl p-5 sm:p-6 shadow-sm space-y-4">
                  <div>
                    <label className="block text-xs font-black uppercase tracking-wider text-slate-700 mb-1.5">
                      Select Target Customer Account
                    </label>
                    <select
                      value={commSelectedUserIdForHub}
                      onChange={(e) => {
                        const targetId = e.target.value;
                        setCommSelectedUserIdForHub(targetId);
                        const found = users.find((u) => u.id === targetId);
                        if (found) {
                          setActiveActionUser(found);
                          setCommRecipientName(found.name);
                          setCommRecipientPhone(found.phone);
                          setCommRecipientEmail(found.email || '');
                          setCommRecipientAccount(found.accountNumber || '');
                          handleSelectCommPreset('CUSTOM', found);
                        }
                      }}
                      className="w-full bg-slate-50 border border-slate-200 rounded-2xl p-3 text-xs font-bold text-slate-900 focus:outline-none focus:border-purple-500 shadow-inner"
                    >
                      <option value="">-- Choose Customer from Directory ({users.length} registered accounts) --</option>
                      {users.map((u) => (
                        <option key={u.id} value={u.id}>
                          {u.name} • A/C {u.accountNumber} • {u.phone} {u.email ? `• ${u.email}` : ''} ({u.branchName || 'Kolkata HO'})
                        </option>
                      ))}
                    </select>
                  </div>

                  {/* Form when user is selected */}
                  {commSelectedUserIdForHub ? (
                    <form onSubmit={handleSendIndividualCommunication} className="space-y-4 pt-2">
                      {/* Channel Selector */}
                      <div>
                        <label className="block text-[11px] font-black uppercase tracking-wider text-slate-700 mb-1.5">
                          Delivery Channels
                        </label>
                        <div className="grid grid-cols-3 gap-2">
                          {[
                            { id: 'BOTH', label: 'SMS & Email (Both)', icon: Send, desc: 'Deliver to Phone & Inbox' },
                            { id: 'EMAIL', label: 'Email Only', icon: Mail, desc: 'Hostinger Modern Template' },
                            { id: 'SMS', label: 'SMS Alert Only', icon: Smartphone, desc: 'Registered Mobile Number' },
                          ].map((ch) => {
                            const Icon = ch.icon;
                            const isSelected = commChannel === ch.id;
                            return (
                              <button
                                key={ch.id}
                                type="button"
                                onClick={() => setCommChannel(ch.id as any)}
                                className={`p-2.5 rounded-2xl border text-left transition flex flex-col justify-between ${
                                  isSelected
                                    ? 'bg-[#0a2540] border-[#0a2540] text-white shadow-md'
                                    : 'bg-slate-50 border-slate-200 text-slate-700 hover:bg-slate-100'
                                }`}
                              >
                                <div className="flex items-center gap-1.5 mb-1">
                                  <Icon className={`w-3.5 h-3.5 ${isSelected ? 'text-amber-400' : 'text-slate-500'}`} />
                                  <span className="text-xs font-black uppercase tracking-wider">{ch.label}</span>
                                </div>
                                <span className={`text-[10px] font-semibold ${isSelected ? 'text-slate-300' : 'text-slate-400'}`}>
                                  {ch.desc}
                                </span>
                              </button>
                            );
                          })}
                        </div>
                      </div>

                      {/* Quick Advisory Presets */}
                      <div>
                        <label className="block text-[11px] font-black uppercase tracking-wider text-slate-700 mb-1.5 flex items-center justify-between">
                          <span>Quick Advisory Presets</span>
                          <span className="text-[10px] text-slate-400 font-bold lowercase">Click to auto-populate template</span>
                        </label>
                        <div className="flex items-center gap-1.5 flex-wrap">
                          {[
                            { id: 'CUSTOM', label: 'Custom Notice' },
                            { id: 'KYC', label: 'Re-KYC Notice' },
                            { id: 'SECURITY', label: 'Security Warning' },
                            { id: 'BALANCE', label: 'Statement / Balance' },
                            { id: 'WELCOME', label: 'Welcome Kit' },
                            { id: 'AGRI', label: 'Kisan / Agri-Credit' },
                          ].map((p) => (
                            <button
                              key={p.id}
                              type="button"
                              onClick={() => handleSelectCommPreset(p.id as any)}
                              className={`px-3 py-1.5 rounded-xl text-xs font-black uppercase tracking-wider transition border ${
                                commPreset === p.id
                                  ? 'bg-purple-100 text-purple-900 border-purple-300 font-black'
                                  : 'bg-slate-50 text-slate-600 border-slate-200 hover:bg-slate-100'
                              }`}
                            >
                              {p.label}
                            </button>
                          ))}
                        </div>
                      </div>

                      {/* Verified Coordinates */}
                      <div className="bg-slate-50 border border-slate-200 rounded-2xl p-3.5 grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                        <div>
                          <label className="block text-[10px] font-black uppercase text-slate-600 mb-1">
                            Customer Legal Name
                          </label>
                          <input
                            type="text"
                            value={commRecipientName}
                            onChange={(e) => setCommRecipientName(e.target.value)}
                            className="w-full bg-white border border-slate-200 rounded-xl px-3 py-2 text-xs font-bold text-slate-900 focus:outline-none focus:border-purple-500"
                          />
                        </div>

                        <div>
                          <label className="block text-[10px] font-black uppercase text-slate-600 mb-1">
                            CBS Account Number
                          </label>
                          <input
                            type="text"
                            value={commRecipientAccount}
                            onChange={(e) => setCommRecipientAccount(e.target.value)}
                            className="w-full bg-white border border-slate-200 rounded-xl px-3 py-2 text-xs font-mono font-bold text-slate-900 focus:outline-none focus:border-purple-500"
                          />
                        </div>

                        <div>
                          <label className="block text-[10px] font-black uppercase text-slate-600 mb-1">
                            Registered Mobile Number (SMS)
                          </label>
                          <input
                            type="text"
                            value={commRecipientPhone}
                            onChange={(e) => setCommRecipientPhone(e.target.value)}
                            placeholder="+91 98765 43210"
                            className="w-full bg-white border border-slate-200 rounded-xl px-3 py-2 text-xs font-mono font-bold text-slate-900 focus:outline-none focus:border-purple-500"
                          />
                        </div>

                        <div>
                          <label className="block text-[10px] font-black uppercase text-slate-600 mb-1 flex items-center justify-between">
                            <span>Email Address (from: support@axisbank.com)</span>
                          </label>
                          <input
                            type="email"
                            value={commRecipientEmail}
                            onChange={(e) => setCommRecipientEmail(e.target.value)}
                            placeholder="customer@domain.com"
                            className="w-full bg-white border border-slate-200 rounded-xl px-3 py-2 text-xs font-bold text-slate-900 focus:outline-none focus:border-purple-500"
                          />
                        </div>
                      </div>

                      {/* Subject & Title */}
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                        <div>
                          <label className="block text-[10px] font-black uppercase text-slate-700 mb-1">
                            Email Subject Line
                          </label>
                          <input
                            type="text"
                            required
                            value={commSubject}
                            onChange={(e) => setCommSubject(e.target.value)}
                            className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs font-bold text-slate-900 focus:outline-none focus:border-purple-500"
                          />
                        </div>
                        <div>
                          <label className="block text-[10px] font-black uppercase text-slate-700 mb-1">
                            Header Badge / Sub-Title
                          </label>
                          <input
                            type="text"
                            value={commTitle}
                            onChange={(e) => setCommTitle(e.target.value)}
                            className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs font-bold text-slate-900 focus:outline-none focus:border-purple-500"
                          />
                        </div>
                      </div>

                      {/* Message Body */}
                      <div>
                        <div className="flex items-center justify-between mb-1">
                          <label className="text-[10px] font-black uppercase text-slate-700">
                            Message Body
                          </label>
                          <span className="text-[10px] font-bold text-slate-400">
                            {commMessage.length} characters
                          </span>
                        </div>
                        <textarea
                          rows={4}
                          required
                          value={commMessage}
                          onChange={(e) => setCommMessage(e.target.value)}
                          className="w-full bg-slate-50 border border-slate-200 rounded-xl p-3 text-xs font-medium text-slate-900 focus:outline-none focus:border-purple-500 leading-relaxed font-sans"
                        />
                      </div>

                      {/* Live Email Preview Toggle */}
                      <div>
                        <button
                          type="button"
                          onClick={() => setCommShowPreview(!commShowPreview)}
                          className="flex items-center gap-1.5 text-xs font-black uppercase tracking-wider text-purple-700 hover:text-purple-900 underline"
                        >
                          <Eye className="w-3.5 h-3.5" />
                          <span>{commShowPreview ? 'Hide Modern Banking Email Preview' : 'Show Modern Banking Email Preview'}</span>
                        </button>

                        {commShowPreview && (
                          <div className="mt-3 p-4 bg-slate-100 rounded-2xl border border-slate-200 animate-in fade-in">
                            <div className="max-w-lg mx-auto bg-white rounded-2xl shadow-md border border-slate-200 overflow-hidden text-slate-800 text-xs">
                              {/* Header */}
                              <div className="bg-gradient-to-r from-[#4E061E] via-[#861F41] to-[#97144D] p-5 text-center text-white border-b-2 border-amber-400">
                                <div className="inline-block px-2.5 py-0.5 rounded-full bg-black/30 text-amber-300 border border-amber-400/30 text-[9px] font-extrabold uppercase tracking-wider mb-2">
                                  🔒 RBI Scheduled Bank • 256-Bit SSL Encrypted
                                </div>
                                <div className="flex justify-center mb-1.5">
                                  <AxisBankLogo size="md" showText={false} />
                                </div>
                                <h5 className="text-sm font-black uppercase tracking-wider text-white m-0">
                                  Axis Bank CC VIP
                                </h5>
                                <p className="text-[10px] text-amber-200 font-bold m-0 mt-0.5 uppercase tracking-wide">
                                  Priority Mobile Banking &amp; Corporate VIP Portal
                                </p>
                                <div className="mt-2">
                                  <span className="inline-block px-3 py-0.5 rounded-full bg-amber-400 text-slate-950 text-[9px] font-black uppercase tracking-wider shadow-xs">
                                    {commTitle || '★ Official Notice ★'}
                                  </span>
                                </div>
                              </div>

                              {/* Body */}
                              <div className="p-4 space-y-3">
                                <p className="font-bold text-slate-900 text-xs">
                                  Dear {commRecipientName || 'Valued Customer'},
                                </p>
                                <div className="bg-slate-50 p-3 rounded-xl border border-slate-200 text-xs leading-relaxed text-slate-700 whitespace-pre-wrap font-sans">
                                  {commMessage || 'Message content preview will appear here.'}
                                </div>

                                <div className="border border-slate-200 rounded-xl overflow-hidden text-[11px]">
                                  <div className="flex justify-between p-1.5 bg-slate-50 border-b border-slate-200">
                                    <span className="text-slate-500 font-bold uppercase text-[9px]">Account Number</span>
                                    <span className="font-mono font-bold text-slate-900">{commRecipientAccount || '•••• •••• ••••'}</span>
                                  </div>
                                  <div className="flex justify-between p-1.5 bg-white">
                                    <span className="text-slate-500 font-bold uppercase text-[9px]">Authority</span>
                                    <span className="font-bold text-slate-900">Branch Officer Administration, Axis Bank CC VIP</span>
                                  </div>
                                </div>

                                <div className="p-2.5 bg-amber-50 border border-amber-200 rounded-xl text-[10px] text-amber-900 leading-normal">
                                  <strong>⚠️ Compliance Notice:</strong> Axis Bank never asks for your MPIN, Password, or OTP. For support call 1860-419-5555.
                                </div>
                              </div>

                              {/* Footer */}
                              <div className="bg-slate-900 text-slate-400 p-3 text-center text-[10px] space-y-0.5">
                                <p className="font-bold text-white">Axis Bank Ltd. (Axis Bank CC VIP)</p>
                                <p className="text-[9px]">Corporate Office: Axis House, C-2, Wadia International Centre, Worli, Mumbai - 400025</p>
                                <p className="text-[9px] text-amber-400">Helpline: 1860-419-5555 • Email: support@axisbank.com</p>
                              </div>
                            </div>
                          </div>
                        )}
                      </div>

                      {/* Dispatch Submit */}
                      <button
                        type="submit"
                        disabled={commIsSending}
                        className="w-full py-3.5 rounded-2xl bg-purple-700 hover:bg-purple-800 disabled:bg-purple-400 text-white font-black uppercase tracking-wider text-xs shadow-md transition active:scale-98 flex items-center justify-center gap-2"
                      >
                        <Send className={`w-4 h-4 ${commIsSending ? 'animate-bounce' : ''}`} />
                        <span>
                          {commIsSending
                            ? 'Dispatching Communication via Hostinger SMTP / SMS...'
                            : commChannel === 'BOTH'
                            ? `Dispatch SMS & Modern Email to ${commRecipientName}`
                            : commChannel === 'EMAIL'
                            ? `Dispatch Modern Banking Email to ${commRecipientEmail || commRecipientName}`
                            : `Dispatch Mobile SMS to ${commRecipientPhone || commRecipientName}`}
                        </span>
                      </button>
                    </form>
                  ) : (
                    <div className="p-8 text-center text-slate-400 space-y-2 border-2 border-dashed border-slate-200 rounded-2xl">
                      <Mail className="w-10 h-10 mx-auto text-slate-300" />
                      <p className="text-xs font-bold">
                        Please choose a customer from the dropdown above, or click <strong className="text-purple-700">"Send SMS/Email"</strong> directly on any user card in the Users & Accounts tab.
                      </p>
                    </div>
                  )}
                </div>
              )}

              {/* -------------------------------------------------------------
                  SUBTAB 2: SYSTEM-WIDE PUSH BROADCAST
              ------------------------------------------------------------- */}
              {commHubSubTab === 'BROADCAST' && (
                <div className="bg-white border border-slate-200 rounded-3xl p-5 sm:p-6 shadow-sm space-y-4">
                  {broadcastSuccess && (
                    <div className="p-4 bg-emerald-50 border border-emerald-200 rounded-2xl text-center space-y-1 animate-in zoom-in-95">
                      <CheckCircle2 className="w-8 h-8 text-emerald-600 mx-auto" />
                      <p className="text-xs font-black text-emerald-900 uppercase tracking-wider">
                        Broadcast Successfully Transmitted to All Users!
                      </p>
                    </div>
                  )}

                  <form onSubmit={handleDispatchBroadcast} className="space-y-3.5">
                    <div>
                      <label className="text-xs font-black text-slate-700 uppercase tracking-wider block mb-1">
                        Broadcast Title
                      </label>
                      <input
                        type="text"
                        required
                        value={broadcastTitle}
                        onChange={(e) => setBroadcastTitle(e.target.value)}
                        className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs font-bold text-slate-900 focus:outline-none focus:border-[#0a2540]"
                      />
                    </div>

                    <div>
                      <label className="text-xs font-black text-slate-700 uppercase tracking-wider block mb-1">
                        Broadcast Message Body
                      </label>
                      <textarea
                        required
                        rows={3}
                        value={broadcastBody}
                        onChange={(e) => setBroadcastBody(e.target.value)}
                        className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs font-bold text-slate-900 focus:outline-none focus:border-[#0a2540]"
                      />
                    </div>

                    <div>
                      <label className="text-xs font-black text-slate-700 uppercase tracking-wider block mb-1">
                        Target Customer Segment
                      </label>
                      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                        {[
                          { id: 'ALL', label: 'All Customers' },
                          { id: 'FARMERS', label: 'Farmers (KCC)' },
                          { id: 'SENIORS', label: 'Senior Pension' },
                          { id: 'MERCHANTS', label: 'Merchants' },
                        ].map((seg) => (
                          <button
                            key={seg.id}
                            type="button"
                            onClick={() => setBroadcastTarget(seg.id as any)}
                            className={`py-2 text-xs font-black uppercase tracking-wider rounded-xl border transition ${
                              broadcastTarget === seg.id
                                ? 'bg-[#0a2540] border-[#0a2540] text-amber-300 shadow-xs'
                                : 'bg-slate-50 border-slate-200 text-slate-600 hover:bg-slate-100'
                            }`}
                          >
                            {seg.label}
                          </button>
                        ))}
                      </div>
                    </div>

                    <div>
                      <label className="text-xs font-black text-slate-700 uppercase tracking-wider block mb-1">
                        Alert Category
                      </label>
                      <div className="grid grid-cols-4 gap-2">
                        {(['SECURITY', 'TRANSACTION', 'OFFER', 'ADMIN_BROADCAST'] as const).map((type) => (
                          <button
                            key={type}
                            type="button"
                            onClick={() => setBroadcastType(type)}
                            className={`py-1.5 text-[10px] font-black uppercase tracking-wider rounded-lg border transition ${
                              broadcastType === type
                                ? 'bg-[#0a2540] border-[#0a2540] text-amber-300 shadow-xs'
                                : 'bg-slate-50 border-slate-200 text-slate-600 hover:bg-slate-100'
                            }`}
                          >
                            {type}
                          </button>
                        ))}
                      </div>
                    </div>

                    <button
                      type="submit"
                      className="w-full py-3 rounded-xl bg-[#0a2540] hover:bg-[#071d34] text-white font-black uppercase tracking-wider text-xs shadow-md transition active:scale-98 flex items-center justify-center gap-1.5"
                    >
                      <Radio className="w-4 h-4 text-amber-300" />
                      <span>Send Immediate Push Broadcast</span>
                    </button>
                  </form>
                </div>
              )}

              {/* -------------------------------------------------------------
                  SUBTAB 3: LIVE COMMUNICATIONS OUTBOX
              ------------------------------------------------------------- */}
              {commHubSubTab === 'OUTBOX' && (
                <div className="bg-white border border-slate-200 rounded-3xl p-5 sm:p-6 shadow-sm space-y-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <h4 className="text-xs font-black uppercase tracking-wider text-slate-900">
                        Dispatched Notifications & Modern Banking Emails Log
                      </h4>
                      <p className="text-[11px] text-slate-500 font-bold">
                        Audited record of transactional alerts, welcome kits, and direct messages
                      </p>
                    </div>
                    <button
                      type="button"
                      onClick={() => emailService.getOutbox().then(setCommOutboxLogs).catch(() => {})}
                      className="px-3 py-1.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-xs font-bold text-slate-700 flex items-center gap-1.5 transition"
                    >
                      <RefreshCw className="w-3.5 h-3.5" />
                      <span>Refresh Outbox</span>
                    </button>
                  </div>

                  {commOutboxLogs.length === 0 ? (
                    <div className="p-8 text-center text-slate-400 border border-slate-200 rounded-2xl">
                      <Inbox className="w-8 h-8 mx-auto text-slate-300 mb-2" />
                      <p className="text-xs font-bold">No communications dispatched in this session yet.</p>
                      <p className="text-[10px]">Send an email or create a transaction to see live records appear here.</p>
                    </div>
                  ) : (
                    <div className="overflow-x-auto border border-slate-200 rounded-2xl">
                      <table className="w-full text-left text-xs border-collapse">
                        <thead>
                          <tr className="bg-slate-50 border-b border-slate-200 text-[10px] font-black uppercase tracking-wider text-slate-500">
                            <th className="p-3">Recipient</th>
                            <th className="p-3">Type</th>
                            <th className="p-3">Subject</th>
                            <th className="p-3">Channel</th>
                            <th className="p-3">Status</th>
                            <th className="p-3">Dispatched Time</th>
                            <th className="p-3 text-right">Action</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-100">
                          {commOutboxLogs.map((log) => (
                            <tr key={log.id} className="hover:bg-slate-50/80 transition">
                              <td className="p-3 font-bold text-slate-900">
                                <div>{log.recipientName}</div>
                                <div className="text-[10px] text-slate-400 font-mono">{log.recipientEmail || log.recipientPhone || 'N/A'}</div>
                              </td>
                              <td className="p-3 font-mono text-[10px] uppercase font-bold text-slate-600">
                                {log.type}
                              </td>
                              <td className="p-3 text-xs font-semibold text-slate-800 max-w-xs truncate">
                                {log.subject}
                              </td>
                              <td className="p-3">
                                <span className={`px-2 py-0.5 rounded-full text-[9px] font-black uppercase ${
                                  log.channel === 'EMAIL'
                                    ? 'bg-purple-100 text-purple-800'
                                    : log.channel === 'SMS'
                                    ? 'bg-blue-100 text-blue-800'
                                    : 'bg-emerald-100 text-emerald-800'
                                }`}>
                                  {log.channel || 'EMAIL'}
                                </span>
                              </td>
                              <td className="p-3">
                                <span className={`px-2 py-0.5 rounded-full text-[9px] font-black uppercase ${
                                  log.status === 'SENT' || log.status === 'DELIVERED'
                                    ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                                    : 'bg-amber-50 text-amber-700 border border-amber-200'
                                }`}>
                                  {log.status}
                                </span>
                              </td>
                              <td className="p-3 text-[10px] text-slate-500 font-medium">
                                {log.timestamp}
                              </td>
                              <td className="p-3 text-right">
                                {log.htmlPreview ? (
                                  <button
                                    type="button"
                                    onClick={() => setCommViewingEmailHtml(log.htmlPreview)}
                                    className="px-2.5 py-1 rounded-lg bg-[#0a2540] hover:bg-[#071d34] text-white text-[10px] font-black uppercase tracking-wider flex items-center gap-1 ml-auto shadow-2xs"
                                  >
                                    <Eye className="w-3 h-3 text-amber-300" />
                                    <span>View Email</span>
                                  </button>
                                ) : (
                                  <span className="text-[10px] text-slate-400 font-bold">SMS Only</span>
                                )}
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  )}
                </div>
              )}

              {/* SUB TAB 4: SMTP & TWILIO GATEWAY ENGINE CONFIG */}
              {commHubSubTab === 'SETTINGS' && (
                <div className="space-y-6 animate-in fade-in">
                  {/* Top Control Bar */}
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white p-4 rounded-2xl border border-slate-200 shadow-2xs">
                    <div>
                      <h4 className="text-base font-black uppercase tracking-wider text-slate-900 flex items-center gap-2">
                        <Server className="w-5 h-5 text-[#861F41]" />
                        <span>Communications Gateway Infrastructure</span>
                      </h4>
                      <p className="text-xs text-slate-500 font-bold mt-0.5">
                        Manage and update live SMTP email delivery and Twilio bulk SMS/OTP gateways
                      </p>
                    </div>

                    <button
                      type="button"
                      onClick={() => loadCommunicationsSettings()}
                      className="px-3.5 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold transition flex items-center gap-1.5 self-start sm:self-auto cursor-pointer"
                    >
                      <RefreshCw className="w-3.5 h-3.5" />
                      <span>Reload Gateway Status</span>
                    </button>
                  </div>

                  <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                    {/* CARD 1: SMTP SETTINGS */}
                    <div className="bg-white border border-slate-200 rounded-3xl p-5 shadow-2xs space-y-4">
                      <div className="flex items-center justify-between pb-3 border-b border-slate-100">
                        <div className="flex items-center gap-2.5">
                          <div className="w-9 h-9 rounded-xl bg-purple-50 text-purple-700 flex items-center justify-center">
                            <Mail className="w-5 h-5" />
                          </div>
                          <div>
                            <h5 className="text-sm font-black uppercase tracking-wider text-slate-900">
                              SMTP Email Gateway
                            </h5>
                            <span className="text-[10px] text-slate-400 font-bold">
                              Welcome, Alerts, KYC &amp; Statements
                            </span>
                          </div>
                        </div>

                        <span
                          className={`px-2.5 py-1 rounded-full text-[10px] font-black uppercase tracking-wider ${
                            smtpStatus?.isConfigured
                              ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                              : 'bg-amber-50 text-amber-700 border border-amber-200'
                          }`}
                        >
                          {smtpStatus?.isConfigured ? '● Active SMTP' : '○ Simulated Outbox'}
                        </span>
                      </div>

                      {/* SMTP Save Feedback */}
                      {smtpSaveMessage && (
                        <div
                          className={`p-3 rounded-xl border flex items-center gap-2 text-xs font-bold animate-in fade-in ${
                            smtpSaveMessage.type === 'success'
                              ? 'bg-emerald-50 border-emerald-200 text-emerald-900'
                              : 'bg-rose-50 border-rose-200 text-rose-900'
                          }`}
                        >
                          {smtpSaveMessage.type === 'success' ? (
                            <CheckCircle2 className="w-4 h-4 text-emerald-600 flex-shrink-0" />
                          ) : (
                            <AlertCircle className="w-4 h-4 text-rose-600 flex-shrink-0" />
                          )}
                          <span>{smtpSaveMessage.text}</span>
                        </div>
                      )}

                      {/* SMTP Test Result Alert */}
                      {smtpTestResult && (
                        <div
                          className={`p-3 rounded-xl border flex items-start gap-2 text-xs font-bold animate-in fade-in ${
                            smtpTestResult.success
                              ? 'bg-emerald-50 border-emerald-200 text-emerald-900'
                              : 'bg-rose-50 border-rose-200 text-rose-900'
                          }`}
                        >
                          {smtpTestResult.success ? (
                            <CheckCircle2 className="w-4 h-4 text-emerald-600 flex-shrink-0 mt-0.5" />
                          ) : (
                            <AlertCircle className="w-4 h-4 text-rose-600 flex-shrink-0 mt-0.5" />
                          )}
                          <div>
                            <p className="font-black">
                              {smtpTestResult.success ? 'SMTP Connection Verified!' : 'SMTP Verification Failed'}
                            </p>
                            <p className="text-[11px] font-normal mt-0.5">{smtpTestResult.message}</p>
                          </div>
                        </div>
                      )}

                      {/* SMTP Edit Form */}
                      <form
                        onSubmit={async (e) => {
                          e.preventDefault();
                          setSmtpSaving(true);
                          setSmtpSaveMessage(null);
                          try {
                            const res = await emailService.updateCommunicationsSettings({
                              smtp: {
                                host: smtpFormHost,
                                port: parseInt(smtpFormPort, 10),
                                secure: smtpFormSecure === 'true',
                                user: smtpFormUser,
                                pass: smtpFormPass.trim() !== '' ? smtpFormPass : undefined,
                                from: smtpFormFrom,
                              },
                            });
                            if (res.success) {
                              setSmtpSaveMessage({ type: 'success', text: 'SMTP Gateway settings updated and persisted successfully!' });
                              setSmtpFormPass('');
                              await loadCommunicationsSettings();
                            } else {
                              setSmtpSaveMessage({ type: 'error', text: res.message || 'Failed to save SMTP settings.' });
                            }
                          } catch (err: any) {
                            setSmtpSaveMessage({ type: 'error', text: err.message || 'Error updating SMTP settings.' });
                          } finally {
                            setSmtpSaving(false);
                          }
                        }}
                        className="space-y-3.5"
                      >
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                          <div>
                            <label className="block text-[10px] font-black uppercase text-slate-700 mb-1">
                              SMTP Host
                            </label>
                            <input
                              type="text"
                              required
                              value={smtpFormHost}
                              onChange={(e) => setSmtpFormHost(e.target.value)}
                              placeholder="smtp.hostinger.com"
                              className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs font-mono font-bold text-slate-900 focus:outline-none focus:border-purple-500"
                            />
                          </div>

                          <div>
                            <label className="block text-[10px] font-black uppercase text-slate-700 mb-1">
                              SMTP Port
                            </label>
                            <input
                              type="number"
                              required
                              value={smtpFormPort}
                              onChange={(e) => setSmtpFormPort(e.target.value)}
                              placeholder="465"
                              className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs font-mono font-bold text-slate-900 focus:outline-none focus:border-purple-500"
                            />
                          </div>
                        </div>

                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                          <div>
                            <label className="block text-[10px] font-black uppercase text-slate-700 mb-1">
                              Encryption Mode
                            </label>
                            <select
                              value={smtpFormSecure}
                              onChange={(e) => setSmtpFormSecure(e.target.value)}
                              className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs font-bold text-slate-900 focus:outline-none focus:border-purple-500"
                            >
                              <option value="true">SSL / TLS (Port 465 recommended)</option>
                              <option value="false">STARTTLS (Port 587)</option>
                            </select>
                          </div>

                          <div>
                            <label className="block text-[10px] font-black uppercase text-slate-700 mb-1">
                              SMTP Username / Mailbox
                            </label>
                            <input
                              type="text"
                              required
                              value={smtpFormUser}
                              onChange={(e) => setSmtpFormUser(e.target.value)}
                              placeholder="support@yourdomain.com"
                              className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs font-mono font-bold text-slate-900 focus:outline-none focus:border-purple-500"
                            />
                          </div>
                        </div>

                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                          <div>
                            <label className="block text-[10px] font-black uppercase text-slate-700 mb-1">
                              SMTP Password
                            </label>
                            <input
                              type="password"
                              value={smtpFormPass}
                              onChange={(e) => setSmtpFormPass(e.target.value)}
                              placeholder={smtpStatus?.hasPass ? '•••••••• (Leave blank to keep)' : 'Enter mailbox password'}
                              className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs font-mono font-bold text-slate-900 focus:outline-none focus:border-purple-500"
                            />
                          </div>

                          <div>
                            <label className="block text-[10px] font-black uppercase text-slate-700 mb-1">
                              Sender "From" Header
                            </label>
                            <input
                              type="text"
                              required
                              value={smtpFormFrom}
                              onChange={(e) => setSmtpFormFrom(e.target.value)}
                              placeholder='"Axis Bank CC VIP" <support@yourdomain.com>'
                              className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs font-bold text-slate-900 focus:outline-none focus:border-purple-500"
                            />
                          </div>
                        </div>

                        <div className="pt-2 flex items-center justify-between gap-3">
                          <button
                            type="button"
                            disabled={smtpTesting}
                            onClick={async () => {
                              setSmtpTesting(true);
                              setSmtpTestResult(null);
                              try {
                                const res = await emailService.testSmtpConnection();
                                setSmtpTestResult(res);
                                await loadCommunicationsSettings();
                              } catch (err: any) {
                                setSmtpTestResult({ success: false, message: err.message || 'SMTP test error' });
                              } finally {
                                setSmtpTesting(false);
                              }
                            }}
                            className="px-3 py-2 rounded-xl bg-purple-50 hover:bg-purple-100 text-purple-700 text-xs font-black uppercase tracking-wider transition flex items-center gap-1.5 cursor-pointer disabled:opacity-50"
                          >
                            <RefreshCw className={`w-3.5 h-3.5 ${smtpTesting ? 'animate-spin' : ''}`} />
                            <span>{smtpTesting ? 'Testing...' : 'Test Connection'}</span>
                          </button>

                          <button
                            type="submit"
                            disabled={smtpSaving}
                            className="px-5 py-2.5 rounded-xl bg-purple-700 hover:bg-purple-800 disabled:bg-purple-400 text-white text-xs font-black uppercase tracking-wider shadow-md transition active:scale-95 flex items-center gap-1.5 cursor-pointer"
                          >
                            <Save className={`w-3.5 h-3.5 ${smtpSaving ? 'animate-spin' : ''}`} />
                            <span>{smtpSaving ? 'Saving...' : 'Save SMTP Settings'}</span>
                          </button>
                        </div>
                      </form>
                    </div>

                    {/* CARD 2: TWILIO SETTINGS */}
                    <div className="bg-white border border-slate-200 rounded-3xl p-5 shadow-2xs space-y-4">
                      <div className="flex items-center justify-between pb-3 border-b border-slate-100">
                        <div className="flex items-center gap-2.5">
                          <div className="w-9 h-9 rounded-xl bg-blue-50 text-blue-700 flex items-center justify-center">
                            <MessageSquare className="w-5 h-5" />
                          </div>
                          <div>
                            <h5 className="text-sm font-black uppercase tracking-wider text-slate-900">
                              Twilio Real SMS &amp; OTP Gateway
                            </h5>
                            <span className="text-[10px] text-slate-400 font-bold">
                              Direct Transaction SMS, OTP &amp; Push Alerts
                            </span>
                          </div>
                        </div>

                        <span
                          className={`px-2.5 py-1 rounded-full text-[10px] font-black uppercase tracking-wider ${
                            twilioStatus?.isConfigured
                              ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                              : 'bg-amber-50 text-amber-700 border border-amber-200'
                          }`}
                        >
                          {twilioStatus?.isConfigured ? '● Active Twilio' : '○ Unconfigured'}
                        </span>
                      </div>

                      {/* Twilio Save Feedback */}
                      {twilioSaveMessage && (
                        <div
                          className={`p-3 rounded-xl border flex items-center gap-2 text-xs font-bold animate-in fade-in ${
                            twilioSaveMessage.type === 'success'
                              ? 'bg-emerald-50 border-emerald-200 text-emerald-900'
                              : 'bg-rose-50 border-rose-200 text-rose-900'
                          }`}
                        >
                          {twilioSaveMessage.type === 'success' ? (
                            <CheckCircle2 className="w-4 h-4 text-emerald-600 flex-shrink-0" />
                          ) : (
                            <AlertCircle className="w-4 h-4 text-rose-600 flex-shrink-0" />
                          )}
                          <span>{twilioSaveMessage.text}</span>
                        </div>
                      )}

                      {/* Twilio Test Result Alert */}
                      {twilioTestResult && (
                        <div
                          className={`p-3 rounded-xl border flex items-start gap-2 text-xs font-bold animate-in fade-in ${
                            twilioTestResult.success
                              ? 'bg-emerald-50 border-emerald-200 text-emerald-900'
                              : 'bg-rose-50 border-rose-200 text-rose-900'
                          }`}
                        >
                          {twilioTestResult.success ? (
                            <CheckCircle2 className="w-4 h-4 text-emerald-600 flex-shrink-0 mt-0.5" />
                          ) : (
                            <AlertCircle className="w-4 h-4 text-rose-600 flex-shrink-0 mt-0.5" />
                          )}
                          <div>
                            <p className="font-black">
                              {twilioTestResult.success ? 'Twilio Verified / Dispatched!' : 'Twilio Verification Failed'}
                            </p>
                            <p className="text-[11px] font-normal mt-0.5">{twilioTestResult.message}</p>
                          </div>
                        </div>
                      )}

                      {/* Twilio Edit Form */}
                      <form
                        onSubmit={async (e) => {
                          e.preventDefault();
                          setTwilioSaving(true);
                          setTwilioSaveMessage(null);
                          try {
                            const res = await emailService.updateCommunicationsSettings({
                              twilio: {
                                accountSid: twilioFormAccountSid,
                                authToken: twilioFormAuthToken.trim() !== '' ? twilioFormAuthToken : undefined,
                                fromPhone: twilioFormFromPhone,
                              },
                            });
                            if (res.success) {
                              setTwilioSaveMessage({ type: 'success', text: 'Twilio Gateway settings updated and persisted successfully!' });
                              setTwilioFormAuthToken('');
                              await loadCommunicationsSettings();
                            } else {
                              setTwilioSaveMessage({ type: 'error', text: res.message || 'Failed to save Twilio settings.' });
                            }
                          } catch (err: any) {
                            setTwilioSaveMessage({ type: 'error', text: err.message || 'Error updating Twilio settings.' });
                          } finally {
                            setTwilioSaving(false);
                          }
                        }}
                        className="space-y-3.5"
                      >
                        <div>
                          <label className="block text-[10px] font-black uppercase text-slate-700 mb-1">
                            Twilio Account SID
                          </label>
                          <input
                            type="text"
                            required
                            value={twilioFormAccountSid}
                            onChange={(e) => setTwilioFormAccountSid(e.target.value)}
                            placeholder="ACxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx"
                            className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs font-mono font-bold text-slate-900 focus:outline-none focus:border-blue-500"
                          />
                        </div>

                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                          <div>
                            <label className="block text-[10px] font-black uppercase text-slate-700 mb-1">
                              Twilio Auth Token
                            </label>
                            <input
                              type="password"
                              value={twilioFormAuthToken}
                              onChange={(e) => setTwilioFormAuthToken(e.target.value)}
                              placeholder={twilioStatus?.hasAuthToken ? '•••••••• (Leave blank to keep)' : 'Enter Twilio Auth Token'}
                              className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs font-mono font-bold text-slate-900 focus:outline-none focus:border-blue-500"
                            />
                          </div>

                          <div>
                            <label className="block text-[10px] font-black uppercase text-slate-700 mb-1">
                              Twilio Sender Phone Number
                            </label>
                            <input
                              type="text"
                              required
                              value={twilioFormFromPhone}
                              onChange={(e) => setTwilioFormFromPhone(e.target.value)}
                              placeholder="+14703488870 (E.164)"
                              className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs font-mono font-bold text-slate-900 focus:outline-none focus:border-blue-500"
                            />
                          </div>
                        </div>

                        <div className="pt-2 flex items-center justify-between gap-3">
                          <button
                            type="button"
                            disabled={twilioTesting}
                            onClick={async () => {
                              setTwilioTesting(true);
                              setTwilioTestResult(null);
                              try {
                                const res = await emailService.testTwilioConnection();
                                setTwilioTestResult(res);
                                await loadCommunicationsSettings();
                              } catch (err: any) {
                                setTwilioTestResult({ success: false, message: err.message || 'Twilio test error' });
                              } finally {
                                setTwilioTesting(false);
                              }
                            }}
                            className="px-3 py-2 rounded-xl bg-blue-50 hover:bg-blue-100 text-blue-700 text-xs font-black uppercase tracking-wider transition flex items-center gap-1.5 cursor-pointer disabled:opacity-50"
                          >
                            <RefreshCw className={`w-3.5 h-3.5 ${twilioTesting ? 'animate-spin' : ''}`} />
                            <span>{twilioTesting ? 'Verifying...' : 'Verify Gateway'}</span>
                          </button>

                          <button
                            type="submit"
                            disabled={twilioSaving}
                            className="px-5 py-2.5 rounded-xl bg-[#0a2540] hover:bg-[#071d34] disabled:bg-slate-400 text-amber-300 text-xs font-black uppercase tracking-wider shadow-md transition active:scale-95 flex items-center gap-1.5 cursor-pointer"
                          >
                            <Save className={`w-3.5 h-3.5 ${twilioSaving ? 'animate-spin' : ''}`} />
                            <span>{twilioSaving ? 'Saving...' : 'Save Twilio Settings'}</span>
                          </button>
                        </div>
                      </form>

                      {/* Live Test SMS Dispatcher */}
                      <div className="pt-3 border-t border-slate-100 space-y-2">
                        <label className="block text-[10px] font-black uppercase text-slate-600">
                          Send Live Test SMS
                        </label>
                        <div className="flex gap-2">
                          <input
                            type="text"
                            value={twilioTestPhone}
                            onChange={(e) => setTwilioTestPhone(e.target.value)}
                            placeholder="+919830012345"
                            className="flex-1 bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs font-mono font-bold text-slate-900 focus:outline-none focus:border-blue-500"
                          />
                          <button
                            type="button"
                            disabled={twilioTesting}
                            onClick={async () => {
                              setTwilioTesting(true);
                              setTwilioTestResult(null);
                              try {
                                const res = await emailService.testTwilioConnection(twilioTestPhone);
                                setTwilioTestResult(res);
                              } catch (err: any) {
                                setTwilioTestResult({ success: false, message: err.message || 'SMS test error' });
                              } finally {
                                setTwilioTesting(false);
                              }
                            }}
                            className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-black uppercase tracking-wider transition active:scale-95 disabled:opacity-50 cursor-pointer flex items-center gap-1.5 shadow-xs"
                          >
                            <Send className="w-3.5 h-3.5" />
                            <span>Dispatch Test SMS</span>
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* -------------------------------------------------------------------
              TAB 8: LIVE GPS USER TRACKING RADAR
          ------------------------------------------------------------------- */}
          {activeTab === 'LOCATIONS' && (
            <AdminUserLocationTracker users={users} />
          )}

          {/* -------------------------------------------------------------------
              TAB 9: ADMIN SECURITY & CREDENTIAL MANAGEMENT
          ------------------------------------------------------------------- */}
          {activeTab === 'ADMIN_MANAGEMENT' && (
            <AdminAccountManagement />
          )}
        </div>
      </div>

      {/* =========================================================================
          MODAL: QUICK MONEY ADJUSTMENT (ADD / DEDUCT) FROM USER ROW
      ========================================================================= */}
      {actionModalType === 'MONEY' && activeActionUser && (
        <div className="fixed inset-0 z-60 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-4 animate-in fade-in">
          <div className="w-full max-w-md bg-white rounded-3xl p-5 border border-slate-200 shadow-2xl space-y-4 animate-in zoom-in-95">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div>
                <h4 className="text-xs font-black uppercase tracking-wider text-slate-900 flex items-center gap-1.5">
                  <DollarSign className="w-4 h-4 text-emerald-600" />
                  <span>Manage Customer Balance</span>
                </h4>
                <p className="text-[11px] text-slate-500 font-bold">
                  {activeActionUser.name} (A/C: *{activeActionUser.accountNumber.slice(-4)})
                </p>
              </div>
              <button
                onClick={() => {
                  setActionModalType(null);
                  setActiveActionUser(null);
                }}
                className="p-1.5 rounded-full bg-slate-100 text-slate-500 hover:text-slate-900"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {moneySuccessMsg && (
              <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-xl text-center text-xs font-black text-emerald-900 uppercase tracking-wider">
                {moneySuccessMsg}
              </div>
            )}

            {/* Credit vs Debit Toggle */}
            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => setMoneyActionType('CREDIT')}
                className={`py-2 text-xs font-black uppercase tracking-wider rounded-xl border flex items-center justify-center gap-1 transition ${
                  moneyActionType === 'CREDIT'
                    ? 'bg-emerald-600 border-emerald-600 text-white shadow-xs'
                    : 'bg-slate-50 border-slate-200 text-slate-700'
                }`}
              >
                <PlusCircle className="w-3.5 h-3.5" />
                <span>Add Money (Credit)</span>
              </button>

              <button
                type="button"
                onClick={() => setMoneyActionType('DEBIT')}
                className={`py-2 text-xs font-black uppercase tracking-wider rounded-xl border flex items-center justify-center gap-1 transition ${
                  moneyActionType === 'DEBIT'
                    ? 'bg-slate-900 border-slate-900 text-white shadow-xs'
                    : 'bg-slate-50 border-slate-200 text-slate-700'
                }`}
              >
                <MinusCircle className="w-3.5 h-3.5" />
                <span>Deduct Money (Debit)</span>
              </button>
            </div>

            {/* Bucket Picker */}
            <div>
              <label className="text-[10px] font-black uppercase tracking-wider text-slate-500 block mb-1">
                Target Balance
              </label>
              <div className="grid grid-cols-2 gap-1.5">
                {[
                  { id: 'savings', label: 'Savings A/C' },
                  { id: 'wallet', label: 'Digital Wallet' },
                  { id: 'upiLite', label: 'UPI Lite' },
                  { id: 'fixedDeposit', label: 'Fixed Deposit' },
                ].map((b) => (
                  <button
                    key={b.id}
                    type="button"
                    onClick={() => setMoneyTargetBalance(b.id as any)}
                    className={`py-1.5 text-xs font-black uppercase tracking-wider rounded-lg border transition ${
                      moneyTargetBalance === b.id
                        ? 'bg-[#0a2540] border-[#0a2540] text-amber-300'
                        : 'bg-slate-50 border-slate-200 text-slate-700'
                    }`}
                  >
                    {b.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Amount */}
            <div>
              <label className="text-[10px] font-black uppercase tracking-wider text-slate-500 block mb-1">
                Amount (₹)
              </label>
              <input
                type="number"
                value={moneyAmount}
                onChange={(e) => setMoneyAmount(e.target.value)}
                className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-sm font-black font-mono text-slate-900 focus:outline-none focus:border-[#0a2540]"
              />
            </div>

            {/* Reason */}
            <div>
              <label className="text-[10px] font-black uppercase tracking-wider text-slate-500 block mb-1">
                Reason / Narration
              </label>
              <input
                type="text"
                value={moneyReason}
                onChange={(e) => setMoneyReason(e.target.value)}
                className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs font-bold text-slate-900 focus:outline-none focus:border-[#0a2540]"
              />
            </div>

            <button
              onClick={() => handleExecuteMoneyAdjustment(activeActionUser.id)}
              className={`w-full py-3 rounded-xl font-black uppercase tracking-wider text-xs shadow-md transition active:scale-98 ${
                moneyActionType === 'CREDIT'
                  ? 'bg-emerald-600 hover:bg-emerald-700 text-white'
                  : 'bg-[#0a2540] hover:bg-[#071d34] text-white'
              }`}
            >
              Confirm & Post {moneyActionType}
            </button>
          </div>
        </div>
      )}

      {/* =========================================================================
          MODAL: BLOCK CONFIRMATION
      ========================================================================= */}
      {actionModalType === 'BLOCK' && activeActionUser && (
        <div className="fixed inset-0 z-60 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-4 animate-in fade-in">
          <div className="w-full max-w-md bg-white rounded-3xl p-5 border border-slate-200 shadow-2xl space-y-4 animate-in zoom-in-95">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <h4 className="text-xs font-black uppercase tracking-wider text-red-700 flex items-center gap-1.5">
                <ShieldAlert className="w-4 h-4 text-red-600" />
                <span>Freeze / Block Customer Account</span>
              </h4>
              <button
                onClick={() => {
                  setActionModalType(null);
                  setActiveActionUser(null);
                }}
                className="p-1.5 rounded-full bg-slate-100 text-slate-500 hover:text-slate-900"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="p-3 bg-red-50 rounded-xl border border-red-200 text-xs text-red-900 space-y-1">
              <p className="font-black">
                You are freezing account: {activeActionUser.name} (*{activeActionUser.accountNumber.slice(-4)})
              </p>
              <p className="text-[11px] text-red-700 font-bold">
                This will immediately suspend inward and outward UPI transactions, wallet payments, and mobile banking.
              </p>
            </div>

            <div>
              <label className="text-xs font-black text-slate-700 uppercase tracking-wider block mb-1">
                Select or Enter Freeze Reason
              </label>
              <select
                value={blockReasonInput}
                onChange={(e) => setBlockReasonInput(e.target.value)}
                className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs font-bold text-slate-900 focus:outline-none focus:border-red-500 mb-2"
              >
                <option value="Suspicious Transaction Pattern / Re-KYC Audit Required">
                  Suspicious Transaction Pattern / Re-KYC Audit Required
                </option>
                <option value="Customer Request: Reported Lost Phone or Stolen SIM">
                  Customer Request: Reported Lost Phone or Stolen SIM
                </option>
                <option value="Court / Regulatory Freeze Order (RBI Directives)">
                  Court / Regulatory Freeze Order (RBI Directives)
                </option>
                <option value="Dormant Account Inactivity Exceeded 24 Months">
                  Dormant Account Inactivity Exceeded 24 Months
                </option>
                <option value="Pending Aadhaar Re-verification by UIDAI">
                  Pending Aadhaar Re-verification by UIDAI
                </option>
              </select>

              <input
                type="text"
                value={blockReasonInput}
                onChange={(e) => setBlockReasonInput(e.target.value)}
                className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs font-bold text-slate-900 focus:outline-none focus:border-red-500"
                placeholder="Custom reason..."
              />
            </div>

            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                onClick={() => {
                  setActionModalType(null);
                  setActiveActionUser(null);
                }}
                className="px-4 py-2 rounded-xl bg-slate-100 text-slate-700 text-xs font-black uppercase tracking-wider hover:bg-slate-200"
              >
                Cancel
              </button>
              <button
                onClick={handleConfirmBlock}
                className="px-5 py-2 rounded-xl bg-red-600 hover:bg-red-700 text-white text-xs font-black uppercase tracking-wider shadow-md"
              >
                Confirm Account Freeze
              </button>
            </div>
          </div>
        </div>
      )}

      {/* =========================================================================
          MODAL: PERMANENT USER ACCOUNT DELETION
      ========================================================================= */}
      {actionModalType === 'DELETE_USER' && activeActionUser && (
        <div className="fixed inset-0 z-60 bg-slate-950/75 backdrop-blur-xs flex items-center justify-center p-4 animate-in fade-in">
          <div className="w-full max-w-md bg-white rounded-3xl p-5 border border-red-200 shadow-2xl space-y-4 animate-in zoom-in-95">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div className="flex items-center gap-2.5">
                <div className="p-2.5 rounded-2xl bg-red-100 text-red-700">
                  <Trash2 className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="text-xs font-black uppercase tracking-wider text-slate-900">
                    Delete Customer Account
                  </h4>
                  <p className="text-[11px] text-red-600 font-bold">
                    Irreversible CBS Account Removal
                  </p>
                </div>
              </div>
              <button
                onClick={() => {
                  setActionModalType(null);
                  setActiveActionUser(null);
                }}
                className="p-1.5 rounded-full bg-slate-100 text-slate-500 hover:text-slate-900"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="p-3.5 bg-red-50 rounded-2xl border border-red-200 text-xs text-red-950 space-y-2">
              <div className="flex items-start gap-2">
                <AlertTriangle className="w-4 h-4 text-red-600 flex-shrink-0 mt-0.5" />
                <p className="font-bold">
                  Are you sure you want to permanently delete this customer account from the Axis Bank CC VIP core banking database?
                </p>
              </div>

              <div className="bg-white p-3 rounded-xl border border-red-100 space-y-1 font-mono text-[11px] shadow-2xs">
                <div className="flex justify-between">
                  <span className="text-slate-500 font-sans font-bold">Customer Name:</span>
                  <span className="font-black text-slate-900">{activeActionUser.name}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500 font-sans font-bold">Account Number:</span>
                  <span className="font-black text-blue-900">{activeActionUser.accountNumber}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500 font-sans font-bold">Registered Mobile:</span>
                  <span className="font-black text-slate-900">{activeActionUser.phone}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500 font-sans font-bold">Savings Balance:</span>
                  <span className="font-black text-emerald-800">
                    ₹{(activeActionUser.savingsBalance || 0).toLocaleString('en-IN', { minimumFractionDigits: 2 })}
                  </span>
                </div>
              </div>

              <p className="text-[10px] text-red-700 font-semibold leading-relaxed">
                ⚠️ All linked transactions, KYC filings, and active sessions for this customer will be permanently deleted from the database.
              </p>
            </div>

            <div className="flex items-center justify-end gap-2 pt-1">
              <button
                type="button"
                onClick={() => {
                  setActionModalType(null);
                  setActiveActionUser(null);
                }}
                className="px-4 py-2 rounded-xl bg-slate-100 text-slate-700 text-xs font-black uppercase tracking-wider hover:bg-slate-200 transition"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleConfirmDeleteUser}
                className="px-5 py-2 rounded-xl bg-red-600 hover:bg-red-700 text-white text-xs font-black uppercase tracking-wider shadow-md transition active:scale-95 flex items-center gap-1.5"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>Delete Permanently</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* =========================================================================
          MODAL: EDIT CUSTOMER & ACCOUNT DETAILS
      ========================================================================= */}
      {actionModalType === 'EDIT_DETAILS' && activeActionUser && (
        <div className="fixed inset-0 z-60 bg-slate-950/75 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 overflow-y-auto animate-in fade-in">
          <div className="w-full max-w-2xl bg-white rounded-3xl p-5 sm:p-6 border border-slate-200 shadow-2xl space-y-4 my-auto max-h-[92vh] flex flex-col animate-in zoom-in-95">
            {/* Header */}
            <div className="flex items-center justify-between border-b border-slate-100 pb-3 flex-shrink-0">
              <div className="flex items-center gap-2.5">
                <div className="p-2.5 rounded-2xl bg-blue-100 text-blue-700">
                  <Edit3 className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="text-sm font-black uppercase tracking-wider text-slate-900">
                    Edit Customer & Account Details
                  </h4>
                  <p className="text-[11px] text-slate-500 font-bold">
                    A/C {activeActionUser.accountNumber} • CIF {activeActionUser.cifNumber || 'N/A'} • Modify Record & Fix Errors
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => {
                  setActionModalType(null);
                  setActiveActionUser(null);
                }}
                className="p-1.5 rounded-full bg-slate-100 text-slate-500 hover:text-slate-900 transition"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Error & Success Messages */}
            {editDetailsErrorMsg && (
              <div className="p-3 bg-red-50 border border-red-200 rounded-2xl flex items-center gap-2 text-xs font-bold text-red-700 flex-shrink-0 animate-in fade-in">
                <AlertTriangle className="w-4 h-4 flex-shrink-0" />
                <span>{editDetailsErrorMsg}</span>
              </div>
            )}
            {editDetailsSuccessMsg && (
              <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-2xl flex items-center gap-2 text-xs font-bold text-emerald-800 flex-shrink-0 animate-in fade-in">
                <CheckCircle2 className="w-4 h-4 text-emerald-600 flex-shrink-0" />
                <span>{editDetailsSuccessMsg}</span>
              </div>
            )}

            {/* Form */}
            <form onSubmit={handleSaveEditUserDetails} className="overflow-y-auto flex-1 pr-1 space-y-4 text-xs">
              {/* Section 1: Personal & Contact Information */}
              <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200 space-y-3">
                <h5 className="font-black text-slate-900 uppercase tracking-wider text-[11px] flex items-center gap-1.5">
                  <Users className="w-3.5 h-3.5 text-blue-700" />
                  <span>1. Personal & Contact Information</span>
                </h5>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-[10px] font-black uppercase text-slate-600 mb-1">
                      Account Holder Full Legal Name *
                    </label>
                    <input
                      type="text"
                      required
                      value={editUserName}
                      onChange={(e) => setEditUserName(e.target.value)}
                      placeholder="e.g. Rahul Sharma"
                      className="w-full bg-white border border-slate-200 rounded-xl px-3 py-2 text-xs font-bold text-slate-900 focus:outline-none focus:border-blue-500"
                    />
                  </div>

                  <div>
                    <label className="block text-[10px] font-black uppercase text-slate-600 mb-1">
                      Registered Mobile Number *
                    </label>
                    <input
                      type="text"
                      required
                      value={editUserPhone}
                      onChange={(e) => setEditUserPhone(e.target.value)}
                      placeholder="+91 98300 12345"
                      className="w-full bg-white border border-slate-200 rounded-xl px-3 py-2 text-xs font-bold text-slate-900 focus:outline-none focus:border-blue-500"
                    />
                  </div>

                  <div>
                    <label className="block text-[10px] font-black uppercase text-slate-600 mb-1">
                      Email Address
                    </label>
                    <input
                      type="email"
                      value={editUserEmail}
                      onChange={(e) => setEditUserEmail(e.target.value)}
                      placeholder="customer@domain.com"
                      className="w-full bg-white border border-slate-200 rounded-xl px-3 py-2 text-xs font-bold text-slate-900 focus:outline-none focus:border-blue-500"
                    />
                  </div>

                  <div>
                    <label className="block text-[10px] font-black uppercase text-slate-600 mb-1">
                      Date of Birth
                    </label>
                    <input
                      type="text"
                      value={editUserDob}
                      onChange={(e) => setEditUserDob(e.target.value)}
                      placeholder="YYYY-MM-DD"
                      className="w-full bg-white border border-slate-200 rounded-xl px-3 py-2 text-xs font-bold text-slate-900 focus:outline-none focus:border-blue-500"
                    />
                  </div>

                  <div className="sm:col-span-2">
                    <label className="block text-[10px] font-black uppercase text-slate-600 mb-1">
                      Permanent / Residential Address
                    </label>
                    <input
                      type="text"
                      value={editUserAddress}
                      onChange={(e) => setEditUserAddress(e.target.value)}
                      placeholder="Street, City, District, State - PIN"
                      className="w-full bg-white border border-slate-200 rounded-xl px-3 py-2 text-xs font-bold text-slate-900 focus:outline-none focus:border-blue-500"
                    />
                  </div>
                </div>
              </div>

              {/* Section 2: Account & Banking Identifiers */}
              <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200 space-y-3">
                <h5 className="font-black text-slate-900 uppercase tracking-wider text-[11px] flex items-center gap-1.5">
                  <Landmark className="w-3.5 h-3.5 text-blue-700" />
                  <span>2. Core Banking Identifiers & Branch</span>
                </h5>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-[10px] font-black uppercase text-slate-600 mb-1">
                      CBS Account Number *
                    </label>
                    <input
                      type="text"
                      required
                      value={editUserAccountNumber}
                      onChange={(e) => setEditUserAccountNumber(e.target.value)}
                      placeholder="501004589211"
                      className="w-full bg-white border border-slate-200 rounded-xl px-3 py-2 text-xs font-mono font-bold text-slate-900 focus:outline-none focus:border-blue-500"
                    />
                  </div>

                  <div>
                    <label className="block text-[10px] font-black uppercase text-slate-600 mb-1">
                      Account Type
                    </label>
                    <select
                      value={editUserAccountType}
                      onChange={(e) => setEditUserAccountType(e.target.value as any)}
                      className="w-full bg-white border border-slate-200 rounded-xl px-3 py-2 text-xs font-bold text-slate-900 focus:outline-none focus:border-blue-500"
                    >
                      <option value="SAVINGS">SAVINGS (Standard Savings Account)</option>
                      <option value="CURRENT">CURRENT (Business Commercial Account)</option>
                      <option value="KCC_FARMER">KCC_FARMER (Kisan Credit Card)</option>
                      <option value="PENSION">PENSION (Government / Retired Pensioner)</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-[10px] font-black uppercase text-slate-600 mb-1">
                      Home Branch
                    </label>
                    <select
                      value={editUserBranch}
                      onChange={(e) => setEditUserBranch(e.target.value)}
                      className="w-full bg-white border border-slate-200 rounded-xl px-3 py-2 text-xs font-bold text-slate-900 focus:outline-none focus:border-blue-500"
                    >
                      {BRANCH_OPTIONS.map((branch) => (
                        <option key={branch} value={branch}>
                          {branch}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="block text-[10px] font-black uppercase text-slate-600 mb-1">
                      Branch IFSC Code
                    </label>
                    <input
                      type="text"
                      value={editUserIfscCode}
                      onChange={(e) => setEditUserIfscCode(e.target.value)}
                      placeholder="UTIB000001"
                      className="w-full bg-white border border-slate-200 rounded-xl px-3 py-2 text-xs font-mono font-bold text-slate-900 focus:outline-none focus:border-blue-500"
                    />
                  </div>

                  <div>
                    <label className="block text-[10px] font-black uppercase text-slate-600 mb-1">
                      Customer CIF Number
                    </label>
                    <input
                      type="text"
                      value={editUserCifNumber}
                      onChange={(e) => setEditUserCifNumber(e.target.value)}
                      placeholder="CIF8891002"
                      className="w-full bg-white border border-slate-200 rounded-xl px-3 py-2 text-xs font-mono font-bold text-slate-900 focus:outline-none focus:border-blue-500"
                    />
                  </div>

                  <div>
                    <label className="block text-[10px] font-black uppercase text-slate-600 mb-1">
                      UPI ID / VPA
                    </label>
                    <input
                      type="text"
                      value={editUserUpiId}
                      onChange={(e) => setEditUserUpiId(e.target.value)}
                      placeholder="name@axisbank"
                      className="w-full bg-white border border-slate-200 rounded-xl px-3 py-2 text-xs font-mono font-bold text-slate-900 focus:outline-none focus:border-blue-500"
                    />
                  </div>
                </div>
              </div>

              {/* Section 3: Regulatory Identity & KYC Status */}
              <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200 space-y-3">
                <h5 className="font-black text-slate-900 uppercase tracking-wider text-[11px] flex items-center gap-1.5">
                  <ShieldCheck className="w-3.5 h-3.5 text-blue-700" />
                  <span>3. Regulatory KYC & Identity Documents</span>
                </h5>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-[10px] font-black uppercase text-slate-600 mb-1">
                      UIDAI Aadhaar Number
                    </label>
                    <input
                      type="text"
                      value={editUserAadhaar}
                      onChange={(e) => setEditUserAadhaar(e.target.value)}
                      placeholder="XXXX-XXXX-1234"
                      className="w-full bg-white border border-slate-200 rounded-xl px-3 py-2 text-xs font-mono font-bold text-slate-900 focus:outline-none focus:border-blue-500"
                    />
                  </div>

                  <div>
                    <label className="block text-[10px] font-black uppercase text-slate-600 mb-1">
                      Income Tax PAN Number
                    </label>
                    <input
                      type="text"
                      value={editUserPan}
                      onChange={(e) => setEditUserPan(e.target.value.toUpperCase())}
                      placeholder="ABCDE1234F"
                      className="w-full bg-white border border-slate-200 rounded-xl px-3 py-2 text-xs font-mono font-bold uppercase text-slate-900 focus:outline-none focus:border-blue-500"
                    />
                  </div>

                  <div>
                    <label className="block text-[10px] font-black uppercase text-slate-600 mb-1">
                      Central KYC (CKYC) Number
                    </label>
                    <input
                      type="text"
                      value={editUserCkyc}
                      onChange={(e) => setEditUserCkyc(e.target.value)}
                      placeholder="CKYC-2026-XXXXXXXX"
                      className="w-full bg-white border border-slate-200 rounded-xl px-3 py-2 text-xs font-mono font-bold text-slate-900 focus:outline-none focus:border-blue-500"
                    />
                  </div>

                  <div>
                    <label className="block text-[10px] font-black uppercase text-slate-600 mb-1">
                      KYC Compliance Status
                    </label>
                    <select
                      value={editUserKycStatus}
                      onChange={(e) => setEditUserKycStatus(e.target.value as any)}
                      className="w-full bg-white border border-slate-200 rounded-xl px-3 py-2 text-xs font-bold text-slate-900 focus:outline-none focus:border-blue-500"
                    >
                      <option value="verified">Verified (Approved & Compliant)</option>
                      <option value="pending">Pending (Pending Branch Review)</option>
                      <option value="rejected">Rejected (Flagged / Deficient)</option>
                    </select>
                  </div>

                  <div className="sm:col-span-2 pt-1">
                    <label className="flex items-center gap-2 p-2.5 bg-white rounded-xl border border-slate-200 cursor-pointer hover:bg-slate-50 transition">
                      <input
                        type="checkbox"
                        checked={editUserSeniorMode}
                        onChange={(e) => setEditUserSeniorMode(e.target.checked)}
                        className="w-4 h-4 text-blue-600 rounded border-slate-300 focus:ring-blue-500"
                      />
                      <div>
                        <span className="text-xs font-black text-slate-900 block">
                          Senior Citizen Easy-Access Mode
                        </span>
                        <span className="text-[10px] text-slate-500 font-bold">
                          Enables larger high-legibility fonts, voice guidance, and simplified navigation
                        </span>
                      </div>
                    </label>
                  </div>
                </div>
              </div>

              {/* Section 4: Audit Trail Note */}
              <div className="p-3 bg-amber-50 rounded-2xl border border-amber-200 space-y-1.5">
                <label className="block text-[10px] font-black uppercase text-amber-900">
                  Branch Officer Correction Audit Reason
                </label>
                <input
                  type="text"
                  value={editAuditReason}
                  onChange={(e) => setEditAuditReason(e.target.value)}
                  placeholder="e.g. Spelling error corrected in customer name per original Aadhaar card"
                  className="w-full bg-white border border-amber-300 rounded-xl px-3 py-2 text-xs font-bold text-slate-900 focus:outline-none focus:border-amber-500"
                />
                <p className="text-[9px] text-amber-700 font-semibold">
                  Changes will be written directly to the CBS core database and immediately reflected across all customer and teller interfaces.
                </p>
              </div>

              {/* Footer Actions */}
              <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-100 flex-shrink-0">
                <button
                  type="button"
                  onClick={() => {
                    setActionModalType(null);
                    setActiveActionUser(null);
                  }}
                  className="px-4 py-2.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-black uppercase tracking-wider transition"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2.5 rounded-xl bg-[#0a2540] hover:bg-[#071d34] text-white text-xs font-black uppercase tracking-wider shadow-md transition active:scale-95 flex items-center gap-1.5"
                >
                  <Check className="w-4 h-4 text-emerald-400" />
                  <span>Save Account Details</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* =========================================================================
          MODAL: SEND INDIVIDUAL CUSTOMER COMMUNICATION (SMS & MODERN BANKING EMAIL)
      ========================================================================= */}
      {actionModalType === 'SEND_COMMUNICATION' && activeActionUser && (
        <div className="fixed inset-0 z-60 bg-slate-950/80 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 overflow-y-auto animate-in fade-in">
          <div className="w-full max-w-3xl bg-white rounded-3xl p-5 sm:p-6 border border-slate-200 shadow-2xl space-y-4 my-auto max-h-[94vh] flex flex-col animate-in zoom-in-95">
            {/* Header */}
            <div className="flex items-center justify-between border-b border-slate-100 pb-3 flex-shrink-0">
              <div className="flex items-center gap-3">
                <div className="p-2.5 rounded-2xl bg-purple-100 text-purple-700 shadow-2xs">
                  <Mail className="w-6 h-6" />
                </div>
                <div>
                  <h4 className="text-sm sm:text-base font-black uppercase tracking-wider text-slate-900 flex items-center gap-2">
                    <span>Send SMS & Email to Customer</span>
                    <span className="text-[10px] font-black uppercase tracking-wider bg-purple-100 text-purple-800 px-2 py-0.5 rounded-full">
                      Hostinger SMTP SSL
                    </span>
                  </h4>
                  <p className="text-[11px] text-slate-500 font-bold">
                    Recipient: <span className="text-slate-900 font-black">{activeActionUser.name}</span> • A/C {activeActionUser.accountNumber} • CIF {activeActionUser.cifNumber || 'N/A'}
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => {
                  setActionModalType(null);
                  setActiveActionUser(null);
                  setCommStatusMsg(null);
                }}
                className="p-1.5 rounded-full bg-slate-100 text-slate-500 hover:text-slate-900 transition"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Error or Success Alerts */}
            {commStatusMsg && (
              <div
                className={`p-3 rounded-2xl flex items-center gap-2 text-xs font-bold flex-shrink-0 animate-in fade-in ${
                  commStatusMsg.type === 'success'
                    ? 'bg-emerald-50 border border-emerald-200 text-emerald-800'
                    : 'bg-red-50 border border-red-200 text-red-700'
                }`}
              >
                {commStatusMsg.type === 'success' ? (
                  <CheckCircle2 className="w-4 h-4 text-emerald-600 flex-shrink-0" />
                ) : (
                  <AlertTriangle className="w-4 h-4 text-red-600 flex-shrink-0" />
                )}
                <span>{commStatusMsg.text}</span>
              </div>
            )}

            <form onSubmit={handleSendIndividualCommunication} className="flex-1 overflow-y-auto space-y-4 pr-1">
              {/* Channel Selector */}
              <div>
                <label className="block text-[11px] font-black uppercase tracking-wider text-slate-700 mb-1.5">
                  1. Dispatch Channel
                </label>
                <div className="grid grid-cols-3 gap-2">
                  {[
                    { id: 'BOTH', label: 'SMS & Email (Both)', icon: Send, desc: 'Highest Deliverability' },
                    { id: 'EMAIL', label: 'Email Only', icon: Mail, desc: 'Modern Banking Template' },
                    { id: 'SMS', label: 'SMS Alert Only', icon: Smartphone, desc: 'Real-Time Mobile SMS' },
                  ].map((ch) => {
                    const Icon = ch.icon;
                    const isSelected = commChannel === ch.id;
                    return (
                      <button
                        key={ch.id}
                        type="button"
                        onClick={() => setCommChannel(ch.id as any)}
                        className={`p-2.5 rounded-2xl border text-left transition flex flex-col justify-between ${
                          isSelected
                            ? 'bg-[#0a2540] border-[#0a2540] text-white shadow-md'
                            : 'bg-slate-50 border-slate-200 text-slate-700 hover:bg-slate-100'
                        }`}
                      >
                        <div className="flex items-center gap-1.5 mb-1">
                          <Icon className={`w-3.5 h-3.5 ${isSelected ? 'text-amber-400' : 'text-slate-500'}`} />
                          <span className="text-xs font-black uppercase tracking-wider">{ch.label}</span>
                        </div>
                        <span className={`text-[10px] font-semibold ${isSelected ? 'text-slate-300' : 'text-slate-400'}`}>
                          {ch.desc}
                        </span>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Template Presets */}
              <div>
                <label className="block text-[11px] font-black uppercase tracking-wider text-slate-700 mb-1.5 flex items-center justify-between">
                  <span>2. Quick Advisory Presets</span>
                  <span className="text-[10px] text-slate-400 font-bold lowercase">Click to auto-populate message</span>
                </label>
                <div className="flex items-center gap-1.5 flex-wrap">
                  {[
                    { id: 'CUSTOM', label: 'Custom Notice' },
                    { id: 'KYC', label: 'Re-KYC Notice' },
                    { id: 'SECURITY', label: 'Security Warning' },
                    { id: 'BALANCE', label: 'Statement / Balance' },
                    { id: 'WELCOME', label: 'Welcome Kit' },
                    { id: 'AGRI', label: 'Kisan / Agri-Credit' },
                  ].map((p) => (
                    <button
                      key={p.id}
                      type="button"
                      onClick={() => handleSelectCommPreset(p.id as any)}
                      className={`px-3 py-1.5 rounded-xl text-xs font-black uppercase tracking-wider transition border ${
                        commPreset === p.id
                          ? 'bg-purple-100 text-purple-900 border-purple-300 font-black'
                          : 'bg-slate-50 text-slate-600 border-slate-200 hover:bg-slate-100'
                      }`}
                    >
                      {p.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* Recipient Details Overrides */}
              <div className="bg-slate-50 border border-slate-200 rounded-2xl p-3.5 space-y-3">
                <span className="text-[10px] font-black uppercase tracking-wider text-slate-500 block">
                  3. Verified Recipient CBS Coordinates
                </span>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                  <div>
                    <label className="block text-[10px] font-black uppercase text-slate-600 mb-1">
                      Customer Legal Name
                    </label>
                    <input
                      type="text"
                      value={commRecipientName}
                      onChange={(e) => setCommRecipientName(e.target.value)}
                      className="w-full bg-white border border-slate-200 rounded-xl px-3 py-2 text-xs font-bold text-slate-900 focus:outline-none focus:border-purple-500"
                    />
                  </div>

                  <div>
                    <label className="block text-[10px] font-black uppercase text-slate-600 mb-1">
                      CBS Account Number
                    </label>
                    <input
                      type="text"
                      value={commRecipientAccount}
                      onChange={(e) => setCommRecipientAccount(e.target.value)}
                      className="w-full bg-white border border-slate-200 rounded-xl px-3 py-2 text-xs font-mono font-bold text-slate-900 focus:outline-none focus:border-purple-500"
                    />
                  </div>

                  <div>
                    <label className="block text-[10px] font-black uppercase text-slate-600 mb-1">
                      Registered Mobile Number (for SMS)
                    </label>
                    <input
                      type="text"
                      value={commRecipientPhone}
                      onChange={(e) => setCommRecipientPhone(e.target.value)}
                      placeholder="+91 98765 43210"
                      className="w-full bg-white border border-slate-200 rounded-xl px-3 py-2 text-xs font-mono font-bold text-slate-900 focus:outline-none focus:border-purple-500"
                    />
                  </div>

                  <div>
                    <label className="block text-[10px] font-black uppercase text-slate-600 mb-1 flex items-center justify-between">
                      <span>Registered Email Address (for Email)</span>
                      <span className="text-[9px] text-purple-700 font-bold lowercase">from: support@axisbank.com</span>
                    </label>
                    <input
                      type="email"
                      value={commRecipientEmail}
                      onChange={(e) => setCommRecipientEmail(e.target.value)}
                      placeholder="customer@domain.com"
                      className="w-full bg-white border border-slate-200 rounded-xl px-3 py-2 text-xs font-bold text-slate-900 focus:outline-none focus:border-purple-500"
                    />
                  </div>
                </div>
              </div>

              {/* Subject & Title */}
              <div className="space-y-3">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-[10px] font-black uppercase text-slate-700 mb-1">
                      Email Subject Line
                    </label>
                    <input
                      type="text"
                      required
                      value={commSubject}
                      onChange={(e) => setCommSubject(e.target.value)}
                      placeholder="e.g. Official Notice from Axis Bank CC VIP"
                      className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs font-bold text-slate-900 focus:outline-none focus:border-purple-500"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] font-black uppercase text-slate-700 mb-1">
                      Email Header Badge / Sub-Title
                    </label>
                    <input
                      type="text"
                      value={commTitle}
                      onChange={(e) => setCommTitle(e.target.value)}
                      placeholder="e.g. Official Institutional Notice"
                      className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs font-bold text-slate-900 focus:outline-none focus:border-purple-500"
                    />
                  </div>
                </div>

                {/* Message Body */}
                <div>
                  <div className="flex items-center justify-between mb-1">
                    <label className="text-[10px] font-black uppercase text-slate-700">
                      Message Content
                    </label>
                    <span className="text-[10px] font-bold text-slate-400">
                      Length: {commMessage.length} chars • {commMessage.split(/\s+/).filter(Boolean).length} words
                    </span>
                  </div>
                  <textarea
                    rows={4}
                    required
                    value={commMessage}
                    onChange={(e) => setCommMessage(e.target.value)}
                    placeholder="Type the official notification text to be delivered..."
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl p-3 text-xs font-medium text-slate-900 focus:outline-none focus:border-purple-500 leading-relaxed font-sans"
                  />
                </div>
              </div>

              {/* Preview Toggle */}
              <div>
                <button
                  type="button"
                  onClick={() => setCommShowPreview(!commShowPreview)}
                  className="flex items-center gap-1.5 text-xs font-black uppercase tracking-wider text-purple-700 hover:text-purple-900 underline"
                >
                  <Eye className="w-3.5 h-3.5" />
                  <span>{commShowPreview ? 'Hide Modern Banking Email Preview' : 'Show Modern Banking Email Preview'}</span>
                </button>

                {commShowPreview && (
                  <div className="mt-3 p-4 bg-slate-100 rounded-2xl border border-slate-200 animate-in fade-in">
                    <div className="max-w-lg mx-auto bg-white rounded-2xl shadow-md border border-slate-200 overflow-hidden text-slate-800 text-xs">
                      {/* Email Header */}
                      <div className="bg-gradient-to-r from-[#4E061E] via-[#861F41] to-[#97144D] p-5 text-center text-white border-b-2 border-amber-400">
                        <div className="inline-block px-2.5 py-0.5 rounded-full bg-black/30 text-amber-300 border border-amber-400/30 text-[9px] font-extrabold uppercase tracking-wider mb-2">
                          🔒 RBI Scheduled Bank • 256-Bit SSL Encrypted
                        </div>
                        <div className="flex justify-center mb-1.5">
                          <AxisBankLogo size="md" showText={false} />
                        </div>
                        <h5 className="text-sm font-black uppercase tracking-wider text-white m-0">
                          Axis Bank CC VIP
                        </h5>
                        <p className="text-[10px] text-amber-200 font-bold m-0 mt-0.5 uppercase tracking-wide">
                          Priority Mobile Banking &amp; Corporate VIP Portal
                        </p>
                        <div className="mt-2">
                          <span className="inline-block px-3 py-0.5 rounded-full bg-amber-400 text-slate-950 text-[9px] font-black uppercase tracking-wider shadow-xs">
                            {commTitle || '★ Official Notice ★'}
                          </span>
                        </div>
                      </div>

                      {/* Email Body */}
                      <div className="p-4 space-y-3">
                        <p className="font-bold text-slate-900 text-xs">
                          Dear {commRecipientName || 'Valued Customer'},
                        </p>
                        <div className="bg-slate-50 p-3 rounded-xl border border-slate-200 text-xs leading-relaxed text-slate-700 whitespace-pre-wrap font-sans">
                          {commMessage || 'Your message preview will appear here.'}
                        </div>

                        <div className="border border-slate-200 rounded-xl overflow-hidden text-[11px]">
                          <div className="flex justify-between p-1.5 bg-slate-50 border-b border-slate-200">
                            <span className="text-slate-500 font-bold uppercase text-[9px]">Account Number</span>
                            <span className="font-mono font-bold text-slate-900">{commRecipientAccount || '•••• •••• ••••'}</span>
                          </div>
                          <div className="flex justify-between p-1.5 bg-white">
                            <span className="text-slate-500 font-bold uppercase text-[9px]">Authority</span>
                            <span className="font-bold text-slate-900">Branch Officer Administration, Axis Bank CC VIP</span>
                          </div>
                        </div>

                        <div className="p-2.5 bg-amber-50 border border-amber-200 rounded-xl text-[10px] text-amber-900 leading-normal">
                          <strong>⚠️ Compliance Notice:</strong> Axis Bank never asks for your MPIN, Password, or OTP. For support call 1860-419-5555.
                        </div>
                      </div>

                      {/* Email Footer */}
                      <div className="bg-slate-900 text-slate-400 p-3 text-center text-[10px] space-y-0.5">
                        <p className="font-bold text-white">Axis Bank Ltd. (Axis Bank CC VIP)</p>
                        <p className="text-[9px]">Corporate Office: Axis House, C-2, Wadia International Centre, Worli, Mumbai - 400025</p>
                        <p className="text-[9px] text-amber-400">Helpline: 1860-419-5555 • Email: vip.support@axisbank.com</p>
                      </div>
                    </div>
                  </div>
                )}
              </div>

              {/* Footer Actions */}
              <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-100 flex-shrink-0">
                <button
                  type="button"
                  onClick={() => {
                    setActionModalType(null);
                    setActiveActionUser(null);
                    setCommStatusMsg(null);
                  }}
                  className="px-4 py-2.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-black uppercase tracking-wider transition"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={commIsSending}
                  className="px-5 py-2.5 rounded-xl bg-purple-700 hover:bg-purple-800 disabled:bg-purple-400 text-white text-xs font-black uppercase tracking-wider shadow-md transition active:scale-95 flex items-center gap-1.5"
                >
                  <Send className={`w-3.5 h-3.5 ${commIsSending ? 'animate-bounce' : ''}`} />
                  <span>
                    {commIsSending
                      ? 'Dispatching Communication...'
                      : commChannel === 'BOTH'
                      ? 'Dispatch SMS & Email'
                      : commChannel === 'EMAIL'
                      ? 'Dispatch Modern Email'
                      : 'Dispatch SMS Alert'}
                  </span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* =========================================================================
          MODAL: ISSUE CUSTOMER ID & NETBANKING CREDENTIALS KIT
      ========================================================================= */}
      {actionModalType === 'ISSUE_NETBANKING' && activeActionUser && (
        <div className="fixed inset-0 z-60 bg-slate-950/80 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 overflow-y-auto animate-in fade-in">
          <div className="w-full max-w-xl bg-white rounded-3xl p-5 sm:p-6 border border-slate-200 shadow-2xl space-y-4 my-auto max-h-[92vh] flex flex-col">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3 flex-shrink-0">
              <div className="flex items-center gap-3">
                <div className="p-2.5 rounded-2xl bg-[#861F41] text-amber-300 shadow-sm">
                  <KeyRound className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="text-sm font-black text-slate-900 uppercase tracking-tight flex items-center gap-2">
                    <span>Issue Cust ID & NetBanking Details</span>
                    <span className="text-[9px] bg-amber-100 text-amber-900 border border-amber-300 px-2 py-0.5 rounded font-mono font-bold">
                      Axis VIP Kit
                    </span>
                  </h4>
                  <p className="text-[11px] text-slate-500 font-bold">
                    Recipient: <span className="text-slate-900 font-black">{activeActionUser.name}</span> • A/C: ••{activeActionUser.accountNumber?.slice(-4)} • IFSC: UTIB000001
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => {
                  setActionModalType(null);
                  setActiveActionUser(null);
                  setIssueStatusMsg(null);
                }}
                className="p-1.5 rounded-full bg-slate-100 text-slate-500 hover:text-slate-900 transition"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {issueStatusMsg && (
              <div
                className={`p-3 rounded-2xl text-xs font-black flex items-center gap-2 ${
                  issueStatusMsg.type === 'success'
                    ? 'bg-emerald-50 text-emerald-900 border border-emerald-200'
                    : 'bg-red-50 text-red-900 border border-red-200'
                }`}
              >
                {issueStatusMsg.type === 'success' ? (
                  <CheckCircle2 className="w-4 h-4 text-emerald-600 flex-shrink-0" />
                ) : (
                  <AlertCircle className="w-4 h-4 text-red-600 flex-shrink-0" />
                )}
                <span>{issueStatusMsg.text}</span>
              </div>
            )}

            <form onSubmit={handleConfirmIssueNetbanking} className="space-y-4 overflow-y-auto pr-1 flex-1">
              {/* Quick Regenerate & Copy Toolbar */}
              <div className="flex items-center justify-between bg-slate-50 p-3 rounded-2xl border border-slate-200">
                <span className="text-xs font-black uppercase tracking-wider text-slate-700">
                  CBS Digital Access Kit
                </span>
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={handleRegenerateNetbankingCreds}
                    className="px-2.5 py-1 rounded-xl bg-white border border-slate-200 text-[11px] font-black uppercase text-slate-700 hover:bg-slate-100 flex items-center gap-1 transition"
                    title="Generate fresh unique login ID and temporary password"
                  >
                    <RefreshCw className="w-3 h-3 text-[#861F41]" />
                    <span>Regenerate Credentials</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      const text = `AXIS BANK CC VIP NETBANKING KIT\nCustomer: ${activeActionUser.name}\nA/C: ${activeActionUser.accountNumber}\nIFSC: UTIB000001\nCust ID: ${issueCifNumber}\nLogin ID: ${issueNetbankingLoginId}\nTemp Password: ${issueNetbankingPassword}\nMPIN: ${issueMpin}\nHelpline: 1860-419-5555`;
                      navigator.clipboard.writeText(text);
                      setIssueCopiedField('ALL');
                      setTimeout(() => setIssueCopiedField(null), 2000);
                    }}
                    className="px-2.5 py-1 rounded-xl bg-[#861F41] text-amber-300 text-[11px] font-black uppercase flex items-center gap-1 transition active:scale-95 shadow-xs"
                  >
                    {issueCopiedField === 'ALL' ? (
                      <>
                        <Check className="w-3 h-3 text-amber-300" />
                        <span>Copied Kit!</span>
                      </>
                    ) : (
                      <>
                        <Copy className="w-3 h-3 text-amber-300" />
                        <span>Copy All Details</span>
                      </>
                    )}
                  </button>
                </div>
              </div>

              {/* Grid 1: Customer ID & NetBanking Login ID */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <div className="flex items-center justify-between mb-1">
                    <label className="text-[10px] font-black uppercase tracking-wider text-slate-600">
                      Customer ID (Cust ID / CIF)
                    </label>
                    <button
                      type="button"
                      onClick={() => {
                        navigator.clipboard.writeText(issueCifNumber);
                        setIssueCopiedField('CIF');
                        setTimeout(() => setIssueCopiedField(null), 1500);
                      }}
                      className="text-[10px] text-[#861F41] font-bold hover:underline"
                    >
                      {issueCopiedField === 'CIF' ? 'Copied' : 'Copy'}
                    </button>
                  </div>
                  <input
                    type="text"
                    required
                    value={issueCifNumber}
                    onChange={(e) => setIssueCifNumber(e.target.value.toUpperCase())}
                    placeholder="AXIS8891002"
                    className="w-full px-3 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-mono font-bold text-slate-900 focus:outline-none focus:border-[#861F41]"
                  />
                </div>

                <div>
                  <div className="flex items-center justify-between mb-1">
                    <label className="text-[10px] font-black uppercase tracking-wider text-slate-600">
                      NetBanking Login ID
                    </label>
                    <button
                      type="button"
                      onClick={() => {
                        navigator.clipboard.writeText(issueNetbankingLoginId);
                        setIssueCopiedField('LOGIN');
                        setTimeout(() => setIssueCopiedField(null), 1500);
                      }}
                      className="text-[10px] text-[#861F41] font-bold hover:underline"
                    >
                      {issueCopiedField === 'LOGIN' ? 'Copied' : 'Copy'}
                    </button>
                  </div>
                  <input
                    type="text"
                    required
                    value={issueNetbankingLoginId}
                    onChange={(e) => setIssueNetbankingLoginId(e.target.value)}
                    placeholder="axis.rajesh"
                    className="w-full px-3 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-mono font-bold text-slate-900 focus:outline-none focus:border-[#861F41]"
                  />
                </div>
              </div>

              {/* Grid 2: Temporary Password & 4-Digit MPIN */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <div className="flex items-center justify-between mb-1">
                    <label className="text-[10px] font-black uppercase tracking-wider text-slate-600">
                      Temporary Access Password
                    </label>
                    <button
                      type="button"
                      onClick={() => {
                        navigator.clipboard.writeText(issueNetbankingPassword);
                        setIssueCopiedField('PASS');
                        setTimeout(() => setIssueCopiedField(null), 1500);
                      }}
                      className="text-[10px] text-[#861F41] font-bold hover:underline"
                    >
                      {issueCopiedField === 'PASS' ? 'Copied' : 'Copy'}
                    </button>
                  </div>
                  <input
                    type="text"
                    required
                    value={issueNetbankingPassword}
                    onChange={(e) => setIssueNetbankingPassword(e.target.value)}
                    placeholder="Axis@2026"
                    className="w-full px-3 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-mono font-bold text-[#861F41] focus:outline-none focus:border-[#861F41]"
                  />
                </div>

                <div>
                  <label className="block text-[10px] font-black uppercase tracking-wider text-slate-600 mb-1">
                    4-Digit Security MPIN
                  </label>
                  <input
                    type="text"
                    maxLength={4}
                    required
                    value={issueMpin}
                    onChange={(e) => setIssueMpin(e.target.value.replace(/\D/g, ''))}
                    placeholder="1234"
                    className="w-full px-3 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-mono font-bold text-slate-900 focus:outline-none focus:border-[#861F41]"
                  />
                </div>
              </div>

              {/* Virtual Debit Card Assignment */}
              <div className="bg-slate-50 p-3.5 rounded-2xl border border-slate-200 space-y-2">
                <div className="flex items-center justify-between">
                  <label className="text-xs font-black uppercase tracking-wider text-slate-800 flex items-center gap-1.5">
                    <CreditCard className="w-3.5 h-3.5 text-[#861F41]" />
                    <span>Assigned Virtual Debit Card Category</span>
                  </label>
                  <span className="text-[10px] text-amber-700 font-bold bg-amber-100 px-2 py-0.5 rounded">
                    Instant Online Activation
                  </span>
                </div>

                <div className="grid grid-cols-2 gap-2 text-xs">
                  {[
                    { id: 'BURGUNDY_PRESTIGE', name: 'Burgundy Prestige', sub: '₹2,999 p.a. • VIP Comp' },
                    { id: 'TITANIUM_REWARDS', name: 'Titanium Rewards', sub: '₹499 p.a. • 3X Points' },
                    { id: 'MAGNUS_METAL', name: 'Magnus Metal Elite', sub: '₹9,999 p.a. • Luxury UHNW' },
                    { id: 'NEO_SHOPPING', name: 'Neo Shopping Card', sub: '₹0 • Lifetime Free' },
                  ].map((card) => (
                    <button
                      key={card.id}
                      type="button"
                      onClick={() => setIssueVirtualCardVariant(card.id as any)}
                      className={`p-2 rounded-xl border text-left transition ${
                        issueVirtualCardVariant === card.id
                          ? 'bg-[#861F41] border-[#861F41] text-white shadow-xs'
                          : 'bg-white border-slate-200 text-slate-800 hover:bg-slate-100'
                      }`}
                    >
                      <p className="font-black text-[11px] truncate">{card.name}</p>
                      <p className={`text-[10px] ${issueVirtualCardVariant === card.id ? 'text-amber-200' : 'text-slate-500'}`}>
                        {card.sub}
                      </p>
                    </button>
                  ))}
                </div>
              </div>

              {/* Dispatch Channels */}
              <div className="p-3 bg-slate-50 rounded-2xl border border-slate-200 space-y-2">
                <span className="text-[10px] font-black uppercase tracking-wider text-slate-600 block">
                  Automated Credentials Dispatch Channels
                </span>
                <div className="space-y-1.5 text-xs">
                  <label className="flex items-center gap-2 cursor-pointer font-bold text-slate-800">
                    <input
                      type="checkbox"
                      checked={issueDispatchEmail}
                      onChange={(e) => setIssueDispatchEmail(e.target.checked)}
                      className="rounded text-[#861F41] focus:ring-[#861F41]"
                    />
                    <span>
                      Dispatch Full NetBanking Kit & Virtual Card via Email ({activeActionUser.email || 'No email registered'})
                    </span>
                  </label>
                  <label className="flex items-center gap-2 cursor-pointer font-bold text-slate-800">
                    <input
                      type="checkbox"
                      checked={issueDispatchSms}
                      onChange={(e) => setIssueDispatchSms(e.target.checked)}
                      className="rounded text-[#861F41] focus:ring-[#861F41]"
                    />
                    <span>
                      Dispatch High-Security SMS with Cust ID, Login ID & Temp Pass to ({activeActionUser.phone})
                    </span>
                  </label>
                </div>
              </div>

              <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => {
                    setActionModalType(null);
                    setActiveActionUser(null);
                  }}
                  className="px-4 py-2.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-black uppercase tracking-wider transition"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={issueIsSubmitting}
                  className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-[#861F41] to-[#580824] hover:from-[#700a2f] text-amber-300 text-xs font-black uppercase tracking-wider shadow-md transition active:scale-95 flex items-center gap-1.5 border border-amber-400/30"
                >
                  <KeyRound className="w-3.5 h-3.5 text-amber-400" />
                  <span>{issueIsSubmitting ? 'Issuing Credentials...' : 'Issue & Dispatch NetBanking Kit'}</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* =========================================================================
          MODAL: LIVE OUTBOX EMAIL HTML VIEWER
      ========================================================================= */}
      {commViewingEmailHtml && (
        <div className="fixed inset-0 z-70 bg-slate-950/80 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 overflow-y-auto animate-in fade-in">
          <div className="w-full max-w-2xl bg-white rounded-3xl p-5 border border-slate-200 shadow-2xl space-y-4 my-auto max-h-[92vh] flex flex-col">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div className="flex items-center gap-2">
                <Mail className="w-5 h-5 text-purple-700" />
                <h4 className="text-xs font-black uppercase tracking-wider text-slate-900">
                  Delivered Banking Email HTML Preview
                </h4>
              </div>
              <button
                type="button"
                onClick={() => setCommViewingEmailHtml(null)}
                className="p-1.5 rounded-full bg-slate-100 text-slate-500 hover:text-slate-900"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
            <div className="flex-1 overflow-y-auto border border-slate-200 rounded-2xl bg-slate-100 p-2">
              <iframe
                title="Email Preview"
                srcDoc={commViewingEmailHtml}
                className="w-full h-[600px] border-none rounded-xl bg-white"
              />
            </div>
          </div>
        </div>
      )}
      {actionModalType === 'SERVICES' && activeActionUser && (
        <div className="fixed inset-0 z-60 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-4 animate-in fade-in">
          <div className="w-full max-w-md bg-white rounded-3xl p-5 border border-slate-200 shadow-2xl space-y-4 animate-in zoom-in-95">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div>
                <h4 className="text-xs font-black uppercase tracking-wider text-slate-900 flex items-center gap-1.5">
                  <Sliders className="w-4 h-4 text-blue-700" />
                  <span>Configure Services for {activeActionUser.name}</span>
                </h4>
                <p className="text-[11px] text-slate-500 font-bold">
                  Toggle individual corporate banking features for this account
                </p>
              </div>
              <button
                onClick={() => {
                  setActionModalType(null);
                  setActiveActionUser(null);
                }}
                className="p-1.5 rounded-full bg-slate-100 text-slate-500 hover:text-slate-900"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-2 max-h-[60vh] overflow-y-auto">
              {[
                { key: 'upiEnabled', label: 'UPI Payments & QR Code Scan', desc: 'Scan any merchant QR and pay via VPA' },
                { key: 'upiLiteEnabled', label: 'UPI Lite (PIN-less Offline)', desc: 'Small ticket payments up to ₹500 without PIN' },
                { key: 'walletEnabled', label: 'Digital Business Wallet', desc: 'Store cash balances in digital wallet' },
                { key: 'soundboxEnabled', label: 'Multilingual Soundbox TTS', desc: 'Real-time audio alert on inward transfers' },
                { key: 'biometricsEnabled', label: 'Biometric Touch / Face ID', desc: 'Instant authentication with biometric limit' },
                { key: 'termDepositEnabled', label: 'High-Yield Fixed Deposits', desc: 'VIP FD booking up to 8.2% p.a.' },
                { key: 'kccLoanEnabled', label: 'Commercial & Priority Credit Subsidies', desc: 'VIP enterprise soft loan limits' },
                { key: 'internationalTxEnabled', label: 'Cross-Border Inward Remittance', desc: 'Receive funds from foreign banking partners' },
                { key: 'smsAlertsEnabled', label: 'Instant SMS & WhatsApp Alerts', desc: 'Real-time ledger updates to registered mobile' },
              ].map((svc) => {
                const svcs = activeActionUser.services || DEFAULT_SERVICES;
                const isEnabled = (svcs as any)[svc.key];
                return (
                  <div
                    key={svc.key}
                    className="p-3 bg-slate-50 rounded-xl border border-slate-200 flex items-center justify-between gap-2"
                  >
                    <div>
                      <p className="text-xs font-black text-slate-900">{svc.label}</p>
                      <p className="text-[10px] text-slate-500 font-bold">{svc.desc}</p>
                    </div>

                    <button
                      onClick={() =>
                        onToggleUserService(
                          activeActionUser.id,
                          svc.key as keyof UserServices,
                          !isEnabled
                        )
                      }
                      className={`px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-wider transition ${
                        isEnabled
                          ? 'bg-emerald-600 text-white shadow-2xs'
                          : 'bg-slate-200 text-slate-600'
                      }`}
                    >
                      {isEnabled ? 'Enabled' : 'Disabled'}
                    </button>
                  </div>
                );
              })}
            </div>

            <button
              onClick={() => {
                setActionModalType(null);
                setActiveActionUser(null);
              }}
              className="w-full py-2.5 rounded-xl bg-[#0a2540] text-white text-xs font-black uppercase tracking-wider shadow-sm"
            >
              Done
            </button>
          </div>
        </div>
      )}

      {/* -------------------------------------------------------------------
          REJECTION MODAL FOR PENDING APPROVALS
      ------------------------------------------------------------------- */}
      {rejectionModalTx && (
        <div className="fixed inset-0 z-60 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl p-5 max-w-md w-full border border-slate-200 shadow-2xl space-y-4 animate-in zoom-in-95">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div className="flex items-center gap-2">
                <div className="p-2 rounded-xl bg-red-100 text-red-700">
                  <XCircle className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="text-sm font-black text-slate-900">Reject & Refund Transfer</h4>
                  <p className="text-[11px] text-slate-500 font-bold">
                    Ref: {rejectionModalTx.utrNumber || rejectionModalTx.id}
                  </p>
                </div>
              </div>
              <button
                onClick={() => setRejectionModalTx(null)}
                className="p-1 rounded-lg hover:bg-slate-100 text-slate-400"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="p-3 bg-red-50 rounded-2xl border border-red-200 space-y-1 text-xs">
              <div className="flex justify-between font-bold">
                <span className="text-red-800">Amount to Refund:</span>
                <span className="font-mono font-black text-red-950">
                  ₹{rejectionModalTx.amount.toLocaleString('en-IN', { minimumFractionDigits: 2 })}
                </span>
              </div>
              <div className="flex justify-between text-[11px] text-red-700">
                <span>Destination:</span>
                <span className="font-bold">{rejectionModalTx.beneficiaryName || rejectionModalTx.recipient}</span>
              </div>
              <p className="text-[10px] text-red-600 font-semibold pt-1">
                The debited funds will be reversed and credited back to the customer's savings account immediately.
              </p>
            </div>

            <div>
              <label className="text-xs font-black text-slate-700 uppercase tracking-wider block mb-1">
                Reason for Rejection / Return Reason *
              </label>
              <select
                value={rejectionReasonInput}
                onChange={(e) => setRejectionReasonInput(e.target.value)}
                className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs font-bold text-slate-900 focus:outline-none focus:border-red-500 mb-2"
              >
                <option value="Recipient account verification mismatch">Recipient account verification mismatch</option>
                <option value="Invalid / Inactive beneficiary IFSC code">Invalid / Inactive beneficiary IFSC code</option>
                <option value="NPCI UPI VPA address rejected by destination PSP">NPCI UPI VPA address rejected by destination PSP</option>
                <option value="Beneficiary credit limit reached">Beneficiary credit limit reached</option>
                <option value="Suspicious transaction flagged by fraud monitoring">Suspicious transaction flagged by fraud monitoring</option>
                <option value="Customer request for stop clearance">Customer request for stop clearance</option>
              </select>

              <input
                type="text"
                placeholder="Or type custom rejection reason..."
                value={rejectionReasonInput}
                onChange={(e) => setRejectionReasonInput(e.target.value)}
                className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs font-bold text-slate-900 focus:outline-none focus:border-red-500"
              />
            </div>

            <div className="flex items-center gap-2 pt-1">
              <button
                type="button"
                onClick={() => setRejectionModalTx(null)}
                className="flex-1 py-2.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-black uppercase tracking-wider transition"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={() => {
                  if (onRejectTransaction && rejectionModalTx) {
                    onRejectTransaction(rejectionModalTx.id, rejectionReasonInput);
                    setApprovalSuccessMsg(
                      `Transaction ${rejectionModalTx.utrNumber || rejectionModalTx.id} rejected and ₹${rejectionModalTx.amount.toLocaleString('en-IN')} refunded to sender.`
                    );
                    setRejectionModalTx(null);
                    setTimeout(() => setApprovalSuccessMsg(null), 4000);
                  }
                }}
                className="flex-1 py-2.5 rounded-xl bg-red-600 hover:bg-red-700 text-white text-xs font-black uppercase tracking-wider transition shadow-sm active:scale-95"
              >
                Confirm Rejection & Refund
              </button>
            </div>
          </div>
        </div>
      )}

      {/* -------------------------------------------------------------------
          SET / RESET MPIN MODAL (Admin override for customer 4-digit PIN)
      ------------------------------------------------------------------- */}
      {mpinModalUser && (
        <div className="fixed inset-0 z-60 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl p-5 max-w-sm w-full border border-slate-200 shadow-2xl space-y-4 animate-in zoom-in-95">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div className="flex items-center gap-2">
                <div className="p-2 rounded-xl bg-amber-100 text-amber-900">
                  <KeyRound className="w-5 h-5 text-amber-700" />
                </div>
                <div>
                  <h4 className="text-sm font-black text-slate-900">Set Customer MPIN</h4>
                  <p className="text-[11px] text-slate-500 font-bold">{mpinModalUser.name}</p>
                </div>
              </div>
              <button
                onClick={() => {
                  setMpinModalUser(null);
                  setAdminMpinMsg('');
                }}
                className="p-1 rounded-lg hover:bg-slate-100 text-slate-400"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="bg-slate-50 p-3 rounded-2xl border border-slate-200 text-xs space-y-1">
              <div className="flex justify-between">
                <span className="text-slate-500 font-bold">Account:</span>
                <span className="font-mono font-black text-slate-800">{mpinModalUser.accountNumber}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500 font-bold">Current MPIN:</span>
                <span className="font-mono font-black text-amber-800 bg-amber-100 px-2 py-0.5 rounded">
                  {mpinModalUser.mpin || '1234'}
                </span>
              </div>
            </div>

            {adminMpinMsg && (
              <div className="p-2.5 rounded-xl bg-emerald-50 text-emerald-800 border border-emerald-200 text-xs font-bold text-center">
                {adminMpinMsg}
              </div>
            )}

            <form
              onSubmit={(e) => {
                e.preventDefault();
                if (adminMpinInput.length !== 4 || !/^\d{4}$/.test(adminMpinInput)) {
                  setAdminMpinMsg('MPIN must be exactly 4 digits');
                  return;
                }
                if (onSetUserMpin) {
                  onSetUserMpin(mpinModalUser.id, adminMpinInput);
                  setAdminMpinMsg(`MPIN for ${mpinModalUser.name} updated to ${adminMpinInput}!`);
                  setTimeout(() => {
                    setMpinModalUser(null);
                    setAdminMpinMsg('');
                  }, 1400);
                }
              }}
              className="space-y-3"
            >
              <div>
                <label className="text-xs font-black text-slate-700 uppercase tracking-wider block mb-1">
                  New 4-Digit Security MPIN
                </label>
                <input
                  type="password"
                  maxLength={4}
                  inputMode="numeric"
                  value={adminMpinInput}
                  onChange={(e) => setAdminMpinInput(e.target.value.replace(/\D/g, ''))}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2.5 text-center text-lg font-mono font-black tracking-widest text-slate-900 focus:outline-none focus:border-[#0a2540]"
                  placeholder="4 Digits"
                  required
                />
              </div>

              <div className="flex items-center gap-2 pt-1">
                <button
                  type="button"
                  onClick={() => {
                    setMpinModalUser(null);
                    setAdminMpinMsg('');
                  }}
                  className="flex-1 py-2.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-black uppercase tracking-wider transition"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2.5 rounded-xl bg-[#0a2540] hover:bg-[#071d34] text-amber-300 text-xs font-black uppercase tracking-wider transition shadow-sm active:scale-95"
                >
                  Update MPIN
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* -------------------------------------------------------------------
          HOLD TRANSACTION MODAL
      ------------------------------------------------------------------- */}
      {holdModalTx && (
        <div className="fixed inset-0 z-60 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl p-5 max-w-md w-full border border-slate-200 shadow-2xl space-y-4 animate-in zoom-in-95">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div className="flex items-center gap-2">
                <div className="p-2 rounded-xl bg-orange-100 text-orange-800">
                  <PauseCircle className="w-5 h-5 text-orange-600" />
                </div>
                <div>
                  <h4 className="text-sm font-black text-slate-900">
                    {holdModalTx.status === 'HOLD' ? 'Update Hold Status' : 'Put Transaction on Hold'}
                  </h4>
                  <p className="text-[11px] text-slate-500 font-bold">
                    Ref: {holdModalTx.upiRefId || holdModalTx.id}
                  </p>
                </div>
              </div>
              <button
                onClick={() => setHoldModalTx(null)}
                className="p-1 rounded-lg hover:bg-slate-100 text-slate-400"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="p-3 bg-orange-50 rounded-2xl border border-orange-200 space-y-1 text-xs">
              <div className="flex justify-between font-bold">
                <span className="text-orange-900">Transaction Amount:</span>
                <span className="font-mono font-black text-orange-950">
                  ₹{holdModalTx.amount.toLocaleString('en-IN', { minimumFractionDigits: 2 })}
                </span>
              </div>
              <div className="flex justify-between text-[11px] text-orange-800">
                <span>Beneficiary:</span>
                <span className="font-bold">{holdModalTx.beneficiaryName || holdModalTx.title}</span>
              </div>
              <p className="text-[10px] text-orange-700 font-semibold pt-1">
                While on HOLD, this transfer remains non-cleared. Funds will remain secured in escrow until approved or rejected.
              </p>
            </div>

            <div>
              <label className="text-xs font-black text-slate-700 uppercase tracking-wider block mb-1">
                Reason for Holding *
              </label>
              <select
                value={holdReasonInput}
                onChange={(e) => setHoldReasonInput(e.target.value)}
                className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs font-bold text-slate-900 focus:outline-none focus:border-orange-500 mb-2"
              >
                <option value="Under administrative review">Under administrative review</option>
                <option value="Awaiting beneficiary bank confirmation">Awaiting beneficiary bank confirmation</option>
                <option value="KYC document re-verification in progress">KYC document re-verification in progress</option>
                <option value="High-value transfer clearance threshold reached">High-value transfer clearance threshold reached</option>
                <option value="Branch officer inquiry requested">Branch officer inquiry requested</option>
              </select>

              <input
                type="text"
                placeholder="Or specify custom reason..."
                value={holdReasonInput}
                onChange={(e) => setHoldReasonInput(e.target.value)}
                className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs font-bold text-slate-900 focus:outline-none focus:border-orange-500"
              />
            </div>

            <div className="flex items-center gap-2 pt-1">
              <button
                type="button"
                onClick={() => setHoldModalTx(null)}
                className="flex-1 py-2.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-black uppercase tracking-wider transition"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={() => {
                  if (onHoldTransaction && holdModalTx) {
                    onHoldTransaction(holdModalTx.id, holdReasonInput);
                    setApprovalSuccessMsg(
                      `Transaction ${holdModalTx.upiRefId || holdModalTx.id} placed on HOLD.`
                    );
                    setHoldModalTx(null);
                    setTimeout(() => setApprovalSuccessMsg(null), 4000);
                  }
                }}
                className="flex-1 py-2.5 rounded-xl bg-orange-600 hover:bg-orange-700 text-white text-xs font-black uppercase tracking-wider transition shadow-sm active:scale-95"
              >
                Confirm Hold
              </button>
            </div>
          </div>
        </div>
      )}

      {/* -------------------------------------------------------------------
          VIEW CAPTURED QR CODE & VPA INSPECTION MODAL
      ------------------------------------------------------------------- */}
      {viewQrModalTx && (
        <div className="fixed inset-0 z-60 bg-black/70 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl p-6 max-w-lg w-full border border-slate-200 shadow-2xl space-y-4 animate-in zoom-in-95 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div className="flex items-center gap-2.5">
                <div className="p-2 rounded-xl bg-blue-100 text-blue-800">
                  <QrCode className="w-5 h-5 text-blue-700" />
                </div>
                <div>
                  <h4 className="text-sm font-black text-slate-900">Captured QR & VPA Audit</h4>
                  <p className="text-[11px] text-slate-500 font-bold">
                    Ref: {viewQrModalTx.upiRefId || viewQrModalTx.id}
                  </p>
                </div>
              </div>
              <button
                onClick={() => setViewQrModalTx(null)}
                className="p-1.5 rounded-lg hover:bg-slate-100 text-slate-400 hover:text-slate-600"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* QR Code display if available */}
            {viewQrModalTx.qrData && viewQrModalTx.qrData.startsWith('data:image') ? (
              <div className="text-center bg-slate-50 p-4 rounded-2xl border border-slate-200 space-y-2">
                <p className="text-[10px] font-black uppercase text-slate-500 tracking-wider">
                  Original Uploaded / Scanned QR
                </p>
                <div className="bg-white p-3 inline-block rounded-xl border border-slate-200 shadow-xs">
                  <img
                    src={viewQrModalTx.qrData}
                    alt="Captured QR Code"
                    className="w-48 h-48 object-contain mx-auto"
                  />
                </div>
              </div>
            ) : viewQrModalTx.qrData ? (
              <div className="bg-slate-50 p-3 rounded-2xl border border-slate-200 space-y-1 text-xs">
                <p className="text-[10px] font-black uppercase text-slate-500 tracking-wider">
                  Decoded QR Payload / URI
                </p>
                <div className="font-mono text-[11px] bg-white p-2.5 rounded-xl border border-slate-200 break-all text-slate-800 select-all">
                  {viewQrModalTx.qrData}
                </div>
              </div>
            ) : (
              <div className="bg-amber-50 p-3 rounded-2xl border border-amber-200 text-xs text-amber-900">
                <p className="font-bold">Manual VPA Entry (No direct QR image attached)</p>
              </div>
            )}

            {/* VPA and Destination Summary */}
            <div className="grid grid-cols-2 gap-3 text-xs">
              <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 space-y-0.5">
                <span className="text-[10px] font-black uppercase text-slate-400">Target VPA / Address</span>
                <p className="font-mono font-black text-blue-900 break-all">
                  {viewQrModalTx.recipientVpa || viewQrModalTx.scannerAddress || 'N/A'}
                </p>
              </div>
              <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 space-y-0.5">
                <span className="text-[10px] font-black uppercase text-slate-400">Payee Name</span>
                <p className="font-black text-slate-900 truncate">
                  {viewQrModalTx.beneficiaryName || viewQrModalTx.title}
                </p>
              </div>
              <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 space-y-0.5">
                <span className="text-[10px] font-black uppercase text-slate-400">Amount</span>
                <p className="font-sans font-black text-base text-[#0a2540]">
                  ₹{viewQrModalTx.amount.toLocaleString('en-IN', { minimumFractionDigits: 2 })}
                </p>
              </div>
              <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 space-y-0.5">
                <span className="text-[10px] font-black uppercase text-slate-400">Current Status</span>
                <p className="font-black text-slate-800 uppercase text-[11px]">
                  {viewQrModalTx.status}
                </p>
              </div>
            </div>

            {/* Quick Actions inside QR Inspection */}
            <div className="flex flex-wrap items-center justify-between gap-2 pt-2 border-t border-slate-100">
              <button
                type="button"
                onClick={() => {
                  const tx = viewQrModalTx;
                  setViewQrModalTx(null);
                  openEditModal(tx);
                }}
                className="px-3 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-black uppercase tracking-wider transition flex items-center gap-1"
              >
                <Edit3 className="w-3.5 h-3.5 text-slate-600" />
                <span>Edit Details</span>
              </button>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => {
                    const tx = viewQrModalTx;
                    setViewQrModalTx(null);
                    setHoldModalTx(tx);
                    setHoldReasonInput('QR VPA requires verification');
                  }}
                  className="px-3 py-2 rounded-xl bg-orange-50 hover:bg-orange-100 text-orange-800 border border-orange-200 text-xs font-black uppercase tracking-wider transition"
                >
                  Hold
                </button>

                <button
                  type="button"
                  onClick={() => {
                    const tx = viewQrModalTx;
                    setViewQrModalTx(null);
                    setRejectionModalTx(tx);
                    setRejectionReasonInput('Invalid QR code / VPA');
                  }}
                  className="px-3 py-2 rounded-xl bg-red-50 hover:bg-red-100 text-red-700 border border-red-200 text-xs font-black uppercase tracking-wider transition"
                >
                  Reject & Refund
                </button>

                <button
                  type="button"
                  onClick={() => {
                    if (onApproveTransaction) {
                      onApproveTransaction(viewQrModalTx.id);
                      setApprovalSuccessMsg(
                        `Transaction ${viewQrModalTx.upiRefId} marked as PAID and settled!`
                      );
                      setViewQrModalTx(null);
                      setTimeout(() => setApprovalSuccessMsg(null), 4000);
                    }
                  }}
                  className="px-4 py-2 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-black uppercase tracking-wider transition shadow-sm"
                >
                  Mark as Paid
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* -------------------------------------------------------------------
          EDIT TRANSACTION HISTORY MODAL (Admin Full CRUD Edit)
      ------------------------------------------------------------------- */}
      {editingTransaction && (
        <div className="fixed inset-0 z-60 bg-black/70 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl p-6 max-w-xl w-full border border-slate-200 shadow-2xl space-y-4 animate-in zoom-in-95 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div className="flex items-center gap-2.5">
                <div className="p-2 rounded-xl bg-amber-100 text-amber-900">
                  <Edit3 className="w-5 h-5 text-amber-700" />
                </div>
                <div>
                  <h4 className="text-sm font-black text-slate-900">Modify Transaction History</h4>
                  <p className="text-[11px] text-slate-500 font-bold">
                    Edit value, timestamp, status, or destination data in the database
                  </p>
                </div>
              </div>
              <button
                onClick={() => setEditingTransaction(null)}
                className="p-1.5 rounded-lg hover:bg-slate-100 text-slate-400 hover:text-slate-600"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form
              onSubmit={(e) => {
                e.preventDefault();
                handleSaveTransactionEdit();
              }}
              className="space-y-4"
            >
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                {/* Title */}
                <div>
                  <label className="font-black text-slate-700 uppercase tracking-wider block mb-1">
                    Title / Payee Name *
                  </label>
                  <input
                    type="text"
                    value={editFormData.title}
                    onChange={(e) => setEditFormData({ ...editFormData, title: e.target.value })}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs font-bold text-slate-900 focus:outline-none focus:border-[#0a2540]"
                    required
                  />
                </div>

                {/* Subtitle / Note */}
                <div>
                  <label className="font-black text-slate-700 uppercase tracking-wider block mb-1">
                    Subtitle / Remarks
                  </label>
                  <input
                    type="text"
                    value={editFormData.subTitle}
                    onChange={(e) => setEditFormData({ ...editFormData, subTitle: e.target.value })}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs font-bold text-slate-900 focus:outline-none focus:border-[#0a2540]"
                  />
                </div>

                {/* Amount */}
                <div>
                  <label className="font-black text-slate-700 uppercase tracking-wider block mb-1">
                    Amount (₹) *
                  </label>
                  <input
                    type="number"
                    step="0.01"
                    min="0"
                    value={editFormData.amount}
                    onChange={(e) => setEditFormData({ ...editFormData, amount: e.target.value })}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs font-mono font-bold text-slate-900 focus:outline-none focus:border-[#0a2540]"
                    required
                  />
                </div>

                {/* Timestamp */}
                <div>
                  <label className="font-black text-slate-700 uppercase tracking-wider block mb-1">
                    Timestamp / Date *
                  </label>
                  <input
                    type="text"
                    value={editFormData.timestamp}
                    onChange={(e) => setEditFormData({ ...editFormData, timestamp: e.target.value })}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs font-mono font-bold text-slate-900 focus:outline-none focus:border-[#0a2540]"
                    placeholder="e.g. 24 Oct 2024, 02:45 PM"
                    required
                  />
                </div>

                {/* Transaction Status */}
                <div>
                  <label className="font-black text-slate-700 uppercase tracking-wider block mb-1">
                    Status *
                  </label>
                  <select
                    value={editFormData.status}
                    onChange={(e) =>
                      setEditFormData({ ...editFormData, status: e.target.value as Transaction['status'] })
                    }
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs font-bold text-slate-900 focus:outline-none focus:border-[#0a2540]"
                  >
                    <option value="SUCCESS">SUCCESS (Completed / Paid)</option>
                    <option value="PROCESSED">PROCESSED (Awaiting Admin)</option>
                    <option value="HOLD">HOLD (On Hold)</option>
                    <option value="REJECTED">REJECTED (Rejected / Refunded)</option>
                    <option value="FAILED">FAILED (Failed)</option>
                    <option value="PENDING_APPROVAL">PENDING_APPROVAL</option>
                  </select>
                </div>

                {/* Type: Debit vs Credit */}
                <div>
                  <label className="font-black text-slate-700 uppercase tracking-wider block mb-1">
                    Direction (Type) *
                  </label>
                  <select
                    value={editFormData.type}
                    onChange={(e) =>
                      setEditFormData({ ...editFormData, type: e.target.value as 'credit' | 'debit' })
                    }
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs font-bold text-slate-900 focus:outline-none focus:border-[#0a2540]"
                  >
                    <option value="debit">Debit (-)</option>
                    <option value="credit">Credit (+)</option>
                  </select>
                </div>

                {/* Payment Mode */}
                <div>
                  <label className="font-black text-slate-700 uppercase tracking-wider block mb-1">
                    Payment Mode
                  </label>
                  <select
                    value={editFormData.paymentMode}
                    onChange={(e) =>
                      setEditFormData({
                        ...editFormData,
                        paymentMode: e.target.value as Transaction['paymentMode'],
                      })
                    }
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs font-bold text-slate-900 focus:outline-none focus:border-[#0a2540]"
                  >
                    <option value="SAVINGS_AC">SAVINGS_AC (Core Account)</option>
                    <option value="WALLET">WALLET (Digital Wallet)</option>
                    <option value="UPI_LITE">UPI_LITE (On-Device PIN-less)</option>
                    <option value="FD_ACCOUNT">FD_ACCOUNT (Fixed Deposit)</option>
                    <option value="QR_SCAN">QR_SCAN (UPI Dynamic Scanner)</option>
                  </select>
                </div>

                {/* UTR / Ref ID */}
                <div>
                  <label className="font-black text-slate-700 uppercase tracking-wider block mb-1">
                    UTR / Reference ID *
                  </label>
                  <input
                    type="text"
                    value={editFormData.upiRefId}
                    onChange={(e) => setEditFormData({ ...editFormData, upiRefId: e.target.value })}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs font-mono font-bold text-slate-900 focus:outline-none focus:border-[#0a2540]"
                    required
                  />
                </div>

                {/* Beneficiary Name */}
                <div>
                  <label className="font-black text-slate-700 uppercase tracking-wider block mb-1">
                    Beneficiary Name
                  </label>
                  <input
                    type="text"
                    value={editFormData.beneficiaryName}
                    onChange={(e) => setEditFormData({ ...editFormData, beneficiaryName: e.target.value })}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs font-bold text-slate-900 focus:outline-none focus:border-[#0a2540]"
                    placeholder="Beneficiary Account Holder"
                  />
                </div>

                {/* Beneficiary Account */}
                <div>
                  <label className="font-black text-slate-700 uppercase tracking-wider block mb-1">
                    Beneficiary Account Number
                  </label>
                  <input
                    type="text"
                    value={editFormData.beneficiaryAccount}
                    onChange={(e) => setEditFormData({ ...editFormData, beneficiaryAccount: e.target.value })}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs font-mono font-bold text-slate-900 focus:outline-none focus:border-[#0a2540]"
                    placeholder="Account Number"
                  />
                </div>

                {/* Recipient IFSC */}
                <div>
                  <label className="font-black text-slate-700 uppercase tracking-wider block mb-1">
                    Recipient Bank IFSC
                  </label>
                  <input
                    type="text"
                    value={editFormData.recipientIfsc}
                    onChange={(e) => setEditFormData({ ...editFormData, recipientIfsc: e.target.value.toUpperCase() })}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs font-mono font-bold text-slate-900 focus:outline-none focus:border-[#0a2540]"
                    placeholder="e.g. SBIN0001234"
                  />
                </div>

                {/* Recipient VPA */}
                <div>
                  <label className="font-black text-slate-700 uppercase tracking-wider block mb-1">
                    Recipient VPA / UPI ID
                  </label>
                  <input
                    type="text"
                    value={editFormData.recipientVpa}
                    onChange={(e) => setEditFormData({ ...editFormData, recipientVpa: e.target.value })}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs font-mono font-bold text-slate-900 focus:outline-none focus:border-[#0a2540]"
                    placeholder="e.g. merchant@upi"
                  />
                </div>
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setEditingTransaction(null)}
                  className="px-4 py-2.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-black uppercase tracking-wider transition"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-6 py-2.5 rounded-xl bg-[#0a2540] hover:bg-[#081e35] text-amber-300 text-xs font-black uppercase tracking-wider transition shadow-sm active:scale-95"
                >
                  Save Changes to Database
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

