import React from 'react';
import {
  PhoneCall,
  Send,
  Eye,
  Zap,
  Mic,
  Volume2,
  HelpCircle,
  ShieldCheck,
  ArrowRight,
  QrCode,
  Sparkles,
} from 'lucide-react';
import { UserProfile, LanguageCode } from '../types';
import { TRANSLATIONS } from '../i18n/translations';
import { speakSoundboxAlert } from '../utils/audioAlert';

interface SeniorModeViewProps {
  user: UserProfile;
  language: LanguageCode;
  onSendMoney: () => void;
  onScanQr: () => void;
  onPayElectricity: () => void;
  onOpenSahayak: () => void;
  onExitSeniorMode: () => void;
}

export const SeniorModeView: React.FC<SeniorModeViewProps> = ({
  user,
  language,
  onSendMoney,
  onScanQr,
  onPayElectricity,
  onOpenSahayak,
  onExitSeniorMode,
}) => {
  const t = TRANSLATIONS[language] || TRANSLATIONS.en;

  const handleReadBalance = () => {
    speakSoundboxAlert(
      user.savingsBalance,
      language,
      language === 'hi'
        ? `आपके Axis Bank CC VIP खाते में ${user.savingsBalance.toLocaleString('hi-IN')} रुपये उपलब्ध हैं।`
        : `Your Axis Bank CC VIP Account has ${user.savingsBalance.toLocaleString('en-IN')} Rupees available.`
    );
  };

  return (
    <div className="bg-amber-50/70 p-4 sm:p-6 rounded-3xl border-2 border-amber-400 text-slate-900 space-y-5 shadow-lg">
      {/* Top Banner */}
      <div className="flex items-center justify-between bg-amber-400 text-slate-950 p-3.5 rounded-2xl font-black shadow-xs">
        <div className="flex items-center gap-2">
          <ShieldCheck className="w-6 h-6 text-slate-950" />
          <span className="text-base font-black tracking-tight">
            {t.seniorMode} (सरल व बड़ा दृश्य)
          </span>
        </div>
        <button
          onClick={onExitSeniorMode}
          className="bg-slate-950 text-white px-3.5 py-1.5 rounded-xl text-xs font-black uppercase tracking-wider hover:bg-slate-800 transition shadow"
        >
          Standard Mode
        </button>
      </div>

      {/* Big Balance Box with Audio Readout */}
      <div className="bg-white border-2 border-slate-200 p-6 rounded-2xl shadow-sm space-y-3 text-center">
        <p className="text-xs font-black text-slate-500 uppercase tracking-widest">
          {t.savingsAc} (बैंक बैलेंस)
        </p>
        <p className="text-4xl sm:text-5xl font-black font-sans text-[#0a2540] tracking-tight">
          ₹{user.savingsBalance.toLocaleString('en-IN', { minimumFractionDigits: 2 })}
        </p>

        <button
          onClick={handleReadBalance}
          className="mt-2 inline-flex items-center gap-2 bg-amber-400 hover:bg-amber-500 text-slate-950 px-5 py-2.5 rounded-xl text-sm font-black uppercase tracking-wider shadow-sm transition active:scale-95"
        >
          <Volume2 className="w-5 h-5" />
          <span>बोलकर बैलेंस सुनें (Audio Readout)</span>
        </button>
      </div>

      {/* 4 Large Action Tiles for Elderly */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
        {/* 1. Send Money */}
        <button
          onClick={onSendMoney}
          className="p-5 rounded-2xl bg-[#0a2540] hover:bg-[#071d34] text-white flex items-center justify-between text-left shadow-md active:scale-98 transition border border-amber-400/30"
        >
          <div className="flex items-center gap-4">
            <div className="w-14 h-14 rounded-2xl bg-white/10 text-amber-300 flex items-center justify-center">
              <Send className="w-7 h-7 text-amber-300" />
            </div>
            <div>
              <p className="text-xl font-black tracking-tight text-white">{t.sendMoney}</p>
              <p className="text-xs text-amber-200 font-bold">घर या दुकान पर पैसे भेजें</p>
            </div>
          </div>
          <ArrowRight className="w-6 h-6 text-amber-300" />
        </button>

        {/* 2. Scan QR */}
        <button
          onClick={onScanQr}
          className="p-5 rounded-2xl bg-slate-900 hover:bg-slate-800 text-white flex items-center justify-between text-left shadow-md active:scale-98 transition"
        >
          <div className="flex items-center gap-4">
            <div className="w-14 h-14 rounded-2xl bg-white/10 text-white flex items-center justify-center">
              <QrCode className="w-7 h-7" />
            </div>
            <div>
              <p className="text-xl font-black tracking-tight">{t.scanQr}</p>
              <p className="text-xs text-slate-300 font-bold">दुकान का कोड स्कैन करें</p>
            </div>
          </div>
          <ArrowRight className="w-6 h-6" />
        </button>

        {/* 3. Pay Light Bill */}
        <button
          onClick={onPayElectricity}
          className="p-5 rounded-2xl bg-amber-400 hover:bg-amber-500 text-slate-950 flex items-center justify-between text-left shadow-md active:scale-98 transition"
        >
          <div className="flex items-center gap-4">
            <div className="w-14 h-14 rounded-2xl bg-slate-950/10 flex items-center justify-center">
              <Zap className="w-7 h-7 text-slate-950" />
            </div>
            <div>
              <p className="text-xl font-black tracking-tight">{t.electricity}</p>
              <p className="text-xs text-slate-800 font-bold">बिजली व पानी बिल भरें</p>
            </div>
          </div>
          <ArrowRight className="w-6 h-6 text-slate-950" />
        </button>

        {/* 4. Sahayak Companion */}
        <button
          onClick={onOpenSahayak}
          className="p-5 rounded-2xl bg-emerald-600 hover:bg-emerald-700 text-white flex items-center justify-between text-left shadow-md active:scale-98 transition"
        >
          <div className="flex items-center gap-4">
            <div className="w-14 h-14 rounded-2xl bg-white/20 flex items-center justify-center">
              <HelpCircle className="w-7 h-7 text-white" />
            </div>
            <div>
              <p className="text-xl font-black tracking-tight">{t.sahayakTitle}</p>
              <p className="text-xs text-emerald-100 font-bold">बोलकर सहायता लें (AI Companion)</p>
            </div>
          </div>
          <ArrowRight className="w-6 h-6" />
        </button>
      </div>

      {/* Emergency 24x7 Helpline Bar */}
      <div className="p-4 bg-rose-50 border-2 border-[#861F41]/30 rounded-2xl flex items-center justify-between">
        <div className="flex items-center gap-3">
          <PhoneCall className="w-7 h-7 text-[#861F41] animate-bounce" />
          <div>
            <p className="font-black text-sm text-slate-900">
              Axis Bank 24x7 CC VIP सहायता (Helpline)
            </p>
            <p className="text-xs text-slate-600 font-bold">
              किसी भी समस्या या फ्रॉड के लिए सीधे फोन मिलाएं
            </p>
          </div>
        </div>
        <a
          href="tel:18604195555"
          className="bg-[#861F41] hover:bg-[#580824] text-white px-4 py-2.5 rounded-xl font-black uppercase tracking-wider text-xs shadow-md transition whitespace-nowrap"
        >
          1860-419-5555
        </a>
      </div>
    </div>
  );
};
