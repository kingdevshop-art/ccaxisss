import React, { useState } from 'react';
import {
  Eye,
  EyeOff,
  Send,
  QrCode,
  BookOpen,
  Sparkles,
  Zap,
  ArrowUpRight,
  ShieldCheck,
  TrendingUp,
  Fingerprint,
  ArrowDownLeft,
  ArrowRightLeft,
  Landmark,
  Lock,
  CreditCard,
  Briefcase,
  ChevronRight,
  CheckCircle2,
  SlidersHorizontal,
} from 'lucide-react';
import { UserProfile, LanguageCode } from '../types';
import { TRANSLATIONS } from '../i18n/translations';
import { AxisBankLogo } from './AxisBankLogo';

interface BalanceCardProps {
  user: UserProfile;
  language: LanguageCode;
  onSendMoney: () => void;
  onScanQr: () => void;
  onAddMoney: () => void;
  onOpenPassbook: () => void;
  onOpenBiometrics: () => void;
  onOpenUpiLite: () => void;
  onOpenAccountDetails?: () => void;
  onReceiveMoney?: () => void;
  onSelfTransfer?: () => void;
  onOpenTermDeposit?: () => void;
  onOpenBusinessLoan?: () => void;
}

export const BalanceCard: React.FC<BalanceCardProps> = ({
  user,
  language,
  onSendMoney,
  onScanQr,
  onAddMoney,
  onOpenPassbook,
  onOpenBiometrics,
  onOpenUpiLite,
  onOpenAccountDetails,
  onReceiveMoney,
  onSelfTransfer,
  onOpenTermDeposit,
  onOpenBusinessLoan,
}) => {
  const [activeCardTab, setActiveCardTab] = useState<'CC_VIP' | 'SAVINGS' | 'BUSINESS_LOAN'>('CC_VIP');
  const [showSavings, setShowSavings] = useState(true);
  const [showCreditLimit, setShowCreditLimit] = useState(true);
  const [showWallet, setShowWallet] = useState(true);
  const t = TRANSLATIONS[language] || TRANSLATIONS.en;

  const formattedSavings = showSavings
    ? `₹${user.savingsBalance.toLocaleString('en-IN', {
        minimumFractionDigits: 2,
        maximumFractionDigits: 2,
      })}`
    : '••••••';

  const formattedWallet = showWallet
    ? `₹${user.walletBalance.toLocaleString('en-IN', {
        minimumFractionDigits: 2,
        maximumFractionDigits: 2,
      })}`
    : '••••••';

  const formattedUpiLite = `₹${user.upiLiteBalance.toFixed(2)}`;

  return (
    <div className="w-full bg-white rounded-3xl border border-slate-200/80 shadow-md overflow-hidden text-slate-900 transition-all">
      {/* Axis Bank Card Switcher Tabs (Axis Burgundy Theme) */}
      <div className="bg-slate-100 p-1.5 flex items-center gap-1 border-b border-slate-200 text-xs font-bold">
        <button
          type="button"
          onClick={() => setActiveCardTab('CC_VIP')}
          className={`flex-1 py-2 px-2.5 rounded-xl transition-all flex items-center justify-center gap-1.5 ${
            activeCardTab === 'CC_VIP'
              ? 'bg-[#861F41] text-white shadow-xs font-black'
              : 'text-slate-600 hover:text-slate-900 hover:bg-white/60'
          }`}
        >
          <CreditCard className="w-3.5 h-3.5" />
          <span className="truncate">Axis CC VIP</span>
          <span className="text-[9px] bg-amber-400 text-slate-950 font-black px-1 rounded-sm uppercase scale-90">
            VIP
          </span>
        </button>

        <button
          type="button"
          onClick={() => setActiveCardTab('SAVINGS')}
          className={`flex-1 py-2 px-2.5 rounded-xl transition-all flex items-center justify-center gap-1.5 ${
            activeCardTab === 'SAVINGS'
              ? 'bg-[#861F41] text-white shadow-xs font-black'
              : 'text-slate-600 hover:text-slate-900 hover:bg-white/60'
          }`}
        >
          <Landmark className="w-3.5 h-3.5" />
          <span className="truncate">A/c Balance</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveCardTab('BUSINESS_LOAN')}
          className={`flex-1 py-2 px-2.5 rounded-xl transition-all flex items-center justify-center gap-1.5 ${
            activeCardTab === 'BUSINESS_LOAN'
              ? 'bg-[#861F41] text-white shadow-xs font-black'
              : 'text-slate-600 hover:text-slate-900 hover:bg-white/60'
          }`}
        >
          <Briefcase className="w-3.5 h-3.5 text-amber-500" />
          <span className="truncate">Business Loan</span>
          <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
        </button>
      </div>

      {/* CARD 1: AXIS BANK CC VIP LUXURY CREDIT CARD */}
      {activeCardTab === 'CC_VIP' && (
        <div className="relative p-5 sm:p-6 bg-gradient-to-br from-[#4A0820] via-[#861F41] to-[#97144D] text-white overflow-hidden shadow-inner">
          {/* Subtle gold metallic accents */}
          <div className="absolute top-0 right-0 w-64 h-64 bg-radial from-amber-400/15 via-transparent to-transparent pointer-events-none" />

          {/* Top row: Brand & EMV Chip */}
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <AxisBankLogo size={36} />
              <div>
                <div className="flex items-center gap-1.5">
                  <span className="text-sm font-black tracking-tight text-white uppercase">
                    AXIS BANK
                  </span>
                  <span className="text-[10px] font-black text-amber-300 uppercase tracking-widest bg-black/30 px-2 py-0.5 rounded border border-amber-400/40">
                    CC VIP
                  </span>
                </div>
                <span className="text-[9px] uppercase tracking-widest text-amber-200/90 font-mono font-bold block">
                  BURGUNDY PRIVATE RESERVE
                </span>
              </div>
            </div>

            {/* EMV Chip and Contactless indicator */}
            <div className="flex items-center gap-2">
              <div className="w-8 h-6 rounded-md bg-gradient-to-tr from-amber-400 via-amber-200 to-amber-300 border border-amber-500/40 shadow-xs flex items-center justify-center">
                <div className="w-6 h-4 border border-amber-600/50 rounded-xs grid grid-cols-2 opacity-60" />
              </div>
              <span className="text-amber-300/80 font-mono text-sm tracking-tighter">))))</span>
            </div>
          </div>

          {/* Card Number & Available Limit */}
          <div className="mb-4">
            <div className="flex items-center justify-between">
              <p className="text-[10px] font-black text-amber-200/90 uppercase tracking-widest">
                Available VIP Credit Limit
              </p>
              <button
                type="button"
                onClick={() => setShowCreditLimit(!showCreditLimit)}
                className="p-1 text-amber-200/80 hover:text-white transition"
              >
                {showCreditLimit ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
              </button>
            </div>
            <h2 className="text-3xl sm:text-4xl font-black tracking-tight font-sans text-white mt-0.5">
              {showCreditLimit ? '₹5,00,000.00' : '••••••'}
            </h2>
            <div className="flex items-center justify-between text-xs font-mono text-amber-100/90 mt-1">
              <span>•••• •••• •••• 4829</span>
              <span className="text-[10px] font-sans font-bold bg-white/10 px-2 py-0.5 rounded text-amber-300">
                Limit: ₹10,00,000
              </span>
            </div>
          </div>

          {/* Quick Credit Card Metrics */}
          <div className="grid grid-cols-3 gap-2 bg-black/25 rounded-2xl p-3 border border-white/10 text-center mb-4">
            <div>
              <span className="text-[9px] text-amber-200/80 uppercase font-black tracking-wider block">
                Total Outstanding
              </span>
              <span className="text-xs sm:text-sm font-black text-white font-mono">₹14,250.00</span>
            </div>
            <div>
              <span className="text-[9px] text-amber-200/80 uppercase font-black tracking-wider block">
                Minimum Due
              </span>
              <span className="text-xs sm:text-sm font-black text-amber-300 font-mono">₹750.00</span>
            </div>
            <div>
              <span className="text-[9px] text-amber-200/80 uppercase font-black tracking-wider block">
                Payment Due
              </span>
              <span className="text-xs sm:text-sm font-black text-white">25th Oct</span>
            </div>
          </div>

          {/* Card Action Buttons */}
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={onSendMoney}
              className="flex-1 py-2.5 px-3 rounded-xl bg-amber-400 hover:bg-amber-300 text-slate-950 font-black text-xs uppercase tracking-wider transition shadow-sm active:scale-95 flex items-center justify-center gap-1.5"
            >
              <Zap className="w-3.5 h-3.5" />
              <span>Pay Card Bill</span>
            </button>
            <button
              type="button"
              onClick={onOpenBusinessLoan}
              className="flex-1 py-2.5 px-3 rounded-xl bg-white/15 hover:bg-white/25 text-white border border-white/20 font-black text-xs uppercase tracking-wider transition active:scale-95 flex items-center justify-center gap-1.5"
            >
              <Briefcase className="w-3.5 h-3.5 text-amber-300" />
              <span>Loan on Card</span>
            </button>
          </div>
        </div>
      )}

      {/* CARD 2: AXIS BANK SAVINGS / CURRENT ACCOUNT */}
      {activeCardTab === 'SAVINGS' && (
        <div className="p-5 sm:p-6 bg-gradient-to-br from-[#5F0C2B] via-[#861F41] to-[#97144D] text-white relative border-b border-[#700a2f]">
          <div className="flex justify-between items-start mb-3">
            <div className="flex items-center gap-2">
              <span className="text-xs font-black uppercase tracking-wider text-amber-300 flex items-center gap-1.5">
                <ShieldCheck className="w-4 h-4 text-amber-400" />
                Axis Corporate Account
              </span>
              <span className="bg-amber-400/20 text-amber-300 border border-amber-400/30 text-[10px] font-black uppercase tracking-wider px-2 py-0.5 rounded-full flex items-center gap-1">
                <TrendingUp className="w-3 h-3 text-amber-300" /> 7.5% p.a.
              </span>
            </div>

            <button
              type="button"
              onClick={() => setShowSavings(!showSavings)}
              className="p-1.5 bg-white/10 hover:bg-white/20 border border-white/15 rounded-lg text-slate-200 transition"
              title={showSavings ? t.hideBalance : t.showBalance}
            >
              {showSavings ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
            </button>
          </div>

          <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-3">
            <div>
              <p className="text-amber-200/90 text-[10px] font-black uppercase tracking-widest">
                Available Clear Balance
              </p>
              <h1 className="text-3xl sm:text-4xl font-black tracking-tight mt-0.5 font-sans text-white">
                {formattedSavings}
              </h1>
              <div className="flex items-center gap-2 mt-1">
                <button
                  type="button"
                  onClick={onOpenAccountDetails}
                  className="text-[11px] text-amber-200/90 hover:text-amber-100 hover:underline font-mono font-bold flex items-center gap-1.5 transition active:scale-95"
                  title="View Full Customer Account Details & Verification Status"
                >
                  <span>
                    A/c: •••• {user.accountNumber ? user.accountNumber.slice(-4) : '0000'} • IFSC: UTIB000001
                  </span>
                  <span className="text-[9px] bg-white/15 px-1.5 py-0.5 rounded font-sans uppercase font-black text-amber-300">
                    Account Info
                  </span>
                </button>
              </div>
            </div>

            <button
              type="button"
              disabled
              className="self-start sm:self-auto bg-white/10 text-white/50 border border-white/20 px-3 py-2 rounded-xl text-xs font-black uppercase tracking-wider cursor-not-allowed flex items-center gap-1.5 select-none"
              title="Deposits can only be credited by authorized Branch Officers at the bank counter or via inward bank transfer."
            >
              <Lock className="w-3.5 h-3.5 text-white/50" />
              <span>Add Money</span>
              <span className="text-[9px] bg-black/25 text-amber-300/80 px-1.5 py-0.5 rounded font-mono font-bold">
                Counter Only
              </span>
            </button>
          </div>
        </div>
      )}

      {/* CARD 3: AXIS PRE-APPROVED BUSINESS LOAN PROMO */}
      {activeCardTab === 'BUSINESS_LOAN' && (
        <div className="p-5 sm:p-6 bg-gradient-to-br from-[#1E293B] via-[#0F172A] to-[#861F41] text-white relative">
          <div className="flex items-center justify-between mb-3">
            <span className="bg-amber-400 text-slate-950 font-black text-[10px] px-2.5 py-0.5 rounded-full uppercase tracking-wider">
              Pre-Approved Offer
            </span>
            <span className="text-xs font-mono font-bold text-amber-300">
              IFSC: UTIB000001
            </span>
          </div>

          <h3 className="text-xl sm:text-2xl font-black text-white leading-tight">
            Axis Bank CC VIP Vyapar Business Loan
          </h3>
          <p className="text-xs text-slate-300 mt-1">
            Collateral-free commercial funding up to <span className="font-bold text-amber-300">₹50,00,000</span> at 9.99% p.a.
          </p>

          <div className="grid grid-cols-3 gap-2 mt-4 mb-4 text-center">
            <div className="bg-white/10 p-2 rounded-xl border border-white/10">
              <span className="text-[9px] text-slate-300 block uppercase font-bold">Max Limit</span>
              <span className="text-xs font-black text-white font-mono">₹50 Lakhs</span>
            </div>
            <div className="bg-white/10 p-2 rounded-xl border border-white/10">
              <span className="text-[9px] text-slate-300 block uppercase font-bold">Interest Rate</span>
              <span className="text-xs font-black text-amber-300 font-mono">9.99% p.a.</span>
            </div>
            <div className="bg-white/10 p-2 rounded-xl border border-white/10">
              <span className="text-[9px] text-slate-300 block uppercase font-bold">Disbursal</span>
              <span className="text-xs font-black text-emerald-400">Instant</span>
            </div>
          </div>

          <button
            type="button"
            onClick={onOpenBusinessLoan}
            className="w-full py-3 bg-gradient-to-r from-[#861F41] to-[#97144D] hover:from-[#700a2f] hover:to-[#861F41] text-white font-black text-xs uppercase tracking-wider rounded-xl shadow-md active:scale-98 transition flex items-center justify-center gap-1.5"
          >
            <Briefcase className="w-4 h-4 text-amber-300" />
            <span>Apply & Disburse in 2 Minutes</span>
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Secondary Account Balances (Wallet + UPI Lite) */}
      <div className="p-4 bg-slate-50 border-b border-slate-200 grid grid-cols-2 gap-3">
        {/* Wallet */}
        <div className="bg-white border border-slate-200 rounded-xl p-3.5 shadow-2xs flex flex-col justify-between">
          <div className="flex items-center justify-between">
            <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">
              Axis VIP Wallet
            </span>
            <button
              type="button"
              onClick={() => setShowWallet(!showWallet)}
              className="text-slate-400 hover:text-slate-600 transition"
            >
              {showWallet ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
            </button>
          </div>
          <div className="mt-1">
            <span className="text-xl font-black text-slate-900 font-sans">
              {formattedWallet}
            </span>
            <span className="text-[10px] text-slate-400 block font-medium">Instant Wallet</span>
          </div>
        </div>

        {/* UPI Lite */}
        <div className="bg-white border border-slate-200 rounded-xl p-3.5 shadow-2xs flex flex-col justify-between">
          <div className="flex items-center justify-between">
            <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest flex items-center gap-1">
              <Zap className="w-3 h-3 text-amber-500 fill-amber-500" /> {t.upiLite}
            </span>
            <button
              type="button"
              onClick={onOpenUpiLite}
              className="text-[10px] font-bold text-[#861F41] hover:underline"
            >
              Manage
            </button>
          </div>
          <div className="mt-1">
            <span className="text-xl font-black text-slate-900 font-sans">
              {formattedUpiLite}
            </span>
            <span className="text-[10px] text-emerald-600 font-bold block flex items-center gap-0.5">
              <Sparkles className="w-2.5 h-2.5" /> Pinless upto ₹500
            </span>
          </div>
        </div>
      </div>

      {/* Axis Bank Quick Primary Action Bar */}
      <div className="p-3 bg-white grid grid-cols-4 gap-2">
        <button
          type="button"
          onClick={onScanQr}
          className="flex flex-col items-center justify-center p-2 rounded-xl hover:bg-rose-50 text-[#861F41] transition active:scale-95 group"
        >
          <div className="w-10 h-10 rounded-xl bg-rose-50 group-hover:bg-rose-100 flex items-center justify-center mb-1 transition text-[#861F41]">
            <QrCode className="w-5 h-5" />
          </div>
          <span className="text-[11px] font-bold text-slate-800 tracking-tight">Scan QR</span>
        </button>

        <button
          type="button"
          onClick={onSendMoney}
          className="flex flex-col items-center justify-center p-2 rounded-xl hover:bg-rose-50 text-[#861F41] transition active:scale-95 group"
        >
          <div className="w-10 h-10 rounded-xl bg-rose-50 group-hover:bg-rose-100 flex items-center justify-center mb-1 transition text-[#861F41]">
            <Send className="w-5 h-5" />
          </div>
          <span className="text-[11px] font-bold text-slate-800 tracking-tight">Pay / UPI</span>
        </button>

        <button
          type="button"
          onClick={onOpenBusinessLoan}
          className="flex flex-col items-center justify-center p-2 rounded-xl hover:bg-amber-50 text-amber-700 transition active:scale-95 group relative"
        >
          <span className="absolute -top-1 right-1 bg-[#861F41] text-white text-[8px] font-black px-1.5 py-0.2 rounded-full uppercase scale-85">
            Loan
          </span>
          <div className="w-10 h-10 rounded-xl bg-amber-50 group-hover:bg-amber-100 flex items-center justify-center mb-1 transition text-amber-700">
            <Briefcase className="w-5 h-5" />
          </div>
          <span className="text-[11px] font-bold text-slate-800 tracking-tight">Business Loan</span>
        </button>

        <button
          type="button"
          onClick={onOpenPassbook}
          className="flex flex-col items-center justify-center p-2 rounded-xl hover:bg-rose-50 text-[#861F41] transition active:scale-95 group"
        >
          <div className="w-10 h-10 rounded-xl bg-rose-50 group-hover:bg-rose-100 flex items-center justify-center mb-1 transition text-[#861F41]">
            <BookOpen className="w-5 h-5" />
          </div>
          <span className="text-[11px] font-bold text-slate-800 tracking-tight">Passbook</span>
        </button>
      </div>

      {/* Axis Bank Sub-Actions Row */}
      <div className="px-4 py-2.5 bg-slate-50 border-t border-slate-200/80 flex items-center justify-between text-xs text-slate-600">
        <button
          type="button"
          onClick={onReceiveMoney}
          className="flex items-center gap-1 font-bold hover:text-[#861F41] transition"
        >
          <ArrowDownLeft className="w-3.5 h-3.5 text-[#861F41]" />
          <span>My QR Code</span>
        </button>
        <span className="text-slate-300">|</span>
        <button
          type="button"
          onClick={onSelfTransfer}
          className="flex items-center gap-1 font-bold hover:text-[#861F41] transition"
        >
          <ArrowRightLeft className="w-3.5 h-3.5 text-[#861F41]" />
          <span>Self Transfer</span>
        </button>
        <span className="text-slate-300">|</span>
        <button
          type="button"
          onClick={onOpenTermDeposit}
          className="flex items-center gap-1 font-bold hover:text-[#861F41] transition"
        >
          <Landmark className="w-3.5 h-3.5 text-[#861F41]" />
          <span>Fixed Deposit</span>
        </button>
      </div>
    </div>
  );
};
