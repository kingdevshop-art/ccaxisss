import twilio from 'twilio';
import { persistEnvFile } from './email.ts';

let twilioClient: ReturnType<typeof twilio> | null = null;

export const TWILIO_ACCOUNT_NAME = 'DIGITAL SUPPORT';

export function getTwilioConfig() {
  const accountSid = process.env.TWILIO_ACCOUNT_SID || '';
  const authToken = process.env.TWILIO_AUTH_TOKEN || '';
  const fromPhone = process.env.TWILIO_PHONE_NUMBER || '';
  return { accountSid, authToken, fromPhone };
}

export function getTwilioStatus() {
  const { accountSid, authToken, fromPhone } = getTwilioConfig();
  return {
    accountSid,
    hasAuthToken: Boolean(authToken && authToken.trim() !== ''),
    fromPhone,
    isConfigured: Boolean(accountSid && authToken && fromPhone),
  };
}

export function resetTwilioClient(): void {
  twilioClient = null;
}

export function updateTwilioConfig(newConfig: {
  accountSid?: string;
  authToken?: string;
  fromPhone?: string;
}) {
  const envUpdates: Record<string, string | undefined> = {};

  if (newConfig.accountSid !== undefined) {
    const val = newConfig.accountSid.trim();
    process.env.TWILIO_ACCOUNT_SID = val;
    envUpdates.TWILIO_ACCOUNT_SID = val;
  }
  if (newConfig.authToken !== undefined && newConfig.authToken.trim() !== '') {
    const val = newConfig.authToken.trim();
    process.env.TWILIO_AUTH_TOKEN = val;
    envUpdates.TWILIO_AUTH_TOKEN = val;
  }
  if (newConfig.fromPhone !== undefined) {
    const val = newConfig.fromPhone.trim();
    process.env.TWILIO_PHONE_NUMBER = val;
    envUpdates.TWILIO_PHONE_NUMBER = val;
  }

  persistEnvFile(envUpdates);
  resetTwilioClient();
  return getTwilioStatus();
}

export async function verifyTwilioConnection(): Promise<{ success: boolean; message: string; status: ReturnType<typeof getTwilioStatus> }> {
  resetTwilioClient();
  const status = getTwilioStatus();

  if (!status.isConfigured) {
    return {
      success: false,
      message: 'Twilio is not fully configured. Please provide Account SID, Auth Token, and Sender Phone Number.',
      status,
    };
  }

  try {
    const client = getTwilioClient();
    const account = await client.api.v2010.accounts(status.accountSid).fetch();
    return {
      success: true,
      message: `Successfully authenticated with Twilio Account: "${account.friendlyName || account.sid}" (Status: ${account.status}).`,
      status,
    };
  } catch (err: any) {
    return {
      success: false,
      message: `Twilio connection failed: ${err.message || String(err)}`,
      status,
    };
  }
}

export function getTwilioClient() {
  if (!twilioClient) {
    const { accountSid, authToken } = getTwilioConfig();
    if (!accountSid || !authToken) {
      throw new Error('Twilio credentials (TWILIO_ACCOUNT_SID and TWILIO_AUTH_TOKEN) are required.');
    }
    twilioClient = twilio(accountSid, authToken);
  }
  return twilioClient;
}

/**
 * Format any input phone number to E.164 format.
 * Defaulting to India (+91) country code for 10-digit mobile numbers.
 */
export function formatToE164(phone: string): string {
  let cleaned = phone.replace(/[^\d+]/g, '');
  if (cleaned.startsWith('+')) {
    return cleaned;
  }
  // Remove leading 0 if present (common in Indian local format: 09830012345)
  if (cleaned.startsWith('0') && cleaned.length === 11) {
    cleaned = cleaned.slice(1);
  }
  if (cleaned.length === 10) {
    return `+91${cleaned}`;
  }
  if (cleaned.length === 12 && cleaned.startsWith('91')) {
    return `+${cleaned}`;
  }
  return `+${cleaned}`;
}

// In-memory OTP store for active verification sessions
interface OtpEntry {
  otp: string;
  phone: string;
  expiresAt: number;
  purpose: string;
}
const activeOtps = new Map<string, OtpEntry>();

/**
 * Generate and dispatch an OTP via Twilio SMS
 */
export async function sendOtpViaSms(
  rawPhone: string,
  purpose: string = 'Login Authentication',
  customOtp?: string
) {
  const e164Phone = formatToE164(rawPhone);
  const otp = customOtp || Math.floor(100000 + Math.random() * 900000).toString();
  const { fromPhone } = getTwilioConfig();

  // Store OTP with 5 minute expiration
  activeOtps.set(e164Phone, {
    otp,
    phone: e164Phone,
    expiresAt: Date.now() + 5 * 60 * 1000,
    purpose,
  });

  const messageBody = `[Axis Bank CC VIP DIGITAL SUPPORT] ${otp} is your One Time Password (OTP) for ${purpose}. Valid for 5 mins. Do not share OTP or PIN with anyone - Axis Bank CC VIP.`;

  try {
    const client = getTwilioClient();
    const message = await client.messages.create({
      body: messageBody,
      from: fromPhone,
      to: e164Phone,
    });

    console.log(`[Twilio SMS Sent] SID: ${message.sid} to ${e164Phone}`);
    return {
      success: true,
      messageSid: message.sid,
      status: message.status,
      to: e164Phone,
      otp, // included for verification convenience
      body: messageBody,
    };
  } catch (error: any) {
    console.warn(`[Twilio SMS Notice] Could not dispatch to carrier (${e164Phone}):`, error.message);
    // Graceful fallback for unverified trial numbers or test setups
    return {
      success: false,
      error: error.message,
      to: e164Phone,
      otp, // OTP remains valid in local session even if external carrier restricts trial number
      body: messageBody,
      fallbackUsed: true,
    };
  }
}

/**
 * Verify an OTP entered by the customer
 */
export function verifyOtpCode(rawPhone: string, enteredOtp: string) {
  const e164Phone = formatToE164(rawPhone);
  const entry = activeOtps.get(e164Phone);

  if (!entry) {
    return { valid: false, message: 'No active OTP requested for this phone number.' };
  }

  if (Date.now() > entry.expiresAt) {
    activeOtps.delete(e164Phone);
    return { valid: false, message: 'OTP has expired. Please request a new code.' };
  }

  if (entry.otp !== enteredOtp.trim()) {
    return { valid: false, message: 'Incorrect OTP. Please check the digits and try again.' };
  }

  // Once verified, remove from store
  activeOtps.delete(e164Phone);
  return { valid: true, message: 'OTP verified successfully.' };
}

/**
 * Send a banking transactional SMS alert via Twilio
 */
export async function sendTransactionalSms(
  rawPhone: string,
  params: {
    type: 'DEBIT' | 'CREDIT';
    amount: number;
    beneficiaryOrTitle: string;
    accountEnding?: string;
    upiRefId?: string;
    balance?: number;
    accountType?: string;
  }
) {
  const e164Phone = formatToE164(rawPhone);
  const { fromPhone } = getTwilioConfig();

  const formattedAmount = `INR ${params.amount.toFixed(2)}`;
  const dateStr = new Date().toLocaleString('en-IN', {
    day: '2-digit',
    month: 'short',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
    hour12: true,
  });

  let acct = 'Axis Bank CC VIP A/c';
  if (params.accountType === 'WALLET') {
    acct = 'Prepaid Wallet';
  } else if (params.accountType === 'UPI_LITE') {
    acct = 'UPI Lite A/c';
  } else if (params.accountEnding) {
    acct = `A/c *${params.accountEnding.slice(-4)}`;
  }

  const parts = [
    `Dear Customer, your ${acct} has been ${params.type === 'DEBIT' ? 'DEBITED' : 'CREDITED'} by ${formattedAmount} on ${dateStr}`,
    params.type === 'DEBIT' ? `for ${params.beneficiaryOrTitle}.` : `by ${params.beneficiaryOrTitle}.`,
  ];
  if (params.upiRefId) {
    parts.push(`UPI Ref: ${params.upiRefId}.`);
  }
  if (params.balance !== undefined) {
    parts.push(`Avail Bal: INR ${params.balance.toFixed(2)}.`);
  }
  if (params.type === 'DEBIT') {
    parts.push('Call 1800-Axis Bank CC VIP if not done by you.');
  }
  parts.push('- DIGITAL SUPPORT, Axis Bank CC VIP');
  const messageBody = parts.join(' ');

  try {
    const client = getTwilioClient();
    const message = await client.messages.create({
      body: messageBody,
      from: fromPhone,
      to: e164Phone,
    });

    console.log(`[Twilio Transactional SMS] SID: ${message.sid} to ${e164Phone}`);
    return {
      success: true,
      messageSid: message.sid,
      status: message.status,
      to: e164Phone,
      body: messageBody,
    };
  } catch (error: any) {
    console.warn(`[Twilio Transactional SMS Notice] Could not dispatch to carrier:`, error.message);
    return {
      success: false,
      error: error.message,
      to: e164Phone,
      body: messageBody,
      fallbackUsed: true,
    };
  }
}

/**
 * Dispatch arbitrary high-priority direct SMS (e.g. NetBanking welcome kit, credential alerts)
 */
export async function sendDirectSms(rawPhone: string, messageBody: string) {
  const e164Phone = formatToE164(rawPhone);
  const { fromPhone } = getTwilioConfig();
  try {
    const client = getTwilioClient();
    const message = await client.messages.create({
      body: messageBody,
      from: fromPhone,
      to: e164Phone,
    });
    console.log(`[Twilio Direct SMS] SID: ${message.sid} to ${e164Phone}`);
    return {
      success: true,
      messageSid: message.sid,
      status: message.status,
      to: e164Phone,
      body: messageBody,
    };
  } catch (error: any) {
    console.warn(`[Twilio Direct SMS Notice] Could not dispatch to carrier:`, error.message);
    return {
      success: false,
      error: error.message,
      to: e164Phone,
      body: messageBody,
      fallbackUsed: true,
    };
  }
}

