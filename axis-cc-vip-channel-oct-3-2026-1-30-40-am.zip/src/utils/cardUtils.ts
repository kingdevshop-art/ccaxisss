import { VirtualDebitCard, VirtualDebitCardVariant } from '../types';

export interface CardVariantConfig {
  variant: VirtualDebitCardVariant;
  name: string;
  network: 'VISA_INFINITE' | 'MASTERCARD_WORLD' | 'RUPAY_SELECT';
  annualFee: number;
  feeScheduleText: string;
  defaultDailyLimit: number;
  maxDailyLimit: number;
  benefits: string[];
  gradientClass: string;
  badgeColor: string;
  cardPrefix: string;
}

export const VIRTUAL_CARD_CONFIGS: Record<VirtualDebitCardVariant, CardVariantConfig> = {
  BURGUNDY_PRESTIGE: {
    variant: 'BURGUNDY_PRESTIGE',
    name: 'Axis Burgundy Prestige Virtual Debit',
    network: 'VISA_INFINITE',
    annualFee: 2999,
    feeScheduleText: '₹2,999 p.a. (Complimentary for Axis VIP & Burgundy Priority clients)',
    defaultDailyLimit: 500000,
    maxDailyLimit: 1000000,
    benefits: [
      'Zero Forex Markup on all international transactions & foreign currency spends',
      'Complimentary Domestic & International Airport Lounge access (4 visits / quarter)',
      'Comprehensive Cyber Fraud Protection Cover up to ₹10,00,000',
      '2X EDGE Reward Points on international merchants and premium lifestyle bookings',
      'Dedicated 24x7 Burgundy Priority Relationship Concierge',
    ],
    gradientClass: 'from-[#580824] via-[#861F41] to-[#3b0416]',
    badgeColor: 'bg-amber-400/20 text-amber-300 border-amber-400/50',
    cardPrefix: '4532 89',
  },
  TITANIUM_REWARDS: {
    variant: 'TITANIUM_REWARDS',
    name: 'Axis Titanium Rewards Virtual Debit',
    network: 'MASTERCARD_WORLD',
    annualFee: 499,
    feeScheduleText: '₹499 p.a. + GST (100% Fee Reversal on spending ₹50,000 annually)',
    defaultDailyLimit: 200000,
    maxDailyLimit: 500000,
    benefits: [
      '3X EDGE Reward points on Dining, Zomato, Swiggy, and online shopping',
      '1% Fuel Surcharge Waiver at all fuel stations across India',
      'Complimentary annual OTT subscription voucher (SonyLIV or Zee5 Premium)',
      'Daily online purchase limit up to ₹2,00,000 with dynamic CVV protection',
      'Zero Lost Card Liability upon reporting via Axis VIP Mobile App',
    ],
    gradientClass: 'from-slate-900 via-slate-800 to-slate-950',
    badgeColor: 'bg-cyan-400/20 text-cyan-300 border-cyan-400/50',
    cardPrefix: '5241 68',
  },
  MAGNUS_METAL: {
    variant: 'MAGNUS_METAL',
    name: 'Axis Magnus Metal Elite Virtual Debit',
    network: 'VISA_INFINITE',
    annualFee: 9999,
    feeScheduleText: '₹9,999 p.a. (Complimentary for Ultra High Net Worth Corporate Directors)',
    defaultDailyLimit: 1000000,
    maxDailyLimit: 2500000,
    benefits: [
      'Unlimited Domestic & International Airport Lounge access with VIP Meet & Assist at 32 airports',
      '5X EDGE Rewards on Flights, Luxury Stays, and Global Travel Bookings',
      'High-value Daily Online Transaction Limit up to ₹10,00,000 (Expandable to ₹25 Lakh)',
      'Personalized 24x7 Luxury Lifestyle Concierge and complimentary Golf privileges across India',
      'Air Accident Cover of ₹4.5 Crore and comprehensive travel insurance',
    ],
    gradientClass: 'from-zinc-950 via-neutral-900 to-amber-950',
    badgeColor: 'bg-amber-400/30 text-amber-200 border-amber-300/60',
    cardPrefix: '4716 90',
  },
  NEO_SHOPPING: {
    variant: 'NEO_SHOPPING',
    name: 'Axis Neo Online Virtual Shopping Card',
    network: 'RUPAY_SELECT',
    annualFee: 0,
    feeScheduleText: '₹0 (100% Lifetime Free Virtual Card with Zero Maintenance)',
    defaultDailyLimit: 100000,
    maxDailyLimit: 300000,
    benefits: [
      '10% Instant Discount on Amazon, Flipkart, Myntra, BookMyShow, and Blinkit',
      'Single-use dynamic expiring CVV for bulletproof online shopping security',
      'Instant one-tap freeze and unfreeze from your mobile dashboard',
      'Seamless integration with RuPay UPI for direct card-on-UPI transactions',
      'Complimentary accident cover of ₹2,00,000 from NPCI RuPay',
    ],
    gradientClass: 'from-[#1e1b4b] via-[#311042] to-[#042f2e]',
    badgeColor: 'bg-emerald-400/20 text-emerald-300 border-emerald-400/50',
    cardPrefix: '6074 12',
  },
};

/**
 * Generates an authentic 16-digit card number with appropriate prefix
 */
export function generateRandomCardNumber(prefix: string): string {
  const cleanPrefix = prefix.replace(/\s+/g, '');
  let remainingDigits = '';
  for (let i = 0; i < 16 - cleanPrefix.length; i++) {
    remainingDigits += Math.floor(Math.random() * 10).toString();
  }
  const full = cleanPrefix + remainingDigits;
  return full.match(/.{1,4}/g)?.join(' ') || full;
}

/**
 * Generates an authentic Virtual Debit Card
 */
export function createVirtualDebitCard(
  holderName: string,
  variant: VirtualDebitCardVariant = 'BURGUNDY_PRESTIGE'
): VirtualDebitCard {
  const config = VIRTUAL_CARD_CONFIGS[variant];
  const now = new Date();
  const expMonth = String((now.getMonth() + 1)).padStart(2, '0');
  const expYear = String((now.getFullYear() + 5) % 100).padStart(2, '0');
  const randomCvv = String(Math.floor(100 + Math.random() * 900));

  return {
    id: `vdc_${variant.toLowerCase()}_${Date.now()}_${Math.floor(Math.random() * 1000)}`,
    cardNumber: generateRandomCardNumber(config.cardPrefix),
    cardHolderName: (holderName || 'VALUED CUSTOMER').toUpperCase(),
    expiryMonth: expMonth,
    expiryYear: expYear,
    cvv: randomCvv,
    pin: '1234',
    variant: variant,
    variantName: config.name,
    network: config.network,
    status: 'ACTIVE',
    dailyEcomLimit: config.defaultDailyLimit,
    maxDailyLimit: config.maxDailyLimit,
    onlineTransactionsEnabled: true,
    internationalUsageEnabled: variant === 'BURGUNDY_PRESTIGE' || variant === 'MAGNUS_METAL',
    contactlessEnabled: true,
    atmWithdrawalEnabled: false, // Virtual card is online/tap-only
    annualFee: config.annualFee,
    feeScheduleText: config.feeScheduleText,
    benefits: config.benefits,
    issuedAt: new Date().toISOString(),
  };
}

/**
 * Default Virtual Card set for any new Axis VIP account
 */
export function getDefaultVirtualCards(holderName: string): VirtualDebitCard[] {
  return [
    createVirtualDebitCard(holderName, 'BURGUNDY_PRESTIGE'),
    createVirtualDebitCard(holderName, 'NEO_SHOPPING'),
  ];
}

/**
 * Generates official NetBanking credentials for a customer
 */
export function generateNetbankingCredentials(name: string, phone: string): {
  cifNumber: string;
  netbankingLoginId: string;
  netbankingPassword: string;
  defaultMpin: string;
} {
  const cleanName = (name || 'customer')
    .toLowerCase()
    .replace(/[^a-z0-9]/g, '')
    .slice(0, 8);
  const cleanPhone = (phone || '').replace(/\D/g, '').slice(-4) || '2026';
  const randomDigits = Math.floor(100000 + Math.random() * 900000);

  return {
    cifNumber: `AXIS${randomDigits}`,
    netbankingLoginId: `axis.${cleanName || 'vip'}${cleanPhone}`,
    netbankingPassword: `Axis@${Math.floor(1000 + Math.random() * 9000)}`,
    defaultMpin: '1234',
  };
}
