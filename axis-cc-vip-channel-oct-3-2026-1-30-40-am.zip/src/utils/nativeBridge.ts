/**
 * Axis Bank CC VIP - Native Android Bridge Client
 * Provides seamless TypeScript bindings to Android's native hardware features:
 * - BiometricPrompt (Hardware Fingerprint / Face ID)
 * - Multilingual Soundbox Engine (Native TextToSpeech + Hardware Chime)
 * - GPS Hardware Geolocation Radar
 * - Haptic Feedback Engine
 * - Screen Privacy Protection (FLAG_SECURE)
 * - Native Document & Receipt Sharing
 */

export interface AndroidLocationResult {
  latitude: number;
  longitude: number;
  accuracy?: number;
}

declare global {
  interface Window {
    AndroidBankingBridge?: {
      isNative: () => boolean;
      getVersion: () => string;
      triggerHapticFeedback: (pattern: string) => void;
      authenticateBiometric: (title: string, subtitle: string, callbackJsFn: string) => void;
      shareReceipt: (receiptText: string, title: string) => void;
      speakSoundbox: (text: string, languageCode: string) => void;
      getDeviceLocation: (callbackJsFn: string) => void;
      isGpsEnabled: () => boolean;
      setScreenSecurity: (enabled: boolean) => void;
    };
    isNativeAndroidApp?: boolean;
    nativeAppVersion?: string;
    handleNativeDeepLink?: (url: string) => void;
  }
}

/**
 * Checks if the current web runtime is hosted inside the native Android APK wrapper
 */
export function isNativeAndroidApp(): boolean {
  if (typeof window === 'undefined') return false;
  return Boolean(window.isNativeAndroidApp || window.AndroidBankingBridge?.isNative());
}

/**
 * Returns native Android app version or null if in standard web/PWA browser
 */
export function getNativeAppVersion(): string | null {
  if (typeof window === 'undefined') return null;
  return window.AndroidBankingBridge?.getVersion() || window.nativeAppVersion || null;
}

/**
 * Native Haptic Feedback trigger
 */
export function triggerNativeHaptic(
  pattern: 'light' | 'medium' | 'heavy' | 'success' | 'error' = 'medium'
) {
  if (typeof window !== 'undefined' && window.AndroidBankingBridge?.triggerHapticFeedback) {
    try {
      window.AndroidBankingBridge.triggerHapticFeedback(pattern);
      return;
    } catch {
      // Ignore if unavailable
    }
  }

  // Fallback to web vibration API
  if (typeof window !== 'undefined' && 'vibrate' in navigator) {
    try {
      if (pattern === 'success') {
        navigator.vibrate([40, 60, 80]);
      } else if (pattern === 'error') {
        navigator.vibrate([50, 40, 50, 40, 50]);
      } else if (pattern === 'light') {
        navigator.vibrate(20);
      } else {
        navigator.vibrate(45);
      }
    } catch {
      // Ignore
    }
  }
}

/**
 * Native Soundbox Voice Engine trigger
 * Plays hardware notification tone followed by native TTS in Indian accent
 */
export function playNativeSoundboxAlert(text: string, languageCode: string): boolean {
  if (typeof window !== 'undefined' && window.AndroidBankingBridge?.speakSoundbox) {
    try {
      window.AndroidBankingBridge.speakSoundbox(text, languageCode);
      return true;
    } catch (err) {
      console.warn('Native Soundbox speech failed, falling back to Web Speech:', err);
    }
  }
  return false;
}

/**
 * Hardware GPS Location Telemetry
 * Interrogates native Android LocationManager with fallback to HTML5 navigator.geolocation
 */
export function getDeviceLocationNative(): Promise<AndroidLocationResult | null> {
  return new Promise((resolve) => {
    if (typeof window !== 'undefined' && window.AndroidBankingBridge?.getDeviceLocation) {
      const callbackName = `__native_loc_cb_${Date.now()}`;
      (window as any)[callbackName] = (success: boolean, data: any) => {
        delete (window as any)[callbackName];
        if (success && data?.latitude && data?.longitude) {
          resolve({
            latitude: Number(data.latitude),
            longitude: Number(data.longitude),
            accuracy: data.accuracy ? Number(data.accuracy) : undefined,
          });
        } else {
          // Fallback to HTML5 Geolocation
          fallbackHtml5Location(resolve);
        }
      };

      try {
        window.AndroidBankingBridge.getDeviceLocation(callbackName);
        // Set a timeout in case user ignores permission prompt
        setTimeout(() => {
          if ((window as any)[callbackName]) {
            delete (window as any)[callbackName];
            fallbackHtml5Location(resolve);
          }
        }, 5000);
        return;
      } catch (err) {
        console.warn('Native GPS call error:', err);
      }
    }

    fallbackHtml5Location(resolve);
  });
}

function fallbackHtml5Location(resolve: (res: AndroidLocationResult | null) => void) {
  if (typeof navigator !== 'undefined' && 'geolocation' in navigator) {
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        resolve({
          latitude: pos.coords.latitude,
          longitude: pos.coords.longitude,
          accuracy: pos.coords.accuracy,
        });
      },
      (err) => {
        console.warn('HTML5 Geolocation fallback failed:', err.message);
        resolve(null);
      },
      { enableHighAccuracy: true, timeout: 6000, maximumAge: 30000 }
    );
  } else {
    resolve(null);
  }
}

/**
 * Biometric Hardware Authentication (Fingerprint / Face ID)
 */
export function authenticateWithBiometrics(
  title: string = 'Verify Fingerprint',
  subtitle: string = 'Authorize banking transaction'
): Promise<boolean> {
  return new Promise((resolve) => {
    if (typeof window !== 'undefined' && window.AndroidBankingBridge?.authenticateBiometric) {
      const callbackName = `__native_bio_cb_${Date.now()}`;
      (window as any)[callbackName] = (success: boolean) => {
        delete (window as any)[callbackName];
        resolve(Boolean(success));
      };

      try {
        window.AndroidBankingBridge.authenticateBiometric(title, subtitle, callbackName);
        return;
      } catch (err) {
        console.warn('Native Biometric call failed:', err);
      }
    }

    // Default simulation resolution if running in plain browser
    resolve(true);
  });
}

/**
 * Native Android Receipt Share via system Intent
 */
export function shareReceiptNative(receiptText: string, title: string = 'Axis Bank CC VIP Payment Receipt'): boolean {
  if (typeof window !== 'undefined' && window.AndroidBankingBridge?.shareReceipt) {
    try {
      window.AndroidBankingBridge.shareReceipt(receiptText, title);
      return true;
    } catch {
      // Ignore
    }
  }

  // Web Share API fallback
  if (typeof navigator !== 'undefined' && navigator.share) {
    navigator.share({
      title,
      text: receiptText,
    }).catch(() => {});
    return true;
  }

  return false;
}

/**
 * Toggle Android FLAG_SECURE (Disables screenshot protection temporarily when user wishes to save a receipt)
 */
export function setScreenProtection(enabled: boolean) {
  if (typeof window !== 'undefined' && window.AndroidBankingBridge?.setScreenSecurity) {
    try {
      window.AndroidBankingBridge.setScreenSecurity(enabled);
    } catch {
      // Ignore
    }
  }
}
