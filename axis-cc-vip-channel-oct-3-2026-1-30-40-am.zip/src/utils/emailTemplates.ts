/**
 * Axis Bank CC VIP Modern Banking Email Template Engine
 * Generates responsive, accessible, institutional HTML & text email templates
 * for Axis Bank CC VIP & Corporate Banking.
 */

export interface EmailTemplateData {
  recipientName: string;
  recipientEmail?: string;
  accountEnding?: string;
  accountNumber?: string;
  cifNumber?: string;
  ifscCode?: string;
  branchName?: string;
  netbankingLoginId?: string;
  netbankingPassword?: string;
  virtualCardNumber?: string;
  virtualCardVariant?: string;
  virtualCardLimit?: number;
  amount?: number;
  balance?: number;
  transactionType?: 'DEBIT' | 'CREDIT';
  referenceId?: string;
  description?: string;
  paymentMode?: string;
  timestamp?: string;
  customSubject?: string;
  customMessage?: string;
  customTitle?: string;
  updateType?: string;
  updateDetails?: string;
}

export interface RenderedEmail {
  subject: string;
  html: string;
  text: string;
}

const BANK_NAME = 'Axis Bank Ltd.';
const APP_TITLE = 'AXIS BANK CC VIP';
const BANK_SHORT = 'Axis Bank CC VIP • Mobile Banking & Corporate VIP Portal';
const BANK_ADDRESS = 'Corporate Office: Axis House, C-2, Wadia International Centre, Pandurang Budhkar Marg, Worli, Mumbai - 400025';
const HELPLINE = '1860-419-5555 / 1860-500-5555';
const SUPPORT_EMAIL = 'vip.support@axisbank.com';
const IFSC_DEFAULT = 'UTIB000001';

/**
 * Generates an inline vector Axis Bank Crest with CC VIP Emblem
 * Renders flawlessly across all email clients without external image downloads.
 */
function getAxisCrestSvgHtml(): string {
  return `<svg width="72" height="72" viewBox="0 0 120 120" xmlns="http://www.w3.org/2000/svg" style="display: block; margin: 0 auto;">
    <defs>
      <linearGradient id="crest_gold_grad" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stop-color="#FEF08A"/>
        <stop offset="40%" stop-color="#FBBF24"/>
        <stop offset="70%" stop-color="#F59E0B"/>
        <stop offset="100%" stop-color="#B45309"/>
      </linearGradient>
      <linearGradient id="bg_crest_grad" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stop-color="#97144D"/>
        <stop offset="50%" stop-color="#861F41"/>
        <stop offset="100%" stop-color="#4E061E"/>
      </linearGradient>
    </defs>
    <!-- Background Shield Squircle -->
    <rect width="120" height="120" rx="26" fill="url(#bg_crest_grad)" stroke="#F59E0B" stroke-width="2.5"/>
    <rect x="3" y="3" width="114" height="114" rx="23" fill="none" stroke="#FFFFFF" stroke-width="1" stroke-opacity="0.25"/>
    <!-- Iconic Axis Triangle Wing Geometry -->
    <path d="M60 16 L98 80 H76 L60 52 L44 80 H22 L60 16 Z" fill="#FFFFFF"/>
    <path d="M60 21 L78 54 H42 L60 21 Z" fill="url(#crest_gold_grad)"/>
    <path d="M51 62 H69 L60 48 L51 62 Z" fill="#861F41"/>
    <!-- CC VIP Luxury Golden Pill Badge -->
    <rect x="25" y="90" width="70" height="20" rx="10" fill="url(#crest_gold_grad)" stroke="#FFFFFF" stroke-width="1"/>
    <text x="60" y="104" text-anchor="middle" font-family="-apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif" font-size="10.5" font-weight="900" fill="#4E061E" letter-spacing="1.5">CC VIP</text>
  </svg>`;
}

/**
 * Base Responsive HTML Email Wrapper
 * Fully compliant with RFC standards, responsive styling, dark-mode tolerance,
 * and high-contrast accessibility.
 */
function getBaseEmailWrapper(
  title: string,
  badgeText: string,
  badgeBgColor: string,
  badgeTextColor: string,
  preheaderSnippet: string,
  contentHtml: string
): string {
  return `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="color-scheme" content="light">
  <meta name="supported-color-schemes" content="light">
  <title>${title}</title>
  <style>
    /* Reset & Base Typography */
    body {
      margin: 0;
      padding: 0;
      background-color: #f1f5f9;
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif;
      -webkit-font-smoothing: antialiased;
      color: #0f172a;
    }
    table { border-collapse: collapse; mso-table-lspace: 0pt; mso-table-rspace: 0pt; }
    td { padding: 0; }
    img { border: 0; outline: none; text-decoration: none; display: block; }
    
    /* Responsive Wrapper */
    .email-wrapper {
      width: 100%;
      background-color: #f1f5f9;
      padding: 28px 12px;
    }
    .email-container {
      max-width: 620px;
      margin: 0 auto;
      background-color: #ffffff;
      border-radius: 28px;
      overflow: hidden;
      box-shadow: 0 16px 36px -8px rgba(134, 31, 65, 0.12), 0 8px 16px -6px rgba(0, 0, 0, 0.06);
      border: 1px solid #e2e8f0;
    }

    /* Luxury Header: Deep Axis Burgundy (#861F41) + Gold Accent Lines */
    .header-table {
      width: 100%;
      background: linear-gradient(145deg, #3D0416 0%, #580824 35%, #861F41 70%, #9E144D 100%);
      border-bottom: 3px solid #f59e0b;
    }
    .header-cell {
      padding: 34px 28px 28px 28px;
      text-align: center;
    }
    .security-top-tag {
      display: inline-block;
      font-size: 9.5px;
      font-weight: 800;
      color: #fef08a;
      letter-spacing: 2px;
      text-transform: uppercase;
      margin-bottom: 16px;
      background-color: rgba(0, 0, 0, 0.35);
      padding: 4px 14px;
      border-radius: 20px;
      border: 1px solid rgba(254, 240, 138, 0.3);
    }
    .app-brand-title {
      color: #ffffff;
      font-size: 26px;
      font-weight: 900;
      margin: 12px 0 4px 0;
      letter-spacing: 3px;
      text-transform: uppercase;
      text-shadow: 0 2px 8px rgba(0, 0, 0, 0.4);
    }
    .app-brand-sub {
      color: #fde68a;
      font-size: 11px;
      margin: 0 0 14px 0;
      letter-spacing: 1.5px;
      font-weight: 800;
      text-transform: uppercase;
    }
    .dispatch-badge {
      display: inline-block;
      padding: 5px 16px;
      border-radius: 9999px;
      font-size: 10px;
      font-weight: 900;
      text-transform: uppercase;
      letter-spacing: 1.2px;
      background-color: ${badgeBgColor};
      color: ${badgeTextColor};
      border: 1px solid #f59e0b;
      box-shadow: 0 2px 6px rgba(0, 0, 0, 0.15);
    }

    /* Content Area */
    .content-cell {
      padding: 32px 30px;
      background-color: #ffffff;
    }
    .customer-greeting {
      font-size: 15px;
      font-weight: 800;
      color: #0f172a;
      margin-bottom: 14px;
    }

    /* Detail Tables */
    .table-details {
      width: 100%;
      margin: 22px 0;
      border: 1px solid #e2e8f0;
      border-radius: 16px;
      overflow: hidden;
      background-color: #f8fafc;
    }
    .table-details td {
      padding: 13px 18px;
      font-size: 12px;
      border-bottom: 1px solid #e2e8f0;
    }
    .table-details tr:last-child td { border-bottom: none; }
    .table-details td.label {
      color: #64748b;
      font-weight: 700;
      width: 38%;
      text-transform: uppercase;
      font-size: 10px;
      letter-spacing: 0.6px;
    }
    .table-details td.value {
      color: #0f172a;
      font-weight: 800;
      text-align: right;
    }

    /* Cards & Badges */
    .highlight-card {
      border-radius: 18px;
      padding: 22px;
      margin: 20px 0;
      text-align: center;
      position: relative;
    }
    .amount-display {
      font-size: 32px;
      font-weight: 900;
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, monospace;
      letter-spacing: -1px;
      margin: 8px 0 4px 0;
    }
    
    /* Security & Regulatory Boxes */
    .security-notice {
      background-color: #fffbeb;
      border: 1px solid #fef3c7;
      border-left: 4px solid #f59e0b;
      padding: 15px 18px;
      border-radius: 14px;
      margin-top: 24px;
      font-size: 11.5px;
      color: #92400e;
      line-height: 1.55;
    }

    /* Institutional Footer */
    .footer-table {
      width: 100%;
      background-color: #0f172a;
      color: #94a3b8;
    }
    .footer-cell {
      padding: 26px 28px;
      text-align: center;
      font-size: 11px;
      line-height: 1.6;
    }
    .footer-cell a {
      color: #fde047;
      text-decoration: none;
      font-weight: 800;
    }
    .footer-divider {
      height: 1px;
      background-color: #334155;
      margin: 16px auto;
      max-width: 480px;
    }
  </style>
</head>
<body>
  <!-- Hidden Preheader text for email inbox snippet previews -->
  <div style="display: none; max-height: 0px; overflow: hidden; opacity: 0; mso-hide: all;">
    ${preheaderSnippet} &zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;
  </div>

  <div class="email-wrapper">
    <div class="email-container">
      
      <!-- Luxury Brand Header -->
      <table class="header-table" role="presentation">
        <tr>
          <td class="header-cell">
            <div class="security-top-tag">🔒 RBI Scheduled Bank • 256-Bit SSL Encrypted</div>
            
            <!-- Axis Crest Vector Graphic -->
            ${getAxisCrestSvgHtml()}

            <h1 class="app-brand-title">${APP_TITLE}</h1>
            <p class="app-brand-sub">Priority Mobile Banking &amp; Corporate VIP Portal</p>
            
            <div class="dispatch-badge">${badgeText}</div>
          </td>
        </tr>
      </table>

      <!-- Main Email Content -->
      <table style="width: 100%;" role="presentation">
        <tr>
          <td class="content-cell">
            ${contentHtml}
          </td>
        </tr>
      </table>

      <!-- Institutional Compliance Footer -->
      <table class="footer-table" role="presentation">
        <tr>
          <td class="footer-cell">
            <div style="color: #ffffff; font-weight: 900; font-size: 12px; letter-spacing: 1px; text-transform: uppercase;">
              ${BANK_NAME}
            </div>
            <div style="font-size: 10.5px; color: #cbd5e1; margin-top: 4px;">
              ${BANK_ADDRESS}
            </div>
            <div style="font-size: 10px; color: #fde68a; font-weight: 700; margin-top: 6px;">
              Official IFSC Code: ${IFSC_DEFAULT} • License No: RBI/BL-8802/SCH-COMMERCIAL
            </div>

            <div class="footer-divider"></div>

            <div style="font-size: 11px; margin-bottom: 8px;">
              24x7 Priority VIP Concierge: <a href="tel:18604195555">${HELPLINE}</a> &bull; Support: <a href="mailto:${SUPPORT_EMAIL}">${SUPPORT_EMAIL}</a>
            </div>

            <div style="font-size: 9.5px; color: #64748b; line-height: 1.5; max-width: 520px; margin: 0 auto;">
              This is a system-generated official communication dispatched from Axis Bank CC VIP Core Banking System (CBS). 
              Axis Bank never contacts customers asking for MPIN, Password, Debit Card CVV, or OTP.
            </div>
          </td>
        </tr>
      </table>

    </div>
  </div>
</body>
</html>`;
}

/**
 * 1. Welcome Email Template
 * Dispatched immediately upon user enrollment or onboarding
 */
export function generateWelcomeEmail(data: EmailTemplateData): RenderedEmail {
  const name = data.recipientName || 'Valued Customer';
  const acct = data.accountNumber || (data.accountEnding ? `•••• •••• •••• ${data.accountEnding}` : '•••• CBS-ACTIVE');
  const branch = data.branchName || 'Axis Bank Corporate HO (Mumbai)';
  const cif = data.cifNumber || 'AXIS8891002';
  const ifsc = data.ifscCode || IFSC_DEFAULT;
  const time = data.timestamp || new Date().toLocaleString('en-IN', { timeZone: 'Asia/Kolkata' });

  const subject = `Welcome to Axis Bank CC VIP: Account Active for ${name} [A/C ••${acct.slice(-4)}]`;
  const preheader = `Your Axis Bank CC VIP account has been successfully verified and activated with immediate access to Priority Corporate & Mobile Banking.`;

  const html = getBaseEmailWrapper(
    subject,
    '★ Official Welcome & Onboarding Kit ★',
    '#FFFBEB',
    '#861F41',
    preheader,
    `
      <div class="customer-greeting">Dear ${name},</div>
      <p style="font-size: 13.5px; line-height: 1.6; color: #334155; margin-bottom: 22px;">
        Welcome to <strong>Axis Bank CC VIP</strong>. We take immense pleasure in confirming that your Corporate &amp; Mobile Banking Account is successfully registered, verified by our Branch Administration, and active for immediate digital transactions.
      </p>

      <!-- Account Status Hero Card -->
      <div class="highlight-card" style="background: linear-gradient(135deg, #f0fdf4 0%, #dcfce7 100%); border: 1.5px solid #86efac; color: #166534;">
        <span style="font-size: 10px; text-transform: uppercase; font-weight: 900; letter-spacing: 1px; color: #15803d;">Institutional Ledger Status</span>
        <div class="amount-display" style="color: #15803d; font-size: 24px;">ACCOUNT ACTIVE &amp; VERIFIED</div>
        <span style="font-size: 11px; font-weight: 700; color: #166534;">Instant UPI 2.0 • IMPS/NEFT/RTGS • High-Yield Treasury Sweep</span>
      </div>

      <!-- Account Details Table -->
      <table class="table-details">
        <tr>
          <td class="label">Account Holder Name</td>
          <td class="value">${name}</td>
        </tr>
        <tr>
          <td class="label">CBS Account Number</td>
          <td class="value" style="font-family: monospace; font-size: 13px;">${acct}</td>
        </tr>
        <tr>
          <td class="label">Customer CIF Identifier</td>
          <td class="value" style="font-family: monospace; color: #861F41; font-size: 13px;">${cif}</td>
        </tr>
        <tr>
          <td class="label">Home Branch IFSC</td>
          <td class="value" style="font-family: monospace; font-size: 13px; color: #861F41;">${ifsc}</td>
        </tr>
        <tr>
          <td class="label">Assigned Branch</td>
          <td class="value">${branch}</td>
        </tr>
        <tr>
          <td class="label">Activation Timestamp</td>
          <td class="value">${time}</td>
        </tr>
      </table>

      <!-- Next Steps Guidance Card -->
      <div style="background-color: #f8fafc; border: 1px solid #e2e8f0; border-radius: 16px; padding: 20px; margin: 22px 0;">
        <h4 style="margin: 0 0 12px 0; font-size: 12px; font-weight: 900; text-transform: uppercase; color: #861F41; letter-spacing: 0.5px;">
          Next Steps to Experience Axis Bank CC VIP:
        </h4>
        <table style="width: 100%;" role="presentation">
          <tr>
            <td style="width: 24px; vertical-align: top; padding-right: 10px;">
              <div style="width: 22px; height: 22px; border-radius: 11px; background-color: #861F41; color: #ffffff; text-align: center; font-size: 11px; font-weight: 900; line-height: 22px;">1</div>
            </td>
            <td style="font-size: 12px; color: #334155; line-height: 1.5; padding-bottom: 10px;">
              <strong>Set your 4-Digit MPIN:</strong> Authenticate securely with your mobile number to set your biometric and PIN credentials.
            </td>
          </tr>
          <tr>
            <td style="width: 24px; vertical-align: top; padding-right: 10px;">
              <div style="width: 22px; height: 22px; border-radius: 11px; background-color: #861F41; color: #ffffff; text-align: center; font-size: 11px; font-weight: 900; line-height: 22px;">2</div>
            </td>
            <td style="font-size: 12px; color: #334155; line-height: 1.5; padding-bottom: 10px;">
              <strong>Virtual Debit Cards:</strong> Access your pre-issued high-limit virtual debit card with zero issuance fees and dynamic security CVV.
            </td>
          </tr>
          <tr>
            <td style="width: 24px; vertical-align: top; padding-right: 10px;">
              <div style="width: 22px; height: 22px; border-radius: 11px; background-color: #861F41; color: #ffffff; text-align: center; font-size: 11px; font-weight: 900; line-height: 22px;">3</div>
            </td>
            <td style="font-size: 12px; color: #334155; line-height: 1.5;">
              <strong>Instant UPI QR Collections:</strong> Receive immediate payments into your account with real-time soundbox and SMS notifications.
            </td>
          </tr>
        </table>
      </div>

      <div class="security-notice">
        <strong>🔒 RBI Security Mandate:</strong> Axis Bank personnel will never ask you for your confidential 4-Digit MPIN, NetBanking Password, OTP, or Card CVV. Keep your credentials private and report suspicious activity to <strong>${HELPLINE}</strong>.
      </div>
    `
  );

  const text = `Dear ${name},\n\nWelcome to Axis Bank CC VIP Mobile Banking & Corporate VIP Portal.\nYour account is active and verified.\n\nAccount Summary:\n- Name: ${name}\n- Account Number: ${acct}\n- Customer CIF: ${cif}\n- IFSC Code: ${ifsc}\n- Branch: ${branch}\n- Activated On: ${time}\n\nSecurity Notice: Axis Bank never asks for your MPIN, Password, or OTP.\n\nHelpline: ${HELPLINE}\nEmail: ${SUPPORT_EMAIL}\n${BANK_NAME}`;

  return { subject, html, text };
}

/**
 * 2. Real-Time Transaction Alert Email Template (Debit & Credit)
 * Styled as a luxury institutional banking advice voucher
 */
export function generateTransactionEmail(data: EmailTemplateData): RenderedEmail {
  const name = data.recipientName || 'Valued Customer';
  const type = (data.transactionType || 'DEBIT').toUpperCase() as 'DEBIT' | 'CREDIT';
  const isCredit = type === 'CREDIT';
  const amountNum = data.amount || 0;
  const formattedAmt = `₹${amountNum.toLocaleString('en-IN', { minimumFractionDigits: 2 })}`;
  const acctEnding = data.accountEnding || (data.accountNumber ? data.accountNumber.slice(-4) : '••••');
  const ref = data.referenceId || `AXIS${Date.now()}`;
  const desc = data.description || (isCredit ? 'Deposit / Funds Received' : 'Funds Transfer / Payment');
  const bal = data.balance !== undefined ? `₹${data.balance.toLocaleString('en-IN', { minimumFractionDigits: 2 })}` : 'Updated Real-time';
  const time = data.timestamp || new Date().toLocaleString('en-IN', { timeZone: 'Asia/Kolkata' });
  const mode = data.paymentMode || 'UPI 2.0 / IMPS Clearing';

  const subject = isCredit
    ? `Axis Bank Alert: ₹${amountNum.toLocaleString('en-IN')} Credited to your A/C ••${acctEnding}`
    : `Axis Bank Alert: ₹${amountNum.toLocaleString('en-IN')} Debited from your A/C ••${acctEnding}`;

  const preheader = isCredit
    ? `₹${amountNum.toLocaleString('en-IN')} has been credited to your Axis Bank CC VIP account ending ••${acctEnding}. Available balance: ${bal}.`
    : `₹${amountNum.toLocaleString('en-IN')} has been debited from your Axis Bank CC VIP account ending ••${acctEnding}. Ref: ${ref}.`;

  const badgeText = isCredit ? '★ Real-time Credit Advice (+) ★' : '★ Real-time Debit Advice (-) ★';
  const badgeBg = isCredit ? '#ECFDF5' : '#FFF1F2';
  const badgeColor = isCredit ? '#047857' : '#BE123C';

  const cardGradient = isCredit
    ? 'linear-gradient(135deg, #F0FDF4 0%, #DCFCE7 100%)'
    : 'linear-gradient(135deg, #FFF1F2 0%, #FFE4E6 100%)';
  const cardBorder = isCredit ? '#86EFAC' : '#FECDD3';
  const amountColor = isCredit ? '#15803D' : '#9F1239';

  const html = getBaseEmailWrapper(
    subject,
    badgeText,
    badgeBg,
    badgeColor,
    preheader,
    `
      <div class="customer-greeting">Dear ${name},</div>
      <p style="font-size: 13px; line-height: 1.6; color: #334155; margin-bottom: 20px;">
        This is an official transactional notification regarding your <strong>Axis Bank CC VIP Corporate Account</strong> ending in <strong>••${acctEnding}</strong>.
      </p>

      <!-- Transaction Amount Voucher Card -->
      <div class="highlight-card" style="background: ${cardGradient}; border: 1.5px solid ${cardBorder};">
        <span style="font-size: 10.5px; text-transform: uppercase; font-weight: 900; letter-spacing: 1px; color: ${amountColor};">
          ${isCredit ? 'Funds Credited to Ledger' : 'Funds Debited from Ledger'}
        </span>
        <div class="amount-display" style="color: ${amountColor};">
          ${isCredit ? '+' : '-'}${formattedAmt}
        </div>
        <span style="font-size: 11.5px; font-weight: 700; color: #475569;">
          Linked Account: •••• •••• •••• ${acctEnding}
        </span>
      </div>

      <!-- Transaction Audit Table -->
      <table class="table-details">
        <tr>
          <td class="label">Transaction Type</td>
          <td class="value" style="color: ${isCredit ? '#15803D' : '#BE123C'}; font-weight: 900;">
            ${isCredit ? 'CREDIT (INWARD SETTLEMENT)' : 'DEBIT (OUTWARD SETTLEMENT)'}
          </td>
        </tr>
        <tr>
          <td class="label">Amount Settled</td>
          <td class="value" style="font-size: 14px; color: ${amountColor}; font-weight: 900;">${formattedAmt}</td>
        </tr>
        <tr>
          <td class="label">Banking Reference / UTR</td>
          <td class="value" style="font-family: monospace; font-size: 13px;">${ref}</td>
        </tr>
        <tr>
          <td class="label">Particulars / Beneficiary</td>
          <td class="value">${desc}</td>
        </tr>
        <tr>
          <td class="label">Payment Network</td>
          <td class="value">${mode}</td>
        </tr>
        <tr>
          <td class="label">Execution Timestamp</td>
          <td class="value">${time}</td>
        </tr>
        ${data.balance !== undefined ? `
        <tr style="background-color: #f8fafc;">
          <td class="label" style="color: #861F41; font-weight: 900;">Updated Net Balance</td>
          <td class="value" style="color: #861F41; font-size: 14px; font-weight: 900;">${bal}</td>
        </tr>` : ''}
      </table>

      <div class="security-notice">
        <strong>⚠️ 24x7 Fraud Alert Desk:</strong> If this transaction was not authorized or initiated by you, please immediately call Axis Bank Priority Fraud Helpline at <strong>${HELPLINE}</strong> or freeze your account instantly from the Axis Bank CC VIP Mobile App.
      </div>
    `
  );

  const text = `Dear ${name},\n\nAxis Bank CC VIP Transaction Alert:\nYour A/C ending ••${acctEnding} has been ${type === 'CREDIT' ? 'credited' : 'debited'} with ${formattedAmt} on ${time}.\n\nDetails:\n- Reference / UTR: ${ref}\n- Description: ${desc}\n- Channel: ${mode}\n- Balance: ${bal}\n\nIf not initiated by you, immediately report to ${HELPLINE}.\n${BANK_NAME}`;

  return { subject, html, text };
}

/**
 * 3. Welcome Email with NetBanking Credentials & Virtual Debit Card
 * Dispatched when Admin or automated system issues NetBanking access & Customer ID
 */
export function generateWelcomeNetbankingEmail(data: EmailTemplateData): RenderedEmail {
  const name = data.recipientName || 'Valued Customer';
  const acct = data.accountNumber || (data.accountEnding ? `•••• •••• •••• ${data.accountEnding}` : '•••• CBS-VIP');
  const cif = data.cifNumber || 'AXIS8891002';
  const loginId = data.netbankingLoginId || `axis.${name.toLowerCase().replace(/[^a-z0-9]/g, '')}`;
  const tempPass = data.netbankingPassword || 'Axis@2026';
  const ifsc = data.ifscCode || IFSC_DEFAULT;
  const cardNo = data.virtualCardNumber || '•••• •••• •••• 4532';
  const cardVar = data.virtualCardVariant || 'Axis Burgundy Prestige Virtual Debit';
  const time = data.timestamp || new Date().toLocaleString('en-IN', { timeZone: 'Asia/Kolkata' });

  const subject = `Welcome to Axis Bank CC VIP: Your NetBanking Credentials & Virtual Card for A/C ••${acct.slice(-4)}`;
  const preheader = `Your Axis Bank CC VIP NetBanking access is ready. Customer ID: ${cif}, Login ID: ${loginId}. Please change password upon initial login.`;

  const html = getBaseEmailWrapper(
    subject,
    '★ Confidential NetBanking Credentials Kit ★',
    '#FFFBEB',
    '#861F41',
    preheader,
    `
      <div class="customer-greeting">Dear ${name},</div>
      <p style="font-size: 13.5px; line-height: 1.6; color: #334155; margin-bottom: 22px;">
        Welcome to <strong>Axis Bank CC VIP Corporate &amp; Priority Banking</strong>. Your institutional access has been authorized with full NetBanking privileges, high-limit digital transfers, and an instant Virtual Debit Card.
      </p>

      <!-- Luxury Obsidian Vault Card for Credentials -->
      <div class="highlight-card" style="background: linear-gradient(145deg, #0F172A 0%, #1E293B 100%); border: 2px solid #F59E0B; color: #ffffff; text-align: left; padding: 24px;">
        <div style="display: flex; justify-content: space-between; align-items: center; border-bottom: 1px solid rgba(245, 158, 11, 0.4); padding-bottom: 12px; margin-bottom: 16px;">
          <span style="font-size: 10px; font-weight: 900; text-transform: uppercase; letter-spacing: 1.5px; color: #FDE047;">CONFIDENTIAL ACCESS CREDENTIALS</span>
          <span style="font-size: 10px; background-color: #861F41; color: #ffffff; padding: 2px 8px; border-radius: 4px; font-weight: 800;">ENCRYPTED</span>
        </div>

        <table style="width: 100%; color: #ffffff; font-size: 13px;" role="presentation">
          <tr>
            <td style="padding: 6px 0; color: #94A3B8; font-size: 11px; text-transform: uppercase; font-weight: 700;">Customer ID (Cust ID / CIF)</td>
            <td style="padding: 6px 0; text-align: right; font-family: monospace; font-size: 15px; font-weight: 900; color: #FDE047;">${cif}</td>
          </tr>
          <tr>
            <td style="padding: 6px 0; color: #94A3B8; font-size: 11px; text-transform: uppercase; font-weight: 700;">NetBanking Login ID</td>
            <td style="padding: 6px 0; text-align: right; font-family: monospace; font-size: 15px; font-weight: 900; color: #FFFFFF;">${loginId}</td>
          </tr>
          <tr>
            <td style="padding: 6px 0; color: #FCA5A5; font-size: 11px; text-transform: uppercase; font-weight: 700;">Temporary Access Password</td>
            <td style="padding: 6px 0; text-align: right; font-family: monospace; font-size: 15px; font-weight: 900; color: #FCA5A5; letter-spacing: 1px;">${tempPass}</td>
          </tr>
          <tr>
            <td style="padding: 6px 0; color: #94A3B8; font-size: 11px; text-transform: uppercase; font-weight: 700;">Default IFSC Code</td>
            <td style="padding: 6px 0; text-align: right; font-family: monospace; font-size: 13px; color: #FDE047;">${ifsc}</td>
          </tr>
        </table>
        
        <div style="margin-top: 14px; padding-top: 10px; border-top: 1px dashed rgba(255, 255, 255, 0.2); font-size: 10.5px; color: #94A3B8;">
          * Mandatory: Please change your temporary password immediately upon your first sign-in.
        </div>
      </div>

      <!-- Account & Virtual Card Specification Table -->
      <table class="table-details">
        <tr>
          <td class="label">Customer Full Name</td>
          <td class="value">${name}</td>
        </tr>
        <tr>
          <td class="label">Core CBS Account Number</td>
          <td class="value" style="font-family: monospace; font-size: 13px;">${acct}</td>
        </tr>
        <tr>
          <td class="label">Virtual Debit Instrument</td>
          <td class="value" style="color: #861F41; font-weight: 900;">${cardVar}</td>
        </tr>
        <tr>
          <td class="label">Card Number Reference</td>
          <td class="value" style="font-family: monospace;">${cardNo}</td>
        </tr>
        <tr>
          <td class="label">Issuing Authority</td>
          <td class="value">Branch Officer Administration, Axis Bank</td>
        </tr>
        <tr>
          <td class="label">Issuance Timestamp</td>
          <td class="value">${time}</td>
        </tr>
      </table>

      <!-- Activation Instructions -->
      <div style="background-color: #f8fafc; border: 1px solid #e2e8f0; border-radius: 16px; padding: 20px; margin: 20px 0;">
        <h4 style="margin: 0 0 10px 0; font-size: 12px; font-weight: 900; text-transform: uppercase; color: #861F41;">
          Quick Sign-In Guide:
        </h4>
        <ol style="margin: 0; padding-left: 20px; font-size: 12px; line-height: 1.6; color: #475569;">
          <li>Open the <strong>Axis Bank CC VIP Portal</strong> and select the <strong>Cust ID</strong> tab.</li>
          <li>Enter your Login ID: <code>${loginId}</code> and Temporary Password.</li>
          <li>Set up your confidential 4-Digit MPIN for rapid biometric login.</li>
          <li>Activate card controls &amp; transaction limits from the VIP dashboard.</li>
        </ol>
      </div>

      <div class="security-notice">
        <strong>🔒 Critical Security Mandate:</strong> Axis Bank will NEVER phone, text, or email you asking for your password, MPIN, or OTP. If anyone contacts you claiming to be from Axis Bank and requests credentials, terminate the call and notify our 24x7 Security Center at <strong>${HELPLINE}</strong>.
      </div>
    `
  );

  const text = `Dear ${name},\n\nWelcome to Axis Bank CC VIP Corporate & Priority Banking.\n\nYour NetBanking Credentials:\n- Customer ID: ${cif}\n- NetBanking Login ID: ${loginId}\n- Temporary Password: ${tempPass}\n- Account Number: ${acct}\n- IFSC: ${ifsc}\n- Virtual Debit Card: ${cardVar} (${cardNo})\n\nPlease change your temporary password on first login.\n\nHelpline: ${HELPLINE}\nEmail: ${SUPPORT_EMAIL}\n${BANK_NAME}`;

  return { subject, html, text };
}

/**
 * 4. Virtual Debit Card Issuance / Update Email Template
 * Highlights luxury card benefits, daily limits, and dynamic CVV protection
 */
export function generateVirtualCardEmail(data: EmailTemplateData): RenderedEmail {
  const name = data.recipientName || 'Valued Customer';
  const cardNo = data.virtualCardNumber || '•••• •••• •••• 4532';
  const variant = data.virtualCardVariant || 'Axis Burgundy Prestige Virtual Debit';
  const limit = data.virtualCardLimit ? `₹${data.virtualCardLimit.toLocaleString('en-IN')}` : '₹5,00,000';
  const time = data.timestamp || new Date().toLocaleString('en-IN', { timeZone: 'Asia/Kolkata' });

  const subject = `Axis Bank CC VIP: Your ${variant} is Active & Ready (${cardNo.slice(-4)})`;
  const preheader = `Your ${variant} ending in ${cardNo.slice(-4)} has been successfully authorized with an instant daily purchase limit of ${limit}.`;

  const html = getBaseEmailWrapper(
    subject,
    '★ Virtual Debit Instrument Advisory ★',
    '#ECFDF5',
    '#047857',
    preheader,
    `
      <div class="customer-greeting">Dear ${name},</div>
      <p style="font-size: 13.5px; line-height: 1.6; color: #334155; margin-bottom: 22px;">
        We are delighted to confirm that your <strong>${variant}</strong> is authorized and ready for instant digital commerce, merchant payments, and priority banking operations.
      </p>

      <!-- Photorealistic Virtual Card Hero Representation -->
      <div style="background: linear-gradient(135deg, #580824 0%, #861F41 50%, #9E144D 100%); border: 2px solid #F59E0B; border-radius: 20px; padding: 26px; color: #ffffff; box-shadow: 0 12px 24px rgba(134, 31, 65, 0.25); margin: 22px 0;">
        <table style="width: 100%; color: #ffffff;" role="presentation">
          <tr>
            <td style="vertical-align: top;">
              <span style="font-size: 10px; font-weight: 900; letter-spacing: 2px; color: #FDE047; text-transform: uppercase;">AXIS BANK CC VIP</span>
              <div style="font-size: 12px; font-weight: 700; color: #FFFFFF; opacity: 0.9;">${variant}</div>
            </td>
            <td style="text-align: right; vertical-align: top;">
              <span style="background-color: rgba(255, 255, 255, 0.2); border: 1px solid rgba(254, 240, 138, 0.4); padding: 3px 10px; border-radius: 12px; font-size: 9.5px; font-weight: 900; color: #FEF08A;">VIP PLATINUM</span>
            </td>
          </tr>
          <tr>
            <td colspan="2" style="padding: 24px 0 16px 0;">
              <div style="font-family: monospace; font-size: 22px; font-weight: 900; letter-spacing: 4px; color: #FFFFFF; text-shadow: 0 2px 4px rgba(0,0,0,0.5);">
                ${cardNo}
              </div>
            </td>
          </tr>
          <tr>
            <td style="vertical-align: bottom;">
              <div style="font-size: 9px; text-transform: uppercase; color: #FDE68A; font-weight: 700;">Cardholder</div>
              <div style="font-size: 13px; font-weight: 900; color: #FFFFFF; text-transform: uppercase;">${name}</div>
            </td>
            <td style="text-align: right; vertical-align: bottom;">
              <div style="font-size: 9px; text-transform: uppercase; color: #FDE68A; font-weight: 700;">Daily Purchase Limit</div>
              <div style="font-size: 14px; font-weight: 900; color: #FEF08A;">${limit}</div>
            </td>
          </tr>
        </table>
      </div>

      <!-- Card Parameter Details -->
      <table class="table-details">
        <tr>
          <td class="label">Assigned Instrument</td>
          <td class="value">${variant}</td>
        </tr>
        <tr>
          <td class="label">Operating Status</td>
          <td class="value" style="color: #15803D; font-weight: 900;">ACTIVE (INSTANT DIGITAL READY)</td>
        </tr>
        <tr>
          <td class="label">Daily Purchase Capacity</td>
          <td class="value" style="color: #861F41; font-weight: 900;">${limit}</td>
        </tr>
        <tr>
          <td class="label">Security Architecture</td>
          <td class="value">Dynamic 3D Secure 2.0 &amp; Dynamic CVV</td>
        </tr>
        <tr>
          <td class="label">Domestic / International</td>
          <td class="value">Toggleable via Mobile App Settings</td>
        </tr>
        <tr>
          <td class="label">Authorized On</td>
          <td class="value">${time}</td>
        </tr>
      </table>

      <div class="security-notice">
        <strong>💡 Card Management Tip:</strong> You can manage transaction limits, freeze/unfreeze your virtual card, and toggle international e-commerce anytime directly from your Axis Bank CC VIP Dashboard.
      </div>
    `
  );

  const text = `Dear ${name},\n\nYour ${variant} (${cardNo}) has been issued and activated.\nDaily Purchase Limit: ${limit}\nActivated: ${time}\n\nManage limits and freeze/unfreeze anytime via Axis Bank CC VIP.\nHelpline: ${HELPLINE}\n${BANK_NAME}`;

  return { subject, html, text };
}

/**
 * 5. Admin Custom / Individual Communication Email Template
 * Official executive memorandum dispatched by authorized Branch Officers
 */
export function generateAdminCustomEmail(data: EmailTemplateData): RenderedEmail {
  const name = data.recipientName || 'Valued Customer';
  const subject = data.customSubject || `Important Advisory from Axis Bank CC VIP`;
  const title = data.customTitle || 'Official Institutional Advisory';
  const messageBody = data.customMessage || 'We are reaching out regarding your account with Axis Bank CC VIP.';
  const acct = data.accountNumber || (data.accountEnding ? `•••• •••• •••• ${data.accountEnding}` : undefined);
  const time = data.timestamp || new Date().toLocaleString('en-IN', { timeZone: 'Asia/Kolkata' });

  const preheader = `${subject} - Dispatched by Axis Bank Branch Officer Administration.`;

  // Convert plain text newlines to clean, styled HTML paragraphs
  const formattedParagraphs = messageBody
    .split('\n\n')
    .map((p) => `<p style="font-size: 13.5px; line-height: 1.65; color: #334155; margin-bottom: 14px;">${p.replace(/\n/g, '<br/>')}</p>`)
    .join('');

  const html = getBaseEmailWrapper(
    subject,
    `★ ${title} ★`,
    '#FEF3C7',
    '#B45309',
    preheader,
    `
      <div class="customer-greeting">Dear ${name},</div>

      <!-- Executive Message Body -->
      <div style="background-color: #f8fafc; border: 1.5px solid #e2e8f0; border-left: 5px solid #861F41; border-radius: 16px; padding: 24px; margin: 20px 0;">
        ${formattedParagraphs}
      </div>

      ${acct ? `
      <table class="table-details">
        <tr>
          <td class="label">Customer Full Name</td>
          <td class="value">${name}</td>
        </tr>
        <tr>
          <td class="label">Linked CBS Account</td>
          <td class="value" style="font-family: monospace; font-size: 13px;">${acct}</td>
        </tr>
        <tr>
          <td class="label">Dispatched Timestamp</td>
          <td class="value">${time}</td>
        </tr>
        <tr>
          <td class="label">Authorized Branch Officer</td>
          <td class="value">Branch Officer Administration, Axis Bank</td>
        </tr>
      </table>` : ''}

      <div class="security-notice">
        <strong>⚠️ Compliance Advisory:</strong> This official communication was dispatched directly by an authorized Branch Officer from the Axis Bank Core Banking Terminal. For questions or in-person assistance, visit your home branch or call <strong>${HELPLINE}</strong>.
      </div>
    `
  );

  const text = `Dear ${name},\n\n${subject}\n\n${messageBody}\n\nDispatched: ${time}\nAuthority: Axis Bank Branch Officer Administration\nHelpline: ${HELPLINE}\n${BANK_NAME}`;

  return { subject, html, text };
}

/**
 * 6. Profile & Services Update Confirmation Email Template
 * Dispatched when account preferences, security, or profile settings are modified
 */
export function generateServiceUpdateEmail(data: EmailTemplateData): RenderedEmail {
  const name = data.recipientName || 'Valued Customer';
  const type = data.updateType || 'Profile & Services Configuration';
  const details = data.updateDetails || 'Your requested banking modifications have been successfully reconciled and processed.';
  const time = data.timestamp || new Date().toLocaleString('en-IN', { timeZone: 'Asia/Kolkata' });

  const subject = `Axis Bank Notification: ${type} Processed Successfully`;
  const preheader = `Your requested account modification (${type}) has been processed and logged in the Axis Bank CC VIP CBS ledger on ${time}.`;

  const html = getBaseEmailWrapper(
    subject,
    '★ Service Authorization Notice ★',
    '#EFF6FF',
    '#1D4ED8',
    preheader,
    `
      <div class="customer-greeting">Dear ${name},</div>
      <p style="font-size: 13.5px; line-height: 1.6; color: #334155; margin-bottom: 22px;">
        This is an official confirmation from <strong>Axis Bank CC VIP Core Banking System (CBS)</strong> regarding changes applied to your account profile and service preferences.
      </p>

      <!-- Status Highlight Card -->
      <div class="highlight-card" style="background: linear-gradient(135deg, #f8fafc 0%, #f1f5f9 100%); border: 1.5px solid #cbd5e1;">
        <span style="font-size: 10px; text-transform: uppercase; font-weight: 800; color: #64748b; letter-spacing: 0.8px;">Modification Scope</span>
        <div style="font-size: 18px; font-weight: 900; margin: 6px 0; color: #861F41;">${type}</div>
        <span style="font-size: 11.5px; color: #15803D; font-weight: 800;">STATUS: APPROVED &amp; RECONCILED</span>
      </div>

      <!-- Update Details Box -->
      <div style="background-color: #ffffff; border: 1px solid #e2e8f0; border-radius: 16px; padding: 20px; margin: 20px 0; font-size: 13px; line-height: 1.6; color: #334155;">
        <strong style="color: #0f172a; text-transform: uppercase; font-size: 11px; letter-spacing: 0.5px;">Summary of Modifications:</strong>
        <p style="margin: 8px 0 0 0; color: #475569; font-weight: 600;">${details}</p>
      </div>

      <!-- Audit Metadata Table -->
      <table class="table-details">
        <tr>
          <td class="label">Customer Full Name</td>
          <td class="value">${name}</td>
        </tr>
        <tr>
          <td class="label">Reconciliation Timestamp</td>
          <td class="value">${time}</td>
        </tr>
        <tr>
          <td class="label">Processing Authority</td>
          <td class="value">Axis Bank Core CBS Operations</td>
        </tr>
        <tr>
          <td class="label">Record Status</td>
          <td class="value" style="color: #15803D; font-weight: 900;">LIVE IN CORE SYSTEM</td>
        </tr>
      </table>

      <div class="security-notice">
        <strong>⚠️ Security Advisory:</strong> If you did not initiate or approve this modification, please contact our Priority Fraud Desk immediately at <strong>${HELPLINE}</strong> to block unauthorized changes.
      </div>
    `
  );

  const text = `Dear ${name},\n\nYour ${type} has been successfully processed on ${time}.\nDetails: ${details}\n\nIf you did not request this, contact ${HELPLINE} immediately.\n${BANK_NAME}`;

  return { subject, html, text };
}
