/**
 * Date and Timestamp Utilities for Banking Operations
 * Axis Bank CC VIP • Mobile Banking
 */

const MONTHS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

/**
 * Returns a standardized banking timestamp in Indian CBS format:
 * e.g., "21 Sep 2026, 06:45 PM"
 */
export function formatBankingTimestamp(input?: Date | string | number | null): string {
  if (!input) return getNowBankingTimestamp();

  let d: Date;
  if (typeof input === 'number') {
    d = new Date(input);
  } else if (input instanceof Date) {
    d = input;
  } else {
    // If it's already formatted like "21 Sep 2026, 06:45 PM", keep it
    if (/^\d{2}\s+[A-Za-z]{3}\s+\d{4},\s+\d{2}:\d{2}\s+(?:AM|PM)$/i.test(input.trim())) {
      return input.trim();
    }
    d = new Date(input);
  }

  if (isNaN(d.getTime())) {
    return getNowBankingTimestamp();
  }

  const day = String(d.getDate()).padStart(2, '0');
  const month = MONTHS[d.getMonth()];
  const year = d.getFullYear();

  let hours = d.getHours();
  const minutes = String(d.getMinutes()).padStart(2, '0');
  const ampm = hours >= 12 ? 'PM' : 'AM';
  hours = hours % 12;
  hours = hours ? hours : 12; // 0 hour should be 12
  const hoursStr = String(hours).padStart(2, '0');

  return `${day} ${month} ${year}, ${hoursStr}:${minutes} ${ampm}`;
}

/**
 * Current timestamp in standard banking format
 */
export function getNowBankingTimestamp(): string {
  const now = new Date();
  const day = String(now.getDate()).padStart(2, '0');
  const month = MONTHS[now.getMonth()];
  const year = now.getFullYear();

  let hours = now.getHours();
  const minutes = String(now.getMinutes()).padStart(2, '0');
  const ampm = hours >= 12 ? 'PM' : 'AM';
  hours = hours % 12;
  hours = hours ? hours : 12;
  const hoursStr = String(hours).padStart(2, '0');

  return `${day} ${month} ${year}, ${hoursStr}:${minutes} ${ampm}`;
}

/**
 * Accurately resolves and formats a transaction timestamp.
 * Eliminates generic "Just now" tags by deriving real time from
 * raw timestamp, createdAt, or tx ID numeric sequence.
 */
export function formatTransactionTimestamp(
  rawTimestamp?: string | null,
  createdAt?: string | Date | null,
  txId?: string | null
): string {
  // Check if rawTimestamp is a legitimate timestamp (not 'Just now')
  if (rawTimestamp && typeof rawTimestamp === 'string') {
    const trimmed = rawTimestamp.trim();
    const isPlaceholder = /^just\s*now$/i.test(trimmed);
    if (!isPlaceholder && trimmed.length > 0) {
      // If it's already nicely formatted, return it
      if (/^\d{2}\s+[A-Za-z]{3}\s+\d{4}/i.test(trimmed) || /^\d{1,2}\/\d{1,2}\/\d{4}/.test(trimmed)) {
        return trimmed;
      }
      const parsed = new Date(trimmed);
      if (!isNaN(parsed.getTime())) {
        return formatBankingTimestamp(parsed);
      }
    }
  }

  // Fallback 1: Use createdAt if valid
  if (createdAt) {
    const createdDate = typeof createdAt === 'string' ? new Date(createdAt) : createdAt;
    if (!isNaN(createdDate.getTime())) {
      return formatBankingTimestamp(createdDate);
    }
  }

  // Fallback 2: Extract timestamp embedded in transaction ID (e.g. tx_1788341726853)
  if (txId) {
    const match = txId.match(/(\d{12,14})/);
    if (match) {
      const numMs = parseInt(match[1], 10);
      if (numMs > 1577836800000 && numMs < 2524608000000) {
        return formatBankingTimestamp(numMs);
      }
    }
  }

  // Fallback 3: Return current banking timestamp
  return getNowBankingTimestamp();
}

/**
 * Formats time for push alerts or notification drawers
 */
export function formatAlertTime(dateInput?: Date | string | number | null): string {
  if (!dateInput) return getNowBankingTimestamp();
  const d = typeof dateInput === 'number' ? new Date(dateInput) : new Date(dateInput);
  if (isNaN(d.getTime())) return getNowBankingTimestamp();

  const now = new Date();
  const diffMs = now.getTime() - d.getTime();

  // If created within the last 2 minutes
  if (diffMs >= 0 && diffMs < 2 * 60 * 1000) {
    let hours = d.getHours();
    const minutes = String(d.getMinutes()).padStart(2, '0');
    const ampm = hours >= 12 ? 'PM' : 'AM';
    hours = hours % 12 || 12;
    return `Today at ${String(hours).padStart(2, '0')}:${minutes} ${ampm}`;
  }

  return formatBankingTimestamp(d);
}
