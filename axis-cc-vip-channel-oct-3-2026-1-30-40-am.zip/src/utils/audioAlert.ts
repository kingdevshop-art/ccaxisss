import { LanguageCode } from '../types';
import { playNativeSoundboxAlert } from './nativeBridge';

let cachedAudioCtx: AudioContext | null = null;

function getAudioContext(): AudioContext | null {
  try {
    if (!cachedAudioCtx) {
      const AudioContextClass =
        window.AudioContext || (window as any).webkitAudioContext;
      if (AudioContextClass) {
        cachedAudioCtx = new AudioContextClass();
      }
    }
    if (cachedAudioCtx && cachedAudioCtx.state === 'suspended') {
      cachedAudioCtx.resume().catch(() => {});
    }
    return cachedAudioCtx;
  } catch (err) {
    console.error('AudioContext initialization error:', err);
    return null;
  }
}

// Crisp scanner recognition beep when QR is detected
export function playScannerBeep() {
  try {
    const ctx = getAudioContext();
    if (!ctx) return;

    const osc = ctx.createOscillator();
    const gain = ctx.createGain();

    osc.type = 'triangle';
    osc.frequency.setValueAtTime(1400, ctx.currentTime);
    osc.frequency.exponentialRampToValueAtTime(1800, ctx.currentTime + 0.08);

    gain.gain.setValueAtTime(0.3, ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.12);

    osc.connect(gain);
    gain.connect(ctx.destination);

    osc.start(ctx.currentTime);
    osc.stop(ctx.currentTime + 0.13);
  } catch (err) {
    console.error('Scanner beep error:', err);
  }
}

// Pleasant 4-note Airtel/NPCI soundbox jingle
export function playSoundboxChime() {
  try {
    const ctx = getAudioContext();
    if (!ctx) return;

    const notes = [523.25, 659.25, 783.99, 1046.5];
    notes.forEach((freq, index) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();

      osc.type = 'sine';
      osc.frequency.setValueAtTime(freq, ctx.currentTime + index * 0.11);

      gain.gain.setValueAtTime(0, ctx.currentTime + index * 0.11);
      gain.gain.linearRampToValueAtTime(0.28, ctx.currentTime + index * 0.11 + 0.03);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + index * 0.11 + 0.38);

      osc.connect(gain);
      gain.connect(ctx.destination);

      osc.start(ctx.currentTime + index * 0.11);
      osc.stop(ctx.currentTime + index * 0.11 + 0.42);
    });
  } catch (err) {
    console.error('Audio chime error:', err);
  }
}

export interface SoundboxAlertOptions {
  type: 'CREDIT' | 'DEBIT';
  amount: number;
  recipientName?: string;
  senderName?: string;
  language?: LanguageCode;
  customText?: string;
}

/**
 * Robust Soundbox Voice Announcement for BOTH Receiving and Sending money
 * Speaks correctly in Hindi, Bengali, English, and other regional languages.
 */
export function speakSoundboxTransactionAlert({
  type,
  amount,
  recipientName,
  senderName,
  language = 'en',
  customText,
}: SoundboxAlertOptions) {
  // Always play the iconic soundbox chime immediately
  playSoundboxChime();

  if (!('speechSynthesis' in window)) return;

  setTimeout(() => {
    try {
      window.speechSynthesis.cancel();

      let message = customText;
      let langCode = 'en-IN';

      if (!message) {
        if (type === 'CREDIT') {
          // RECEIVING MONEY
          switch (language) {
            case 'hi':
              message = senderName
                ? `एक्सिस बैंक सीसी वीआईपी पर ${senderName} से ${amount} रुपये प्राप्त हुए।`
                : `एक्सिस बैंक सीसी वीआईपी पर ${amount} रुपये प्राप्त हुए।`;
              langCode = 'hi-IN';
              break;
            case 'bn':
              message = senderName
                ? `অ্যাক্সিস ব্যাংক সিসি ভিআইপিতে ${senderName}-এর কাছ থেকে ${amount} টাকা জমা হয়েছে।`
                : `অ্যাক্সিস ব্যাংক সিসি ভিআইপিতে ${amount} টাকা জমা হয়েছে।`;
              langCode = 'bn-IN';
              break;
            case 'te':
              message = `యాక్సిస్ బ్యాంక్ సిసి విఐపిలో ${amount} రూపాయలు జమయ్యాయి.`;
              langCode = 'te-IN';
              break;
            case 'mr':
              message = `अ‍ॅक्सिस बँक सीसी व्हीआयपीमध्ये ${amount} रुपये प्राप्त झाले.`;
              langCode = 'mr-IN';
              break;
            case 'ta':
              message = `ஆக்சிஸ் வங்கி சிசி விஐபியில் ${amount} ரூபாய் பெறப்பட்டது.`;
              langCode = 'ta-IN';
              break;
            case 'gu':
              message = `એક્સિસ બેંક સીસી વીઆઇપીમાં ${amount} રૂપિયા મળ્યા.`;
              langCode = 'gu-IN';
              break;
            case 'kn':
              message = `ಆಕ್ಸಿಸ್ ಬ್ಯಾಂಕ್ ಸಿಸಿ ವಿಐಪಿಯಲ್ಲಿ ${amount} ರೂಪಾಯಿ ಸ್ವೀಕರಿಸಲಾಗಿದೆ.`;
              langCode = 'kn-IN';
              break;
            case 'pa':
              message = `ਐਕਸਿਸ ਬੈਂਕ ਸੀਸੀ ਵੀਆਈਪੀ ਵਿੱਚ ${amount} ਰੁਪਏ ਪ੍ਰਾਪਤ ਹੋਏ।`;
              langCode = 'pa-IN';
              break;
            case 'bho':
              message = `एक्सिस बैंक सीसी वीआईपी पर ${amount} रुपया मिलल।`;
              langCode = 'hi-IN';
              break;
            case 'en':
            default:
              message = senderName
                ? `${amount} Rupees received from ${senderName} on Axis Bank CC VIP.`
                : `${amount} Rupees received on Axis Bank CC VIP.`;
              langCode = 'en-IN';
              break;
          }
        } else {
          // SENDING MONEY (DEBIT)
          const payee = recipientName ? `to ${recipientName}` : '';
          switch (language) {
            case 'hi':
              message = recipientName
                ? `एक्सिस बैंक सीसी वीआईपी से ${recipientName} को ${amount} रुपये का भुगतान सफलतापूर्वक भेजा गया।`
                : `एक्सिस बैंक सीसी वीआईपी से ${amount} रुपये का भुगतान सफलतापूर्वक पूरा हुआ।`;
              langCode = 'hi-IN';
              break;
            case 'bn':
              message = recipientName
                ? `অ্যাক্সিস ব্যাংক সিসি ভিআইপি থেকে ${recipientName}-কে ${amount} টাকা সফলভাবে পাঠানো হয়েছে।`
                : `অ্যাক্সিস ব্যাংক সিসি ভিআইপি থেকে ${amount} টাকা সফলভাবে পাঠানো হয়েছে।`;
              langCode = 'bn-IN';
              break;
            case 'te':
              message = `యాక్సిస్ బ్యాంక్ సిసి విఐపి నుండి ${amount} రూపాయల చెల్లింపు విజయవంతమైంది.`;
              langCode = 'te-IN';
              break;
            case 'mr':
              message = `अ‍ॅक्सिस बँक सीसी व्हीआयपीमधून ${amount} रुपयांचे पेमेंट यशस्वीरित्या पाठवले गेले.`;
              langCode = 'mr-IN';
              break;
            case 'ta':
              message = `ஆக்சிஸ் வங்கி சிசி விஐபியிலிருந்து ${amount} ரூபாய் வெற்றிகரமாக செலுத்தப்பட்டது.`;
              langCode = 'ta-IN';
              break;
            case 'gu':
              message = `એક્સિસ બેંક સીસી વીઆઇપીમાંથી ${amount} રૂપિયાની ચુકવણી સફળ થઈ.`;
              langCode = 'gu-IN';
              break;
            case 'kn':
              message = `ಆಕ್ಸಿಸ್ ಬ್ಯಾಂಕ್ ಸಿಸಿ ವಿಐಪಿಯಿಂದ ${amount} ರೂಪಾಯಿ ಯಶಸ್ವಿಯಾಗಿ ಕಳುಹಿಸಲಾಗಿದೆ.`;
              langCode = 'kn-IN';
              break;
            case 'pa':
              message = `ਐਕਸਿਸ ਬੈਂਕ ਸੀਸੀ ਵੀਆਈਪੀ ਤੋਂ ${amount} ਰੁਪਏ ਸਫਲਤਾਪੂਰਵਕ ਭੇਜੇ ਗਏ।`;
              langCode = 'pa-IN';
              break;
            case 'bho':
              message = `एक्सिस बैंक सीसी वीआईपी से ${amount} रुपया के भुगतान सफल भइल।`;
              langCode = 'hi-IN';
              break;
            case 'en':
            default:
              message = recipientName
                ? `Payment of ${amount} Rupees to ${recipientName} successful from Axis Bank CC VIP.`
                : `Payment of ${amount} Rupees successful from Axis Bank CC VIP.`;
              langCode = 'en-IN';
              break;
          }
        }
      }

      // Delegate to native Android Soundbox engine if available
      if (message && playNativeSoundboxAlert(message, language)) {
        return;
      }

      const utterance = new SpeechSynthesisUtterance(message);
      utterance.lang = langCode;
      utterance.rate = 0.96;
      utterance.pitch = 1.02;

      // Select best matching Indian accent / voice
      const voices = window.speechSynthesis.getVoices();
      const inVoice = voices.find(
        (v) =>
          v.lang.toLowerCase().includes(langCode.toLowerCase().slice(0, 2)) ||
          v.lang.includes('IN') ||
          v.name.includes('India')
      );
      if (inVoice) {
        utterance.voice = inVoice;
      }

      window.speechSynthesis.speak(utterance);
    } catch (err) {
      console.error('Speech synthesis alert error:', err);
    }
  }, 480);
}

// Backward compatibility export
export function speakSoundboxAlert(
  amount: number,
  language: LanguageCode = 'hi',
  customText?: string
) {
  speakSoundboxTransactionAlert({
    type: 'CREDIT',
    amount,
    language,
    customText,
  });
}
