/**
 * Banking Account & Security Utilities
 * Axis Bank CC VIP • Mobile Banking
 */

/**
 * Generates a unique, random 12-digit bank account number.
 * Conforms to Indian Core Banking System (CBS) standards.
 * Guaranteed to NOT be a 10-digit mobile number.
 */
export function generateRandomAccountNumber(existingAccounts?: string[]): string {
  let acct: string;
  let attempts = 0;
  do {
    // Axis Bank series prefix '91' followed by 10 random digits
    // Total length is exactly 12 digits
    const prefix = '50';
    const random10 = Math.floor(1000000000 + Math.random() * 9000000000).toString();
    acct = `${prefix}${random10}`;
    attempts++;
  } while (existingAccounts && existingAccounts.includes(acct) && attempts < 100);

  return acct;
}

const THIRTY_DAYS_MS = 30 * 24 * 60 * 60 * 1000;

export interface PhotoEligibilityResult {
  eligible: boolean;
  daysRemaining: number;
  nextEligibleDate: string | null;
  lastUpdatedFormatted: string | null;
}

/**
 * Checks if the user is eligible to update their profile photo.
 * Policy: Profile photo can be updated once per month (every 30 days).
 */
export function checkProfilePhotoEligibility(profilePhotoUpdatedAt?: string): PhotoEligibilityResult {
  if (!profilePhotoUpdatedAt) {
    return {
      eligible: true,
      daysRemaining: 0,
      nextEligibleDate: null,
      lastUpdatedFormatted: null,
    };
  }

  const lastTime = new Date(profilePhotoUpdatedAt).getTime();
  if (isNaN(lastTime)) {
    return {
      eligible: true,
      daysRemaining: 0,
      nextEligibleDate: null,
      lastUpdatedFormatted: null,
    };
  }

  const now = Date.now();
  const diff = now - lastTime;

  const lastUpdatedFormatted = new Date(lastTime).toLocaleDateString('en-IN', {
    day: 'numeric',
    month: 'short',
    year: 'numeric',
  });

  if (diff >= THIRTY_DAYS_MS) {
    return {
      eligible: true,
      daysRemaining: 0,
      nextEligibleDate: null,
      lastUpdatedFormatted,
    };
  }

  const remainingMs = THIRTY_DAYS_MS - diff;
  const daysRemaining = Math.max(1, Math.ceil(remainingMs / (24 * 60 * 60 * 1000)));
  const nextEligibleDate = new Date(lastTime + THIRTY_DAYS_MS).toLocaleDateString('en-IN', {
    day: 'numeric',
    month: 'short',
    year: 'numeric',
  });

  return {
    eligible: false,
    daysRemaining,
    nextEligibleDate,
    lastUpdatedFormatted,
  };
}

/**
 * Generates a cryptographically sound active session token for single device login.
 */
export function generateSessionToken(): string {
  const rand1 = Math.random().toString(36).substring(2, 10);
  const rand2 = Math.random().toString(36).substring(2, 10);
  return `sess_${Date.now()}_${rand1}${rand2}`;
}
