import QRCode from 'qrcode';
import { UserProfile } from '../types';

/**
 * Generates an active, standard NPCI UPI QR code Data URL for any user.
 * Encodes upi://pay?pa=...&pn=...&cu=INR
 */
export async function generateUserQrCode(
  user: UserProfile,
  requestedAmount?: number
): Promise<string> {
  const upiId = user.upiId || `${user.phone}@axisbank`;
  const name = user.name || 'Axis Bank CC VIP Account Holder';

  const upiUri =
    requestedAmount && requestedAmount > 0
      ? `upi://pay?pa=${upiId}&pn=${encodeURIComponent(name)}&am=${requestedAmount}&cu=INR&mc=0000`
      : `upi://pay?pa=${upiId}&pn=${encodeURIComponent(name)}&cu=INR&mc=0000`;

  try {
    const dataUrl = await QRCode.toDataURL(upiUri, {
      errorCorrectionLevel: 'H',
      margin: 2,
      width: 340,
      color: {
        dark: '#580824',
        light: '#ffffff',
      },
    });
    return dataUrl;
  } catch (err) {
    console.error('Error generating QR code:', err);
    return '';
  }
}

/**
 * Parses raw text from a scanned QR code (camera or gallery upload)
 * Extracts UPI VPA, Payee Name, Preset Amount, IFSC, or Account details.
 */
export function parseUpiQr(qrText: string): {
  upiId?: string;
  name?: string;
  amount?: number;
  accountNumber?: string;
  ifsc?: string;
  raw: string;
} {
  const trimmed = qrText.trim();
  const result: {
    upiId?: string;
    name?: string;
    amount?: number;
    accountNumber?: string;
    ifsc?: string;
    raw: string;
  } = { raw: trimmed };

  if (trimmed.startsWith('upi://') || trimmed.includes('pa=')) {
    try {
      const queryIndex = trimmed.indexOf('?');
      const searchParams = new URLSearchParams(
        queryIndex !== -1 ? trimmed.slice(queryIndex) : trimmed
      );
      result.upiId = searchParams.get('pa') || undefined;
      result.name = searchParams.get('pn')
        ? decodeURIComponent(searchParams.get('pn')!)
        : undefined;
      const am = searchParams.get('am');
      if (am && !isNaN(parseFloat(am))) {
        result.amount = parseFloat(am);
      }
      result.accountNumber = searchParams.get('acc') || undefined;
      result.ifsc = searchParams.get('ifsc') || undefined;
    } catch {
      const paMatch = trimmed.match(/[?&]pa=([^&]+)/);
      if (paMatch) result.upiId = decodeURIComponent(paMatch[1]);
      const pnMatch = trimmed.match(/[?&]pn=([^&]+)/);
      if (pnMatch) result.name = decodeURIComponent(pnMatch[1]);
    }
  } else if (trimmed.includes('@')) {
    result.upiId = trimmed;
    result.name = trimmed.split('@')[0].toUpperCase();
  } else if (/^\d{9,18}$/.test(trimmed)) {
    result.accountNumber = trimmed;
  }

  return result;
}
