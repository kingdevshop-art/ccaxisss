export type LanguageCode =
  | 'en'
  | 'hi'
  | 'bn'
  | 'te'
  | 'mr'
  | 'ta'
  | 'gu'
  | 'kn'
  | 'pa'
  | 'bho';

export interface LanguageOption {
  code: LanguageCode;
  label: string;
  nativeLabel: string;
  flag: string;
}

export interface UserServices {
  upiEnabled: boolean;
  upiLiteEnabled: boolean;
  walletEnabled: boolean;
  soundboxEnabled: boolean;
  biometricsEnabled: boolean;
  termDepositEnabled: boolean;
  kccLoanEnabled: boolean;
  businessLoanEnabled?: boolean;
  internationalTxEnabled: boolean;
  smsAlertsEnabled: boolean;
}

export type UpiHandleDomain = '@okaxis' | '@axissbs' | '@axisbank';

export type VirtualDebitCardVariant =
  | 'BURGUNDY_PRESTIGE'
  | 'TITANIUM_REWARDS'
  | 'MAGNUS_METAL'
  | 'NEO_SHOPPING';

export interface VirtualDebitCard {
  id: string;
  cardNumber: string; // 16 digits e.g. 4532 8901 2345 6789
  cardHolderName: string;
  expiryMonth: string; // MM
  expiryYear: string; // YY
  cvv: string; // 3 digits
  pin?: string; // 4-digit ATM/Card PIN
  variant: VirtualDebitCardVariant;
  variantName: string;
  network: 'VISA_INFINITE' | 'MASTERCARD_WORLD' | 'RUPAY_SELECT';
  status: 'ACTIVE' | 'FROZEN' | 'BLOCKED';
  dailyEcomLimit: number;
  maxDailyLimit: number;
  onlineTransactionsEnabled: boolean;
  internationalUsageEnabled: boolean;
  contactlessEnabled: boolean;
  atmWithdrawalEnabled: boolean;
  annualFee: number; // in INR
  feeScheduleText: string;
  benefits: string[];
  issuedAt: string;
}

export interface ProfileUpdateRequest {
  id: string;
  userId: string;
  userPhone: string;
  userName: string;
  type: 'PHONE' | 'EMAIL' | 'ADDRESS' | 'SERVICES' | 'LIMIT';
  title: string;
  details: string;
  requestedChanges: Record<string, any>;
  status: 'PENDING' | 'APPROVED' | 'REJECTED';
  submittedAt: string;
  reviewedAt?: string;
  reviewedBy?: string;
  rejectionReason?: string;
}

export interface UserProfile {
  id: string;
  name: string;
  phone: string;
  email: string;
  photoUrl?: string;
  dob?: string;
  address?: string;
  ckycNumber?: string;
  upiId: string;
  activeUpiHandle?: UpiHandleDomain;
  upiHandles?: string[];
  accountNumber: string;
  ifscCode: string;
  savingsBalance: number;
  walletBalance: number;
  upiLiteBalance: number;
  fixedDepositBalance: number;
  digitalGoldGrams: number;
  kycStatus: 'verified' | 'pending' | 'rejected';
  aadhaarNumber: string;
  panNumber: string;
  biometricEnabled: boolean;
  biometricLimit: number; // Max amount without UPI PIN
  soundboxVoiceAlerts: boolean;
  soundboxLanguage: LanguageCode;
  seniorMode: boolean;
  highContrast: boolean;
  branchName?: string;
  cifNumber?: string;
  netbankingLoginId?: string;
  netbankingPassword?: string;
  netbankingStatus?: 'ACTIVE' | 'LOCKED' | 'NOT_ISSUED';
  virtualCards?: VirtualDebitCard[];
  updateRequests?: ProfileUpdateRequest[];
  accountType?: 'SAVINGS' | 'CURRENT' | 'KCC_FARMER' | 'PENSION';
  accountStatus?: 'APPROVED' | 'PENDING_APPROVAL' | 'REJECTED';
  rejectionReason?: string;
  profilePhotoUpdatedAt?: string; // ISO date string of last profile photo update
  activeSessionToken?: string; // Single device active session token
  lastLoginAt?: string;
  isBlocked?: boolean;
  blockReason?: string;
  services?: UserServices;
  mpin?: string; // 4-digit security PIN
  liveLatitude?: number;
  liveLongitude?: number;
  liveAccuracy?: number;
  liveLocationAddress?: string;
  liveLocationUpdatedAt?: string;
  isOnline?: boolean;
  qrCodeDataUrl?: string;
  createdAt?: string;
}

export interface AdminAccount {
  id: string;
  username: string;
  fullName: string;
  role: 'SUPER_ADMIN' | 'BRANCH_MANAGER' | 'OFFICER';
  pinOrPassword: string;
  email?: string;
  branchName?: string;
  isActive: boolean;
  lastLoginAt?: string;
  createdAt?: string;
}

export type TransactionType = 'debit' | 'credit';

export type TransactionCategory =
  | 'groceries'
  | 'bills'
  | 'food'
  | 'travel'
  | 'shopping'
  | 'transfer'
  | 'recharge'
  | 'salary'
  | 'cashback'
  | 'invest'
  | 'savings';

export interface Transaction {
  id: string;
  userId?: string;
  userPhone?: string;
  title: string;
  subTitle: string;
  amount: number;
  type: TransactionType;
  category: TransactionCategory;
  timestamp: string;
  status: 'SUCCESS' | 'PENDING' | 'FAILED' | 'QUEUED_OFFLINE' | 'PENDING_APPROVAL' | 'PROCESSED' | 'HOLD' | 'REJECTED';
  paymentMode: 'UPI' | 'WALLET' | 'SAVINGS_AC' | 'UPI_LITE' | 'USSD_OFFLINE';
  upiRefId: string;
  recipientVpa?: string;
  senderVpa?: string;
  bankName?: string;
  fraudFlag?: 'CLEAN' | 'REVIEW' | 'SUSPICIOUS';
  beneficiaryName?: string;
  beneficiaryAccount?: string;
  recipientIfsc?: string;
  qrData?: string;
  scannerAddress?: string;
  transferType?: 'SAME_BANK' | 'OTHER_BANK' | 'UPI';
  approvalStatus?: 'APPROVED' | 'REJECTED' | 'AWAITING_ADMIN' | 'HOLD';
  approvalReason?: string;
  createdAt?: string | Date;
  smsDispatched?: boolean;
}

export interface Contact {
  id: string;
  name: string;
  phone: string;
  upiId: string;
  avatarBg: string;
  isRecent?: boolean;
}

export interface SavingsPot {
  id: string;
  title: string;
  name?: string;
  targetAmount: number;
  currentAmount: number;
  category: string;
  interestRate: number; // e.g. 7.5
  emoji: string;
}

export interface BudgetCategorySpend {
  category: TransactionCategory;
  name: string;
  budget: number;
  spent: number;
  color: string;
  iconName: string;
}

export interface KYCApplication {
  id: string;
  applicantName: string;
  phone: string;
  aadhaarNumber: string;
  panNumber: string;
  accountType: 'SAVINGS' | 'WALLET' | 'MERCHANT';
  status: 'PENDING_VERIFICATION' | 'APPROVED' | 'REJECTED';
  submittedAt: string;
  documentType: 'Aadhaar + PAN' | 'Voter ID' | 'Passport';
  riskScore: number; // 0 to 100
  initialDeposit: number;
}

export interface PushAlert {
  id: string;
  userId?: string;
  title: string;
  body: string;
  time: string;
  read: boolean;
  type: 'TRANSACTION' | 'SECURITY' | 'OFFER' | 'ADMIN_BROADCAST';
  amount?: number;
}

export interface OfflineQueuedTransfer {
  id: string;
  recipient: string;
  amount: number;
  mode: 'UPI_LITE' | 'USSD_99';
  timestamp: string;
  synced: boolean;
}

export interface LoanApplication {
  id: string;
  userId: string;
  loanType: 'BUSINESS_TERM_LOAN' | 'WORKING_CAPITAL' | 'MSME_UDYAM' | 'EQUIPMENT_MACHINERY';
  businessName: string;
  businessType: 'Proprietorship' | 'Partnership' | 'Pvt Ltd' | 'LLP';
  annualTurnover: number;
  gstin?: string;
  loanAmount: number;
  tenureMonths: number;
  interestRate: number;
  monthlyEmi: number;
  status: 'PRE_APPROVED' | 'IN_REVIEW' | 'SANCTIONED' | 'DISBURSED' | 'REJECTED';
  appliedAt: string;
  sanctionLetterUrl?: string;
}

