import { UserProfile, Transaction, Contact, SavingsPot, BudgetCategorySpend, KYCApplication, PushAlert, UserServices } from '../types';

export const DEFAULT_SERVICES: UserServices = {
  upiEnabled: true,
  upiLiteEnabled: true,
  walletEnabled: true,
  soundboxEnabled: true,
  biometricsEnabled: true,
  termDepositEnabled: true,
  kccLoanEnabled: false,
  businessLoanEnabled: true,
  internationalTxEnabled: false,
  smsAlertsEnabled: true,
};

// No demo or dummy accounts - clean banking database where real accounts are registered or created by admin
export const INITIAL_USER: UserProfile = {
  id: '',
  name: '',
  phone: '',
  email: '',
  upiId: '',
  activeUpiHandle: '@axisbank',
  upiHandles: [],
  accountNumber: '',
  ifscCode: 'UTIB000001',
  branchName: 'Axis Bank Corporate HO (Mumbai)',
  cifNumber: '',
  accountType: 'SAVINGS',
  savingsBalance: 0,
  walletBalance: 0,
  upiLiteBalance: 0,
  fixedDepositBalance: 0,
  digitalGoldGrams: 0,
  kycStatus: 'verified',
  aadhaarNumber: '',
  panNumber: '',
  biometricEnabled: false,
  biometricLimit: 5000,
  soundboxVoiceAlerts: true,
  soundboxLanguage: 'en',
  seniorMode: false,
  highContrast: false,
  isBlocked: false,
  services: { ...DEFAULT_SERVICES },
  mpin: '1234',
  virtualCards: [],
  updateRequests: [],
  createdAt: new Date().toISOString(),
};

export const AVAILABLE_ACCOUNTS: UserProfile[] = [];

export const INITIAL_TRANSACTIONS: Transaction[] = [];

export const INITIAL_CONTACTS: Contact[] = [];

export const INITIAL_SAVINGS_POTS: SavingsPot[] = [];

export const INITIAL_BUDGET_SPENDS: BudgetCategorySpend[] = [];

export const INITIAL_KYC_APPLICATIONS: KYCApplication[] = [];

export const INITIAL_PUSH_ALERTS: PushAlert[] = [];
