# Proguard Rules for WBSCB Corporate Banking Android App

# Keep JavaScript Interfaces
-keepclassmembers class * {
    @android.webkit.JavascriptInterface <methods>;
}

# Keep Biometric and AndroidX WebKit classes
-keep class androidx.biometric.** { *; }
-keep class androidx.webkit.** { *; }

# Preserve Native Activity bindings
-keep class in.wbscb.banking.MainActivity$AndroidBankingBridge { *; }
