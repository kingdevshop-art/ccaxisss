package in.wbscb.banking

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.media.AudioManager
import android.media.ToneGenerator
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.speech.tts.TextToSpeech
import android.view.View
import android.view.WindowManager
import android.webkit.CookieManager
import android.webkit.GeolocationPermissions
import android.webkit.JavascriptInterface
import android.webkit.PermissionRequest
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.ProgressBar
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import java.util.Locale
import java.util.concurrent.Executor

class MainActivity : AppCompatActivity(), TextToSpeech.OnInitListener {

    private lateinit var webView: WebView
    private lateinit var swipeRefresh: SwipeRefreshLayout
    private lateinit var progressBar: ProgressBar
    private var filePathCallback: ValueCallback<Array<Uri>>? = null

    // Native Multilingual Soundbox Engine
    private var textToSpeech: TextToSpeech? = null
    private var isTtsReady = false

    // Geolocation and Camera permission callbacks
    private var pendingGeolocationOrigin: String? = null
    private var pendingGeolocationCallback: GeolocationPermissions.Callback? = null
    private var pendingCameraPermissionRequest: PermissionRequest? = null
    private var pendingLocationCallbackJsFn: String? = null

    // Target App URL (Production Domain / Local Asset fallback)
    private val appUrl = "https://wbscb.in"
    private val localAssetUrl = "file:///android_asset/dist/index.html"

    // File Chooser Launcher for KYC Documents
    private val fileChooserLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (filePathCallback != null) {
            val results = WebChromeClient.FileChooserParams.parseResult(result.resultCode, result.data)
            filePathCallback?.onReceiveValue(results)
            filePathCallback = null
        }
    }

    // Dynamic Permission Launchers
    private val locationPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        val fineGranted = permissions[Manifest.permission.ACCESS_FINE_LOCATION] == true
        val coarseGranted = permissions[Manifest.permission.ACCESS_COARSE_LOCATION] == true
        val isGranted = fineGranted || coarseGranted

        // Handle WebView HTML5 geolocation prompt
        pendingGeolocationCallback?.invoke(pendingGeolocationOrigin, isGranted, false)
        pendingGeolocationCallback = null
        pendingGeolocationOrigin = null

        // Handle direct JavaScript Bridge GPS request
        val callback = pendingLocationCallbackJsFn
        if (callback != null) {
            pendingLocationCallbackJsFn = null
            if (isGranted) {
                fetchAndSendLocation(callback)
            } else {
                webView.evaluateJavascript("$callback(false, null, 'LOCATION_PERMISSION_DENIED')", null)
            }
        }
    }

    private val cameraPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        val request = pendingCameraPermissionRequest
        if (request != null) {
            if (isGranted) {
                request.grant(request.resources)
            } else {
                request.deny()
            }
            pendingCameraPermissionRequest = null
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Banking Security: Prevent screenshots and task previews containing sensitive passbook & balances
        try {
            window.setFlags(
                WindowManager.LayoutParams.FLAG_SECURE,
                WindowManager.LayoutParams.FLAG_SECURE
            )
        } catch (e: Exception) {
            e.printStackTrace()
        }

        setContentView(R.layout.activity_main)

        // Initialize Views
        webView = findViewById(R.id.bankingWebView)
        swipeRefresh = findViewById(R.id.swipeRefresh)
        progressBar = findViewById(R.id.progressBar)

        // Initialize Native Soundbox Text-to-Speech Engine
        textToSpeech = TextToSpeech(this, this)

        setupWebView()
        setupSwipeRefresh()
        setupBackNavigation()

        // Handle incoming intents (UPI scan or deep link)
        handleIntent(intent)

        // Load Application Entry Point
        loadBankingPortal()
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        handleIntent(intent)
    }

    private fun handleIntent(intent: Intent?) {
        val uri = intent?.data ?: return
        val urlString = uri.toString()

        Handler(Looper.getMainLooper()).postDelayed({
            val escapedUrl = urlString.replace("'", "\\'")
            webView.evaluateJavascript(
                "window.handleNativeDeepLink && window.handleNativeDeepLink('$escapedUrl'); " +
                "window.dispatchEvent(new CustomEvent('wbscb-deep-link', { detail: { url: '$escapedUrl' } }));",
                null
            )
        }, 1200)
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun setupWebView() {
        val settings: WebSettings = webView.settings
        settings.javaScriptEnabled = true
        settings.domStorageEnabled = true
        settings.databaseEnabled = true
        settings.allowFileAccess = true
        settings.allowContentAccess = true
        settings.useWideViewPort = true
        settings.loadWithOverviewMode = true
        settings.setSupportZoom(false)
        settings.builtInZoomControls = false
        settings.displayZoomControls = false
        settings.mediaPlaybackRequiresUserGesture = false

        // Geolocation for live branch locator & GPS radar
        settings.setGeolocationEnabled(true)

        // Cache Configuration for Offline Resilience
        settings.cacheMode = if (isNetworkAvailable()) {
            WebSettings.LOAD_DEFAULT
        } else {
            WebSettings.LOAD_CACHE_ELSE_NETWORK
        }

        // Cookie and Security Configuration
        val cookieManager = CookieManager.getInstance()
        cookieManager.setAcceptCookie(true)
        cookieManager.setAcceptThirdPartyCookies(webView, false)

        // Hardware Acceleration
        webView.setLayerType(View.LAYER_TYPE_HARDWARE, null)

        // Native JavaScript Bridge
        webView.addJavascriptInterface(AndroidBankingBridge(this), "AndroidBankingBridge")

        // WebViewClient to handle page navigation & external schemes
        webView.webViewClient = object : WebViewClient() {
            override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                super.onPageStarted(view, url, favicon)
                progressBar.visibility = View.VISIBLE
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                progressBar.visibility = View.GONE
                swipeRefresh.isRefreshing = false

                // Inform React frontend that native Android wrapper is active
                webView.evaluateJavascript(
                    "window.isNativeAndroidApp = true; " +
                    "window.nativeAppVersion = '2.5.0'; " +
                    "window.dispatchEvent(new CustomEvent('native-app-ready', { detail: { version: '2.5.0' } }));",
                    null
                )
            }

            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                val url = request?.url?.toString() ?: return false

                // Handle UPI Intent links (Google Pay, PhonePe, Paytm, BHIM, WhatsApp Pay)
                if (url.startsWith("upi://") || url.startsWith("wbscb://")) {
                    try {
                        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
                        startActivity(intent)
                        return true
                    } catch (e: Exception) {
                        Toast.makeText(this@MainActivity, "No supported UPI payment app installed", Toast.LENGTH_SHORT).show()
                        return true
                    }
                }

                // Handle Phone Dialing & SMS
                if (url.startsWith("tel:") || url.startsWith("sms:") || url.startsWith("mailto:")) {
                    try {
                        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
                        startActivity(intent)
                    } catch (e: Exception) {
                        e.printStackTrace()
                    }
                    return true
                }

                // Keep banking navigation inside WebView
                return false
            }

            override fun onReceivedError(view: WebView?, request: WebResourceRequest?, error: WebResourceError?) {
                super.onReceivedError(view, request, error)
                if (request?.isForMainFrame == true && !isNetworkAvailable()) {
                    // Try offline fallback bundle
                    webView.loadUrl(localAssetUrl)
                }
            }
        }

        // WebChromeClient for Progress, Camera Permissions & HTML5 Geolocation
        webView.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView?, newProgress: Int) {
                progressBar.progress = newProgress
                if (newProgress == 100) {
                    progressBar.visibility = View.GONE
                }
            }

            override fun onGeolocationPermissionsShowPrompt(
                origin: String?,
                callback: GeolocationPermissions.Callback?
            ) {
                val hasFine = ContextCompat.checkSelfPermission(
                    this@MainActivity,
                    Manifest.permission.ACCESS_FINE_LOCATION
                ) == PackageManager.PERMISSION_GRANTED
                val hasCoarse = ContextCompat.checkSelfPermission(
                    this@MainActivity,
                    Manifest.permission.ACCESS_COARSE_LOCATION
                ) == PackageManager.PERMISSION_GRANTED

                if (hasFine || hasCoarse) {
                    callback?.invoke(origin, true, false)
                } else {
                    pendingGeolocationOrigin = origin
                    pendingGeolocationCallback = callback
                    locationPermissionLauncher.launch(
                        arrayOf(
                            Manifest.permission.ACCESS_FINE_LOCATION,
                            Manifest.permission.ACCESS_COARSE_LOCATION
                        )
                    )
                }
            }

            override fun onPermissionRequest(request: PermissionRequest?) {
                if (request == null) return
                val resources = request.resources

                var cameraRequested = false
                for (res in resources) {
                    if (res == PermissionRequest.RESOURCE_VIDEO_CAPTURE) {
                        cameraRequested = true
                        break
                    }
                }

                if (cameraRequested) {
                    val hasCamera = ContextCompat.checkSelfPermission(
                        this@MainActivity,
                        Manifest.permission.CAMERA
                    ) == PackageManager.PERMISSION_GRANTED

                    if (hasCamera) {
                        request.grant(request.resources)
                    } else {
                        pendingCameraPermissionRequest = request
                        cameraPermissionLauncher.launch(Manifest.permission.CAMERA)
                    }
                } else {
                    request.grant(request.resources)
                }
            }

            override fun onShowFileChooser(
                webView: WebView?,
                filePathCallback: ValueCallback<Array<Uri>>?,
                fileChooserParams: FileChooserParams?
            ): Boolean {
                this@MainActivity.filePathCallback?.onReceiveValue(null)
                this@MainActivity.filePathCallback = filePathCallback

                val intent = fileChooserParams?.createIntent() ?: Intent(Intent.ACTION_GET_CONTENT).apply {
                    type = "*/*"
                    addCategory(Intent.CATEGORY_OPENABLE)
                }
                fileChooserLauncher.launch(intent)
                return true
            }
        }
    }

    private fun setupSwipeRefresh() {
        swipeRefresh.setColorSchemeColors(
            ContextCompat.getColor(this, R.color.brand_navy),
            ContextCompat.getColor(this, R.color.brand_gold)
        )
        swipeRefresh.setOnRefreshListener {
            webView.reload()
        }
    }

    private fun setupBackNavigation() {
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (webView.canGoBack()) {
                    webView.goBack()
                } else {
                    finish()
                }
            }
        })
    }

    private fun loadBankingPortal() {
        if (isNetworkAvailable()) {
            webView.loadUrl(appUrl)
        } else {
            webView.loadUrl(localAssetUrl)
        }
    }

    private fun isNetworkAvailable(): Boolean {
        val connectivityManager = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val network = connectivityManager.activeNetwork ?: return false
        val capabilities = connectivityManager.getNetworkCapabilities(network) ?: return false
        return capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            isTtsReady = true
            textToSpeech?.language = Locale("en", "IN")
        }
    }

    private fun playSoundboxChimeTone() {
        try {
            val toneGen = ToneGenerator(AudioManager.STREAM_NOTIFICATION, 100)
            toneGen.startTone(ToneGenerator.TONE_PROP_BEEP, 120)
            Handler(Looper.getMainLooper()).postDelayed({
                try {
                    toneGen.startTone(ToneGenerator.TONE_PROP_ACK, 160)
                    toneGen.release()
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }, 140)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun fetchAndSendLocation(callbackJsFn: String) {
        try {
            val locationManager = getSystemService(Context.LOCATION_SERVICE) as LocationManager
            val fineOk = ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
            val coarseOk = ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED

            if (!fineOk && !coarseOk) {
                webView.evaluateJavascript("$callbackJsFn(false, null, 'PERMISSION_DENIED')", null)
                return
            }

            var bestLocation: Location? = null
            if (fineOk && locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
                bestLocation = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER)
            }
            if (bestLocation == null && locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER)) {
                bestLocation = locationManager.getLastKnownLocation(LocationManager.NETWORK_PROVIDER)
            }

            if (bestLocation != null) {
                val lat = bestLocation.latitude
                val lng = bestLocation.longitude
                val acc = bestLocation.accuracy
                val jsonResult = "{\"latitude\": $lat, \"longitude\": $lng, \"accuracy\": $acc}"
                webView.evaluateJavascript("$callbackJsFn(true, $jsonResult, null)", null)
            } else {
                // Request single location update
                val provider = if (locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
                    LocationManager.GPS_PROVIDER
                } else {
                    LocationManager.NETWORK_PROVIDER
                }
                locationManager.requestSingleUpdate(provider, object : LocationListener {
                    override fun onLocationChanged(location: Location) {
                        val lat = location.latitude
                        val lng = location.longitude
                        val acc = location.accuracy
                        val jsonResult = "{\"latitude\": $lat, \"longitude\": $lng, \"accuracy\": $acc}"
                        runOnUiThread {
                            webView.evaluateJavascript("$callbackJsFn(true, $jsonResult, null)", null)
                        }
                    }
                    @Deprecated("Deprecated in Java")
                    override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}
                    override fun onProviderEnabled(provider: String) {}
                    override fun onProviderDisabled(provider: String) {}
                }, Looper.getMainLooper())
            }
        } catch (e: Exception) {
            webView.evaluateJavascript("$callbackJsFn(false, null, '${e.message ?: "LOCATION_ERROR"}')", null)
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        textToSpeech?.stop()
        textToSpeech?.shutdown()
        textToSpeech = null
    }

    /**
     * Native JavaScript Bridge for Biometrics, Haptics, Soundbox TTS, GPS & Sharing
     */
    inner class AndroidBankingBridge(private val context: Context) {

        @JavascriptInterface
        fun isNative(): Boolean = true

        @JavascriptInterface
        fun getVersion(): String = "2.5.0-production"

        @JavascriptInterface
        fun triggerHapticFeedback(pattern: String) {
            runOnUiThread {
                try {
                    val vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                        val vibratorManager = getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager
                        vibratorManager.defaultVibrator
                    } else {
                        @Suppress("DEPRECATION")
                        getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
                    }

                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                        when (pattern.lowercase()) {
                            "light" -> vibrator.vibrate(VibrationEffect.createOneShot(25, 80))
                            "medium" -> vibrator.vibrate(VibrationEffect.createOneShot(50, 160))
                            "heavy" -> vibrator.vibrate(VibrationEffect.createOneShot(80, VibrationEffect.DEFAULT_AMPLITUDE))
                            "success" -> {
                                val timings = longArrayOf(0, 40, 60, 50)
                                val amplitudes = intArrayOf(0, 120, 0, 200)
                                vibrator.vibrate(VibrationEffect.createWaveform(timings, amplitudes, -1))
                            }
                            "error" -> {
                                val timings = longArrayOf(0, 50, 40, 50, 40, 50)
                                val amplitudes = intArrayOf(0, 200, 0, 200, 0, 200)
                                vibrator.vibrate(VibrationEffect.createWaveform(timings, amplitudes, -1))
                            }
                            else -> vibrator.vibrate(VibrationEffect.createOneShot(45, VibrationEffect.DEFAULT_AMPLITUDE))
                        }
                    } else {
                        @Suppress("DEPRECATION")
                        vibrator.vibrate(50)
                    }
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }
        }

        @JavascriptInterface
        fun speakSoundbox(text: String, languageCode: String) {
            runOnUiThread {
                try {
                    playSoundboxChimeTone()

                    val targetLocale = when (languageCode.lowercase().trim()) {
                        "bn", "bn-in", "bn_in" -> Locale("bn", "IN")
                        "hi", "hi-in", "hi_in", "bho" -> Locale("hi", "IN")
                        "te", "te-in", "te_in" -> Locale("te", "IN")
                        "ta", "ta-in", "ta_in" -> Locale("ta", "IN")
                        "mr", "mr-in", "mr_in" -> Locale("mr", "IN")
                        "gu", "gu-in", "gu_in" -> Locale("gu", "IN")
                        "kn", "kn-in", "kn_in" -> Locale("kn", "IN")
                        "pa", "pa-in", "pa_in" -> Locale("pa", "IN")
                        else -> Locale("en", "IN")
                    }

                    if (isTtsReady && textToSpeech != null) {
                        val checkLang = textToSpeech?.setLanguage(targetLocale)
                        if (checkLang == TextToSpeech.LANG_MISSING_DATA || checkLang == TextToSpeech.LANG_NOT_SUPPORTED) {
                            textToSpeech?.language = Locale("en", "IN")
                        }
                        textToSpeech?.setSpeechRate(0.96f)
                        textToSpeech?.setPitch(1.02f)

                        Handler(Looper.getMainLooper()).postDelayed({
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                                textToSpeech?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "WBSCB_SOUNDBOX_TX")
                            } else {
                                @Suppress("DEPRECATION")
                                textToSpeech?.speak(text, TextToSpeech.QUEUE_FLUSH, null)
                            }
                        }, 240)
                    }
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }
        }

        @JavascriptInterface
        fun isGpsEnabled(): Boolean {
            val lm = getSystemService(Context.LOCATION_SERVICE) as? LocationManager ?: return false
            return lm.isProviderEnabled(LocationManager.GPS_PROVIDER) || lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER)
        }

        @JavascriptInterface
        fun getDeviceLocation(callbackJsFn: String) {
            runOnUiThread {
                val hasFine = ContextCompat.checkSelfPermission(this@MainActivity, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
                val hasCoarse = ContextCompat.checkSelfPermission(this@MainActivity, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED

                if (!hasFine && !hasCoarse) {
                    pendingLocationCallbackJsFn = callbackJsFn
                    locationPermissionLauncher.launch(
                        arrayOf(
                            Manifest.permission.ACCESS_FINE_LOCATION,
                            Manifest.permission.ACCESS_COARSE_LOCATION
                        )
                    )
                } else {
                    fetchAndSendLocation(callbackJsFn)
                }
            }
        }

        @JavascriptInterface
        fun setScreenSecurity(enabled: Boolean) {
            runOnUiThread {
                try {
                    if (enabled) {
                        window.setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE)
                    } else {
                        window.clearFlags(WindowManager.LayoutParams.FLAG_SECURE)
                    }
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }
        }

        @JavascriptInterface
        fun authenticateBiometric(title: String, subtitle: String, callbackJsFn: String) {
            runOnUiThread {
                val executor: Executor = ContextCompat.getMainExecutor(context)
                val biometricManager = BiometricManager.from(context)

                if (biometricManager.canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_STRONG) != BiometricManager.BIOMETRIC_SUCCESS) {
                    webView.evaluateJavascript("$callbackJsFn(false, 'BIOMETRIC_NOT_AVAILABLE')", null)
                    return@runOnUiThread
                }

                val promptInfo = BiometricPrompt.PromptInfo.Builder()
                    .setTitle(title)
                    .setSubtitle(subtitle)
                    .setNegativeButtonText("Use MPIN")
                    .setAllowedAuthenticators(BiometricManager.Authenticators.BIOMETRIC_STRONG)
                    .build()

                val biometricPrompt = BiometricPrompt(
                    this@MainActivity,
                    executor,
                    object : BiometricPrompt.AuthenticationCallback() {
                        override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                            super.onAuthenticationSucceeded(result)
                            webView.evaluateJavascript("$callbackJsFn(true, 'SUCCESS')", null)
                        }

                        override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                            super.onAuthenticationError(errorCode, errString)
                            webView.evaluateJavascript("$callbackJsFn(false, '$errString')", null)
                        }

                        override fun onAuthenticationFailed() {
                            super.onAuthenticationFailed()
                            webView.evaluateJavascript("$callbackJsFn(false, 'FAILED')", null)
                        }
                    }
                )

                biometricPrompt.authenticate(promptInfo)
            }
        }

        @JavascriptInterface
        fun shareReceipt(receiptText: String, title: String) {
            runOnUiThread {
                val sendIntent = Intent().apply {
                    action = Intent.ACTION_SEND
                    putExtra(Intent.EXTRA_TEXT, receiptText)
                    putExtra(Intent.EXTRA_TITLE, title)
                    type = "text/plain"
                }
                val shareIntent = Intent.createChooser(sendIntent, title)
                startActivity(shareIntent)
            }
        }
    }
}
