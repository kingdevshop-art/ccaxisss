# WBSCB Corporate Banking & Officer Administration Portal

Enterprise cooperative banking platform and branch officer management terminal for **West Bengal State Cooperative Bank Ltd. (WBSCB)**.

## Key Features

- **Corporate Customer Portal**:
  - Unified multi-account dashboard (Savings, Corporate Wallet, UPI Lite, Cooperative Term Deposits).
  - Real-time transaction alerts, SMS passbook updates, and audit trail.
  - Multi-channel payments: Bharat QR Scanner, Contact Transfers, Virtual Payment Address (VPA / UPI ID), Bank Account + IFSC, and Utility Bill Desk.
  - Biometric authentication & limit settings (WebAuthn / Android Fingerprint).
  - Soundbox voice payment announcements in 4 languages (English, Bengali, Hindi, Santali).
  - Senior Citizen Mode with high-contrast accessibility typography.
  - Offline Banking (*99# USSD and local UPI Lite transfer queue).

- **Branch Officer Administration Terminal**:
  - Full user directory management (view, filter, account freezing & reactivation with audit reasons).
  - Instant new customer onboarding and KYC application approval/rejection desk.
  - Cashier / Teller balance management (Direct Credit / Debit across balances with ledger reference tracking).
  - Granular service entitlements (UPI AutoPay, international remittance, micro-credit overdraft, biometric authorizations).
  - Real-time transaction radar with one-click financial reversal operations.
  - System-wide security broadcast dispatcher.

- **Mobile & Android Capabilities**:
  - **Progressive Web App (PWA)**: Auto-updating service worker with Workbox offline precaching, Web App Manifest, maskable Android icons, and in-app install prompt.
  - **Native Android App Source Code**: Kotlin-based Android Studio project in `/android` featuring hardware-accelerated WebView, AndroidX BiometricPrompt bridge, UPI intent delegation, and strict HTTPS security config.

## Quick Start (Development)

```bash
# Install dependencies
npm install

# Start development server (Port 3000)
npm run dev
```

## Production Build

```bash
# Compile web application and server bundle
npm run build

# Start production server
npm start
```

## Android App Build

Refer to [`ANDROID_BUILD_GUIDE.md`](./ANDROID_BUILD_GUIDE.md) for full instructions on building debug and release APKs via Gradle or Android Studio.

```bash
npm run build
cd android
./gradlew assembleRelease
```

## GitHub Synchronization

The repository is fully configured for continuous synchronization with your GitHub repository:

### Method 1: Via Google AI Studio UI (Instant)
1. In the upper-right corner of the **Google AI Studio** workspace, open the menu (or Settings &rarr; **Export to GitHub**).
2. Authorize your GitHub account when prompted.
3. Select your desired GitHub organization/account and choose an existing repository or create a new repository (e.g. `wbscb-banking`).
4. Click **Export / Sync** — Google AI Studio will push all files, commit history, and branches directly to your repository!

### Method 2: Via Git Remote Terminal Push
If you have a GitHub repository URL:

```bash
# Add your GitHub repository as remote origin
git remote add origin https://github.com/<your-username>/<your-repo-name>.git

# Push the main branch
git push -u origin main
```

Or run the automated helper script:
```bash
./scripts/sync-github.sh https://github.com/<your-username>/<your-repo-name>.git
```

